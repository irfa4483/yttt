<?php
require 'FLASH/config/database.php';
$stmt = $pdo->prepare('SELECT id, name, canonical_url, amp_url, title, banner_url, logo_url FROM projects WHERE id IN (9, 10, 11, 12, 13)');
$stmt->execute();
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
