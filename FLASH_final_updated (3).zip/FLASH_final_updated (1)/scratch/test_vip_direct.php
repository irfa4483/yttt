<?php
// scratch/test_vip_direct.php
session_start();
$_SESSION['user_id'] = 1; // Admin user
$_POST['keyword'] = 'slot gacor';

require_once __DIR__ . '/../FLASH/config/database.php';
require_once __DIR__ . '/../FLASH/includes/auth.php';

echo "1. Current User: " . current_user()['name'] . " (Role: " . current_user()['role'] . ")\n";
$quota = get_user_quota_info();
echo "2. Quota Plan: " . $quota['plan_name'] . " (Is VIP: " . ($quota['is_vip'] ? 'YES' : 'NO') . ")\n";

ob_start();
require __DIR__ . '/../FLASH/api/vip_keyword_research.php';
$json = ob_get_clean();
$data = json_decode($json, true);

echo "3. Keyword Research Engine:\n";
echo "   Seed: " . ($data['seed_keyword'] ?? '') . "\n";
echo "   Google Suggest Real-Time: " . count($data['real_google_keywords'] ?? []) . " keywords ditemukan langsung dari Google!\n";
if (!empty($data['real_google_keywords'])) {
    echo "   Contoh: " . implode(', ', array_slice($data['real_google_keywords'], 0, 4)) . "\n";
}
echo "   Recommended Titles: " . ($data['ai_analysis']['recommended_titles'][0] ?? '') . "\n";
echo "\nVIP Direct Test 100% SUCCESS!\n";
