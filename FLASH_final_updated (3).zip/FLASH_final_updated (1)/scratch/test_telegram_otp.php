<?php
// scratch/test_telegram_otp.php
require_once __DIR__ . '/../FLASH/config/database.php';

// Test generate
$email = 'test_marketer@example.com';
$tokenSync = bin2hex(random_bytes(12));
$otpCode = (string)random_int(100000, 999999);
$expiresAt = date('Y-m-d H:i:s', time() + 900);

$stmt = $pdo->prepare("INSERT INTO telegram_otps (email, otp_code, token_sync, is_verified, expires_at) VALUES (?, ?, ?, 0, ?)");
$stmt->execute([$email, $otpCode, $tokenSync, $expiresAt]);

echo "OTP Generated for {$email}: Code = {$otpCode}, Token = {$tokenSync}\n";

// Test verify
$stmtCheck = $pdo->prepare("SELECT * FROM telegram_otps WHERE token_sync = ? AND email = ?");
$stmtCheck->execute([$tokenSync, $email]);
$row = $stmtCheck->fetch();

if ($row && $row['otp_code'] === $otpCode) {
    echo "OTP Verification SUCCESS!\n";
    $pdo->prepare("UPDATE telegram_otps SET is_verified = 1 WHERE id = ?")->execute([$row['id']]);
} else {
    echo "OTP Verification FAILED!\n";
}

// Check table count
$count = $pdo->query("SELECT COUNT(*) FROM telegram_otps")->fetchColumn();
echo "Total records in telegram_otps: {$count}\n";
