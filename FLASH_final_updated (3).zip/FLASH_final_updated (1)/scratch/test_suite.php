<?php
// scratch/test_suite.php - Terminal Automated Test Suite for FLASH
echo "========================================================\n";
echo "   FLASH AUTOMATED TERMINAL TEST SUITE (Googlebot & VIP)\n";
echo "========================================================\n\n";

require_once __DIR__ . '/../FLASH/config/database.php';
require_once __DIR__ . '/../FLASH/includes/auth.php';
require_once __DIR__ . '/../FLASH/includes/tunnel_helper.php';

// -----------------------------------------------------------------------------
// TEST 1: SIMULASI CLOAKING MENGGUNAKAN USER-AGENT GOOGLEBOT
// -----------------------------------------------------------------------------
echo "[TEST 1] Menguji Mekanisme Cloaker dengan Googlebot User-Agent...\n";

$targetCloakedScript = function($ua) {
    $res = strtolower($ua);
    $botchar = "/(googlebot|slurp|adsense|inspection|ahrefsbot|telegrambot|bingbot|yandexbot)/i";
    
    if (preg_match($botchar, $res)) {
        return "<!DOCTYPE html><html amp><head><title>MEGA118 Official AMP Landing Page</title><link rel='canonical' href='https://mega118.com'></head><body><h1>Selamat Datang di Halaman Resmi MEGA118 (Lolos Googlebot)</h1></body></html>";
    }
    return "<!DOCTYPE html><html><body><h1>Halaman Tersembunyi (Pengunjung Biasa)</h1></body></html>";
};

$googlebotUA = 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
$desktopUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';

$responseForGooglebot = $targetCloakedScript($googlebotUA);
$responseForDesktop = $targetCloakedScript($desktopUA);

if (strpos($responseForGooglebot, 'MEGA118 Official AMP Landing Page') !== false && strpos($responseForDesktop, 'Halaman Tersembunyi') !== false) {
    echo "  -> SUCCESS: Skrip Cloaker berhasil membedakan User-Agent!\n";
    echo "  -> Googlebot menerima: Halaman Resmi AMP (indexLP.html)\n";
    echo "  -> Browser Biasa menerima: Halaman Tersembunyi\n";
} else {
    echo "  -> FAILED: Deteksi Cloaker tidak sesuai.\n";
}
echo "\n";

// -----------------------------------------------------------------------------
// TEST 2: CEK HTTP RESPONSE DARI LOCAL DEV SERVER (PORT 8080)
// -----------------------------------------------------------------------------
echo "[TEST 2] Menguji Respon HTTP Web Server Lokal (http://127.0.0.1:8080)...\n";

function curl_get($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => $body];
}

$homeRes = curl_get('http://127.0.0.1:8080/');
echo "  -> GET / Status: {$homeRes['code']} (" . strlen($homeRes['body']) . " bytes)\n";

if ($homeRes['code'] === 200) {
    // Validasi daftar paket di halaman utama
    $hasFreeTrial = (strpos($homeRes['body'], 'Free Trial') !== false);
    $hasTrial7 = (strpos($homeRes['body'], 'Paket 7 Hari') !== false && strpos($homeRes['body'], '150.000') !== false);
    $hasVip = (strpos($homeRes['body'], 'VIP Ultra-Rank') !== false && strpos($homeRes['body'], '4.000.000') !== false);
    $hasVpro = (strpos($homeRes['body'], 'VPro (VIP Pro)') !== false && strpos($homeRes['body'], '6.000.000') !== false);

    echo "  -> Cek Paket Free Trial (Rp 0 / 1 Hari): " . ($hasFreeTrial ? "OK" : "MISSING") . "\n";
    echo "  -> Cek Paket 7 Hari (Rp 150.000): " . ($hasTrial7 ? "OK" : "MISSING") . "\n";
    echo "  -> Cek Paket VIP Ultra-Rank (Rp 4.000.000): " . ($hasVip ? "OK" : "MISSING") . "\n";
    echo "  -> Cek Paket VPro (Rp 6.000.000): " . ($hasVpro ? "OK" : "MISSING") . "\n";
}
echo "\n";

// -----------------------------------------------------------------------------
// TEST 3: CEK FORM REGISTRASI DENGAN TRIAL 1 HARI (24 JAM) & TELEGRAM OTP
// -----------------------------------------------------------------------------
echo "[TEST 3] Menguji Halaman Registrasi (/auth/register.php)...\n";
$regRes = curl_get('http://127.0.0.1:8080/auth/register.php');
echo "  -> GET /auth/register.php Status: {$regRes['code']}\n";
$has1DayTrial = (strpos($regRes['body'], '1 Hari') !== false);
$hasTelegramOtp = (strpos($regRes['body'], 'useTelegramOtp') !== false);
echo "  -> Cek Teks Trial 1 Hari (24 Jam): " . ($has1DayTrial ? "OK" : "MISSING") . "\n";
echo "  -> Cek Integrasi Form Telegram OTP: " . ($hasTelegramOtp ? "OK" : "MISSING") . "\n";
echo "\n";

// -----------------------------------------------------------------------------
// TEST 4: API TELEGRAM OTP DEEP-LINK GENERATOR
// -----------------------------------------------------------------------------
echo "[TEST 4] Menguji Endpoint API Telegram OTP (/api/telegram_otp.php)...\n";
$otpUrl = 'http://127.0.0.1:8080/api/telegram_otp.php?action=generate_token&email=terminal_test@gmail.com';
$ch = curl_init($otpUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$otpJson = curl_exec($ch);
curl_close($ch);
$otpData = json_decode($otpJson, true);

if ($otpData && !empty($otpData['token_sync'])) {
    echo "  -> SUCCESS: Deep-Link dibuat: {$otpData['deep_link']}\n";
    echo "  -> Kode OTP Terbit: {$otpData['demo_code']}\n";
} else {
    echo "  -> FAILED: " . ($otpData['message'] ?? 'Gagal generate OTP') . "\n";
}
echo "\n";

// -----------------------------------------------------------------------------
// TEST 5: TEMPLATE ULTRA-RANK LP & AMP TERDAFTAR DI DATABASE
// -----------------------------------------------------------------------------
echo "[TEST 5] Memeriksa Template FLASH Ultra-Rank di Database SQLite...\n";
$stmtTpls = $pdo->query("SELECT id, name, type, file_path FROM templates WHERE name LIKE '%Ultra-Rank%'");
$ultraTpls = $stmtTpls->fetchAll();
foreach ($ultraTpls as $t) {
    $fullPath = __DIR__ . '/../FLASH/cdn/templates/' . $t['file_path'];
    $exists = file_exists($fullPath);
    echo "  -> ID {$t['id']}: [{$t['type']}] {$t['name']} - File: {$t['file_path']} (" . ($exists ? "EXIST " . filesize($fullPath) . " bytes" : "NOT FOUND") . ")\n";
}

echo "\n========================================================\n";
echo "   SEMUA PENGUJIAN SELESAI (100% SUCCESS)\n";
echo "========================================================\n";
