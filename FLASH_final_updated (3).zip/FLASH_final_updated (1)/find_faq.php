<?php
$html = file_get_contents('raw_template_input.html');
$lines = explode("\n", $html);
foreach ($lines as $i => $line) {
    if (strpos($line, 'Apa itu BENTO4D') !== false) {
        echo "Found at line " . ($i + 1) . "\n";
        for ($j = $i - 10; $j <= $i + 30; $j++) {
            if (isset($lines[$j])) {
                echo ($j + 1) . ": " . trim($lines[$j]) . "\n";
            }
        }
    }
}
