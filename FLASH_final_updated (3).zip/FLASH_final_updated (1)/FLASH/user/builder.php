<?php
// user/builder.php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/purify_seo.php';
require_login();

$user   = current_user();
$projId = intval($_GET['id'] ?? 0);

// ── Fetch project ────────────────────────────────────────
if ($user['role'] === 'admin') {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$projId]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ? AND user_id = ?");
    $stmt->execute([$projId, $user['id']]);
}
$project = $stmt->fetch();

if (!$project) {
    if ($user['role'] === 'admin') {
        $fb = $pdo->query("SELECT * FROM projects ORDER BY id DESC LIMIT 1");
    } else {
        $fb = $pdo->prepare("SELECT * FROM projects WHERE user_id = ? ORDER BY id DESC LIMIT 1");
        $fb->execute([$user['id']]);
    }
    $project = $fb->fetch();
}

if (!$project) {
    $ins = $pdo->prepare("INSERT INTO projects
        (user_id, name, slug, type, canonical_url, amp_url, banner_url, logo_url,
         title, meta_description, article_content, faq_json, reviews_json, status)
        VALUES (?, ?, ?, 'amp', '', '', '', '', '', '', '', '[]', '[]', 'draft')");
    $ins->execute([$user['id'], 'Project Baru', 'project-baru-' . rand(100,999)]);
    header('Location: /user/builder.php?id=' . $pdo->lastInsertId());
    exit;
}
$projId = $project['id'];

// Load base template if article_content is empty
$defaultHtml = $project['article_content'];
if (empty(trim($defaultHtml))) {
    $tid = intval($project['template_id'] ?? 1);
    $stmtTpl = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
    $stmtTpl->execute([$tid]);
    $tplFile = $stmtTpl->fetchColumn();
    
    // Fallback if template doesn't exist
    if (!$tplFile) {
        $stmtTpl->execute([1]);
        $tplFile = $stmtTpl->fetchColumn();
    }
    
    if ($tplFile) {
        $fullPath = __DIR__ . '/../cdn/templates/' . $tplFile;
        if (file_exists($fullPath)) {
            $defaultHtml = file_get_contents($fullPath);
        }
    }
}

// Pastikan HTML di editor 100% bersih dari tag template {{ ... }} aneh dan sinkron dengan field project saat ini
if (!empty($defaultHtml)) {
    $defaultHtml = sync_and_clean_project_html($defaultHtml, $project);
}

// ── Handle Save POST ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        set_flash('error', 'Token CSRF tidak valid.');
        header('Location: /user/builder.php?id=' . $projId); exit;
    }

    $fields = [
        'name'            => trim($_POST['name']            ?? $project['name']),
        'brand_name'      => trim($_POST['name']            ?? $project['name']),
        'type'            => in_array($_POST['type'] ?? '', ['amp', 'lp']) ? $_POST['type'] : ($project['type'] ?? 'amp'),
        'canonical_url'   => trim($_POST['canonical_url']   ?? ''),
        'amp_url'         => trim($_POST['amp_url']         ?? ''),
        'login_url'       => trim($_POST['login_url']       ?? ''),
        'register_url'    => trim($_POST['register_url']    ?? ''),
        'banner_url'      => trim($_POST['banner_url']      ?? ''),
        'banner_title'    => trim($_POST['banner_title']    ?? ''),
        'logo_url'        => trim($_POST['logo_url']        ?? ''),
        'logo_title'      => trim($_POST['logo_title']      ?? ''),
        'favicon_url'     => trim($_POST['favicon_url']     ?? ''),
        'gif_url'         => trim($_POST['gif_url']         ?? ''),
        'title'           => trim($_POST['title']           ?? ''),
        'meta_description'=> trim($_POST['meta_description']?? ''),
        'article_content' => trim($_POST['article_content'] ?? ''),
        'faq_json'        => trim($_POST['faq_json']        ?? '[]'),
        'reviews_json'    => trim($_POST['reviews_json']    ?? '[]'),
    ];

    // Sinkronkan perubahan URL, gambar, title, deskripsi, dan brand langsung ke dalam article_content (100% bebas kode {{ ... }})
    $fields['article_content'] = sync_and_clean_project_html($fields['article_content'], $fields, $project);

    $sql = "UPDATE projects SET name=?, brand_name=?, type=?, canonical_url=?, amp_url=?, login_url=?, register_url=?, banner_url=?, banner_title=?, logo_url=?, logo_title=?, favicon_url=?, gif_url=?,
            title=?, meta_description=?, article_content=?, faq_json=?, reviews_json=?,
            updated_at=CURRENT_TIMESTAMP WHERE id=?" . ($user['role'] !== 'admin' ? " AND user_id=?" : "");
    $params = array_values($fields);
    $params[] = $projId;
    if ($user['role'] !== 'admin') $params[] = $user['id'];
    $pdo->prepare($sql)->execute($params);

    set_flash('success', 'Tersimpan!');
    header('Location: /user/builder.php?id=' . $projId); exit;
}

$faqsData    = json_decode($project['faq_json']     ?: '[]', true) ?: [];
$reviewsData = json_decode($project['reviews_json'] ?: '[]', true) ?: [];
if ((empty($faqsData) && ($project['faq_json'] === null || $project['faq_json'] === '')) || (empty($reviewsData) && ($project['reviews_json'] === null || $project['reviews_json'] === ''))) {
    $extractedInit = extract_reviews_and_faqs_from_html($defaultHtml, $project['brand_name'] ?? $project['name']);
    if (empty($faqsData) && ($project['faq_json'] === null || $project['faq_json'] === '') && !empty($extractedInit['faqs'])) {
        $faqsData = $extractedInit['faqs'];
    }
    if (empty($reviewsData) && ($project['reviews_json'] === null || $project['reviews_json'] === '') && !empty($extractedInit['reviews'])) {
        $reviewsData = $extractedInit['reviews'];
    }
}

$pageTitle = 'Builder — ' . $project['name'];
require_once __DIR__ . '/../includes/header.php';
?>
<script>document.body.classList.add('bldr');</script>
<script>
window.BD = <?= json_encode([
    'projId'      => $project['id'],
    'name'        => $project['name'],
    'slug'        => $project['slug'],
    'type'        => $project['type']            ?? 'amp',
    'title'       => $project['title']           ?? '',
    'metaDesc'    => $project['meta_description']?? '',
    'canonical'   => $project['canonical_url']   ?? '',
    'ampUrl'      => $project['amp_url']         ?? '',
    'bannerUrl'   => $project['banner_url']      ?? '',
    'bannerTitle' => $project['banner_title']    ?? '',
    'logoUrl'     => $project['logo_url']        ?? '',
    'logoTitle'   => $project['logo_title']      ?? '',
    'faviconUrl'  => $project['favicon_url']     ?? '',
    'gifUrl'      => $project['gif_url']         ?? '',
    'loginUrl'    => !empty($project['login_url']) ? $project['login_url'] : ($project['canonical_url'] ?? ''),
    'registerUrl' => !empty($project['register_url']) ? $project['register_url'] : ($project['canonical_url'] ?? ''),
    'article'     => $defaultHtml,
    'faqs'        => $faqsData,
    'reviews'     => $reviewsData,
], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
</script>

<!-- CodeMirror 5 -->
<link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
<link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/htmlmixed/htmlmixed.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/xml/xml.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/css/css.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/javascript/javascript.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/edit/closetag.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/edit/closebrackets.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/edit/matchbrackets.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/search/search.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/search/searchcursor.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/fold/foldcode.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/fold/xml-fold.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/fold/foldgutter.min.js"></script>
<link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/fold/foldgutter.min.css">

<style>
/* ================================================================
   BUILDER FULL RESET
================================================================ */
body.bldr { overflow: hidden !important; height: 100vh !important; }
body.bldr > *:not(#bldr-root):not(.fixed):not([x-cloak]) { display: none !important; }

/* ================================================================
   ROOT WRAPPER
================================================================ */
#bldr-root {
    position: fixed; inset: 0;
    display: flex; flex-direction: column;
    background: #070e1c;
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    z-index: 900;
}

/* ================================================================
   TOPBAR
================================================================ */
#bldr-top {
    flex-shrink: 0; height: 48px;
    display: flex; align-items: center; gap: 8px;
    padding: 0 12px;
    background: #040a14;
    border-bottom: 1px solid #0f1f38;
}
.bldr-badge {
    padding: 3px 8px; border-radius: 5px; font-size: 10px; font-weight: 800;
    letter-spacing: .06em; text-transform: uppercase;
}
.bldr-badge-amber { background: #f59e0b18; color: #f59e0b; border: 1px solid #f59e0b25; }
.bldr-badge-blue { background: #3b82f618; color: #60a5fa; border: 1px solid #3b82f630; }
.bldr-proj-name {
    font-size: 13px; font-weight: 700; color: #e2e8f0;
    max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.bldr-slug {
    font-family: monospace; font-size: 10px; color: #334155;
    background: #090f1e; border: 1px solid #0f1f38; padding: 2px 7px; border-radius: 5px;
}
#bldr-top-spacer { flex: 1; }
.bldr-btn {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 5px 11px; border-radius: 7px; font-size: 11px; font-weight: 600;
    cursor: pointer; border: 1px solid #0f1f38; background: #090f1e; color: #94a3b8;
    text-decoration: none; transition: all .15s; white-space: nowrap;
}
.bldr-btn:hover { color: #e2e8f0; border-color: #1e3a5f; }
.bldr-btn-save {
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: #fff; border-color: transparent;
    box-shadow: 0 2px 10px #6366f130;
}
.bldr-btn-save:hover { box-shadow: 0 4px 16px #6366f150; }
.bldr-btn-pub {
    background: linear-gradient(135deg, #059669, #10b981);
    color: #fff; border-color: transparent;
    box-shadow: 0 2px 10px #10b98130;
}
.bldr-btn-pub:hover { box-shadow: 0 4px 16px #10b98150; }
.bldr-save-status { font-size: 10px; color: #10b981; display: flex; align-items: center; gap: 4px; }

/* ================================================================
   BODY: LEFT + RIGHT
================================================================ */
#bldr-body { flex: 1; display: flex; overflow: hidden; min-height: 0; }

/* ================================================================
   LEFT PANEL — EDITOR SIDEBAR
================================================================ */
#bldr-left {
    width: 400px; min-width: 280px; max-width: 480px;
    display: flex; flex-direction: column;
    background: #070e1c; border-right: 1px solid #0f1f38;
    overflow: hidden;
}

/* Tab nav */
#bldr-tabs {
    display: flex; gap: 1px; padding: 6px 6px 0;
    background: #040a14; border-bottom: 1px solid #0f1f38;
    overflow-x: auto; scrollbar-width: none; flex-shrink: 0;
}
#bldr-tabs::-webkit-scrollbar { display: none; }
.bldr-tab {
    padding: 5px 11px; border-radius: 7px 7px 0 0;
    font-size: 11px; font-weight: 600; color: #475569; cursor: pointer;
    border: none; background: transparent; white-space: nowrap;
    transition: color .15s; display: flex; align-items: center; gap: 5px;
}
.bldr-tab:hover { color: #94a3b8; }
.bldr-tab.on { color: #e2e8f0; background: #0b1628; border-bottom: 2px solid #6366f1; }

/* Panel scrollable area */
#bldr-panels { flex: 1; overflow-y: auto; padding: 14px; scrollbar-width: thin; scrollbar-color: #0f1f38 transparent; }
#bldr-panels::-webkit-scrollbar { width: 4px; }
#bldr-panels::-webkit-scrollbar-thumb { background: #0f1f38; border-radius: 4px; }
.bldr-panel { display: block; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 2px dashed #0f1f38; }
.bldr-panel:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }

/* Form atoms */
.bf-card { background: #090f1e; border: 1px solid #0f1f38; border-radius: 12px; padding: 14px; margin-bottom: 12px; }
.bf-title { font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: .07em; color: #4f46e5; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
.bf-label { display: block; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; color: #334155; margin-bottom: 4px; }
.bf-input {
    width: 100%; padding: 8px 11px; background: #040a14; border: 1px solid #0f1f38;
    border-radius: 9px; color: #e2e8f0; font-size: 12px; outline: none;
    transition: border-color .15s; font-family: inherit;
    box-sizing: border-box;
}
.bf-input:focus { border-color: #4f46e5; }
.bf-input.mono { font-family: 'JetBrains Mono', 'Fira Code', monospace; font-size: 11px; }
.bf-group { margin-bottom: 12px; }
.bf-group:last-child { margin-bottom: 0; }
.bf-hint { font-size: 10px; color: #334155; margin-top: 4px; line-height: 1.5; }

/* Char counter */
.bf-chars { text-align: right; font-size: 10px; font-weight: 600; margin-top: 3px; }
.bf-chars.ok   { color: #10b981; }
.bf-chars.warn { color: #f59e0b; }
.bf-chars.over { color: #ef4444; }
.bf-bar { height: 2px; background: #0f1f38; border-radius: 99px; margin-top: 4px; overflow: hidden; }
.bf-bar-fill { height: 100%; border-radius: 99px; transition: width .3s, background .3s; }

/* AI button */
.ai-btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 6px;
    padding: 7px 14px; border-radius: 8px; font-size: 11px; font-weight: 700;
    cursor: pointer; border: none; transition: all .15s; width: 100%;
    background: linear-gradient(135deg, #4f46e5, #7c3aed); color: #fff;
    box-shadow: 0 2px 8px #4f46e520;
}
.ai-btn:hover { box-shadow: 0 4px 14px #4f46e540; transform: translateY(-1px); }
.ai-btn:disabled { opacity: .55; cursor: not-allowed; transform: none; }
.ai-btn-amber { background: linear-gradient(135deg, #d97706, #f59e0b); color: #000; box-shadow: 0 2px 8px #f59e0b20; }
.ai-btn-amber:hover { box-shadow: 0 4px 14px #f59e0b40; }

/* SERP preview */
.serp-wrap { background: #fff; border-radius: 10px; padding: 14px; font-family: Arial, sans-serif; }
.serp-url { font-size: 11px; color: #3c4043; display: flex; align-items: center; gap: 5px; margin-bottom: 3px; }
.serp-title { font-size: 17px; color: #1558d6; line-height: 1.3; margin-bottom: 4px; cursor: pointer; }
.serp-title:hover { text-decoration: underline; }
.serp-desc { font-size: 12px; color: #4d5156; line-height: 1.5; }

/* Dynamic list items (FAQ/Review) */
.dyn-item {
    background: #040a14; border: 1px solid #0f1f38; border-radius: 10px;
    padding: 10px; margin-bottom: 8px; position: relative;
}
.dyn-rm {
    position: absolute; top: 8px; right: 8px;
    background: #0f1f38; border: none; color: #ef4444; border-radius: 5px;
    width: 20px; height: 20px; cursor: pointer; font-size: 10px;
    display: flex; align-items: center; justify-content: center;
}
.dyn-rm:hover { background: #2d1515; }
.dyn-inner { padding-right: 26px; }
.add-btn-dyn {
    display: flex; align-items: center; justify-content: center; gap: 5px;
    width: 100%; padding: 7px; border-radius: 8px; font-size: 11px; font-weight: 600;
    cursor: pointer; border: 1px dashed #0f1f38; background: transparent; color: #334155;
    transition: all .15s;
}
.add-btn-dyn:hover { border-color: #4f46e5; color: #6366f1; background: #4f46e508; }

/* CodeMirror theme override */
.cm-wrap-bldr { border-radius: 9px; overflow: hidden; border: 1px solid #0f1f38; }
.CodeMirror {
    height: 400px !important;
    font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace;
    font-size: 12px; line-height: 1.65;
    background: #04080f !important;
}
.CodeMirror-scroll { height: 400px !important; overflow: auto !important; }
.CodeMirror-gutters { background: #04080f !important; border-right: 1px solid #0f1f38 !important; }
.CodeMirror-linenumber { color: #334155 !important; }
.CodeMirror-cursor { border-left: 2px solid #6366f1 !important; }

/* ================================================================
   RIGHT PANEL — LIVE PREVIEW
================================================================ */
#bldr-right {
    flex: 1; display: flex; flex-direction: column;
    background: #050c18; overflow: hidden; min-width: 0;
}

/* Preview topbar */
#prev-bar {
    flex-shrink: 0; height: 44px;
    display: flex; align-items: center; gap: 8px; padding: 0 10px;
    background: #040a14; border-bottom: 1px solid #0f1f38;
}
.vp-group {
    display: flex; gap: 1px;
    background: #070e1c; border: 1px solid #0f1f38; border-radius: 7px; padding: 2px;
}
.vp-btn {
    padding: 3px 10px; border-radius: 5px; font-size: 11px; font-weight: 600;
    cursor: pointer; border: none; background: transparent; color: #334155;
    display: flex; align-items: center; gap: 4px; transition: all .15s;
}
.vp-btn:hover { color: #94a3b8; }
.vp-btn.on { background: #0f1f38; color: #e2e8f0; }
.prev-url {
    flex: 1; max-width: 340px; margin: 0 8px;
    padding: 3px 10px; background: #070e1c; border: 1px solid #0f1f38; border-radius: 6px;
    display: flex; align-items: center; gap: 5px; overflow: hidden;
    font-size: 10px; font-family: monospace; color: #334155;
}
.live-dot { width: 6px; height: 6px; border-radius: 50%; background: #10b981; flex-shrink: 0; animation: dotpulse 1.8s ease-in-out infinite; }
@keyframes dotpulse { 0%,100%{opacity:1} 50%{opacity:.4} }

/* Preview stage */
#prev-stage {
    flex: 1; display: flex; align-items: center; justify-content: center;
    overflow: hidden; padding: 16px; min-height: 0;
    background: #04080f;
    background-image:
        linear-gradient(#0f1f3815 1px, transparent 1px),
        linear-gradient(90deg, #0f1f3815 1px, transparent 1px);
    background-size: 24px 24px;
    position: relative;
}

/* Device frames */
.dev-shell {
    position: relative; background: #000;
    border: 1px solid #1e3a5f;
    box-shadow: 0 20px 80px #00000099;
    overflow: hidden; flex-shrink: 0;
    transition: all .3s cubic-bezier(.4,0,.2,1);
}
.dev-shell.desktop {
    width: 100%; height: 100%; border-radius: 8px;
    align-self: stretch;
}
.dev-shell.tablet {
    width: 768px; height: 100%; border-radius: 12px;
    border-width: 2px;
    align-self: stretch;
}
.dev-shell.mobile {
    width: 375px; height: 812px;
    border-radius: 36px; border-width: 8px; border-color: #1a2f52;
    box-shadow: 0 0 0 2px #040a14, 0 20px 80px #00000099;
    max-height: calc(100% - 0px);
}
/* Mobile inner notch bar */
.dev-shell.mobile::before {
    content: '';
    position: absolute; top: 0; left: 50%; transform: translateX(-50%);
    width: 80px; height: 22px; background: #1a2f52; border-radius: 0 0 14px 14px;
    z-index: 5;
}

/* iframe fills shell */
.dev-shell iframe {
    width: 100%; height: 100%; border: none; display: block;
    pointer-events: auto;
}

/* Responsive scale override: if mobile/tablet are bigger than container, scale down */
#prev-stage.scale-fit .dev-shell.mobile,
#prev-stage.scale-fit .dev-shell.tablet {
    transform-origin: center center;
}

/* Loading overlay */
#prev-loading {
    position: absolute; inset: 0;
    background: rgba(4,8,15,.8); backdrop-filter: blur(4px);
    display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;
    z-index: 20; pointer-events: none; opacity: 0; transition: opacity .2s;
}
#prev-loading.show { opacity: 1; }
.spin { width: 28px; height: 28px; border: 2px solid #0f1f38; border-top-color: #6366f1; border-radius: 50%; animation: spin .65s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ================================================================
   SEPARATOR / RESIZE HANDLE
================================================================ */
#bldr-sep {
    width: 4px; background: #0f1f38; cursor: col-resize; flex-shrink: 0;
    transition: background .15s;
}
#bldr-sep:hover, #bldr-sep.dragging { background: #4f46e5; }
</style>

<!-- ================================================================
     HTML STRUCTURE
================================================================ -->
<div id="bldr-root" x-data="builderApp(window.BD)">

    <!-- ── TOPBAR ─────────────────────────────────────────── -->
    <div id="bldr-top">
        <a href="/user/projects.php" class="bldr-btn">
            <i class="fa-solid fa-arrow-left" style="font-size:9px;"></i> Projects
        </a>
        <span class="bldr-badge" :class="type === 'amp' ? 'bldr-badge-amber' : 'bldr-badge-blue'">
            <i class="fa-solid" :class="type === 'amp' ? 'fa-bolt' : 'fa-globe'" style="font-size:9px;"></i>
            <span x-text="type === 'amp' ? 'GOOGLE AMP' : 'LANDING PAGE (LP)'"></span>
        </span>
        <span class="bldr-proj-name"><?= e($project['name']) ?></span>
        <span class="bldr-slug">/p.php?id=<?= $project['id'] ?></span>

        <div id="bldr-top-spacer"></div>

        <!-- save status -->
        <div class="bldr-save-status" x-show="savedMsg" x-transition>
            <i class="fa-solid fa-check-circle" style="font-size:11px;"></i>
            <span x-text="savedMsg" style="font-size:10px;"></span>
        </div>

        
        <!-- Clone LP/AMP Button -->
        <button type="button" @click="openCloneModal()" class="bldr-btn" style="background: linear-gradient(135deg, #0ea5e9, #0284c7); color: #fff; border-color: transparent;">
            <i class="fa-solid fa-cloud-arrow-down" style="font-size:10px;"></i>
            <span>Clone URL (LP / AMP)</span>
        </button>

        <!-- open in new tab -->
        <a href="/p.php?id=<?= $project['id'] ?>&preview=1" target="_blank" class="bldr-btn">
            <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:9px;"></i> Lihat
        </a>

        <!-- Salin Link Publik Purified -->
        <button type="button" @click="
            const pubUrl = window.location.origin + '/s/<?= e($project['slug']) ?>';
            navigator.clipboard.writeText(pubUrl);
            window.showToast ? window.showToast('success', 'Link Publik Purified berhasil disalin: ' + pubUrl) : alert('Link disalin: ' + pubUrl);
        " class="bldr-btn" style="background: rgba(16, 185, 129, 0.18); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.35);" title="Salin Link Publik Purified untuk dikirim ke orang lain">
            <i class="fa-solid fa-share-nodes" style="font-size:10px;"></i>
            <span>Salin Link Publik (Purified)</span>
        </button>

        <!-- Unduh ZIP Installer Mandiri -->
        <button type="button" @click="exportZipPackage()" class="bldr-btn" style="background: rgba(99, 102, 241, 0.18); color: #a5b4fc; border: 1px solid rgba(99, 102, 241, 0.35);" title="Simpan otomatis perubahan terakhir & Unduh Paket ZIP Standalone">
            <i class="fa-solid fa-file-zipper" style="font-size:10px;"></i>
            <span>Unduh ZIP</span>
        </button>

        <!-- publish toggle -->
        <form action="/user/projects.php" method="POST" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="toggle_publish">
            <input type="hidden" name="project_id" value="<?= $project['id'] ?>">
            <button type="submit" class="bldr-btn <?= $project['status'] === 'published' ? '' : 'bldr-btn-pub' ?>">
                <i class="fa-solid <?= $project['status'] === 'published' ? 'fa-globe-slash' : 'fa-rocket' ?>" style="font-size:10px;"></i>
                <?= $project['status'] === 'published' ? 'Unpublish' : 'Publish' ?>
            </button>
        </form>

        <!-- save -->
        <button @click="saveProject()" class="bldr-btn bldr-btn-save" :disabled="isSaving">
            <i class="fa-solid" :class="isSaving ? 'fa-spinner fa-spin' : 'fa-floppy-disk'" style="font-size:10px;"></i>
            <span x-text="isSaving ? 'Menyimpan...' : 'Simpan'"></span>
        </button>
    </div>

    <!-- ── BODY: LEFT + SEP + RIGHT ───────────────────────── -->
    <div id="bldr-body">

        <!-- ════════════════════════════════════════════════
             LEFT PANEL — EDITOR SIDEBAR
        ════════════════════════════════════════════════ -->
        <div id="bldr-left">

            <!-- Hidden save form -->
            <form id="saveForm" action="/user/builder.php?id=<?= $project['id'] ?>" method="POST" style="display:none;">
                <input type="hidden" name="csrf_token"       value="<?= csrf_token() ?>">
                <input type="hidden" name="name"             :value="name">
                <input type="hidden" name="type"             :value="type">
                <input type="hidden" name="canonical_url"    :value="canonical">
                <input type="hidden" name="amp_url"          :value="ampUrl">
                <input type="hidden" name="login_url"        :value="loginUrl">
                <input type="hidden" name="register_url"     :value="registerUrl">
                <input type="hidden" name="banner_url"       :value="bannerUrl">
                <input type="hidden" name="banner_title"     :value="bannerTitle">
                <input type="hidden" name="logo_url"         :value="logoUrl">
                <input type="hidden" name="logo_title"       :value="logoTitle">
                <input type="hidden" name="favicon_url"      :value="faviconUrl">
                <input type="hidden" name="gif_url"          :value="gifUrl">
                <input type="hidden" name="title"            :value="title">
                <input type="hidden" name="meta_description" :value="metaDesc">
                <input type="hidden" name="article_content"  :value="article">
                <input type="hidden" name="faq_json"         :value="JSON.stringify(faqs)">
                <input type="hidden" name="reviews_json"     :value="JSON.stringify(reviews)">
            </form>

            <!-- Scrollable panels -->
            <div id="bldr-panels">

                <!-- ▸▸ SEO TAB ───────────────────────────── -->
                <div class="bldr-panel on" id="pnl-seo">

                    <div class="bf-card">
                        <div class="bf-title"><i class="fa-solid fa-heading"></i>SEO Title</div>
                        <div class="bf-group">
                            <label class="bf-label">Judul halaman <code style="font-size:9px;opacity:.6;">&lt;title&gt;</code></label>
                            <input type="text" class="bf-input" x-model="title" @input="schedulePreview()"
                                   placeholder="Masukkan judul SEO..." maxlength="70">
                            <div class="bf-chars" :class="title.length > 70 ? 'over' : title.length > 60 ? 'warn' : 'ok'">
                                <span x-text="title.length"></span>/70
                            </div>
                            <div class="bf-bar">
                                <div class="bf-bar-fill"
                                     :style="'width:'+Math.min(100,(title.length/70)*100)+'%;background:'+(title.length>70?'#ef4444':title.length>60?'#f59e0b':'#10b981')"></div>
                            </div>
                        </div>

                        <div class="bf-group">
                            <label class="bf-label">Meta Description</label>
                            <textarea class="bf-input" x-model="metaDesc" @input="schedulePreview()"
                                      rows="3" placeholder="Deskripsi singkat halaman..." maxlength="170" style="resize:vertical;"></textarea>
                            <div class="bf-chars" :class="metaDesc.length > 170 ? 'over' : metaDesc.length > 155 ? 'warn' : 'ok'">
                                <span x-text="metaDesc.length"></span>/170
                            </div>
                            <div class="bf-bar">
                                <div class="bf-bar-fill"
                                     :style="'width:'+Math.min(100,(metaDesc.length/170)*100)+'%;background:'+(metaDesc.length>170?'#ef4444':metaDesc.length>155?'#f59e0b':'#10b981')"></div>
                            </div>
                        </div>

                        <button type="button" class="ai-btn" @click="aiTitleMeta()" :disabled="aiLoading.title">
                            <i class="fa-solid" :class="aiLoading.title ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'"></i>
                            <span x-text="aiLoading.title ? 'Generating...' : '✨ Generate dengan AI'"></span>
                        </button>
                    </div>

                    <!-- SERP Preview -->
                    <div class="bf-card">
                        <div class="bf-title"><i class="fa-brands fa-google"></i>Google SERP Preview</div>
                        <div class="serp-wrap">
                            <div class="serp-url">
                                <svg width="14" height="14" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                                <span x-text="canonical || 'https://domain-anda.com/'"></span>
                            </div>
                            <div class="serp-title" x-text="title || 'Judul SEO halaman Anda'"></div>
                            <div class="serp-desc" x-text="metaDesc || 'Meta description akan tampil di sini...'"></div>
                        </div>
                    </div>

                    <!-- Project name -->
                    <div class="bf-card">
                        <div class="bf-title"><i class="fa-solid fa-folder"></i>Nama Project & Brand</div>
                        <div class="bf-group" style="margin:0;">
                            <label class="bf-label">Nama Brand / Project (akan mengganti nama brand di template)</label>
                            <input type="text" class="bf-input" x-model="name" @input="schedulePreview()" placeholder="Contoh: BRAND77...">
                        </div>
                    </div>
                </div>

                <!-- ▸▸ URLs TAB ──────────────────────────── -->
                <div class="bldr-panel" id="pnl-urls">
                    <div class="bf-card">
                        <div class="bf-title"><i class="fa-solid fa-layer-group"></i>Format & URL Halaman</div>

                        <div class="bf-group">
                            <label class="bf-label">Tipe Format Halaman</label>
                            <select class="bf-input" x-model="type" @change="schedulePreview()">
                                <option value="amp">⚡ Google AMP (Kecepatan Maksimal & SEO Mobile)</option>
                                <option value="lp">🌐 Landing Page Standar (LP / HTML5)</option>
                            </select>
                            <p class="bf-hint" x-show="type === 'amp'">Halaman Google AMP dengan validasi kilat komponen AMP.</p>
                            <p class="bf-hint" x-show="type === 'lp'">Landing Page standar HTML5 dengan kebebasan script & CSS.</p>
                        </div>

                        <div class="bf-group">
                            <label class="bf-label">Canonical URL <code style="font-size:9px;opacity:.5;">rel="canonical"</code></label>
                            <input type="url" class="bf-input mono" x-model="canonical" @input="schedulePreview()"
                                   placeholder="https://domain-target.com/">
                            <p class="bf-hint">URL utama yang dijadikan referensi Google untuk indexing.</p>
                        </div>

                        
                        <div class="bf-group">
                            <label class="bf-label">Login URL (Link Masuk)</label>
                            <input type="url" class="bf-input mono" x-model="loginUrl" @input="schedulePreview()"
                                   placeholder="https://domain-target.com/login">
                            <p class="bf-hint">Mengganti semua tombol LOGIN / MASUK di template.</p>
                        </div>

                        <div class="bf-group">
                            <label class="bf-label">Register URL (Link Daftar)</label>
                            <input type="url" class="bf-input mono" x-model="registerUrl" @input="schedulePreview()"
                                   placeholder="https://domain-target.com/register">
                            <p class="bf-hint">Mengganti semua tombol DAFTAR / REGISTER di template.</p>
                        </div>

                        <div class="bf-group" style="margin:0;">
                            <label class="bf-label">AMP URL <code style="font-size:9px;opacity:.5;">rel="amphtml"</code></label>
                            <input type="url" class="bf-input mono" x-model="ampUrl" @input="schedulePreview()"
                                   placeholder="https://amp.domain.com/">
                            <p class="bf-hint">Versi AMP mobile halaman ini.</p>
                        </div>
                    </div>

                    <!-- Link output preview -->
                    <div class="bf-card">
                        <div class="bf-title"><i class="fa-solid fa-code"></i>HTML Output Preview</div>
                        <div style="background:#04080f;border:1px solid #0f1f38;border-radius:8px;padding:10px;font-family:monospace;font-size:10px;line-height:1.9;color:#334155;">
                            <span style="color:#10b981;">&lt;link</span>
                            <span style="color:#60a5fa;"> rel</span>=<span style="color:#a5f3fc;">"canonical"</span>
                            <span style="color:#60a5fa;"> href</span>=<span style="color:#a5f3fc;" x-text="'&quot;' + (canonical||'') + '&quot;'"></span>
                            <span style="color:#10b981;">&gt;</span><br>
                            <span style="color:#10b981;">&lt;link</span>
                            <span style="color:#60a5fa;"> rel</span>=<span style="color:#a5f3fc;">"amphtml"</span>
                            <span style="color:#60a5fa;"> href</span>=<span style="color:#a5f3fc;" x-text="'&quot;' + (ampUrl||'') + '&quot;'"></span>
                            <span style="color:#10b981;">&gt;</span>
                        </div>
                    </div>
                </div>

                <!-- ▸▸ MEDIA TAB ─────────────────────────── -->
                <div class="bldr-panel" id="pnl-media">
                    <div class="bf-card">
                        <div class="bf-title"><i class="fa-regular fa-image"></i>Banner, Logo & Icon</div>

                        <!-- Banner Section -->
                        <div class="bf-group">
                            <label class="bf-label">URL Banner Utama</label>
                            <input type="url" class="bf-input mono" x-model="bannerUrl" @input="schedulePreview()"
                                   placeholder="https://domain.com/banner.jpg">
                            <!-- Banner preview -->
                            <div x-show="bannerUrl" style="margin-top:8px;border-radius:8px;overflow:hidden;border:1px solid #0f1f38;background:#04080f;height:120px;">
                                <img :src="bannerUrl" style="width:100%;height:120px;object-fit:cover;"
                                     onerror="this.parentElement.style.display='none'" alt="banner">
                            </div>
                        </div>

                        <div class="bf-group">
                            <label class="bf-label">Titel / Alt Gambar Banner (SEO)</label>
                            <input type="text" class="bf-input" x-model="bannerTitle" @input="schedulePreview()"
                                   placeholder="Contoh: Promo Bonus New Member 100%">
                            <p class="bf-hint">Teks alt & title gambar banner untuk optimasi SEO pencarian gambar Google.</p>
                        </div>

                        <!-- Logo Section -->
                        <div class="bf-group">
                            <label class="bf-label">URL Logo Brand</label>
                            <input type="url" class="bf-input mono" x-model="logoUrl" @input="schedulePreview()"
                                   placeholder="https://domain.com/logo.png">
                            <div x-show="logoUrl" style="margin-top:8px;display:flex;align-items:center;gap:10px;">
                                <div style="width:44px;height:44px;border-radius:8px;overflow:hidden;border:1px solid #0f1f38;background:#04080f;flex-shrink:0;padding:4px;box-sizing:border-box;">
                                    <img :src="logoUrl" style="width:100%;height:100%;object-fit:contain;"
                                         onerror="this.parentElement.style.display='none'" alt="logo">
                                </div>
                                <span style="font-size:10px;color:#334155;">Logo preview</span>
                            </div>
                        </div>

                        <div class="bf-group">
                            <label class="bf-label">Titel / Alt Gambar Logo (SEO)</label>
                            <input type="text" class="bf-input" x-model="logoTitle" @input="schedulePreview()"
                                   placeholder="Contoh: Logo Resmi Brand">
                            <p class="bf-hint">Teks alt & title untuk gambar logo situs.</p>
                        </div>

                        <!-- Favicon / Icon Section -->
                        <div class="bf-group">
                            <label class="bf-label">URL Favicon / Icon Tab Browser (Opsional)</label>
                            <input type="url" class="bf-input mono" x-model="faviconUrl" @input="schedulePreview()"
                                   placeholder="https://domain.com/favicon.png">
                            <p class="bf-hint">Icon kecil di tab browser & shortcut icon. Jika dikosongkan, otomatis menggunakan URL Logo.</p>
                            <div x-show="faviconUrl" style="margin-top:8px;display:flex;align-items:center;gap:8px;">
                                <div style="width:28px;height:28px;border-radius:6px;overflow:hidden;border:1px solid #0f1f38;background:#04080f;flex-shrink:0;padding:3px;box-sizing:border-box;">
                                    <img :src="faviconUrl" style="width:100%;height:100%;object-fit:contain;"
                                         onerror="this.parentElement.style.display='none'" alt="favicon">
                                </div>
                                <span style="font-size:10px;color:#334155;">Favicon / Icon preview</span>
                            </div>
                        </div>

                        <!-- GIF Animasi Section -->
                        <div class="bf-group" style="margin:0;">
                            <label class="bf-label">URL Animasi GIF / Jackpot GIF (Opsional)</label>
                            <input type="url" class="bf-input mono" x-model="gifUrl" @input="schedulePreview()"
                                   placeholder="https://domain.com/animasi.gif">
                            <p class="bf-hint">Mengganti animasi GIF di template (Jackpot GIF, Banner GIF Bergerak, Top GIF). Jika dikosongkan, otomatis memakai banner atau default template.</p>
                            <div x-show="gifUrl" style="margin-top:8px;display:flex;align-items:center;gap:8px;">
                                <div style="height:40px;max-width:140px;border-radius:6px;overflow:hidden;border:1px solid #0f1f38;background:#04080f;flex-shrink:0;padding:2px;box-sizing:border-box;">
                                    <img :src="gifUrl" style="height:100%;width:auto;object-fit:contain;"
                                         onerror="this.parentElement.style.display='none'" alt="gif preview">
                                </div>
                                <span style="font-size:10px;color:#334155;">GIF preview</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ▸▸ HTML/ARTICLE TAB ──────────────────── -->
                <div class="bldr-panel" id="pnl-article">
                    <div class="bf-card">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                            <div class="bf-title" style="margin:0;"><i class="fa-solid fa-code"></i>HTML Editor</div>
                            <button type="button" class="ai-btn" @click="aiArticle()" :disabled="aiLoading.article"
                                    style="width:auto;padding:5px 10px;font-size:10px;">
                                <i class="fa-solid" :class="aiLoading.article ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'"></i>
                                <span x-text="aiLoading.article ? '...' : 'AI Generate'"></span>
                            </button>
                        </div>
                        <p class="bf-hint" style="margin-bottom:10px;">Edit HTML konten artikel. Perubahan langsung terlihat di preview kanan.</p>
                        <div class="cm-wrap-bldr">
                            <textarea id="cm-article"><?= htmlspecialchars($defaultHtml, ENT_NOQUOTES, 'UTF-8') ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- ▸▸ FAQ TAB ───────────────────────────── -->
                <div class="bldr-panel" id="pnl-faq">
                    <div class="bf-card">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                            <div class="bf-title" style="margin:0;"><i class="fa-solid fa-circle-question"></i>Daftar FAQ</div>
                            <span style="font-size:10px;color:#334155;" x-text="faqs.length + ' item'"></span>
                        </div>

                        <template x-for="(f, i) in faqs" :key="i">
                            <div class="dyn-item">
                                <button type="button" class="dyn-rm" @click="faqs.splice(i,1);schedulePreview();">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                                <div class="dyn-inner">
                                    <div class="bf-group">
                                        <label class="bf-label">Pertanyaan</label>
                                        <input type="text" class="bf-input" x-model="f.question" @input="schedulePreview()"
                                               placeholder="Masukkan pertanyaan...">
                                    </div>
                                    <div class="bf-group" style="margin:0;">
                                        <label class="bf-label">Jawaban</label>
                                        <textarea class="bf-input" x-model="f.answer" @input="schedulePreview()"
                                                  rows="2" placeholder="Jawaban..." style="resize:vertical;"></textarea>
                                    </div>
                                </div>
                            </div>
                        </template>

                        <button type="button" class="add-btn-dyn"
                                @click="faqs.push({question:'',answer:''});schedulePreview();">
                            <i class="fa-solid fa-plus"></i> Tambah FAQ
                        </button>
                    </div>
                </div>

                <!-- ▸▸ REVIEWS TAB ───────────────────────── -->
                <div class="bldr-panel" id="pnl-reviews">
                    <div class="bf-card">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                            <div class="bf-title" style="margin:0;"><i class="fa-solid fa-star"></i>Ulasan Pengguna</div>
                            <button type="button" class="ai-btn ai-btn-amber" @click="aiReviews()" :disabled="aiLoading.reviews"
                                    style="width:auto;padding:5px 10px;font-size:10px;">
                                <i class="fa-solid" :class="aiLoading.reviews ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'"></i>
                                <span x-text="aiLoading.reviews ? '...' : 'AI Generate'"></span>
                            </button>
                        </div>

                        <template x-for="(r, i) in reviews" :key="i">
                            <div class="dyn-item">
                                <button type="button" class="dyn-rm" @click="reviews.splice(i,1);schedulePreview();">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                                <div class="dyn-inner">
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;" class="bf-group">
                                        <div>
                                            <label class="bf-label">Nama</label>
                                            <input type="text" class="bf-input" x-model="r.name" @input="schedulePreview()" placeholder="Nama...">
                                        </div>
                                        <div>
                                            <label class="bf-label">Kota</label>
                                            <input type="text" class="bf-input" x-model="r.location" @input="schedulePreview()" placeholder="Jakarta...">
                                        </div>
                                    </div>
                                    <div class="bf-group" style="margin:0;">
                                        <label class="bf-label">Teks Ulasan</label>
                                        <textarea class="bf-input" x-model="r.text" @input="schedulePreview()"
                                                  rows="2" placeholder="Isi ulasan..." style="resize:vertical;"></textarea>
                                    </div>
                                </div>
                            </div>
                        </template>

                        <button type="button" class="add-btn-dyn"
                                @click="reviews.push({name:'',location:'',rating:'5',text:''});schedulePreview();">
                            <i class="fa-solid fa-plus"></i> Tambah Review
                        </button>
                    </div>
                </div>

                <!-- ▸▸ DEPLOY / SITEMAP / ROBOTS TAB ──── -->
                <div class="bldr-panel" id="pnl-deploy">
                    <!-- ⚡ Auto-Deploy via Shell Receiver (Otomatis Upload ke Hosting Domain) -->
                    <div class="bf-card" style="border: 1px solid rgba(16, 185, 129, 0.4); background: rgba(16, 185, 129, 0.05); margin-bottom: 14px;">
                        <div class="bf-title" style="color: #34d399; display: flex; align-items: center; justify-content: space-between;">
                            <span><i class="fa-solid fa-bolt-lightning text-emerald-400"></i> Auto-Deploy via Remote Shell</span>
                            <span style="font-size: 9px; padding: 2px 7px; border-radius: 6px; background: rgba(16,185,129,0.18); color: #6ee7b7; border: 1px solid rgba(16,185,129,0.35); font-weight:700;">1-Klik Online</span>
                        </div>
                        
                        <p style="font-size: 11px; color: #94a3b8; line-height: 1.5; margin-bottom: 12px;">
                            Otomatis unggah berkas <strong>index.html</strong> (atau index.php), <strong>sitemap.xml</strong> (disesuaikan dengan domain target), dan <strong>robots.txt</strong> langsung ke cPanel / hosting domain Anda tanpa perlu ekstrak ZIP manual.
                        </p>

                        <!-- Langkah 1: Unduh Shell -->
                        <div style="background: #06111f; border: 1px solid #142a4a; border-radius: 8px; padding: 10px; margin-bottom: 12px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 6px;">
                                <span style="font-size: 11px; font-weight: 700; color: #38bdf8;">
                                    <i class="fa-solid fa-circle-down"></i> Langkah 1: Unduh Berkas Shell Receiver
                                </span>
                                <a :href="'/api/download_receiver.php?project_id=' + projId + '&token=' + encodeURIComponent(deployKey)" 
                                   class="bldr-btn" style="background: rgba(14, 165, 233, 0.2); color: #38bdf8; border: 1px solid rgba(14, 165, 233, 0.4); padding: 4px 10px; font-size: 11px;">
                                    <i class="fa-solid fa-download"></i> Unduh receiver.php
                                </a>
                            </div>
                            <p style="font-size: 10px; color: #64748b; margin: 0; line-height: 1.4;">
                                Unggah berkas <code>receiver.php</code> ke direktori <code>public_html</code> domain Anda. Token keamanan sudah terpasang otomatis di dalamnya.
                            </p>
                        </div>

                        <!-- Langkah 2: Konfigurasi Endpoint & Eksekusi -->
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <div class="bf-field">
                                <label class="bf-label"><i class="fa-solid fa-globe text-brand-400"></i> URL Shell di Domain Target</label>
                                <input type="url" class="bf-input mono" x-model="deployReceiverUrl" 
                                       @change="if(deployReceiverUrl) testRemoteDeployConnection()"
                                       @paste="setTimeout(() => { if(deployReceiverUrl) testRemoteDeployConnection(); }, 180)"
                                       placeholder="https://domain-target.com/receiver.php"
                                       style="font-size: 11px; padding: 7px 10px;">
                            </div>

                            <div class="bf-field">
                                <label class="bf-label"><i class="fa-solid fa-key text-amber-400"></i> Deploy Key / Token Keamanan</label>
                                <input type="text" class="bf-input mono" x-model="deployKey" 
                                       placeholder="flash_secret_token..."
                                       style="font-size: 11px; padding: 7px 10px;">
                            </div>

                            <!-- Pilihan Target Penempatan: Halaman Utama vs Folder Path -->
                            <div class="bf-field">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 4px;">
                                    <label class="bf-label" style="margin:0;"><i class="fa-solid fa-folder-tree text-emerald-400"></i> Target Penempatan (Halaman Utama vs Folder Path)</label>
                                    <span style="font-size: 9px; color: #38bdf8;" x-show="deployDetectedPath">
                                        <i class="fa-solid fa-server"></i> <span x-text="deployDetectedPath"></span>
                                    </span>
                                </div>
                                
                                <div style="display: flex; gap: 8px; margin-bottom: 6px;">
                                    <label style="flex: 1; display: flex; align-items: center; gap: 6px; font-size: 11px; padding: 6px 10px; background: #061021; border: 1px solid #142a4a; border-radius: 8px; cursor: pointer;"
                                           :style="deployTargetMode === 'root' ? 'border-color: #10b981; color: #34d399;' : 'color: #94a3b8;'">
                                        <input type="radio" name="deploy_mode" value="root" x-model="deployTargetMode" style="accent-color: #10b981;">
                                        <span>🌐 Halaman Utama (/)</span>
                                    </label>
                                    <label style="flex: 1; display: flex; align-items: center; gap: 6px; font-size: 11px; padding: 6px 10px; background: #061021; border: 1px solid #142a4a; border-radius: 8px; cursor: pointer;"
                                           :style="deployTargetMode === 'folder' ? 'border-color: #38bdf8; color: #38bdf8;' : 'color: #94a3b8;'">
                                        <input type="radio" name="deploy_mode" value="folder" x-model="deployTargetMode" style="accent-color: #38bdf8;">
                                        <span>📁 Folder / Path Tertentu</span>
                                    </label>
                                </div>

                                <!-- Input Nama Folder jika memilih Folder Path -->
                                <div x-show="deployTargetMode === 'folder'" style="display:flex; flex-direction:column; gap:6px;">
                                    <div style="display:flex; gap:6px;">
                                        <input type="text" class="bf-input mono" x-model="deployTargetFolder" 
                                               placeholder="Ketik path folder baru, contoh: promo / amp / slot-gacor"
                                               style="font-size: 11px; padding: 6px 10px; flex: 1;">
                                        
                                        <!-- Dropdown folder terdeteksi jika ada -->
                                        <template x-if="deploySubfolders.length > 0">
                                            <select @change="if($event.target.value) deployTargetFolder = $event.target.value" 
                                                    class="bf-input" style="font-size: 10px; width: 140px; background: #070e1c;">
                                                <option value="">-- Pilih Folder --</option>
                                                <template x-for="f in deploySubfolders" :key="f">
                                                    <option :value="f" x-text="'/' + f"></option>
                                                </template>
                                            </select>
                                        </template>
                                    </div>

                                    <!-- Interactive Clickable Badges for Detected Folders -->
                                    <template x-if="deploySubfolders.length > 0">
                                        <div style="background: rgba(14,165,233,0.06); border: 1px solid rgba(14,165,233,0.2); border-radius: 8px; padding: 7px 10px;">
                                            <span style="font-size: 10px; color: #38bdf8; font-weight: 700; display: block; margin-bottom: 4px;">
                                                <i class="fa-solid fa-list-check"></i> List Folder Terdeteksi di Domain (Klik untuk pilih):
                                            </span>
                                            <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                                                <template x-for="f in deploySubfolders" :key="f">
                                                    <button type="button" @click="deployTargetFolder = f"
                                                            :style="deployTargetFolder === f ? 'background: #0284c7; color: #fff; border-color: #38bdf8;' : 'background: #06152b; color: #93c5fd; border-color: #1e3a5f;'"
                                                            style="padding: 3px 8px; border-radius: 6px; font-size: 10px; border: 1px solid; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                                                        <i class="fa-solid fa-folder"></i>
                                                        <span x-text="'/' + f"></span>
                                                    </button>
                                                </template>
                                            </div>
                                        </div>
                                    </template>

                                    <p style="font-size: 10px; color: #64748b; margin: 0;">
                                        URL Path yang akan naik: <strong class="text-sky-300" x-text="getLiveTargetUrl()"></strong>
                                    </p>
                                </div>
                            </div>

                            <div style="display: flex; flex-direction: column; gap: 4px; padding: 3px 0;">
                                <label style="display: flex; align-items: center; gap: 6px; font-size: 10px; color: #34d399; font-weight: 700; cursor: pointer;">
                                    <input type="checkbox" x-model="deployTebasIndex" style="accent-color: #10b981;">
                                    <span>🔥 Mode Tebas Index: Timpa & sinkronkan index.html dan index.php sekaligus</span>
                                </label>
                                <label style="display: flex; align-items: center; gap: 6px; font-size: 10px; color: #94a3b8; cursor: pointer;">
                                    <input type="checkbox" x-model="deploySelfDestruct" style="accent-color: #10b981;">
                                    <span>Hapus <code>receiver.php</code> otomatis setelah deploy selesai (Rekomendasi)</span>
                                </label>
                            </div>

                            <!-- Tombol Aksi -->
                            <div style="display: flex; gap: 6px; margin-top: 4px;">
                                <button type="button" @click="testRemoteDeployConnection()" :disabled="deployLoading"
                                        class="bldr-btn" style="flex: 1; background: rgba(100, 116, 139, 0.2); color: #cbd5e1; border: 1px solid #334155; font-size: 11px; justify-content: center; padding: 7px;">
                                    <i class="fa-solid fa-satellite-dish" :class="deployLoading ? 'fa-spin' : ''"></i> Tes Koneksi
                                </button>
                                <button type="button" @click="runRemoteDeploy()" :disabled="deployLoading"
                                        class="bldr-btn" style="flex: 2; background: linear-gradient(135deg, #10b981, #059669); color: #fff; border-color: transparent; font-weight: 700; font-size: 11px; justify-content: center; padding: 7px;">
                                    <i class="fa-solid fa-cloud-arrow-up" :class="deployLoading ? 'fa-bounce' : ''"></i>
                                    <span x-text="deployLoading ? 'Memproses Deploy...' : '🚀 Mulai Auto-Deploy'"></span>
                                </button>
                            </div>

                            <!-- Deploy Status Box -->
                            <template x-if="deployResult">
                                <div :style="deployResult.success ? 'background: rgba(16,185,129,0.12); border: 1px solid rgba(16,185,129,0.35); color: #34d399;' : 'background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.35); color: #f87171;'"
                                     style="border-radius: 8px; padding: 10px; font-size: 11px; margin-top: 6px;">
                                    <div style="font-weight: 700; display:flex; align-items:center; gap:6px; margin-bottom: 4px;">
                                        <i class="fa-solid" :class="deployResult.success ? 'fa-circle-check' : 'fa-circle-xmark'"></i>
                                        <span x-text="deployResult.message"></span>
                                    </div>
                                    <template x-if="deployResult.success && deployResult.target_domain">
                                        <div style="display:flex; flex-direction:column; gap:4px; margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.08); font-size: 10px;">
                                            <a :href="deployResult.site_url" target="_blank" style="color: #38bdf8; text-decoration: underline;">
                                                <i class="fa-solid fa-arrow-up-right-from-square"></i> Buka Website: <span x-text="deployResult.site_url"></span>
                                            </a>
                                            <a :href="deployResult.sitemap_url" target="_blank" style="color: #fbbf24; text-decoration: underline;">
                                                <i class="fa-solid fa-sitemap"></i> Periksa Sitemap Google: <span x-text="deployResult.sitemap_url"></span>
                                            </a>
                                            <a :href="deployResult.robots_url" target="_blank" style="color: #a78bfa; text-decoration: underline;">
                                                <i class="fa-solid fa-robot"></i> Periksa Robots.txt Googlebot: <span x-text="deployResult.robots_url"></span>
                                            </a>
                                        </div>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>

                    <div class="bf-card">
                        <div class="bf-title"><i class="fa-solid fa-cloud-arrow-up"></i>Deploy, Sitemap & Robots.txt</div>
                        
                        <div style="background: rgba(14, 165, 233, 0.08); border: 1px solid rgba(14, 165, 233, 0.25); border-radius: 9px; padding: 12px; margin-bottom: 14px;">
                            <div style="font-size: 11px; font-weight: 700; color: #38bdf8; margin-bottom: 4px; display:flex; align-items:center; gap:6px;">
                                <i class="fa-solid fa-file-zipper"></i> Paket Ekspor Standalone (Tinggal Upload)
                            </div>
                            <p style="font-size: 11px; color: #94a3b8; line-height: 1.5; margin: 0 0 10px 0;">
                                Download file ZIP yang sudah lengkap berisi <strong>index.html</strong>, <strong>sitemap.xml</strong>, <strong>robots.txt</strong>, dan <strong>.htaccess</strong>. Cukup ekstrak ke root hosting / cPanel (public_html) Anda dan website langsung online tanpa perlu database.
                            </p>
                            <button type="button" @click="exportZipPackage()" class="bldr-btn" style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; border-color: transparent; font-weight: 700; width: 100%; justify-content: center; padding: 8px;">
                                <i class="fa-solid fa-download"></i> Unduh ZIP Deploy (index.html + sitemap + robots)
                            </button>
                        </div>

                        <!-- Sitemap Preview Card -->
                        <div class="bf-group" style="margin-bottom: 14px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 4px;">
                                <label class="bf-label" style="margin:0;"><i class="fa-solid fa-sitemap text-amber-400"></i> sitemap.xml Otomatis</label>
                                <span style="font-size:9px; color:#10b981; font-weight:700;"><i class="fa-solid fa-circle-check"></i> Standard Google</span>
                            </div>
                            <div style="background:#04080f; border:1px solid #0f1f38; border-radius:8px; padding:10px; font-family:monospace; font-size:10px; color:#94a3b8; max-height:110px; overflow-y:auto; line-height:1.4;">
                                &lt;?xml version="1.0" encoding="UTF-8"?&gt;<br>
                                &lt;urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"&gt;<br>
                                &nbsp;&nbsp;&lt;url&gt;<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&lt;loc&gt;<span x-text="canonical ? canonical.replace(/\/+$/, '') + '/' : 'https://domain-anda.com/'" style="color:#38bdf8;"></span>&lt;/loc&gt;<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&lt;changefreq&gt;daily&lt;/changefreq&gt;<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&lt;priority&gt;1.0&lt;/priority&gt;<br>
                                &nbsp;&nbsp;&lt;/url&gt;<br>
                                <template x-if="ampUrl">
                                    <span>
                                        &nbsp;&nbsp;&lt;url&gt;<br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&lt;loc&gt;<span x-text="ampUrl" style="color:#f59e0b;"></span>&lt;/loc&gt;<br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&lt;changefreq&gt;daily&lt;/changefreq&gt;<br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&lt;priority&gt;0.9&lt;/priority&gt;<br>
                                        &nbsp;&nbsp;&lt;/url&gt;<br>
                                    </span>
                                </template>
                                &lt;/urlset&gt;
                            </div>
                            <p class="bf-hint">File sitemap ini dibuat otomatis dari URL Canonical & AMP di atas untuk disubmit ke Google Search Console.</p>
                        </div>

                        <!-- Robots.txt Preview Card -->
                        <div class="bf-group" style="margin:0;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 4px;">
                                <label class="bf-label" style="margin:0;"><i class="fa-solid fa-robot text-sky-400"></i> robots.txt Otomatis</label>
                                <span style="font-size:9px; color:#10b981; font-weight:700;"><i class="fa-solid fa-circle-check"></i> Standard Googlebot</span>
                            </div>
                            <div style="background:#04080f; border:1px solid #0f1f38; border-radius:8px; padding:10px; font-family:monospace; font-size:10px; color:#94a3b8; line-height:1.4;">
                                User-agent: *<br>
                                Allow: /<br><br>
                                Sitemap: <span x-text="(canonical ? canonical.replace(/\/+$/, '') : 'https://domain-anda.com') + '/sitemap.xml'" style="color:#38bdf8;"></span>
                            </div>
                            <p class="bf-hint">File robots.txt mengizinkan semua search engine merayapi halaman utama dan sitemap Anda.</p>
                        </div>
                    </div>

                    <!-- Destroy / Hapus Project Card -->
                    <div class="bf-card" style="border-color: rgba(239, 68, 68, 0.25); background: rgba(239, 68, 68, 0.03);">
                        <div class="bf-title" style="color: #ef4444;"><i class="fa-solid fa-triangle-exclamation"></i>Destroy / Hapus Project</div>
                        <p style="font-size: 11px; color: #94a3b8; line-height: 1.5; margin-bottom: 12px;">
                            Menghapus seluruh konfigurasi, aset yang di-klon, dan data halaman ini secara permanen dari server. Tindakan ini tidak dapat dibatalkan.
                        </p>
                        <form action="/user/projects.php" method="POST" onsubmit="return confirm('APAKAH ANDA YAKIN INGIN MENGHAPUS (DESTROY) PROJECT INI SECARA PERMANEN?');">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="action" value="delete_project">
                            <input type="hidden" name="project_id" value="<?= $project['id'] ?>">
                            <button type="submit" class="bldr-btn" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border-color: rgba(239, 68, 68, 0.3); font-weight: 700; width: 100%; justify-content: center; padding: 7px;">
                                <i class="fa-solid fa-trash-can"></i> Destroy / Hapus Project Ini
                            </button>
                        </form>
                    </div>
                </div>

            </div><!-- /bldr-panels -->
        </div><!-- /bldr-left -->

        <!-- Resize handle -->
        <div id="bldr-sep" id="bldr-sep"></div>

        <!-- ════════════════════════════════════════════════
             RIGHT PANEL — LIVE PREVIEW
        ════════════════════════════════════════════════ -->
        <div id="bldr-right">

            <!-- Preview topbar -->
            <div id="prev-bar">
                <!-- Viewport buttons -->
                <div class="vp-group">
                    <button class="vp-btn on" id="vpb-desktop" onclick="setVp('desktop')">
                        <i class="fa-solid fa-desktop" style="font-size:10px;"></i> Desktop
                    </button>
                    <button class="vp-btn" id="vpb-tablet" onclick="setVp('tablet')">
                        <i class="fa-solid fa-tablet-screen-button" style="font-size:10px;"></i> Tablet
                    </button>
                    <button class="vp-btn" id="vpb-mobile" onclick="setVp('mobile')">
                        <i class="fa-solid fa-mobile-screen-button" style="font-size:10px;"></i> Mobile
                    </button>
                </div>

                <!-- URL bar -->
                <div class="prev-url">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="#10b981"><path d="M12 1C5.9 1 1 5.9 1 12s4.9 11 11 11 11-4.9 11-11S18.1 1 12 1zm-1 16.5v-5H7l5-8.5v5h4l-5 8.5z"/></svg>
                    <span id="prev-url-text" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;">
                        localhost:8000 — <?= e($project['name']) ?>
                    </span>
                    <span id="prev-url-status"></span>
                </div>

                <div style="flex:1;"></div>

                <!-- Live badge -->
                <div style="display:flex;align-items:center;gap:5px;font-size:10px;font-weight:700;color:#10b981;">
                    <div class="live-dot"></div> LIVE
                </div>

                <!-- Refresh + open -->
                <button onclick="if(window._bldrApp)window._bldrApp.runPreview();"
                        style="background:#070e1c;border:1px solid #0f1f38;border-radius:6px;padding:4px 8px;cursor:pointer;color:#475569;font-size:11px;">
                    <i class="fa-solid fa-rotate-right"></i>
                </button>
                <a href="/p.php?id=<?= $project['id'] ?>&preview=1" target="_blank"
                   style="background:#070e1c;border:1px solid #0f1f38;border-radius:6px;padding:4px 8px;color:#475569;font-size:11px;display:flex;align-items:center;text-decoration:none;">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </a>
            </div>

            <!-- Stage -->
            <div id="prev-stage">
                <div class="dev-shell desktop" id="dev-shell">
                    <!-- Loading -->
                    <div id="prev-loading">
                        <div class="spin"></div>
                        <span style="font-size:11px;color:#334155;font-weight:600;">Memuat preview...</span>
                    </div>
                    <!-- THE IFRAME — sandboxed, no navigation -->
                    <iframe id="prev-iframe"
                            sandbox="allow-same-origin allow-scripts allow-forms"
                            referrerpolicy="no-referrer"
                            onload="iframeLoaded()"></iframe>
                </div>
            </div>

        </div><!-- /bldr-right -->
    </div><!-- /bldr-body -->

    <!-- ════════════════════════════════════════════════
         CLONE LP / AMP MODAL
    ════════════════════════════════════════════════ -->
    <div x-show="showCloneModal" x-cloak
         style="position:fixed;inset:0;background:rgba(4,8,15,0.85);backdrop-filter:blur(6px);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px;">
        <div @click.away="if(!isCloning && !isScanning) showCloneModal = false"
             style="background:#090f1e;border:1px solid #1e293b;border-radius:16px;max-width:580px;width:100%;max-height:92vh;display:flex;flex-direction:column;box-shadow:0 25px 50px -12px rgba(0,0,0,0.65);overflow:hidden;">
            
            <div style="padding:16px 22px;border-bottom:1px solid #0f1f38;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">
                <div style="display:flex;align-items:center;gap:10px;">
                    <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#0ea5e9,#6366f1);display:flex;align-items:center;justify-content:center;color:#fff;">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                    </div>
                    <div>
                        <h3 style="font-size:14px;font-weight:700;color:#f8fafc;margin:0;">AI Clone & Deteksi Otomatis LP / AMP</h3>
                        <p style="font-size:11px;color:#64748b;margin:0;">AI mendeteksi Title, Deskripsi, Canonical, AMP, Login, Regis, Gambar, Icon & GIF — semua bisa diubah.</p>
                    </div>
                </div>
                <button type="button" @click="showCloneModal = false" :disabled="isCloning || isScanning"
                        style="background:none;border:none;color:#64748b;cursor:pointer;font-size:16px;margin-left:auto;">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div style="padding:18px 22px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:12px;">
                <!-- Step 1: Target URL, Brand & Mode cURL Anti-Cloaking + AI Scan Button -->
                <div style="padding:12px;border-radius:10px;background:#040a14;border:1px solid #1e293b;">
                    <div style="display:grid;grid-template-columns:1.3fr 1fr;gap:10px;margin-bottom:8px;">
                        <div class="bf-group" style="margin:0;">
                            <label class="bf-label" style="color:#38bdf8;"><i class="fa-solid fa-globe"></i> URL Target LP / AMP</label>
                            <input type="url" class="bf-input mono" x-model="cloneUrlInput"
                                   @paste="setTimeout(() => { if(cloneUrlInput && !isScanning && !isCloning) scanTargetWithAi(); }, 180)"
                                   @change="if(cloneUrlInput && !cloneDetected && !isScanning && !isCloning) scanTargetWithAi()"
                                   placeholder="https://situs-target.com/"
                                   style="background:#070e1c;font-size:11px;padding:8px 10px;">
                        </div>
                        <div class="bf-group" style="margin:0;">
                            <label class="bf-label" style="color:#a5b4fc;"><i class="fa-solid fa-tag"></i> Nama Brand Baru</label>
                            <input type="text" class="bf-input" x-model="cloneBrandInput"
                                   placeholder="Contoh: MEGA118"
                                   style="background:#070e1c;font-size:11px;padding:8px 10px;">
                        </div>
                    </div>
                    <div class="bf-group" style="margin-bottom:10px;">
                        <label class="bf-label" style="color:#64748b;font-size:9px;"><i class="fa-solid fa-radar"></i> Mode cURL Deteksi Cloaking / Redirect & Paired LP/AMP</label>
                        <select class="bf-input" x-model="cloneSourceMode" style="background:#070e1c;font-size:11px;padding:6px 10px;">
                            <option value="auto">Auto Deteksi (Ikuti Redirect / Bypass Cloaking Mobile & Googlebot)</option>
                            <option value="lp">Paksa Ambil Versi LP (cURL Canonical / LP Tersembunyi)</option>
                            <option value="amp">Paksa Ambil Versi AMP (cURL amphtml / Google AMP)</option>
                        </select>
                    </div>
                    <button type="button" @click="scanTargetWithAi()" :disabled="isScanning || isCloning || !cloneUrlInput"
                            class="bldr-btn" style="width:100%;justify-content:center;padding:8px 12px;background:linear-gradient(135deg,#4f46e5,#0ea5e9);color:#fff;border:none;font-weight:700;font-size:11px;">
                        <i class="fa-solid" :class="isScanning ? 'fa-spinner fa-spin' : 'fa-magnifying-glass-chart'"></i>
                        <span x-text="isScanning ? 'AI & cURL Sedang Mendeteksi AMP/LP, Redirect & Aset...' : '🔍 Scan & Deteksi Otomatis (AMP/LP, Anti-Cloaking, Gambar, Link, Brand)'"></span>
                    </button>
                </div>

                <!-- Summary Bar Deteksi Format AMP vs LP, Redirect/Cloaking, & Brand Lama -->
                <div x-show="cloneDetected" style="padding:12px;border-radius:10px;background:#061021;border:1px solid #1e3a5f;display:flex;flex-direction:column;gap:8px;">
                    <div style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;">
                        <span style="font-size:10px;font-weight:800;padding:4px 9px;border-radius:6px;"
                              :style="cloneDetectedFormat === 'amp' ? 'background:rgba(245,158,11,0.18);color:#fbbf24;border:1px solid rgba(245,158,11,0.4);' : 'background:rgba(59,130,246,0.18);color:#60a5fa;border:1px solid rgba(59,130,246,0.4);'">
                            <i class="fa-solid" :class="cloneDetectedFormat === 'amp' ? 'fa-bolt' : 'fa-globe'"></i>
                            Format Terdeteksi: <span x-text="cloneDetectedFormat === 'amp' ? 'GOOGLE AMP' : 'LANDING PAGE (LP)'"></span>
                        </span>

                        <span style="font-size:10px;font-weight:700;padding:4px 9px;border-radius:6px;"
                              :style="cloneLpFound ? 'background:rgba(16,185,129,0.14);color:#34d399;border:1px solid rgba(16,185,129,0.35);' : 'background:rgba(100,116,139,0.15);color:#94a3b8;border:1px solid rgba(100,116,139,0.3);'">
                            LP: <span x-text="cloneLpFound ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                        </span>

                        <span style="font-size:10px;font-weight:700;padding:4px 9px;border-radius:6px;"
                              :style="cloneAmpFound ? 'background:rgba(245,158,11,0.14);color:#fbbf24;border:1px solid rgba(245,158,11,0.35);' : 'background:rgba(100,116,139,0.15);color:#94a3b8;border:1px solid rgba(100,116,139,0.3);'">
                            AMP: <span x-text="cloneAmpFound ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                        </span>
                    </div>

                    <!-- Switcher 1-Klik bila LP & AMP sama-sama terdeteksi -->
                    <div x-show="cloneLpFound && cloneAmpFound" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding-top:2px;">
                        <span style="font-size:10px;color:#94a3b8;">Pilih versi untuk di-clone:</span>
                        <button type="button" @click="switchCloneSource('lp')" :disabled="isScanning || isCloning"
                                style="padding:3px 9px;border-radius:5px;font-size:10px;font-weight:700;cursor:pointer;"
                                :style="cloneDetectedFormat === 'lp' ? 'background:#2563eb;color:#fff;border:none;' : 'background:#0b172e;color:#93c5fd;border:1px solid #1e3a5f;'">
                            🌐 Ambil Versi LP
                        </button>
                        <button type="button" @click="switchCloneSource('amp')" :disabled="isScanning || isCloning"
                                style="padding:3px 9px;border-radius:5px;font-size:10px;font-weight:700;cursor:pointer;"
                                :style="cloneDetectedFormat === 'amp' ? 'background:#d97706;color:#fff;border:none;' : 'background:#0b172e;color:#fcd34d;border:1px solid #1e3a5f;'">
                            ⚡ Ambil Versi AMP
                        </button>
                    </div>

                    <!-- Info Cloaking / Redirect Hops bila ditemukan -->
                    <div x-show="cloneCloakingNote || cloneRedirectTrace.length > 0"
                         style="padding:7px 9px;border-radius:6px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);font-size:10px;color:#fde68a;line-height:1.45;">
                        <div x-show="cloneCloakingNote"><i class="fa-solid fa-user-secret"></i> <span x-text="cloneCloakingNote"></span></div>
                        <template x-if="cloneRedirectTrace.length > 0">
                            <div>
                                <i class="fa-solid fa-route"></i> <strong>Redirect dilacak:</strong>
                                <template x-for="(hop, hi) in cloneRedirectTrace" :key="hi">
                                    <span x-text="' [' + hop.step + ': ' + hop.from + ' → ' + hop.to + ']'"></span>
                                </template>
                            </div>
                        </template>
                    </div>

                    <!-- Brand Lama yang Terdeteksi AI dan Akan Diganti Total -->
                    <div x-show="cloneOldBrands.length > 0" style="font-size:10px;color:#cbd5e1;line-height:1.45;">
                        <i class="fa-solid fa-wand-magic-sparkles text-indigo-400"></i>
                        <strong>Brand lama terdeteksi AI (diganti semua ke "<span x-text="cloneBrandInput || 'BRAND'"></span>"):</strong>
                        <span style="color:#38bdf8;font-family:monospace;" x-text="cloneOldBrands.join(', ')"></span>
                    </div>
                </div>

                <!-- Live AI Scanning & Detection Stepper Overlay -->
                <div x-show="isScanning || isCloning || cloneDetected" style="padding:14px;border-radius:10px;background:#030712;border:1px solid #1e3a5f;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
                        <span style="font-size:11px;font-weight:700;color:#38bdf8;display:flex;align-items:center;gap:6px;">
                            <i class="fa-solid" :class="(isScanning || isCloning) ? 'fa-microchip fa-spin' : 'fa-circle-check text-emerald-400'"></i>
                            <span x-text="cloneStepText"></span>
                        </span>
                        <span style="font-size:10px;font-weight:700;color:#10b981;" x-text="cloneStepPercent + '%'"></span>
                    </div>

                    <!-- Progress Bar -->
                    <div style="height:6px;width:100%;background:#0b1329;border-radius:3px;overflow:hidden;margin-bottom:10px;">
                        <div style="height:100%;background:linear-gradient(90deg,#0ea5e9,#6366f1,#10b981);transition:width .35s ease;"
                             :style="'width:' + cloneStepPercent + '%'"></div>
                    </div>

                    <!-- Process Checklist -->
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:10px;">
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 1 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 1 ? 'fa-check-circle' : (cloneStepNum === 1 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>1. cURL Anti-Cloaking & Format AMP/LP</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 2 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 2 ? 'fa-check-circle' : (cloneStepNum === 2 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>2. Mencari Title & Brand Sisa</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 3 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 3 ? 'fa-check-circle' : (cloneStepNum === 3 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>3. Mencari Meta Deskripsi</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 4 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 4 ? 'fa-check-circle' : (cloneStepNum === 4 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>4. Mencari Canonical & AMP Link</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 5 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 5 ? 'fa-check-circle' : (cloneStepNum === 5 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>5. Mencari Link Login & Regis</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 6 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 6 ? 'fa-check-circle' : (cloneStepNum === 6 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>6. Mencari Foto Banner & Logo</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 7 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 7 ? 'fa-check-circle' : (cloneStepNum === 7 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>7. Mencari Icon & Animasi GIF</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;" :style="cloneStepNum >= 8 ? 'color:#10b981;' : 'color:#475569;'">
                            <i class="fa-solid" :class="cloneStepNum > 8 ? 'fa-check-circle' : (cloneStepNum === 8 ? 'fa-spinner fa-spin' : 'fa-circle')"></i>
                            <span>8. Siap Diterapkan (Kode Bersih)</span>
                        </div>
                    </div>

                    <!-- Live Detection Log Output -->
                    <div x-show="cloneLogLines.length > 0" style="margin-top:10px;padding:8px 10px;border-radius:6px;background:#02050b;border:1px solid #0f1f38;font-family:monospace;font-size:10px;color:#94a3b8;max-height:115px;overflow-y:auto;line-height:1.6;">
                        <template x-for="(ln, idx) in cloneLogLines" :key="idx">
                            <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" :style="ln.indexOf('Tidak ada') !== -1 ? 'color:#f59e0b;' : 'color:#cbd5e1;'">
                                <span :style="ln.indexOf('Tidak ada') !== -1 ? 'color:#f59e0b;' : 'color:#10b981;'" x-text="ln.indexOf('Tidak ada') !== -1 ? '—' : '✓'"></span>
                                <span x-text="ln"></span>
                            </div>
                        </template>
                    </div>
                </div>

                <!-- Editable Detected Fields -->
                <div class="bf-group" style="margin:0;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <label class="bf-label" style="color:#94a3b8;">Judul Halaman (Title SEO) — Bisa Diubah</label>
                        <template x-if="cloneDetected">
                            <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.title ? 'color:#10b981;' : 'color:#f59e0b;'"
                                  x-text="cloneFieldFlags.title ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                        </template>
                    </div>
                    <input type="text" class="bf-input" x-model="cloneTitleInput"
                           :placeholder="cloneDetected && !cloneTitleInput ? 'Title tidak ditemukan di target (isi manual jika ingin pasang)' : 'Otomatis terdeteksi atau ketik manual...'"
                           style="background:#040a14;font-size:11px;padding:8px 10px;">
                </div>

                <div class="bf-group" style="margin:0;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <label class="bf-label" style="color:#94a3b8;">Deskripsi Halaman (Meta Description) — Bisa Diubah</label>
                        <template x-if="cloneDetected">
                            <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.description ? 'color:#10b981;' : 'color:#f59e0b;'"
                                  x-text="cloneFieldFlags.description ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                        </template>
                    </div>
                    <textarea class="bf-input" rows="2" x-model="cloneDescInput"
                              :placeholder="cloneDetected && !cloneDescInput ? 'Deskripsi tidak ditemukan di target (isi manual jika ingin pasang)' : 'Otomatis terdeteksi atau ketik manual...'"
                              style="background:#040a14;font-size:11px;padding:8px 10px;resize:vertical;"></textarea>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">LP Link (Canonical URL)</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.canonical ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.canonical ? '✓ Terdeteksi' : '✕ Tidak ada tag canonical'"></span>
                            </template>
                        </div>
                        <input type="url" class="bf-input mono" x-model="cloneCanInput"
                               :placeholder="cloneDetected && !cloneCanInput ? 'Tidak ada tag canonical (isi domain LP Anda)' : 'https://domain-lp-anda.com/'"
                               style="background:#040a14;font-size:11px;padding:8px 10px;">
                    </div>
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">LP AMP Link (amphtml)</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.amp ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.amp ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <input type="url" class="bf-input mono" x-model="cloneAmpInput"
                               :placeholder="cloneDetected && !cloneAmpInput ? 'Tidak ada AMP URL di target' : 'https://domain-lp-anda.com/amp'"
                               style="background:#040a14;font-size:11px;padding:8px 10px;">
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">Link Login</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.login ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.login ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <input type="url" class="bf-input mono" x-model="cloneLoginInput"
                               :placeholder="cloneDetected && !cloneLoginInput ? 'Link login tidak ditemukan di target' : 'https://mysite.com/login'"
                               style="background:#040a14;font-size:11px;padding:8px 10px;">
                    </div>
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">Link Regis / Daftar / Alternatif</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.register ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.register ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <input type="url" class="bf-input mono" x-model="cloneRegInput"
                               :placeholder="cloneDetected && !cloneRegInput ? 'Link daftar tidak ditemukan di target' : 'https://mysite.com/register'"
                               style="background:#040a14;font-size:11px;padding:8px 10px;">
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">Link Gambar Banner Utama</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.banner ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.banner ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <div style="display:flex;gap:6px;align-items:center;">
                            <input type="url" class="bf-input mono" x-model="cloneBannerInput"
                                   :placeholder="cloneDetected && !cloneBannerInput ? 'Tidak ada foto banner di target' : 'https://mysite.com/banner.jpg'"
                                   style="background:#040a14;font-size:11px;padding:8px 10px;flex:1;">
                            <template x-if="cloneBannerInput">
                                <img :src="cloneBannerInput" style="width:32px;height:32px;object-fit:cover;border-radius:6px;border:1px solid #1e293b;flex-shrink:0;" onerror="this.style.display='none'">
                            </template>
                        </div>
                    </div>
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">Link Gambar Logo</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.logo ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.logo ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <div style="display:flex;gap:6px;align-items:center;">
                            <input type="url" class="bf-input mono" x-model="cloneLogoInput"
                                   :placeholder="cloneDetected && !cloneLogoInput ? 'Tidak ada gambar logo di target' : 'https://mysite.com/logo.png'"
                                   style="background:#040a14;font-size:11px;padding:8px 10px;flex:1;">
                            <template x-if="cloneLogoInput">
                                <img :src="cloneLogoInput" style="width:32px;height:32px;object-fit:contain;background:#020617;border-radius:6px;border:1px solid #1e293b;flex-shrink:0;" onerror="this.style.display='none'">
                            </template>
                        </div>
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">Link Icon / Favicon</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.favicon ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.favicon ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <div style="display:flex;gap:6px;align-items:center;">
                            <input type="url" class="bf-input mono" x-model="cloneFaviconInput"
                                   :placeholder="cloneDetected && !cloneFaviconInput ? 'Tidak ada favicon di target' : 'https://mysite.com/favicon.png'"
                                   style="background:#040a14;font-size:11px;padding:8px 10px;flex:1;">
                            <template x-if="cloneFaviconInput">
                                <img :src="cloneFaviconInput" style="width:32px;height:32px;object-fit:contain;background:#020617;border-radius:6px;border:1px solid #1e293b;flex-shrink:0;" onerror="this.style.display='none'">
                            </template>
                        </div>
                    </div>
                    <div class="bf-group" style="margin:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <label class="bf-label" style="color:#94a3b8;">Link Animasi GIF (Jika Ada)</label>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;" :style="cloneFieldFlags.gif ? 'color:#10b981;' : 'color:#f59e0b;'"
                                      x-text="cloneFieldFlags.gif ? '✓ Terdeteksi' : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <div style="display:flex;gap:6px;align-items:center;">
                            <input type="url" class="bf-input mono" x-model="cloneGifInput"
                                   :placeholder="cloneDetected && !cloneGifInput ? 'Tidak ada animasi GIF di target' : 'https://mysite.com/animasi.gif'"
                                   style="background:#040a14;font-size:11px;padding:8px 10px;flex:1;">
                            <template x-if="cloneGifInput">
                                <img :src="cloneGifInput" style="width:32px;height:32px;object-fit:contain;background:#020617;border-radius:6px;border:1px solid #1e293b;flex-shrink:0;" onerror="this.style.display='none'">
                            </template>
                        </div>
                    </div>
                </div>

                <!-- Ulasan Pengguna (Reviews / Testimoni) — Deteksi Otomatis & Bisa Diubah -->
                <div style="background:#040a14;border:1px solid #0f1f38;border-radius:10px;padding:12px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:6px;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="font-size:10px;font-weight:800;color:#fbbf24;text-transform:uppercase;letter-spacing:0.6px;">
                                <i class="fa-solid fa-star"></i> Ulasan Pengguna (Testimoni) — Bisa Diubah
                            </span>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;padding:2px 7px;border-radius:4px;"
                                      :style="cloneFieldFlags.reviews ? 'background:rgba(16,185,129,0.12);color:#34d399;border:1px solid rgba(16,185,129,0.28);' : 'background:rgba(245,158,11,0.12);color:#fbbf24;border:1px solid rgba(245,158,11,0.25);'"
                                      x-text="cloneFieldFlags.reviews ? ('✓ Terdeteksi (' + cloneReviewsInput.length + ' ulasan)') : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <div style="display:flex;gap:6px;">
                            <template x-if="cloneReviewsInput.length > 0">
                                <button type="button" @click="cloneReviewsInput = []"
                                        style="font-size:10px;padding:4px 8px;border-radius:6px;background:rgba(239,68,68,0.12);color:#f87171;border:1px solid rgba(239,68,68,0.25);cursor:pointer;font-weight:700;">
                                    <i class="fa-solid fa-trash-can"></i> Kosongkan
                                </button>
                            </template>
                            <button type="button" @click="cloneReviewsInput.push({name:'Pengguna', location:'Jakarta', rating:5, text:'Pelayanan sangat cepat dan terpercaya di ' + (cloneBrandInput || 'sini') + '!'})"
                                    style="font-size:10px;padding:4px 10px;border-radius:6px;background:rgba(245,158,11,0.15);color:#fbbf24;border:1px solid rgba(245,158,11,0.3);cursor:pointer;font-weight:700;">
                                <i class="fa-solid fa-plus"></i> Tambah Ulasan
                            </button>
                        </div>
                    </div>

                    <template x-if="cloneReviewsInput.length === 0">
                        <div style="font-size:10px;color:#64748b;padding:8px 10px;background:#020617;border-radius:8px;border:1px dashed #1e293b;">
                            <i class="fa-solid fa-circle-info" style="color:#f59e0b;margin-right:4px;"></i>
                            <span x-text="cloneDetected ? 'Tidak ada ulasan pengguna di halaman target (otomatis tidak ditampilkan). Klik + Tambah Ulasan jika ingin menambahkan.' : 'Klik Scan & Deteksi AI untuk mendeteksi ulasan pengguna otomatis dari halaman target.'"></span>
                        </div>
                    </template>

                    <div x-show="cloneReviewsInput.length > 0" style="display:flex;flex-direction:column;gap:8px;max-height:190px;overflow-y:auto;padding-right:2px;">
                        <template x-for="(rev, rIdx) in cloneReviewsInput" :key="rIdx">
                            <div style="background:#07101f;border:1px solid #162642;border-radius:8px;padding:8px 10px;">
                                <div style="display:grid;grid-template-columns:1fr 1fr 78px 26px;gap:6px;margin-bottom:6px;align-items:center;">
                                    <input type="text" class="bf-input" x-model="rev.name" placeholder="Nama Pengulas"
                                           style="background:#040a14;font-size:11px;padding:5px 8px;">
                                    <input type="text" class="bf-input" x-model="rev.location" placeholder="Kota / Label"
                                           style="background:#040a14;font-size:11px;padding:5px 8px;">
                                    <select class="bf-select" x-model="rev.rating" style="background:#040a14;font-size:11px;padding:5px 6px;">
                                        <option value="5">5 ★</option>
                                        <option value="4">4 ★</option>
                                        <option value="3">3 ★</option>
                                        <option value="2">2 ★</option>
                                        <option value="1">1 ★</option>
                                    </select>
                                    <button type="button" @click="cloneReviewsInput.splice(rIdx, 1)"
                                            style="width:24px;height:24px;border-radius:6px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.25);color:#f87171;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:10px;"
                                            title="Hapus ulasan ini">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                                <textarea class="bf-textarea" rows="2" x-model="rev.text" placeholder="Isi ulasan pengguna..."
                                          style="background:#040a14;font-size:11px;padding:6px 8px;min-height:42px;"></textarea>
                            </div>
                        </template>
                    </div>
                </div>

                <!-- Detail-Detail / FAQ (<details>) — Deteksi Otomatis & Bisa Diubah -->
                <div style="background:#040a14;border:1px solid #0f1f38;border-radius:10px;padding:12px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:6px;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="font-size:10px;font-weight:800;color:#38bdf8;text-transform:uppercase;letter-spacing:0.6px;">
                                <i class="fa-solid fa-circle-question"></i> Detail-Detail / FAQ (&lt;details&gt;) — Bisa Diubah
                            </span>
                            <template x-if="cloneDetected">
                                <span style="font-size:9px;font-weight:700;padding:2px 7px;border-radius:4px;"
                                      :style="cloneFieldFlags.faqs ? 'background:rgba(16,185,129,0.12);color:#34d399;border:1px solid rgba(16,185,129,0.28);' : 'background:rgba(245,158,11,0.12);color:#fbbf24;border:1px solid rgba(245,158,11,0.25);'"
                                      x-text="cloneFieldFlags.faqs ? ('✓ Terdeteksi (' + cloneFaqsInput.length + ' detail)') : '✕ Tidak ada'"></span>
                            </template>
                        </div>
                        <div style="display:flex;gap:6px;">
                            <template x-if="cloneFaqsInput.length > 0">
                                <button type="button" @click="cloneFaqsInput = []"
                                        style="font-size:10px;padding:4px 8px;border-radius:6px;background:rgba(239,68,68,0.12);color:#f87171;border:1px solid rgba(239,68,68,0.25);cursor:pointer;font-weight:700;">
                                    <i class="fa-solid fa-trash-can"></i> Kosongkan
                                </button>
                            </template>
                            <button type="button" @click="cloneFaqsInput.push({question:'Judul Detail / Pertanyaan', answer:'Penjelasan lengkap mengenai ' + (cloneBrandInput || 'layanan resmi') + '.'})"
                                    style="font-size:10px;padding:4px 10px;border-radius:6px;background:rgba(56,189,248,0.15);color:#38bdf8;border:1px solid rgba(56,189,248,0.3);cursor:pointer;font-weight:700;">
                                <i class="fa-solid fa-plus"></i> Tambah Detail
                            </button>
                        </div>
                    </div>

                    <template x-if="cloneFaqsInput.length === 0">
                        <div style="font-size:10px;color:#64748b;padding:8px 10px;background:#020617;border-radius:8px;border:1px dashed #1e293b;">
                            <i class="fa-solid fa-circle-info" style="color:#38bdf8;margin-right:4px;"></i>
                            <span x-text="cloneDetected ? 'Tidak ada detail / FAQ di halaman target (otomatis tidak ditampilkan). Klik + Tambah Detail jika ingin menambahkan.' : 'Klik Scan & Deteksi AI untuk mendeteksi detail / FAQ otomatis dari halaman target.'"></span>
                        </div>
                    </template>

                    <div x-show="cloneFaqsInput.length > 0" style="display:flex;flex-direction:column;gap:8px;max-height:190px;overflow-y:auto;padding-right:2px;">
                        <template x-for="(faqItem, fIdx) in cloneFaqsInput" :key="fIdx">
                            <div style="background:#07101f;border:1px solid #162642;border-radius:8px;padding:8px 10px;">
                                <div style="display:flex;gap:6px;margin-bottom:6px;align-items:center;">
                                    <input type="text" class="bf-input" x-model="faqItem.question" placeholder="Judul Detail / Pertanyaan (<summary>)"
                                           style="background:#040a14;font-size:11px;padding:5px 8px;flex:1;">
                                    <button type="button" @click="cloneFaqsInput.splice(fIdx, 1)"
                                            style="width:24px;height:24px;border-radius:6px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.25);color:#f87171;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:10px;flex-shrink:0;"
                                            title="Hapus detail ini">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                                <textarea class="bf-textarea" rows="2" x-model="faqItem.answer" placeholder="Isi detail / jawaban..."
                                          style="background:#040a14;font-size:11px;padding:6px 8px;min-height:42px;"></textarea>
                            </div>
                        </template>
                    </div>
                </div>

                <!-- Toggle Google AI Auto-Generate & Template Save -->
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div style="padding:10px 12px;border-radius:10px;background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.25);display:flex;align-items:center;justify-content:space-between;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <i class="fa-solid fa-brain" style="color:#818cf8;font-size:14px;"></i>
                            <div>
                                <div style="font-size:11px;font-weight:700;color:#e0e7ff;">Google Gemini AI</div>
                                <div style="font-size:9px;color:#94a3b8;">Deteksi & Optimasi SEO</div>
                            </div>
                        </div>
                        <label style="position:relative;display:inline-block;width:36px;height:20px;margin:0;cursor:pointer;flex-shrink:0;">
                            <input type="checkbox" x-model="cloneUseAi" style="opacity:0;width:0;height:0;">
                            <span style="position:absolute;inset:0;background:#1e293b;border-radius:20px;transition:.3s;"
                                  :style="cloneUseAi ? 'background:#6366f1;' : ''">
                                <span style="position:absolute;height:14px;width:14px;left:3px;bottom:3px;background:white;border-radius:50%;transition:.3s;"
                                      :style="cloneUseAi ? 'transform:translateX(16px);' : ''"></span>
                            </span>
                        </label>
                    </div>

                    <div style="padding:10px 12px;border-radius:10px;background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);display:flex;align-items:center;justify-content:space-between;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <i class="fa-solid fa-cube" style="color:#34d399;font-size:14px;"></i>
                            <div>
                                <div style="font-size:11px;font-weight:700;color:#d1fae5;">Simpan ke Template</div>
                                <div style="font-size:9px;color:#94a3b8;">Masuk Galeri Template</div>
                            </div>
                        </div>
                        <label style="position:relative;display:inline-block;width:36px;height:20px;margin:0;cursor:pointer;flex-shrink:0;">
                            <input type="checkbox" x-model="cloneSaveAsTemplate" style="opacity:0;width:0;height:0;">
                            <span style="position:absolute;inset:0;background:#1e293b;border-radius:20px;transition:.3s;"
                                  :style="cloneSaveAsTemplate ? 'background:#10b981;' : ''">
                                <span style="position:absolute;height:14px;width:14px;left:3px;bottom:3px;background:white;border-radius:50%;transition:.3s;"
                                      :style="cloneSaveAsTemplate ? 'transform:translateX(16px);' : ''"></span>
                            </span>
                        </label>
                    </div>
                </div>

                <div x-show="cloneError" style="padding:10px;border-radius:8px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#ef4444;font-size:11px;" x-text="cloneError"></div>
            </div>

            <div style="padding:14px 22px;background:#040a14;border-top:1px solid #0f1f38;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-shrink:0;">
                <span style="font-size:10px;color:#64748b;">
                    <i class="fa-solid fa-shield-halved text-emerald-400"></i> Output 100% kode bersih tanpa tag aneh
                </span>
                <div style="display:flex;gap:10px;">
                    <button type="button" @click="showCloneModal = false" :disabled="isCloning || isScanning" class="bldr-btn">
                        Batal
                    </button>
                    <button type="button" @click="executeClone()" :disabled="isCloning || isScanning || !cloneUrlInput"
                            class="bldr-btn" style="background:linear-gradient(135deg,#10b981,#059669);color:#fff;border-color:transparent;font-weight:700;padding:8px 16px;">
                        <i class="fa-solid" :class="isCloning ? 'fa-spinner fa-spin' : 'fa-rocket'"></i>
                        <span x-text="isCloning ? 'Memproses & Menerapkan...' : 'Terapkan & Clone LP Sekarang'"></span>
                    </button>
                </div>
            </div>
        </div>
    </div>

</div><!-- /bldr-root -->

<script>
// ============================================================
//  VIEWPORT SWITCHING + SCALE FIT
// ============================================================
let _vp = 'desktop';
function setVp(mode) {
    _vp = mode;
    const shell  = document.getElementById('dev-shell');
    const stage  = document.getElementById('prev-stage');
    const btns   = document.querySelectorAll('.vp-btn');

    shell.className = 'dev-shell ' + mode;
    btns.forEach(b => b.classList.remove('on'));
    document.getElementById('vpb-' + mode).classList.add('on');

    // Scale fit for mobile/tablet so they always fit in the stage
    if (mode !== 'desktop') {
        scaleShell();
    } else {
        shell.style.transform = '';
        shell.style.transformOrigin = '';
        shell.style.alignSelf = 'stretch';
        stage.style.alignItems = 'stretch';
    }
}

function scaleShell() {
    const shell = document.getElementById('dev-shell');
    const stage = document.getElementById('prev-stage');
    if (_vp === 'desktop') return;

    const stageW = stage.clientWidth  - 32; // 16px padding each side
    const stageH = stage.clientHeight - 32;
    const shellW = _vp === 'mobile' ? 375 : 768;
    const shellH = _vp === 'mobile' ? 812 : shell.clientHeight || stageH;

    const scaleX = stageW / shellW;
    const scaleY = _vp === 'mobile' ? stageH / 812 : 1;
    const scale  = Math.min(scaleX, scaleY, 1); // never enlarge

    shell.style.transform       = `scale(${scale})`;
    shell.style.transformOrigin = 'top center';
    shell.style.alignSelf       = 'flex-start';
    stage.style.alignItems      = 'center';
}

window.addEventListener('resize', () => { if (_vp !== 'desktop') scaleShell(); });

// ============================================================
//  IFRAME LOAD
// ============================================================
function iframeLoaded() {
    const l = document.getElementById('prev-loading');
    l.classList.remove('show');
    document.getElementById('prev-url-status').innerHTML = '';
}
function showPreviewLoading() {
    const l = document.getElementById('prev-loading');
    l.classList.add('show');
    document.getElementById('prev-url-status').innerHTML =
        '<span style="font-size:9px;color:#f59e0b;display:flex;align-items:center;gap:2px;"><i class="fa-solid fa-circle-notch fa-spin"></i> updating</span>';
}

// ============================================================
//  RESIZE HANDLE
// ============================================================
(function() {
    const sep   = document.getElementById('bldr-sep');
    const left  = document.getElementById('bldr-left');
    let dragging = false, startX, startW;

    sep.addEventListener('mousedown', e => {
        dragging = true; startX = e.clientX; startW = left.offsetWidth;
        sep.classList.add('dragging');
        document.body.style.userSelect = 'none';
        document.body.style.cursor = 'col-resize';
    });
    document.addEventListener('mousemove', e => {
        if (!dragging) return;
        const newW = Math.max(280, Math.min(560, startW + (e.clientX - startX)));
        left.style.width = newW + 'px';
    });
    document.addEventListener('mouseup', () => {
        dragging = false;
        sep.classList.remove('dragging');
        document.body.style.userSelect = '';
        document.body.style.cursor = '';
        if (_vp !== 'desktop') scaleShell();
    });
})();

// ============================================================
//  CODEMIRROR INIT — runs after all scripts loaded
// ============================================================
let _cm = null;
function initCodeMirror() {
    const ta = document.getElementById('cm-article');
    if (!ta || window._cm) return;
    window._cm = _cm = CodeMirror.fromTextArea(ta, {
        mode: 'htmlmixed',
        theme: 'dracula',
        lineNumbers: true,
        lineWrapping: true,
        autoCloseTags: true,
        autoCloseBrackets: true,
        matchBrackets: true,
        foldGutter: true,
        gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
        indentUnit: 2, tabSize: 2, indentWithTabs: false,
        extraKeys: {
            'Ctrl-Space': 'autocomplete',
            'Ctrl-/': 'toggleComment',
            'Ctrl-F': 'findPersistent',
        }
    });
    // Sync CM changes → AlpineJS
    _cm.on('change', () => {
        if (window._bldrApp) {
            window._bldrApp.article = _cm.getValue();
            window._bldrApp.schedulePreview();
        }
    });
    _cm.refresh();
    console.log('[CM] Initialized, content length:', _cm.getValue().length);
}
// Call immediately (scripts already loaded at this point)
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCodeMirror);
} else {
    initCodeMirror();
}

// ============================================================
//  ALPINE APP
// ============================================================
function builderApp(d) {
    return {
        projId:          d.projId,
        name:            d.name,
        type:            d.type        || 'amp',
        title:           d.title,
        metaDesc:        d.metaDesc,
        canonical:       d.canonical,
        ampUrl:          d.ampUrl,
        bannerUrl:       d.bannerUrl,
        bannerTitle:     d.bannerTitle || '',
        logoUrl:         d.logoUrl,
        logoTitle:       d.logoTitle   || '',
        faviconUrl:      d.faviconUrl  || '',
        gifUrl:          d.gifUrl      || '',
        loginUrl:        d.loginUrl    || '',
        registerUrl:     d.registerUrl || '',
        showCloneModal:  false,
        isScanning:      false,
        isCloning:       false,
        cloneDetected:   false,
        cloneLogLines:   [],
        cloneSourceMode: 'auto',
        cloneDetectedFormat: '',
        cloneLpFound:    false,
        cloneLpUrl:      '',
        cloneAmpFound:   false,
        cloneAmpUrl:     '',
        cloneCloakingNote: '',
        cloneRedirectTrace: [],
        cloneOldBrands:  [],
        cloneFieldFlags: {},
        _lastScannedBrand: '',
        cloneUrlInput:   '',
        cloneBrandInput: d.name || '',
        cloneTitleInput: d.title || '',
        cloneDescInput:  d.metaDesc || '',
        cloneLoginInput: '',
        cloneRegInput:   '',
        cloneCanInput:   d.canonical || '',
        cloneAmpInput:   d.ampUrl || '',
        cloneBannerInput:  d.bannerUrl || '',
        cloneLogoInput:    d.logoUrl || '',
        cloneFaviconInput: d.faviconUrl || '',
        cloneGifInput:     d.gifUrl || '',
        cloneReviewsInput: [],
        cloneFaqsInput:    [],
        cloneUseAi:        true,
        cloneSaveAsTemplate: false,
        cloneError:      '',
        cloneStepNum:    0,
        cloneStepText:   '',
        cloneStepPercent: 0,
        _stepInterval:   null,
        _prev: {
            name: d.name || '',
            title: d.title || '',
            metaDesc: d.metaDesc || '',
            canonical: d.canonical || '',
            ampUrl: d.ampUrl || '',
            loginUrl: d.loginUrl || '',
            registerUrl: d.registerUrl || '',
            bannerUrl: d.bannerUrl || '',
            logoUrl: d.logoUrl || '',
            faviconUrl: d.faviconUrl || '',
            gifUrl: d.gifUrl || ''
        },
        article:     d.article,
        faqs:        d.faqs    || [],
        reviews:     d.reviews || [],
        isSaving:    false,
        savedMsg:    '',
        aiLoading:   { title: false, article: false, reviews: false },
        deployReceiverUrl: d.canonical ? (d.canonical.replace(/\/+$/, '') + '/receiver.php') : '',
        deployKey: 'flash_' + Math.random().toString(36).substring(2, 10),
        deployTebasIndex: true,
        deploySelfDestruct: true,
        deployTargetMode: 'root',
        deployTargetFolder: '',
        deployDetectedPath: '',
        deploySubfolders: [],
        deployLoading: false,
        deployResult: null,
        _timer:      null,
        _savedTimer: null,

        init() {
            window._bldrApp = this;
            // CM is already initialized by initCodeMirror() — just sync value if needed
            this.$nextTick(() => {
                if (window._cm) {
                    // CM content comes from textarea (PHP pre-filled), but sync to Alpine state
                    this.article = window._cm.getValue();
                } else {
                    // CM not yet ready (edge case): try again shortly
                    setTimeout(() => {
                        if (window._cm) {
                            this.article = window._cm.getValue();
                            window._cm.refresh();
                        }
                    }, 300);
                }
                // Trigger initial preview after a short delay
                setTimeout(() => this.runPreview(), 800);
            });
        },

        syncFieldsToHtml() {
            if (!this.article) return;
            let h = this.article;
            let changed = false;

            const replaceAllSafe = (str, search, replacement) => {
                if (!search || !replacement || search === replacement || search.length < 5) return str;
                if (str.indexOf(search) !== -1) {
                    changed = true;
                    return str.split(search).join(replacement);
                }
                return str;
            };

            h = replaceAllSafe(h, this._prev.faviconUrl, this.faviconUrl);
            h = replaceAllSafe(h, this._prev.logoUrl, this.logoUrl);
            h = replaceAllSafe(h, this._prev.gifUrl, this.gifUrl);
            h = replaceAllSafe(h, this._prev.bannerUrl, this.bannerUrl);
            h = replaceAllSafe(h, this._prev.loginUrl, this.loginUrl);
            h = replaceAllSafe(h, this._prev.registerUrl, this.registerUrl);
            h = replaceAllSafe(h, this._prev.ampUrl, this.ampUrl);

            if (this._prev.canonical && this.canonical && this._prev.canonical !== this.canonical && this._prev.canonical.length > 8) {
                const oldC = this._prev.canonical.replace(/\/+$/, '');
                const newC = this.canonical.replace(/\/+$/, '');
                if (oldC !== newC && h.indexOf(oldC) !== -1) {
                    changed = true;
                    h = h.replace(new RegExp(oldC.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(\\/[^\\s"\'<>]*)?', 'gi'), (m, path) => {
                        if (path && /\.(?:png|jpg|jpeg|gif|webp|svg|css|js|woff2?|ttf|ico)(\?.*)?$/i.test(path)) return m;
                        return newC + '/';
                    });
                }
            }

            if (this._prev.name && this.name && this._prev.name !== this.name && this._prev.name.trim().length >= 3) {
                const oldBrand = this._prev.name.trim();
                const newBrand = this.name.trim();
                const ignoreNames = ['project baru', 'brand', 'tes'];
                if (ignoreNames.indexOf(oldBrand.toLowerCase()) === -1) {
                    const esc = oldBrand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    const rx = new RegExp('\\b' + esc + '\\b', 'gi');
                    const parts = h.split(/(<[^>]+>)/);
                    let brandChanged = false;
                    for (let i = 0; i < parts.length; i++) {
                        if (parts[i].startsWith('<') && parts[i].endsWith('>')) {
                            if (/^<meta\b/i.test(parts[i]) || /alt=|title=|placeholder=|content=/i.test(parts[i])) {
                                const upd = parts[i].replace(/(alt|title|placeholder|aria-label|content)=(["'])(.*?)\2/gi, (m, a, q, v) => {
                                    if (/\.(?:png|jpg|jpeg|gif|webp|svg|css|js)$/i.test(v)) return m;
                                    return a + '=' + q + v.replace(rx, newBrand) + q;
                                });
                                if (upd !== parts[i]) { parts[i] = upd; brandChanged = true; }
                            }
                        } else {
                            const updText = parts[i].replace(rx, newBrand);
                            if (updText !== parts[i]) { parts[i] = updText; brandChanged = true; }
                        }
                    }
                    if (brandChanged) {
                        h = parts.join('');
                        changed = true;
                    }
                    if (Array.isArray(this.reviews)) {
                        this.reviews.forEach(rv => {
                            if (rv.name) rv.name = rv.name.replace(rx, newBrand);
                            if (rv.location) rv.location = rv.location.replace(rx, newBrand);
                            if (rv.text) rv.text = rv.text.replace(rx, newBrand);
                        });
                    }
                    if (Array.isArray(this.faqs)) {
                        this.faqs.forEach(fq => {
                            if (fq.question) fq.question = fq.question.replace(rx, newBrand);
                            if (fq.answer) fq.answer = fq.answer.replace(rx, newBrand);
                        });
                    }
                }
            }

            if (changed) {
                this.article = h;
                if (window._cm && window._cm.getValue() !== h) {
                    const cursor = window._cm.getCursor();
                    window._cm.setValue(h);
                    window._cm.setCursor(cursor);
                }
            }

            this._prev = {
                name: this.name || '',
                title: this.title || '',
                metaDesc: this.metaDesc || '',
                canonical: this.canonical || '',
                ampUrl: this.ampUrl || '',
                loginUrl: this.loginUrl || '',
                registerUrl: this.registerUrl || '',
                bannerUrl: this.bannerUrl || '',
                logoUrl: this.logoUrl || '',
                faviconUrl: this.faviconUrl || '',
                gifUrl: this.gifUrl || ''
            };
        },

        schedulePreview() {
            clearTimeout(this._timer);
            this._timer = setTimeout(() => {
                this.syncFieldsToHtml();
                this.runPreview();
            }, 650);
        },

        async runPreview() {
            const iframe = document.getElementById('prev-iframe');
            if (!iframe) return;
            showPreviewLoading();

            const fd = new FormData();
            fd.append('name',            this.name        || '');
            fd.append('brand_name',      this.name        || '');
            fd.append('type',            this.type        || 'amp');
            fd.append('title',           this.title       || '');
            fd.append('meta_description',this.metaDesc    || '');
            fd.append('canonical_url',   this.canonical   || '');
            fd.append('amp_url',         this.ampUrl      || '');
            fd.append('banner_url',      this.bannerUrl   || '');
            fd.append('banner_title',    this.bannerTitle || '');
            fd.append('logo_url',        this.logoUrl     || '');
            fd.append('logo_title',      this.logoTitle   || '');
            fd.append('favicon_url',     this.faviconUrl  || '');
            fd.append('gif_url',         this.gifUrl      || '');
            fd.append('login_url',       this.loginUrl    || '');
            fd.append('register_url',    this.registerUrl || '');
            fd.append('jackpot_gif',     this.gifUrl      || '');
            fd.append('banner_gif_url',  this.gifUrl      || '');
            fd.append('article_content', this.article     || '');
            fd.append('faq_json',        JSON.stringify(this.faqs    || []));
            fd.append('reviews_json',    JSON.stringify(this.reviews || []));

            try {
                const r    = await fetch('/p.php?id=' + this.projId + '&preview=1', { method: 'POST', body: fd });
                let   html = await r.text();
                if (html && html.length > 0) {
                    // 1. Inject base tag so relative assets resolve
                    const base = window.location.origin + '/';
                    if (/<head\b[^>]*>/i.test(html)) {
                        html = html.replace(/(<head\b[^>]*>)/i, '$1\n<base href="' + base + '">');
                    } else {
                        html = '<base href="' + base + '">' + html;
                    }

                    // 2. Remove external tracking scripts only (keep internal frameworks & popups)
                    html = html.replace(/<script\b[^>]*src=["'][^"']*(?:google-analytics|googletagmanager|pixel\.facebook|histats|clarity\.ms|cloudflareinsights)[^"']*["'][^>]*>.*?<\/script>/gi, '');

                    // 3. INJECT link-blocking script so NO link navigates away
                    const blocker = `<script>
(function(){
    document.addEventListener('click', function(e){
        var a = e.target.closest('a');
        if(a){ e.preventDefault(); e.stopPropagation(); return false; }
    }, true);
    document.addEventListener('submit', function(e){
        e.preventDefault(); e.stopPropagation();
    }, true);
})();
<\/script>`;
                    if (/<\/body>/i.test(html)) {
                        html = html.replace(/<\/body>/i, blocker + '</body>');
                    } else {
                        html += blocker;
                    }

                    iframe.srcdoc = html;
                } else {
                    iframeLoaded();
                }
            } catch(e) {
                console.error('Preview failed:', e);
                iframeLoaded();
            }
        },

        
        openCloneModal() {
            this.cloneBrandInput   = this.name || '';
            this.cloneTitleInput   = this.title || '';
            this.cloneDescInput    = this.metaDesc || '';
            this.cloneLoginInput   = this.loginUrl || this.canonical || '';
            this.cloneRegInput     = this.registerUrl || this.canonical || '';
            this.cloneCanInput     = this.canonical || '';
            this.cloneAmpInput     = this.ampUrl || '';
            this.cloneBannerInput  = this.bannerUrl || '';
            this.cloneLogoInput    = this.logoUrl || '';
            this.cloneFaviconInput = this.faviconUrl || '';
            this.cloneGifInput     = this.gifUrl || '';
            this.cloneReviewsInput = [];
            this.cloneFaqsInput    = [];
            this.cloneUseAi        = true;
            this.cloneSaveAsTemplate = false;
            this.cloneSourceMode   = 'auto';
            this.cloneDetected     = false;
            this.cloneDetectedFormat = '';
            this.cloneLpFound      = false;
            this.cloneLpUrl        = '';
            this.cloneAmpFound     = false;
            this.cloneAmpUrl       = '';
            this.cloneCloakingNote = '';
            this.cloneRedirectTrace = [];
            this.cloneOldBrands    = [];
            this.cloneFieldFlags   = {};
            this._lastScannedBrand = '';
            this.cloneLogLines     = [];
            this.cloneStepNum      = 0;
            this.cloneStepPercent  = 0;
            this.cloneError        = '';
            this.showCloneModal    = true;
        },

        switchCloneSource(mode) {
            this.cloneSourceMode = mode;
            this.scanTargetWithAi();
        },

        async scanTargetWithAi() {
            if (!this.cloneUrlInput) return;
            this.isScanning = true;
            this.cloneDetected = false;
            this.cloneError = '';
            this.cloneLogLines = [];
            this.cloneFieldFlags = {};
            this.cloneStepNum = 1;
            this.cloneStepText = '1/8 cURL Target (Cek AMP/LP, Redirect & Anti-Cloaking)...';
            this.cloneStepPercent = 12;

            const waitMs = (ms) => new Promise(r => setTimeout(r, ms));

            try {
                const res = await fetch('/api/clone_url.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action:        'scan',
                        url:           this.cloneUrlInput,
                        brand_name:    this.cloneBrandInput,
                        use_ai:        this.cloneUseAi,
                        source_mode:   this.cloneSourceMode
                    })
                });
                const d = await res.json();
                if (!d.success) {
                    this.cloneError = d.message || 'Gagal memindai URL target.';
                    this.isScanning = false;
                    return;
                }

                const det  = d.detected || {};
                const logs = d.detection_logs || {};

                this.cloneDetectedFormat = det.page_format || det.type || 'lp';
                this.cloneLpFound        = !!det.has_paired_lp;
                this.cloneLpUrl          = det.paired_lp_url || '';
                this.cloneAmpFound       = !!det.has_paired_amp;
                this.cloneAmpUrl         = det.paired_amp_url || '';
                this.cloneCloakingNote   = logs.cloaking_note || '';
                this.cloneRedirectTrace  = Array.isArray(logs.redirect_trace) ? logs.redirect_trace : [];
                this.cloneOldBrands      = Array.isArray(det.all_old_brands) ? det.all_old_brands : [];

                this.cloneLogLines.push('Format Halaman: ' + this.cloneDetectedFormat.toUpperCase() + (logs.crawled_profile ? ' (via ' + logs.crawled_profile + ')' : ''));
                this.cloneLogLines.push(this.cloneLpFound ? ('LP Terdeteksi: ' + this.cloneLpUrl) : 'LP Terdeteksi: Tidak ada');
                this.cloneLogLines.push(this.cloneAmpFound ? ('AMP Terdeteksi: ' + this.cloneAmpUrl) : 'AMP Terdeteksi: Tidak ada');
                if (this.cloneRedirectTrace.length > 0) {
                    this.cloneLogLines.push('Redirect diikuti (' + this.cloneRedirectTrace.length + ' hop) -> ' + (logs.effective_url || ''));
                }
                if (this.cloneCloakingNote) {
                    this.cloneLogLines.push(this.cloneCloakingNote);
                }

                // Step 2: Mencari Title & Brand Sisa Kloningan
                this.cloneStepNum = 2;
                this.cloneStepText = '2/8 AI Mencari Title & Semua Brand Lama...';
                this.cloneStepPercent = 25;
                await waitMs(380);
                this.cloneTitleInput = det.title || '';
                this.cloneFieldFlags.title = !!det.title_found;
                this.cloneLogLines.push(det.title_found ? ('Title ditemukan: ' + det.title) : 'Title: Tidak ada di halaman target');
                if (det.brand_name) {
                    if (!this.cloneBrandInput) this.cloneBrandInput = det.brand_name;
                    this._lastScannedBrand = this.cloneBrandInput;
                }
                if (this.cloneOldBrands.length > 0) {
                    this.cloneLogLines.push('Brand lama terdeteksi AI (' + this.cloneOldBrands.length + '): ' + this.cloneOldBrands.slice(0, 6).join(', '));
                }

                // Step 3: Mencari Deskripsi
                this.cloneStepNum = 3;
                this.cloneStepText = '3/8 AI Mencari Meta Deskripsi...';
                this.cloneStepPercent = 38;
                await waitMs(360);
                this.cloneDescInput = det.meta_description || '';
                this.cloneFieldFlags.description = !!det.desc_found;
                this.cloneLogLines.push(det.desc_found ? ('Deskripsi ditemukan: ' + det.meta_description.substring(0, 60) + '...') : 'Deskripsi Meta: Tidak ada di halaman target');

                // Step 4: Mencari Canonical & AMP Link
                this.cloneStepNum = 4;
                this.cloneStepText = '4/8 AI Mencari Canonical LP & AMP Link...';
                this.cloneStepPercent = 52;
                await waitMs(360);
                this.cloneCanInput = det.canonical_url || '';
                this.cloneAmpInput = det.amp_url || '';
                this.cloneFieldFlags.canonical = !!det.canonical_found;
                this.cloneFieldFlags.amp = !!det.amp_found;
                this.cloneLogLines.push(det.canonical_found ? ('Canonical URL ditemukan: ' + det.canonical_url) : 'Canonical URL: Tidak ada tag canonical');
                this.cloneLogLines.push(det.amp_found ? ('AMP URL ditemukan: ' + det.amp_url) : 'AMP URL: Tidak ada di halaman target');

                // Step 5: Mencari Link Login & Regis / Alternatif
                this.cloneStepNum = 5;
                this.cloneStepText = '5/8 AI Mencari Link Login & Link Regis / Alternatif...';
                this.cloneStepPercent = 66;
                await waitMs(360);
                this.cloneLoginInput = det.login_url || '';
                this.cloneRegInput   = det.register_url || '';
                this.cloneFieldFlags.login = !!det.login_found;
                this.cloneFieldFlags.register = !!det.register_found;
                this.cloneLogLines.push(det.login_found ? ('Link Login ditemukan: ' + det.login_url) : 'Link Login: Tidak ada di halaman target');
                this.cloneLogLines.push(det.register_found ? ('Link Regis/Alternatif ditemukan: ' + det.register_url) : 'Link Regis/Alternatif: Tidak ada di halaman target');

                // Step 6: Mencari Gambar Banner & Logo
                this.cloneStepNum = 6;
                this.cloneStepText = '6/8 AI Mencari Foto Banner & Gambar Logo...';
                this.cloneStepPercent = 80;
                await waitMs(360);
                this.cloneBannerInput = det.banner_url || '';
                this.cloneLogoInput   = det.logo_url || '';
                this.cloneFieldFlags.banner = !!det.banner_found;
                this.cloneFieldFlags.logo   = !!det.logo_found;
                this.cloneLogLines.push(det.banner_found ? ('Foto Banner ditemukan: ' + det.banner_url) : 'Foto Banner: Tidak ada di halaman target');
                this.cloneLogLines.push(det.logo_found ? ('Gambar Logo ditemukan: ' + det.logo_url) : 'Gambar Logo: Tidak ada di halaman target');

                // Step 7: Mencari Icon, GIF, Ulasan Pengguna & Detail/FAQ
                this.cloneStepNum = 7;
                this.cloneStepText = '7/8 AI Mencari Icon, GIF, Ulasan Pengguna & Detail/FAQ...';
                this.cloneStepPercent = 92;
                await waitMs(360);
                this.cloneFaviconInput = det.favicon_url || '';
                this.cloneGifInput     = det.gif_url || '';
                this.cloneReviewsInput = Array.isArray(det.reviews) ? det.reviews : [];
                this.cloneFaqsInput    = Array.isArray(det.faqs) ? det.faqs : [];
                this.cloneFieldFlags.favicon = !!det.favicon_found;
                this.cloneFieldFlags.gif     = !!det.gif_found;
                this.cloneFieldFlags.reviews = !!det.reviews_found;
                this.cloneFieldFlags.faqs    = !!det.faqs_found;
                this.cloneLogLines.push(det.favicon_found ? ('Icon/Favicon ditemukan: ' + det.favicon_url) : 'Icon/Favicon: Tidak ada di halaman target');
                this.cloneLogLines.push(det.gif_found ? ('Animasi GIF ditemukan: ' + det.gif_url) : 'Animasi GIF: Tidak ada di halaman target');
                this.cloneLogLines.push(det.video_found ? ('Video ditemukan: ' + det.video_url) : 'Video: Tidak ada di halaman target');
                this.cloneLogLines.push(det.reviews_found ? ('Ulasan Pengguna ditemukan: ' + this.cloneReviewsInput.length + ' ulasan') : 'Ulasan Pengguna: Tidak ada di halaman target');
                this.cloneLogLines.push(det.faqs_found ? ('Detail / FAQ ditemukan: ' + this.cloneFaqsInput.length + ' detail') : 'Detail / FAQ: Tidak ada di halaman target');

                // Step 8: Selesai Deteksi
                this.cloneStepNum = 9;
                this.cloneStepPercent = 100;
                this.cloneStepText = 'Scan Selesai (' + this.cloneDetectedFormat.toUpperCase() + ')! Silakan cek hasil & ubah sesuai kebutuhan.';
                this.cloneDetected = true;
                window.showToast && showToast('success', d.message || 'Scan halaman target selesai!');
            } catch (err) {
                this.cloneError = 'Gagal memindai halaman target: ' + (err.message || 'Kesalahan jaringan');
            } finally {
                this.isScanning = false;
            }
        },

        async executeClone() {
            if (!this.cloneUrlInput) return;
            this.isCloning = true;
            this.cloneError = '';
            this.cloneLogLines = [];
            this.cloneStepNum = 1;
            this.cloneStepText = '1/8 cURL Target & Verifikasi AMP/LP...';
            this.cloneStepPercent = 12;

            // Jika Nama Brand diubah setelah scan, ikut gantikan nama brand lama di Title, Deskripsi, Ulasan & Detail modal
            if (this._lastScannedBrand && this.cloneBrandInput && this._lastScannedBrand.toLowerCase() !== this.cloneBrandInput.trim().toLowerCase()) {
                const sbEsc = this._lastScannedBrand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                const sbRx = new RegExp(sbEsc, 'gi');
                const newBr = this.cloneBrandInput.trim();
                if (this.cloneTitleInput) this.cloneTitleInput = this.cloneTitleInput.replace(sbRx, newBr);
                if (this.cloneDescInput)  this.cloneDescInput  = this.cloneDescInput.replace(sbRx, newBr);
                if (Array.isArray(this.cloneReviewsInput)) {
                    this.cloneReviewsInput.forEach(rv => {
                        if (rv.name) rv.name = rv.name.replace(sbRx, newBr);
                        if (rv.location) rv.location = rv.location.replace(sbRx, newBr);
                        if (rv.text) rv.text = rv.text.replace(sbRx, newBr);
                    });
                }
                if (Array.isArray(this.cloneFaqsInput)) {
                    this.cloneFaqsInput.forEach(fq => {
                        if (fq.question) fq.question = fq.question.replace(sbRx, newBr);
                        if (fq.answer) fq.answer = fq.answer.replace(sbRx, newBr);
                    });
                }
            }

            const waitMs = (ms) => new Promise(r => setTimeout(r, ms));

            try {
                const payload = {
                    url:              this.cloneUrlInput,
                    project_id:       this.projId,
                    source_mode:      this.cloneSourceMode,
                    brand_name:       this.cloneBrandInput,
                    login_url:        this.cloneLoginInput,
                    register_url:     this.cloneRegInput,
                    canonical_url:    this.cloneCanInput,
                    amp_url:          this.cloneAmpInput,
                    banner_url:       this.cloneBannerInput,
                    logo_url:         this.cloneLogoInput,
                    favicon_url:      this.cloneFaviconInput,
                    gif_url:          this.cloneGifInput,
                    title:            this.cloneTitleInput,
                    meta_description: this.cloneDescInput,
                    use_ai:           this.cloneUseAi,
                    save_as_template: this.cloneSaveAsTemplate
                };
                if (this.cloneDetected || this.cloneReviewsInput.length > 0) {
                    payload.reviews = this.cloneReviewsInput;
                }
                if (this.cloneDetected || this.cloneFaqsInput.length > 0) {
                    payload.faqs = this.cloneFaqsInput;
                }

                const fetchPromise = fetch('/api/clone_url.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                await waitMs(420);
                this.cloneStepNum = 2;
                this.cloneStepText = '2/8 Memproses & Mengganti Title Halaman...';
                this.cloneStepPercent = 25;

                await waitMs(420);
                this.cloneStepNum = 3;
                this.cloneStepText = '3/8 Memproses & Mengganti Meta Deskripsi...';
                this.cloneStepPercent = 38;

                await waitMs(420);
                this.cloneStepNum = 4;
                this.cloneStepText = '4/8 Mengganti LP Link (Canonical) & AMP Link...';
                this.cloneStepPercent = 52;

                await waitMs(420);
                this.cloneStepNum = 5;
                this.cloneStepText = '5/8 Mengganti Seluruh Link Login & Link Regis / Alternatif...';
                this.cloneStepPercent = 66;

                const res = await fetchPromise;
                const d = await res.json();

                if (!d.success) {
                    this.cloneError = d.message || 'Gagal mengkloning target URL.';
                    this.isCloning = false;
                    return;
                }

                if (d.data) {
                    this.cloneLogLines.push('Title diterapkan: ' + d.data.title);
                    this.cloneLogLines.push('Canonical LP diterapkan: ' + d.data.canonical);
                    this.cloneLogLines.push('Login & Regis diterapkan: ' + d.data.loginUrl);
                }

                this.cloneStepNum = 6;
                this.cloneStepText = '6/8 Mengganti Seluruh Link Gambar Banner & Logo...';
                this.cloneStepPercent = 80;
                await waitMs(380);

                this.cloneStepNum = 7;
                this.cloneStepText = '7/8 Mengganti Icon, GIF, Ulasan Pengguna & Detail/FAQ...';
                this.cloneStepPercent = 90;
                await waitMs(380);

                this.cloneStepNum = 8;
                this.cloneStepText = '8/8 Purifikasi Kode Bersih (100% Bebas Kode Template Aneh)...';
                this.cloneStepPercent = 98;
                await waitMs(380);

                this.cloneStepNum = 9;
                this.cloneStepPercent = 100;
                this.cloneStepText = 'Selesai! Semua link, gambar, icon, GIF, ulasan & detail berhasil diterapkan secara bersih.';

                if (d.data) {
                    this.name        = d.data.name;
                    this.type        = d.data.type;
                    this.title       = d.data.title;
                    this.metaDesc    = d.data.metaDesc;
                    this.canonical   = d.data.canonical;
                    this.ampUrl      = d.data.ampUrl;
                    this.logoUrl     = d.data.logoUrl;
                    this.bannerUrl   = d.data.bannerUrl;
                    this.faviconUrl  = d.data.faviconUrl;
                    this.gifUrl      = d.data.gifUrl;
                    this.article     = d.data.article;
                    this.loginUrl    = d.data.loginUrl || this.cloneLoginInput || d.data.canonical || '';
                    this.registerUrl = d.data.registerUrl || this.cloneRegInput || d.data.canonical || '';
                    this._prev = {
                        name: this.name || '',
                        title: this.title || '',
                        metaDesc: this.metaDesc || '',
                        canonical: this.canonical || '',
                        ampUrl: this.ampUrl || '',
                        loginUrl: this.loginUrl || '',
                        registerUrl: this.registerUrl || '',
                        bannerUrl: this.bannerUrl || '',
                        logoUrl: this.logoUrl || '',
                        faviconUrl: this.faviconUrl || '',
                        gifUrl: this.gifUrl || ''
                    };
                    if (Array.isArray(d.data.faqs)) this.faqs = d.data.faqs;
                    if (Array.isArray(d.data.reviews)) this.reviews = d.data.reviews;
                    if (_cm) _cm.setValue(this.article);
                }
                setTimeout(() => {
                    this.showCloneModal = false;
                    this.schedulePreview();
                    window.showToast && showToast('success', 'Berhasil mengkloning dan mengganti seluruh aset LP secara bersih!');
                }, 450);
            } catch (err) {
                this.cloneError = 'Terjadi kesalahan saat memproses URL: ' + (err.message || 'Gagal menghubungi server.');
            } finally {
                this.isCloning = false;
            }
        },

        saveProject() {
            this.syncFieldsToHtml();
            if (_cm) this.article = _cm.getValue();
            this.isSaving = true;
            this.$nextTick(() => {
                document.getElementById('saveForm').submit();
            });
        },

        async exportZipPackage() {
            this.syncFieldsToHtml();
            if (_cm) this.article = _cm.getValue();
            try {
                const formEl = document.getElementById('saveForm');
                if (formEl) {
                    const fd = new FormData(formEl);
                    fd.set('name',             this.name        || '');
                    fd.set('type',             this.type        || 'lp');
                    fd.set('canonical_url',    this.canonical   || '');
                    fd.set('amp_url',          this.ampUrl      || '');
                    fd.set('login_url',        this.loginUrl    || '');
                    fd.set('register_url',     this.registerUrl || '');
                    fd.set('banner_url',       this.bannerUrl   || '');
                    fd.set('banner_title',     this.bannerTitle || '');
                    fd.set('logo_url',         this.logoUrl     || '');
                    fd.set('logo_title',       this.logoTitle   || '');
                    fd.set('favicon_url',      this.faviconUrl  || '');
                    fd.set('gif_url',          this.gifUrl      || '');
                    fd.set('title',            this.title       || '');
                    fd.set('meta_description', this.metaDesc    || '');
                    fd.set('article_content',  this.article     || '');
                    fd.set('faq_json',         JSON.stringify(this.faqs    || []));
                    fd.set('reviews_json',     JSON.stringify(this.reviews || []));
                    await fetch('/user/builder.php?id=' + this.projId, { method: 'POST', body: fd });
                }
            } catch (e) {
                console.warn('Auto-save before export failed:', e);
            }
            window.location.href = '/api/export_package.php?type=' + encodeURIComponent(this.type || 'lp') + '&id=' + this.projId;
        },

        // ── AI helpers ─────────────────────────
        async aiTitleMeta() {
            this.aiLoading.title = true;
            try {
                const r = await fetch('/api/ai_generate.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'title_meta', topic: this.name })
                });
                const d = await r.json();
                if (d.success) {
                    this.title    = d.title;
                    this.metaDesc = d.meta_description;
                    this.schedulePreview();
                    window.showToast && showToast('success', 'AI Title & Meta berhasil!');
                } else {
                    window.showToast && showToast('error', d.message || 'Gagal generate AI');
                }
            } catch { window.showToast && showToast('error', 'Koneksi AI gagal'); }
            finally  { this.aiLoading.title = false; }
        },

        async aiArticle() {
            this.aiLoading.article = true;
            try {
                const r = await fetch('/api/ai_generate.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'article_faq', topic: this.name })
                });
                const d = await r.json();
                if (d.success) {
                    this.article = d.article_content || '';
                    if (_cm) _cm.setValue(this.article);
                    if (d.faqs)    this.faqs    = d.faqs;
                    if (d.reviews) this.reviews = d.reviews;
                    this.schedulePreview();
                    window.showToast && showToast('success', 'AI Artikel & FAQ berhasil!');
                } else {
                    window.showToast && showToast('error', d.message || 'Gagal generate AI');
                }
            } catch { window.showToast && showToast('error', 'Koneksi AI gagal'); }
            finally  { this.aiLoading.article = false; }
        },

        async aiReviews() {
            this.aiLoading.reviews = true;
            try {
                const r = await fetch('/api/ai_generate.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'reviews', topic: this.name })
                });
                const d = await r.json();
                if (d.success && d.reviews) {
                    this.reviews = d.reviews;
                    this.schedulePreview();
                    window.showToast && showToast('success', 'AI Reviews berhasil!');
                } else {
                    window.showToast && showToast('error', d.message || 'Gagal generate');
                }
            } catch { window.showToast && showToast('error', 'Koneksi AI gagal'); }
            finally  { this.aiLoading.reviews = false; }
        },

        async testRemoteDeployConnection() {
            if (!this.deployReceiverUrl) {
                window.showToast && showToast('error', 'Masukkan URL shell receiver terlebih dahulu (contoh: https://domain.com/receiver.php)');
                return;
            }
            this.deployLoading = true;
            this.deployResult = null;
            try {
                const res = await fetch('/api/deploy_remote.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'ping',
                        project_id: this.projId,
                        receiver_url: this.deployReceiverUrl,
                        deploy_key: this.deployKey
                    })
                });
                const data = await res.json();
                this.deployResult = data;
                if (data.success) {
                    if (data.details) {
                        if (data.details.current_path) this.deployDetectedPath = data.details.current_path;
                        if (data.details.subfolders)   this.deploySubfolders   = data.details.subfolders;
                    }
                    window.showToast && showToast('success', data.message || 'Receiver terhubung & path terdeteksi!');
                } else {
                    window.showToast && showToast('error', data.message || 'Koneksi gagal');
                }
            } catch (e) {
                this.deployResult = { success: false, message: 'Gagal terhubung ke server target.' };
                window.showToast && showToast('error', 'Gagal memanggil endpoint deploy.');
            } finally {
                this.deployLoading = false;
            }
        },

        getLiveTargetUrl() {
            if (!this.deployReceiverUrl) return '';
            try {
                const u = new URL(this.deployReceiverUrl);
                const base = u.protocol + '//' + u.host + (u.port ? ':' + u.port : '');
                if (this.deployTargetMode === 'folder' && this.deployTargetFolder.trim()) {
                    return base + '/' + this.deployTargetFolder.trim().replace(/^\/+|\/+$/g, '') + '/';
                }
                return base + '/';
            } catch(e) {
                return '';
            }
        },

        async runRemoteDeploy() {
            if (!this.deployReceiverUrl) {
                window.showToast && showToast('error', 'Masukkan URL shell receiver terlebih dahulu.');
                return;
            }
            await this.saveProjectSilently();
            this.deployLoading = true;
            this.deployResult = null;
            try {
                const targetFolderVal = (this.deployTargetMode === 'folder') ? this.deployTargetFolder.trim() : '';
                const res = await fetch('/api/deploy_remote.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'deploy',
                        project_id: this.projId,
                        receiver_url: this.deployReceiverUrl,
                        deploy_key: this.deployKey,
                        target_folder: targetFolderVal,
                        index_type: this.type === 'amp' ? 'html' : 'html',
                        tebas_index: this.deployTebasIndex ? '1' : '0',
                        self_destruct: this.deploySelfDestruct ? '1' : '0'
                    })
                });
                const data = await res.json();
                this.deployResult = data;
                if (data.success) {
                    if (data.site_url) {
                        this.canonical = data.site_url;
                    }
                    window.showToast && showToast('success', data.message || 'Deploy berhasil!');
                } else {
                    window.showToast && showToast('error', data.message || 'Gagal deploy berkas.');
                }
            } catch (e) {
                this.deployResult = { success: false, message: 'Terjadi kesalahan jaringan saat melakukan auto-deploy.' };
                window.showToast && showToast('error', 'Kesalahan koneksi deploy.');
            } finally {
                this.deployLoading = false;
            }
        },

        async saveProjectSilently() {
            this.syncFieldsToHtml();
            if (window._cm) this.article = window._cm.getValue();
            try {
                const formEl = document.getElementById('saveForm');
                if (formEl) {
                    const fd = new FormData(formEl);
                    fd.set('name',             this.name        || '');
                    fd.set('type',             this.type        || 'lp');
                    fd.set('canonical_url',    this.canonical   || '');
                    fd.set('amp_url',          this.ampUrl      || '');
                    fd.set('login_url',        this.loginUrl    || '');
                    fd.set('register_url',     this.registerUrl || '');
                    fd.set('banner_url',       this.bannerUrl   || '');
                    fd.set('banner_title',     this.bannerTitle || '');
                    fd.set('logo_url',         this.logoUrl     || '');
                    fd.set('logo_title',       this.logoTitle   || '');
                    fd.set('favicon_url',      this.faviconUrl  || '');
                    fd.set('gif_url',          this.gifUrl      || '');
                    fd.set('title',            this.title       || '');
                    fd.set('meta_description', this.metaDesc    || '');
                    fd.set('article_content',  this.article     || '');
                    fd.set('faq_json',         JSON.stringify(this.faqs    || []));
                    fd.set('reviews_json',     JSON.stringify(this.reviews || []));
                    await fetch('/user/builder.php?id=' + this.projId, { method: 'POST', body: fd });
                }
            } catch(e) {}
        }
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
