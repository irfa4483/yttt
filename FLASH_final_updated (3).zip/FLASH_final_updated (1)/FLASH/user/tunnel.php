<?php
// user/tunnel.php - Auto Tunnel, Sitemap & Meta Manager
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/tunnel_helper.php';
require_login();

$user = current_user();

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        set_flash('error', 'Validasi keamanan CSRF gagal. Silakan muat ulang halaman.');
        header('Location: /user/tunnel.php');
        exit;
    }

    $action = $_POST['action'] ?? '';

    // Action 1: Simpan Pengaturan Meta & Tunnel
    if ($action === 'save_tunnel_settings') {
        $data = [
            'tunnel_enabled'         => isset($_POST['tunnel_enabled']) ? '1' : '0',
            'tunnel_index_override'  => isset($_POST['tunnel_index_override']) ? '1' : '0',
            'tunnel_strict_keywords' => isset($_POST['tunnel_strict_keywords']) ? '1' : '0',
            'tunnel_template_mode'   => $_POST['tunnel_template_mode'] ?? 'project',
            'tunnel_project_id'      => strval(intval($_POST['tunnel_project_id'] ?? 0)),
            'tunnel_param'           => trim($_POST['tunnel_param'] ?? 'gacor') ?: 'gacor',
            'tunnel_default_brand'   => trim($_POST['tunnel_default_brand'] ?? 'PENIDABET') ?: 'PENIDABET',
            'tunnel_murl'            => trim($_POST['tunnel_murl'] ?? ''),
            'tunnel_ampurl'          => trim($_POST['tunnel_ampurl'] ?? ''),
            'tunnel_login_url'       => trim($_POST['tunnel_login_url'] ?? ''),
            'tunnel_register_url'    => trim($_POST['tunnel_register_url'] ?? ''),
            'tunnel_title'           => trim($_POST['tunnel_title'] ?? ''),
            'tunnel_desc'            => trim($_POST['tunnel_desc'] ?? ''),
            'tunnel_tag'             => trim($_POST['tunnel_tag'] ?? ''),
            'tunnel_favurl'          => trim($_POST['tunnel_favurl'] ?? ''),
            'tunnel_mainlogo'        => trim($_POST['tunnel_mainlogo'] ?? ''),
            'tunnel_maincontent'     => trim($_POST['tunnel_maincontent'] ?? '')
        ];

        save_tunnel_settings($pdo, $data);
        set_flash('success', 'Pengaturan SEO Doorway / Tunnel & Meta berhasil disimpan!');
        header('Location: /user/tunnel.php?tab=meta');
        exit;
    }

    // Action 2: Generate Sitemap Otomatis
    if ($action === 'generate_sitemap') {
        $domain = trim($_POST['sitemap_domain'] ?? '');
        if (empty($domain)) {
            $settings = get_tunnel_settings($pdo);
            $domain = $settings['tunnel_murl'];
        }
        $param = trim($_POST['sitemap_param'] ?? 'gacor') ?: 'gacor';
        $freq = $_POST['sitemap_freq'] ?? 'daily';
        $priority = $_POST['sitemap_priority'] ?? '0.9';
        $encodeSpaces = isset($_POST['sitemap_encode_spaces']) && $_POST['sitemap_encode_spaces'] === '1';

        $res = generate_sitemap_xml($domain, $param, $freq, $priority, $encodeSpaces);
        if ($res['success']) {
            set_flash('success', $res['message']);
        } else {
            set_flash('error', $res['message']);
        }
        header('Location: /user/tunnel.php?tab=sitemap');
        exit;
    }

    // Action 3: Hapus Sitemap
    if ($action === 'delete_sitemap') {
        $res = delete_sitemap_xml();
        if ($res['success']) {
            set_flash('success', $res['message']);
        } else {
            set_flash('error', $res['message']);
        }
        header('Location: /user/tunnel.php?tab=sitemap');
        exit;
    }

    // Action 3B: Ubah Nama Berkas Sitemap (Rename File XML)
    if ($action === 'rename_sitemap') {
        $oldName = $settings['sitemap_filename'] ?? 'sitemap.xml';
        $newName = trim($_POST['new_sitemap_filename'] ?? '');
        $res = rename_sitemap_file($pdo, $oldName, $newName);
        if ($res['success']) {
            set_flash('success', $res['message']);
        } else {
            set_flash('error', $res['message']);
        }
        header('Location: /user/tunnel.php?tab=sitemap');
        exit;
    }

    // Action 3C: Ubah Nama Domain di Dalam Sitemap Asli (Tanpa Buat Ulang)
    if ($action === 'change_sitemap_domain') {
        $activeFile = $settings['sitemap_filename'] ?? 'sitemap.xml';
        $newDomain = trim($_POST['sitemap_target_domain'] ?? '');
        $oldDomain = trim($_POST['sitemap_old_domain'] ?? '');
        $res = replace_sitemap_domain($activeFile, $newDomain, $oldDomain);
        if ($res['success']) {
            set_flash('success', $res['message']);
        } else {
            set_flash('error', $res['message']);
        }
        header('Location: /user/tunnel.php?tab=sitemap');
        exit;
    }

    // Action 4: Upload Sitemap File
    if ($action === 'upload_sitemap') {
        if (isset($_FILES['sitemap_file']) && $_FILES['sitemap_file']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['sitemap_file']['tmp_name'];
            $dest = __DIR__ . '/../sitemap.xml';
            if (move_uploaded_file($tmpName, $dest)) {
                set_flash('success', 'File sitemap.xml berhasil diunggah dan diperbarui!');
            } else {
                set_flash('error', 'Gagal memindahkan file yang diunggah. Periksa izin folder.');
            }
        } else {
            set_flash('error', 'Silakan pilih file XML sitemap yang valid.');
        }
        header('Location: /user/tunnel.php?tab=sitemap');
        exit;
    }

    // Action 5: Simpan Kata Kunci (daftar.txt)
    if ($action === 'save_keywords') {
        $content = trim($_POST['keywords_text'] ?? '');
        $mode = $_POST['keywords_mode'] ?? 'replace'; // 'replace' or 'append'
        $append = ($mode === 'append');

        if (!empty($content)) {
            $res = save_keywords_list($content, $append);
            if ($res['success']) {
                set_flash('success', $res['message']);
            } else {
                set_flash('error', $res['message']);
            }
        } else {
            set_flash('warning', 'Tidak ada kata kunci yang dimasukkan.');
        }
        header('Location: /user/tunnel.php?tab=keywords');
        exit;
    }

    // Action 6: Upload File Kata Kunci (daftar.txt)
    if ($action === 'upload_keywords_file') {
        if (isset($_FILES['keywords_file']) && $_FILES['keywords_file']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['keywords_file']['tmp_name'];
            $mode = $_POST['upload_mode'] ?? 'replace';
            $content = file_get_contents($tmpName);
            if ($content !== false) {
                $res = save_keywords_list($content, ($mode === 'append'));
                set_flash('success', $res['message']);
            } else {
                set_flash('error', 'Gagal membaca file yang diunggah.');
            }
        } else {
            set_flash('error', 'Silakan pilih file teks kata kunci (.txt).');
        }
        header('Location: /user/tunnel.php?tab=keywords');
        exit;
    }

    // Action 7: Download Sitemap / Keywords (GET handled separately)
}

// Fetch Current Settings & Stats
$settings = get_tunnel_settings($pdo);
$activeSitemapFile = basename($settings['sitemap_filename'] ?? 'sitemap.xml');
$sitemapStats = get_sitemap_stats($activeSitemapFile);
$keywordsStats = get_keywords_stats();

// Download handlers via GET
if (isset($_GET['download'])) {
    $dl = $_GET['download'];
    if ($dl === 'sitemap') {
        $dlPath = __DIR__ . '/../' . $activeSitemapFile;
        if (file_exists($dlPath)) {
            header('Content-Type: application/xml');
            header('Content-Disposition: attachment; filename="' . $activeSitemapFile . '"');
            readfile($dlPath);
            exit;
        }
    }
    if ($dl === 'daftar' && file_exists(__DIR__ . '/../daftar.txt')) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="daftar.txt"');
        readfile(__DIR__ . '/../daftar.txt');
        exit;
    }
}

// Fetch Projects List for Template Selection
$stmtProjects = $pdo->prepare("SELECT id, name, type, slug FROM projects ORDER BY id DESC");
$stmtProjects->execute();
$allProjects = $stmtProjects->fetchAll(PDO::FETCH_ASSOC);

// Fetch preview snippet of sitemap (max 50 lines)
$sitemapPreview = '';
if ($sitemapStats['exists']) {
    $fp = fopen(__DIR__ . '/../' . $activeSitemapFile, 'r');
    if ($fp) {
        $lines = [];
        $i = 0;
        while (($line = fgets($fp)) !== false && $i < 30) {
            $lines[] = rtrim($line);
            $i++;
        }
        fclose($fp);
        $sitemapPreview = implode("\n", $lines);
        if ($sitemapStats['count'] > 30) {
            $sitemapPreview .= "\n... [ " . ($sitemapStats['count'] - 30) . " baris URL lainnya disembunyikan untuk performa pratinjau ] ...\n</urlset>";
        }
    }
}

$pageTitle = 'Auto Tunnel & Sitemap Manager';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" 
     x-data="{ 
        sidebarOpen: false, 
        activeTab: new URLSearchParams(window.location.search).get('tab') || localStorage.getItem('tunnelActiveTab') || 'meta',
        keywordSearch: '',
        searchResult: null,
        isSearching: false,
        testKeyword(kw) {
            if (!kw.trim()) return;
            this.isSearching = true;
            fetch('/api/test_tunnel_keyword.php?kw=' + encodeURIComponent(kw))
                .then(r => r.json())
                .then(d => {
                    this.searchResult = d;
                    this.isSearching = false;
                })
                .catch(() => {
                    this.searchResult = { found: false, message: 'Gagal menghubungi server pengujian.' };
                    this.isSearching = false;
                });
        }
     }"
     x-init="$watch('activeTab', val => {
         localStorage.setItem('tunnelActiveTab', val);
         window.history.replaceState(null, '', '?tab=' + val);
     })">
    
    <!-- Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <!-- Brand Logo -->
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/25">
                    <i class="fa-solid fa-cube text-lg"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Member Area</h2>
                    <span class="text-[11px] text-slate-400">Portal Pengguna</span>
                </div>
            </div>

            <!-- Navigation Links -->
            <nav class="space-y-1.5 pt-4">
                <a href="/user/dashboard.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-house w-4 text-center"></i>
                    <span>Dashboard Utama</span>
                </a>

                <a href="/user/projects.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-layer-group w-4 text-center"></i>
                        <span>Daftar Project Saya</span>
                    </div>
                    <i class="fa-solid fa-angle-right text-[10px]"></i>
                </a>

                <a href="/user/tunnel.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold border text-xs transition-all text-left">
                    <i class="fa-solid fa-network-wired w-4 text-center text-amber-400"></i>
                    <span>Tunnel & Sitemap</span>
                </a>

                <a href="/user/dashboard.php?tab=news" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-newspaper w-4 text-center"></i>
                        <span>Berita & Pengumuman</span>
                    </div>
                </a>

                <a href="/user/dashboard.php?tab=profile" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-regular fa-id-card w-4 text-center"></i>
                    <span>Profil Saya</span>
                </a>
            </nav>

            <?php if ($user['role'] === 'admin'): ?>
                <div class="pt-6 border-t border-slate-800/80">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-amber-400/90 block mb-2 px-1">Akses Khusus Admin</span>
                    <a href="/admin/dashboard.php" 
                       class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 hover:text-amber-200 text-xs font-semibold transition-all group">
                        <div class="flex items-center gap-3">
                            <i class="fa-solid fa-shield-halved text-amber-400 group-hover:rotate-12 transition-transform"></i>
                            <span>Ke Dashboard Admin</span>
                        </div>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <a href="/auth/logout.php" class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </a>
        </div>
    </aside>

    <!-- Main Workspace Content -->
    <div class="flex-1 flex flex-col min-w-0">
        <!-- Top Bar -->
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <div class="flex items-center gap-2">
                    <i class="fa-solid fa-network-wired text-brand-400"></i>
                    <h1 class="text-sm font-bold text-white tracking-wide">SEO Tunnel & Dynamic LP Gateway</h1>
                    <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">Ready</span>
                </div>
            </div>

            <div class="flex items-center gap-3">
                <a href="/?<?= htmlspecialchars($settings['tunnel_param']) ?>=<?= urlencode($keywordsStats['sample'][0] ?? 'situs bola bisa cashout') ?>" target="_blank" 
                   class="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all">
                    <i class="fa-solid fa-arrow-up-right-from-square text-[11px] text-amber-400"></i>
                    <span>Test Buka Tunnel</span>
                </a>
                <a href="/sitemap.xml" target="_blank" 
                   class="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-brand-500/15 hover:bg-brand-500/25 text-brand-300 text-xs font-semibold border border-brand-500/30 transition-all">
                    <i class="fa-solid fa-sitemap text-[11px]"></i>
                    <span>Lihat sitemap.xml</span>
                </a>
            </div>
        </header>

        <!-- Content Area -->
        <main class="flex-1 p-4 lg:p-8 space-y-6 max-w-7xl w-full mx-auto">
            
            <!-- System Overview Badges -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Card 1: Status Tunnel -->
                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div class="space-y-1">
                        <span class="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Status Tunnel Doorway</span>
                        <div class="flex items-center gap-2">
                            <?php if (($settings['tunnel_enabled'] ?? '1') === '1'): ?>
                                <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                <span class="text-sm font-bold text-emerald-400">AKTIF BERJALAN</span>
                            <?php else: ?>
                                <span class="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                                <span class="text-sm font-bold text-slate-400">NON-AKTIF</span>
                            <?php endif; ?>
                        </div>
                        <span class="text-[10px] text-slate-400 block">Parameter: <code class="text-amber-300">?<?= htmlspecialchars($settings['tunnel_param']) ?>=...</code></span>
                    </div>
                    <div class="w-12 h-12 rounded-2xl bg-brand-500/10 border border-brand-500/20 text-brand-400 flex items-center justify-center text-xl">
                        <i class="fa-solid fa-bolt-lightning"></i>
                    </div>
                </div>

                <!-- Card 2: Status Sitemap -->
                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div class="space-y-1">
                        <span class="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Status Sitemap.xml</span>
                        <div class="flex items-center gap-2">
                            <?php if ($sitemapStats['exists']): ?>
                                <span class="text-sm font-bold text-white"><?= number_format($sitemapStats['count']) ?> URL</span>
                                <span class="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-semibold"><?= $sitemapStats['size_fmt'] ?></span>
                            <?php else: ?>
                                <span class="text-sm font-bold text-rose-400">Belum Ada File</span>
                            <?php endif; ?>
                        </div>
                        <span class="text-[10px] text-slate-400 block"><?= $sitemapStats['exists'] ? 'Diperbarui: ' . $sitemapStats['modified'] : 'Klik generate di bawah' ?></span>
                    </div>
                    <div class="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center text-xl">
                        <i class="fa-solid fa-sitemap"></i>
                    </div>
                </div>

                <!-- Card 3: Keywords Total -->
                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div class="space-y-1">
                        <span class="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Database Kata Kunci</span>
                        <div class="flex items-center gap-2">
                            <span class="text-sm font-bold text-white"><?= number_format($keywordsStats['count']) ?> Keywords</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-md bg-brand-500/15 text-brand-300 border border-brand-500/30 font-semibold">daftar.txt</span>
                        </div>
                        <span class="text-[10px] text-slate-400 block">Kecocokan: <?= ($settings['tunnel_strict_keywords'] ?? '1') === '1' ? 'Validasi Ketat' : 'Bebas Dinamis' ?></span>
                    </div>
                    <div class="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-xl">
                        <i class="fa-solid fa-list-check"></i>
                    </div>
                </div>
            </div>

            <!-- Tab Navigation Header -->
            <div class="border-b border-slate-800 flex gap-2">
                <button @click="activeTab = 'meta'" 
                        :class="activeTab === 'meta' ? 'border-brand-500 text-brand-300 bg-brand-500/10' : 'border-transparent text-slate-400 hover:text-white'"
                        class="px-5 py-3 border-b-2 font-bold text-xs flex items-center gap-2 transition-all rounded-t-xl">
                    <i class="fa-solid fa-sliders"></i>
                    <span>Pengaturan Tunnel & Meta LP</span>
                </button>

                <button @click="activeTab = 'sitemap'" 
                        :class="activeTab === 'sitemap' ? 'border-brand-500 text-brand-300 bg-brand-500/10' : 'border-transparent text-slate-400 hover:text-white'"
                        class="px-5 py-3 border-b-2 font-bold text-xs flex items-center gap-2 transition-all rounded-t-xl">
                    <i class="fa-solid fa-sitemap"></i>
                    <span>Manajemen Sitemap.xml</span>
                </button>

                <button @click="activeTab = 'keywords'" 
                        :class="activeTab === 'keywords' ? 'border-brand-500 text-brand-300 bg-brand-500/10' : 'border-transparent text-slate-400 hover:text-white'"
                        class="px-5 py-3 border-b-2 font-bold text-xs flex items-center gap-2 transition-all rounded-t-xl">
                    <i class="fa-solid fa-file-lines"></i>
                    <span>Kelola Kata Kunci (daftar.txt)</span>
                </button>
            </div>

            <!-- ========================================== -->
            <!-- TAB 1: PENGATURAN TUNNEL & META LP         -->
            <!-- ========================================== -->
            <div x-show="activeTab === 'meta'" class="space-y-6">

                <!-- Card: Link Publik Purified Siap Kirim / Sebar -->
                <div class="glass-card p-6 rounded-3xl border border-emerald-500/30 bg-gradient-to-br from-emerald-950/20 via-slate-900/60 to-slate-900 space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-500/20 pb-3">
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                <h3 class="text-sm font-bold text-white uppercase tracking-wider">Link Publik Purified (Siap Kirim & Disebar)</h3>
                            </div>
                            <p class="text-xs text-slate-300 mt-1">
                                Landing page dan tunnel sudah dipurifikasi: pelacak lama & skrip pihak ketiga dihapus, meta robots dioptimalkan, dan Schema.org JSON-LD valid diinjeksi.
                            </p>
                        </div>
                        <div class="flex items-center gap-1.5 flex-wrap">
                            <span class="px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold flex items-center gap-1.5">
                                <i class="fa-solid fa-shield-halved text-emerald-400"></i> 100% Bebas Copyright Target
                            </span>
                            <span class="px-2.5 py-1 rounded-full bg-brand-500/15 border border-brand-500/30 text-brand-300 text-[11px] font-semibold flex items-center gap-1.5">
                                <i class="fa-solid fa-check text-brand-400"></i> Google Core 2026 Ready
                            </span>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                        <!-- Link Tunnel Berdasarkan Kata Kunci -->
                        <div class="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">Link Publik Tunnel (Dinamis Sesuai Kata Kunci):</span>
                            <?php 
                                $sampleKw = $keywordsStats['sample'][0] ?? 'situs bola bisa cashout';
                                $tunnelFullUrl = rtrim($settings['tunnel_murl'], '/') . '/?' . ($settings['tunnel_param'] ?? 'gacor') . '=' . urlencode($sampleKw);
                            ?>
                            <div class="flex items-center gap-2">
                                <input type="text" readonly value="<?= e($tunnelFullUrl) ?>" id="publicTunnelUrl" 
                                       class="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs font-mono select-all">
                                <button type="button" 
                                        @click="
                                            navigator.clipboard.writeText(document.getElementById('publicTunnelUrl').value);
                                            showToast('success', 'Link Tunnel Purified berhasil disalin!');
                                        "
                                        class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer flex-shrink-0">
                                    <i class="fa-solid fa-copy"></i> Salin
                                </button>
                                <a href="<?= e($tunnelFullUrl) ?>" target="_blank" class="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-all flex-shrink-0" title="Buka di tab baru">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                </a>
                            </div>
                            <span class="text-[10px] text-slate-400 block">Kirim link ini ke orang lain atau Googlebot untuk menampilkan kata kunci dinamis.</span>
                        </div>

                        <!-- Link Halaman Utama / Selected LP -->
                        <div class="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-brand-400 block">Link Landing Page Index Utama:</span>
                            <?php 
                                $indexFullUrl = rtrim($settings['tunnel_murl'], '/') . '/';
                            ?>
                            <div class="flex items-center gap-2">
                                <input type="text" readonly value="<?= e($indexFullUrl) ?>" id="publicIndexUrl" 
                                       class="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs font-mono select-all">
                                <button type="button" 
                                        @click="
                                            navigator.clipboard.writeText(document.getElementById('publicIndexUrl').value);
                                            showToast('success', 'Link Index Utama berhasil disalin!');
                                        "
                                        class="px-3.5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer flex-shrink-0">
                                    <i class="fa-solid fa-copy"></i> Salin
                                </button>
                                <a href="<?= e($indexFullUrl) ?>" target="_blank" class="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-all flex-shrink-0" title="Buka di tab baru">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                </a>
                            </div>
                            <span class="text-[10px] text-slate-400 block">Halaman utama root website yang akan mengikuti desain LP terpilih di bawah.</span>
                        </div>
                    </div>
                </div>

                <!-- Card: Ekspor Paket Installer Tunnel Mandiri (ZIP Siap Pasang) -->
                <div class="glass-card p-6 rounded-3xl border border-amber-500/30 bg-gradient-to-br from-amber-950/20 via-slate-900/60 to-slate-900 space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2">
                                <i class="fa-solid fa-file-zipper text-amber-400 text-lg"></i>
                                <h3 class="text-sm font-bold text-white uppercase tracking-wider">Paket Installer Tunnel Mandiri (ZIP Siap Pasang VPS / cPanel)</h3>
                            </div>
                            <p class="text-xs text-slate-300">
                                Unduh arsip ZIP mandiri lengkap (berisi <code>index.php</code>, <code>meta.php</code>, <code>daftar.txt</code> 19.100 kata kunci, <code>sitemap.xml</code> valid, dan template LP terpilih). Tanpa butuh database, langsung diekstrak di VPS/cPanel langsung jalan.
                            </p>
                            <div class="flex items-center gap-2 pt-1 text-[11px] text-amber-300/80">
                                <i class="fa-solid fa-clock-rotate-left"></i>
                                <span>File ZIP di server otomatis dihapus setelah 24 jam untuk menjaga privasi & menghemat penyimpanan.</span>
                            </div>
                        </div>

                        <a href="/api/export_package.php?type=tunnel" 
                           class="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-xl shadow-amber-500/20 transition-all flex items-center justify-center gap-2.5 flex-shrink-0 cursor-pointer">
                            <i class="fa-solid fa-download text-sm"></i>
                            <span>Unduh Paket Tunnel (ZIP)</span>
                        </a>
                    </div>
                </div>

                <form method="POST" action="/user/tunnel.php" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="save_tunnel_settings">

                    <!-- Section: Aktivasi & Template LP yang Diikuti -->
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-6">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                            <div>
                                <h3 class="text-base font-bold text-white flex items-center gap-2">
                                    <i class="fa-solid fa-wand-magic-sparkles text-amber-400"></i>
                                    <span>Tampilan & Desain Landing Page</span>
                                </h3>
                                <p class="text-xs text-slate-400 mt-1">
                                    Pilih tampilan Landing Page mana yang akan digunakan untuk menyajikan halaman Tunnel dinamis.
                                </p>
                            </div>

                            <div class="flex items-center gap-4">
                                <label class="inline-flex items-center gap-2 cursor-pointer">
                                    <input type="checkbox" name="tunnel_enabled" value="1" <?= ($settings['tunnel_enabled'] ?? '1') === '1' ? 'checked' : '' ?> class="sr-only peer">
                                    <div class="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600 relative"></div>
                                    <span class="text-xs font-semibold text-slate-200">Tunnel Aktif</span>
                                </label>
                            </div>
                        </div>

                        <!-- Dropdown Pilihan Template LP -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">
                                    Desain Tampilan LP yang Diikuti:
                                </label>
                                <select name="tunnel_template_mode" class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs focus:ring-2 focus:ring-brand-500">
                                    <option value="project" <?= ($settings['tunnel_template_mode'] ?? 'project') === 'project' ? 'selected' : '' ?>>
                                        🌟 Ikuti Project Landing Page FLASH (Rekomendasi)
                                    </option>
                                    <option value="squarespace" <?= ($settings['tunnel_template_mode'] ?? '') === 'squarespace' ? 'selected' : '' ?>>
                                        🌟 Template Squarespace / Undar (Star Slot 777 - index_(1).php yang Anda kirim)
                                    </option>
                                    <option value="etsy" <?= ($settings['tunnel_template_mode'] ?? '') === 'etsy' ? 'selected' : '' ?>>
                                        🛍️ Template Etsy Marketplace (Product & Reviews - etsy.php yang Anda kirim)
                                    </option>
                                </select>
                                <p class="text-[11px] text-slate-400 leading-relaxed">
                                    Template yang Anda kirim sudah tersedia dan terpasang. Tampilan halaman Index & Tunnel akan otomatis mengadopsi pilihan ini.
                                </p>
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">
                                    Pilih Project LP Terpilih:
                                </label>
                                <select name="tunnel_project_id" class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs focus:ring-2 focus:ring-brand-500">
                                    <option value="0">-- Gunakan Project Terakhir Dibuat --</option>
                                    <?php foreach ($allProjects as $p): ?>
                                        <option value="<?= $p['id'] ?>" <?= ($settings['tunnel_project_id'] ?? '0') == $p['id'] ? 'selected' : '' ?>>
                                            [#<?= $p['id'] ?>] <?= e($p['name']) ?> (<?= strtoupper($p['type']) ?>) - /s/<?= e($p['slug']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="text-[11px] text-slate-400 leading-relaxed">
                                    Anda dapat membuat project baru di menu <a href="/user/projects.php" class="text-brand-400 hover:underline">Daftar Project</a> atau Clone URL target orang lain.
                                </p>
                            </div>
                        </div>

                        <!-- Opsi Index Override -->
                        <div class="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-2">
                            <label class="inline-flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="tunnel_index_override" value="1" <?= ($settings['tunnel_index_override'] ?? '0') === '1' ? 'checked' : '' ?> class="w-4 h-4 rounded text-brand-600 bg-slate-900 border-slate-700 focus:ring-brand-500">
                                <span class="text-xs font-bold text-amber-300">
                                    Jadikan LP Tunnel Sebagai Halaman Utama Langsung (Index /)
                                </span>
                            </label>
                            <p class="text-[11px] text-slate-300 leading-relaxed pl-7">
                                Jika diaktifkan, saat ada pengunjung membuka domain utama tanpa parameter (misal: <code>http://domain.com/</code>), sistem langsung menampilkan Landing Page terpilih dengan brand default, bukan homepage SaaS FLASH. Portal login admin/member tetap aman diakses di <code>/auth/login.php</code>.
                            </p>
                        </div>
                    </div>

                    <!-- Section: Link Pendaftaran & Login (Wajib Diubah) -->
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-6">
                        <div class="border-b border-slate-800 pb-4">
                            <h3 class="text-base font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-link text-emerald-400"></i>
                                <span>Link Tujuan Tombol DAFTAR & LOGIN</span>
                            </h3>
                            <p class="text-xs text-slate-400 mt-1">
                                Semua tombol Daftar dan Login pada seluruh kata kunci tunnel otomatis dialihkan ke URL yang Anda tentukan di bawah ini.
                            </p>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-2">
                                <label class="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                                    <i class="fa-solid fa-user-plus"></i>
                                    <span>URL Link Tombol DAFTAR (Register CTA):</span>
                                </label>
                                <input type="text" name="tunnel_register_url" value="<?= e($settings['tunnel_register_url'] ?? '') ?>" 
                                       placeholder="https://situstarget.com/register" 
                                       class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs focus:ring-2 focus:ring-emerald-500 font-mono">
                                <span class="text-[10px] text-slate-400 block">Link pendaftaran akun baru pengunjung Anda.</span>
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold text-brand-400 flex items-center gap-1.5">
                                    <i class="fa-solid fa-right-to-bracket"></i>
                                    <span>URL Link Tombol LOGIN (Login CTA):</span>
                                </label>
                                <input type="text" name="tunnel_login_url" value="<?= e($settings['tunnel_login_url'] ?? '') ?>" 
                                       placeholder="https://situstarget.com/login" 
                                       class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs focus:ring-2 focus:ring-brand-500 font-mono">
                                <span class="text-[10px] text-slate-400 block">Link login member lama pengunjung Anda.</span>
                            </div>
                        </div>
                    </div>

                    <!-- Section: Parameter & Meta SEO Google -->
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-6">
                        <div class="border-b border-slate-800 pb-4">
                            <h3 class="text-base font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-magnifying-glass text-brand-400"></i>
                                <span>Konfigurasi Parameter URL, Judul & Meta SEO</span>
                            </h3>
                            <p class="text-xs text-slate-400 mt-1">
                                Digunakan untuk merender tag canonical, amphtml, OpenGraph, dan Schema.org JSON-LD agar terindeks sempurna di Google.
                            </p>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">Parameter Query URL:</label>
                                <input type="text" name="tunnel_param" value="<?= e($settings['tunnel_param'] ?? 'gacor') ?>" 
                                       placeholder="gacor" 
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                                <span class="text-[10px] text-slate-400 block">Contoh: <code>domain.com/?gacor=kata-kunci</code></span>
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">Mother URL / Domain Utama:</label>
                                <input type="text" name="tunnel_murl" value="<?= e($settings['tunnel_murl'] ?? '') ?>" 
                                       placeholder="https://situstogelmalamini.com" 
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                                <span class="text-[10px] text-slate-400 block">Domain server saat ini (otomatis dideteksi).</span>
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">Link URL AMP (amphtml):</label>
                                <input type="text" name="tunnel_ampurl" value="<?= e($settings['tunnel_ampurl'] ?? '') ?>" 
                                       placeholder="https://situstogelmalamini.pages.dev/ampsitustogel" 
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                                <span class="text-[10px] text-slate-400 block">Target link tag <code>&lt;link rel="amphtml"&gt;</code>.</span>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">Template Judul Halaman (Title):</label>
                                <input type="text" name="tunnel_title" value="<?= e($settings['tunnel_title'] ?? '') ?>" 
                                       placeholder="Sarana Terbaik Situs Togel Malam Ini dengan Hadiah Terbesar" 
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs">
                                <span class="text-[10px] text-slate-400 block">Format hasil: <code>[BRAND] - [JUDUL_DI_ATAS]</code></span>
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">Brand Default (Tanpa Parameter):</label>
                                <input type="text" name="tunnel_default_brand" value="<?= e($settings['tunnel_default_brand'] ?? 'PENIDABET') ?>" 
                                       placeholder="PENIDABET" 
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-bold">
                                <span class="text-[10px] text-slate-400 block">Brand yang tampil jika dibuka tanpa query param.</span>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <label class="text-xs font-bold text-slate-300 block">Template Deskripsi Meta (Meta Description):</label>
                            <textarea name="tunnel_desc" rows="2" 
                                      class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs"><?= e($settings['tunnel_desc'] ?? '') ?></textarea>
                            <span class="text-[10px] text-slate-400 block">Format hasil: <code>[BRAND] [DESKRIPSI_DI_ATAS]</code></span>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">URL Favicon:</label>
                                <input type="text" name="tunnel_favurl" value="<?= e($settings['tunnel_favurl'] ?? '') ?>" 
                                       placeholder="https://.../favicon.png" 
                                       class="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">URL Logo Utama:</label>
                                <input type="text" name="tunnel_mainlogo" value="<?= e($settings['tunnel_mainlogo'] ?? '') ?>" 
                                       placeholder="https://.../logo.png" 
                                       class="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold text-slate-300 block">URL Banner / Konten Utama:</label>
                                <input type="text" name="tunnel_maincontent" value="<?= e($settings['tunnel_maincontent'] ?? '') ?>" 
                                       placeholder="https://.../banner.png" 
                                       class="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                            </div>
                        </div>

                        <div class="space-y-2">
                            <label class="text-xs font-bold text-slate-300 block">Google Verification Code / Tag:</label>
                            <input type="text" name="tunnel_tag" value="<?= e($settings['tunnel_tag'] ?? '') ?>" 
                                   placeholder="PENIDABET atau kode google-site-verification" 
                                   class="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                        </div>

                        <!-- Checkbox Validasi Kata Kunci -->
                        <div class="pt-2">
                            <label class="inline-flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" name="tunnel_strict_keywords" value="1" <?= ($settings['tunnel_strict_keywords'] ?? '1') === '1' ? 'checked' : '' ?> class="w-4 h-4 rounded text-brand-600 bg-slate-900 border-slate-700 focus:ring-brand-500">
                                <span class="text-xs font-semibold text-slate-300">
                                    Validasi Ketat: Hanya respon kata kunci yang ada di <code>daftar.txt</code> (Kirim 404 jika kata kunci tidak terdaftar)
                                </span>
                            </label>
                        </div>
                    </div>

                    <!-- Tombol Submit Simpan -->
                    <div class="flex items-center justify-end gap-3">
                        <button type="submit" class="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white font-extrabold text-xs shadow-xl shadow-brand-500/25 transition-all flex items-center gap-2">
                            <i class="fa-solid fa-floppy-disk text-amber-300"></i>
                            <span>Simpan Semua Pengaturan Meta & Tunnel</span>
                        </button>
                    </div>
                </form>
            </div>

            <!-- ========================================== -->
            <!-- TAB 2: MANAJEMEN SITEMAP.XML               -->
            <!-- ========================================== -->
            <div x-show="activeTab === 'sitemap'" class="space-y-6" style="display: none;">
                <!-- Status File Sitemap -->
                <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                        <div>
                            <h3 class="text-base font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-sitemap text-indigo-400"></i>
                                <span>Informasi Berkas Sitemap Aktif: <code class="text-amber-300 font-mono text-sm"><?= e($activeSitemapFile) ?></code></span>
                            </h3>
                            <p class="text-xs text-slate-400 mt-1">
                                Berkas sitemap berada di direktori server dan dapat langsung diakses publik oleh Googlebot.
                            </p>
                        </div>

                        <div class="flex items-center gap-2">
                            <?php if ($sitemapStats['exists']): ?>
                                <a href="/user/tunnel.php?download=sitemap" class="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center gap-2 transition-all">
                                    <i class="fa-solid fa-download text-amber-400"></i>
                                    <span>Download XML</span>
                                </a>
                                <a href="/<?= e($activeSitemapFile) ?>" target="_blank" class="px-3.5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold flex items-center gap-2 transition-all shadow-lg shadow-brand-600/25">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                    <span>Buka /<?= e($activeSitemapFile) ?></span>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
                        <div class="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
                            <span class="text-[10px] text-slate-400 uppercase font-bold block mb-1">Nama File Aktif</span>
                            <span class="text-sm font-bold text-amber-300 font-mono"><?= e($activeSitemapFile) ?></span>
                        </div>

                        <div class="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
                            <span class="text-[10px] text-slate-400 uppercase font-bold block mb-1">Total URL di Sitemap</span>
                            <span class="text-sm font-bold text-white"><?= number_format($sitemapStats['count']) ?> Link</span>
                        </div>

                        <div class="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
                            <span class="text-[10px] text-slate-400 uppercase font-bold block mb-1">Ukuran File</span>
                            <span class="text-sm font-bold text-slate-200"><?= $sitemapStats['exists'] ? $sitemapStats['size_fmt'] : '-' ?></span>
                        </div>

                        <div class="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
                            <span class="text-[10px] text-slate-400 uppercase font-bold block mb-1">Domain di Dalam File</span>
                            <span class="text-xs font-bold text-indigo-300 truncate block" title="<?= e($sitemapStats['detected_domain']) ?>">
                                <?= e($sitemapStats['detected_domain'] ?: '-') ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- CARD BARU: Ubah Nama Berkas & Ubah Nama Domain di Sitemap Asli (Tanpa Buat Ulang) -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Form 1: Ubah Nama Berkas Sitemap (Rename File) -->
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                        <div class="border-b border-slate-800 pb-3">
                            <h4 class="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-2">
                                <i class="fa-solid fa-pen-to-square"></i>
                                <span>Ubah Nama Berkas File Sitemap</span>
                            </h4>
                            <p class="text-xs text-slate-400 mt-1">
                                Anda dapat mengganti nama file sitemap di server (contoh: <code>sitemap.xml</code> menjadi <code>sitemap_gacor.xml</code>, <code>sitemap1.xml</code>, dll).
                            </p>
                        </div>

                        <form method="POST" action="/user/tunnel.php" class="space-y-3">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="rename_sitemap">

                            <div class="space-y-1.5">
                                <label class="text-xs font-bold text-slate-300 block">Nama File Baru (harus akhiran .xml):</label>
                                <input type="text" name="new_sitemap_filename" value="<?= e($activeSitemapFile) ?>" 
                                       placeholder="sitemap.xml" required
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                            </div>

                            <button type="submit" class="w-full px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-700">
                                <i class="fa-solid fa-i-cursor"></i>
                                <span>Ganti Nama File Sitemap</span>
                            </button>
                        </form>
                    </div>

                    <!-- Form 2: Ubah Nama Domain di Dalam Sitemap Asli (Tanpa Buat Ulang) -->
                    <div class="glass-card p-6 rounded-3xl border border-indigo-500/30 bg-indigo-950/10 space-y-4">
                        <div class="border-b border-indigo-500/20 pb-3">
                            <h4 class="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-2">
                                <i class="fa-solid fa-globe"></i>
                                <span>Ubah Nama Domain di Dalam Sitemap Asli</span>
                            </h4>
                            <p class="text-xs text-slate-300 mt-1">
                                Menjaga seluruh <strong><?= number_format($sitemapStats['count']) ?> kata kunci</strong> dari sitemap yang Anda kirim tetap utuh, hanya mengganti nama domain lama menjadi domain Anda.
                            </p>
                        </div>

                        <form method="POST" action="/user/tunnel.php" class="space-y-3">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="change_sitemap_domain">

                            <div class="grid grid-cols-2 gap-2">
                                <div class="space-y-1">
                                    <label class="text-[11px] font-bold text-slate-400 block">Domain Lama Saat Ini:</label>
                                    <input type="text" name="sitemap_old_domain" value="<?= e($sitemapStats['detected_domain']) ?>" 
                                           placeholder="https://ejournal.undar.ac.id" 
                                           class="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 text-xs font-mono text-xs">
                                </div>
                                <div class="space-y-1">
                                    <label class="text-[11px] font-bold text-emerald-400 block">Domain Tujuan Baru:</label>
                                    <input type="text" name="sitemap_target_domain" value="<?= e($settings['tunnel_murl']) ?>" 
                                           placeholder="https://situstogelmalamini.com" required
                                           class="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono text-xs">
                                </div>
                            </div>

                            <button type="submit" class="w-full px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg transition-all flex items-center justify-center gap-2">
                                <i class="fa-solid fa-bolt-lightning text-amber-300"></i>
                                <span>Ganti Nama Domain di Sitemap (Tanpa Buat Ulang)</span>
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Generator Sitemap 1-Klik -->
                <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-6">
                    <div class="border-b border-slate-800 pb-4">
                        <h3 class="text-base font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-wand-magic-sparkles text-amber-400"></i>
                            <span>Generator Sitemap.xml Otomatis 1-Klik</span>
                        </h3>
                        <p class="text-xs text-slate-400 mt-1">
                            Sistem akan membaca seluruh kata kunci dari <code>daftar.txt</code> (total <?= number_format($keywordsStats['count']) ?> kata kunci) dan mengonversinya menjadi URL sitemap berstandar Google.
                        </p>
                    </div>

                    <form method="POST" action="/user/tunnel.php" class="space-y-4">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="generate_sitemap">

                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div class="md:col-span-2 space-y-1.5">
                                <label class="text-xs font-bold text-slate-300 block">Domain Base URL:</label>
                                <input type="text" name="sitemap_domain" value="<?= e($settings['tunnel_murl']) ?>" 
                                       placeholder="https://situstogelmalamini.com" 
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                            </div>

                            <div class="space-y-1.5">
                                <label class="text-xs font-bold text-slate-300 block">Parameter Target:</label>
                                <input type="text" name="sitemap_param" value="<?= e($settings['tunnel_param']) ?>" 
                                       class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono">
                            </div>

                            <div class="space-y-1.5">
                                <label class="text-xs font-bold text-slate-300 block">Changefreq:</label>
                                <select name="sitemap_freq" class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs">
                                    <option value="daily" selected>daily (Harian)</option>
                                    <option value="hourly">hourly (Tiap Jam)</option>
                                    <option value="weekly">weekly (Mingguan)</option>
                                    <option value="always">always (Selalu)</option>
                                </select>
                            </div>
                        </div>

                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
                            <label class="inline-flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" name="sitemap_encode_spaces" value="1" class="w-4 h-4 rounded text-brand-600 bg-slate-900 border-slate-700 focus:ring-brand-500">
                                <span class="text-xs text-slate-300">Encode spasi URL menjadi <code>%20</code> (biarkan tidak dicentang untuk spasi alami)</span>
                            </label>

                            <button type="submit" class="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2">
                                <i class="fa-solid fa-bolt-lightning"></i>
                                <span>Generate sitemap.xml Sekarang</span>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Aksi Upload & Hapus Sitemap -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Upload External Sitemap -->
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                        <h4 class="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                            <i class="fa-solid fa-upload text-brand-400"></i>
                            <span>Unggah File sitemap.xml Baru</span>
                        </h4>
                        <p class="text-xs text-slate-400">
                            Punya file sitemap XML yang sudah siap? Anda dapat langsung mengunggahnya ke server.
                        </p>
                        <form method="POST" action="/user/tunnel.php" enctype="multipart/form-data" class="space-y-3">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="upload_sitemap">
                            <input type="file" name="sitemap_file" accept=".xml" required
                                   class="block w-full text-xs text-slate-400 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-slate-200 hover:file:bg-slate-700 cursor-pointer">
                            <button type="submit" class="w-full px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all">
                                Upload & Timpa sitemap.xml
                            </button>
                        </form>
                    </div>

                    <!-- Hapus Sitemap -->
                    <div class="glass-card p-6 rounded-3xl border border-rose-900/30 bg-rose-950/10 space-y-4">
                        <h4 class="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                            <i class="fa-solid fa-trash-can"></i>
                            <span>Hapus Berkas sitemap.xml</span>
                        </h4>
                        <p class="text-xs text-slate-400">
                            Menghapus file <code>sitemap.xml</code> dari server secara permanen. Anda dapat men-generate ulang kapan saja.
                        </p>
                        <form method="POST" action="/user/tunnel.php" 
                              @submit.prevent="customConfirm({
                                  title: 'Hapus File sitemap.xml?',
                                  message: 'Apakah Anda yakin ingin menghapus sitemap.xml dari server?',
                                  variant: 'danger',
                                  confirmText: 'Ya, Hapus',
                                  onConfirm: () => $el.submit()
                              })">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="delete_sitemap">
                            <button type="submit" class="w-full px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-semibold transition-all">
                                <i class="fa-solid fa-trash-can mr-1.5"></i> Hapus Berkas sitemap.xml
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Pratinjau Konten Sitemap -->
                <?php if ($sitemapStats['exists']): ?>
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-3">
                        <div class="flex items-center justify-between">
                            <h4 class="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                                <i class="fa-solid fa-code text-indigo-400"></i>
                                <span>Pratinjau Kode sitemap.xml (Cuplikan 30 Baris Teratas)</span>
                            </h4>
                            <span class="text-[10px] text-slate-400"><?= number_format($sitemapStats['count']) ?> Total Baris URL</span>
                        </div>
                        <pre class="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 text-[11px] text-slate-300 font-mono overflow-x-auto max-h-72 leading-relaxed selection:bg-brand-500 selection:text-white"><?= htmlspecialchars($sitemapPreview) ?></pre>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ========================================== -->
            <!-- TAB 3: KELOLA KATA KUNCI (DAFTAR.TXT)      -->
            <!-- ========================================== -->
            <div x-show="activeTab === 'keywords'" class="space-y-6" style="display: none;">
                <!-- Ringkasan Kata Kunci & Live Tester -->
                <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                        <div>
                            <h3 class="text-base font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-list-check text-amber-400"></i>
                                <span>Daftar Kata Kunci (daftar.txt)</span>
                            </h3>
                            <p class="text-xs text-slate-400 mt-1">
                                Saat ini tersimpan <strong class="text-white"><?= number_format($keywordsStats['count']) ?> kata kunci</strong> (Ukuran: <?= $keywordsStats['size_fmt'] ?>).
                            </p>
                        </div>

                        <a href="/user/tunnel.php?download=daftar" class="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center gap-2 transition-all">
                            <i class="fa-solid fa-download text-amber-400"></i>
                            <span>Unduh daftar.txt</span>
                        </a>
                    </div>

                    <!-- Uji Pencarian Kata Kunci Real-Time -->
                    <div class="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                        <label class="text-xs font-bold text-slate-300 block">
                            Cek Validasi Kata Kunci Tunnel:
                        </label>
                        <div class="flex gap-2">
                            <input type="text" x-model="keywordSearch" @keydown.enter.prevent="testKeyword(keywordSearch)"
                                   placeholder="Ketik kata kunci, contoh: situs bola bisa cashout" 
                                   class="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs">
                            <button type="button" @click="testKeyword(keywordSearch)" :disabled="isSearching"
                                    class="px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold transition-all flex items-center gap-2">
                                <i class="fa-solid fa-magnifying-glass" :class="{ 'fa-spin': isSearching }"></i>
                                <span>Cek Validitas</span>
                            </button>
                        </div>

                        <!-- Result Alert -->
                        <template x-if="searchResult">
                            <div class="p-3 rounded-xl border text-xs flex items-center gap-2 transition-all"
                                 :class="searchResult.found ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-rose-500/10 border-rose-500/30 text-rose-300'">
                                <i class="fa-solid" :class="searchResult.found ? 'fa-circle-check text-emerald-400' : 'fa-circle-xmark text-rose-400'"></i>
                                <span x-text="searchResult.message"></span>
                                <template x-if="searchResult.found">
                                    <a :href="'/?<?= htmlspecialchars($settings['tunnel_param']) ?>=' + encodeURIComponent(keywordSearch)" target="_blank" class="ml-auto underline font-bold text-amber-300">
                                        Buka Hasil di Tab Baru &rarr;
                                    </a>
                                </template>
                            </div>
                        </template>
                    </div>

                    <!-- Sampel Kata Kunci -->
                    <?php if (!empty($keywordsStats['sample'])): ?>
                        <div class="space-y-1.5 pt-2">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Contoh 10 Kata Kunci Pertama:</span>
                            <div class="flex flex-wrap gap-1.5">
                                <?php foreach ($keywordsStats['sample'] as $s): ?>
                                    <span class="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-[11px] font-mono">
                                        <?= e($s) ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Form Tambah / Timpa Kata Kunci Manual -->
                <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                    <div class="border-b border-slate-800 pb-3">
                        <h4 class="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                            <i class="fa-solid fa-pen-to-square text-brand-400"></i>
                            <span>Tambah / Tempel (Paste) Kata Kunci Baru</span>
                        </h4>
                        <p class="text-xs text-slate-400 mt-1">
                            Masukkan satu kata kunci per baris. Anda dapat menambahkan ke daftar yang ada atau mengganti seluruhnya.
                        </p>
                    </div>

                    <form method="POST" action="/user/tunnel.php" class="space-y-4">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="save_keywords">

                        <textarea name="keywords_text" rows="6" placeholder="situs bola bisa cashout&#10;situs bola bet 5000&#10;situs bola bet 1000&#10;..."
                                  class="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-slate-100 text-xs font-mono"></textarea>

                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div class="flex items-center gap-4">
                                <label class="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                                    <input type="radio" name="keywords_mode" value="append" checked class="text-brand-600 focus:ring-brand-500">
                                    <span>Tambahkan ke Akhir File (Append)</span>
                                </label>
                                <label class="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                                    <input type="radio" name="keywords_mode" value="replace" class="text-brand-600 focus:ring-brand-500">
                                    <span>Gantikan Seluruh Isi (Replace)</span>
                                </label>
                            </div>

                            <button type="submit" class="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs shadow-lg transition-all flex items-center gap-2">
                                <i class="fa-solid fa-floppy-disk"></i>
                                <span>Simpan Kata Kunci</span>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Form Upload File daftar.txt -->
                <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                    <div class="border-b border-slate-800 pb-3">
                        <h4 class="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                            <i class="fa-solid fa-file-arrow-up text-amber-400"></i>
                            <span>Unggah File Teks Kata Kunci (.txt)</span>
                        </h4>
                        <p class="text-xs text-slate-400 mt-1">
                            Unggah berkas <code>.txt</code> dari komputer Anda untuk memperbarui daftar kata kunci sekaligus.
                        </p>
                    </div>

                    <form method="POST" action="/user/tunnel.php" enctype="multipart/form-data" class="space-y-4">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="upload_keywords_file">

                        <input type="file" name="keywords_file" accept=".txt" required
                               class="block w-full text-xs text-slate-400 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-slate-200 hover:file:bg-slate-700 cursor-pointer">

                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div class="flex items-center gap-4">
                                <label class="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                                    <input type="radio" name="upload_mode" value="replace" checked class="text-brand-600 focus:ring-brand-500">
                                    <span>Ganti File (Timpa daftar.txt)</span>
                                </label>
                                <label class="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                                    <input type="radio" name="upload_mode" value="append" class="text-brand-600 focus:ring-brand-500">
                                    <span>Gabungkan (Append ke Akhir)</span>
                                </label>
                            </div>

                            <button type="submit" class="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs border border-slate-700 transition-all flex items-center gap-2">
                                <i class="fa-solid fa-upload"></i>
                                <span>Unggah Berkas</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
