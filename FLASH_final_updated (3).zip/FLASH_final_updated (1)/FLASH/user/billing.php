<?php
// user/billing.php - Payment, QRIS & Subscription Upgrade Portal
require_once __DIR__ . '/../includes/auth.php';
require_login();

$user = current_user();
$quota = get_user_quota_info($user);

// Ambil pengaturan bot Telegram, bank & QRIS dari settings
$stmtSet = $pdo->prepare("SELECT key, value FROM settings WHERE key IN ('telegram_bot_username', 'bank_name', 'bank_account_number', 'bank_account_name', 'qris_image_path')");
$stmtSet->execute();
$sysSettings = $stmtSet->fetchAll(PDO::FETCH_KEY_PAIR);
$tgBot         = $sysSettings['telegram_bot_username'] ?? 'FlashOfficialBot';
$bankName      = !empty($sysSettings['bank_name']) ? $sysSettings['bank_name'] : 'BCA';
$bankAccNumber = !empty($sysSettings['bank_account_number']) ? $sysSettings['bank_account_number'] : '8735091234';
$bankAccName   = !empty($sysSettings['bank_account_name']) ? $sysSettings['bank_account_name'] : 'FLASH OFFICIAL';
$qrisImagePath = $sysSettings['qris_image_path'] ?? '';

$successMsg = '';
$errorMsg = '';

// Handle Upload Bukti Transfer di Web
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        $errorMsg = 'Validasi keamanan CSRF gagal. Silakan muat ulang halaman.';
    } else {
        $plan = trim($_POST['plan'] ?? 'trial7');
        $invoiceId = 'INV-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
        
        $baseAmounts = [
            'trial7'  => 150000,
            'lite'    => 350000,
            'elite'   => 550000,
            'premium' => 1000000,
            'diamond' => 2000000,
            'vip'     => 4000000,
            'vpro'    => 6000000
        ];
        $amount = $baseAmounts[$plan] ?? 150000;
        $uniqueCode = rand(100, 999);
        $totalAmount = $amount + $uniqueCode;

        $proofFileName = '';
        if (isset($_FILES['proof_file']) && $_FILES['proof_file']['error'] === UPLOAD_ERR_OK) {
            $allowedExts = ['jpg', 'jpeg', 'png', 'webp'];
            $fileInfo = pathinfo($_FILES['proof_file']['name']);
            $ext = strtolower($fileInfo['extension'] ?? '');

            if (in_array($ext, $allowedExts)) {
                $uploadDir = __DIR__ . '/../uploads/proofs/';
                if (!is_dir($uploadDir)) {
                    @mkdir($uploadDir, 0755, true);
                }
                $proofFileName = 'proof_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
                if (!move_uploaded_file($_FILES['proof_file']['tmp_name'], $uploadDir . $proofFileName)) {
                    $proofFileName = '';
                }
            } else {
                $errorMsg = 'Format berkas bukti transfer harus berupa gambar (JPG, PNG, atau WEBP).';
            }
        }

        if (empty($errorMsg)) {
            $stmtPay = $pdo->prepare("INSERT INTO payments (user_id, invoice_id, plan_name, amount, unique_code, total_amount, payment_method, proof_image, telegram_username, status) VALUES (?, ?, ?, ?, ?, ?, 'qris_transfer', ?, ?, 'pending')");
            $stmtPay->execute([
                $user['id'],
                $invoiceId,
                $plan,
                $amount,
                $uniqueCode,
                $totalAmount,
                $proofFileName,
                trim($_POST['telegram_username'] ?? '')
            ]);
            $successMsg = "Pembayaran untuk Invoice <b>{$invoiceId}</b> berhasil diajukan! Admin akan memverifikasi dan mengaktifkan akun Anda.";
        }
    }
}

// Ambil Riwayat Pembayaran User
$stmtHistory = $pdo->prepare("SELECT * FROM payments WHERE user_id = ? ORDER BY id DESC");
$stmtHistory->execute([$user['id']]);
$paymentHistory = $stmtHistory->fetchAll();

$pageTitle = 'Pembayaran & Upgrade Paket - FLASH';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" 
     x-data="{ 
        sidebarOpen: false, 
        selectedPlan: 'trial7',
        planDetails: {
            trial7:  { name: 'Paket 7 Hari', price: 150000, duration: '1 Minggu (7 Hari)', desc: 'Akses 1 minggu, kuota 30 project & 60x kloning AI' },
            lite:    { name: 'Paket Lite', price: 350000, duration: '2 Minggu (14 Hari)', desc: 'Akses 2 minggu, kuota 75 project & 150x kloning AI' },
            elite:   { name: 'Paket Elite', price: 550000, duration: '1 Bulan (30 Hari)', desc: 'Akses 1 bulan, kuota 150 project & 300x kloning AI' },
            premium: { name: 'Paket Premium', price: 1000000, duration: '1 Bulan (30 Hari)', desc: 'Akses 1 bulan, kuota 300 project & 600x kloning AI' },
            diamond: { name: 'Paket Diamond', price: 2000000, duration: '1 Bulan (30 Hari)', desc: 'Akses 1 bulan, kuota 600 project & 1200x kloning AI' },
            vip:     { name: 'VIP Ultra-Rank', price: 4000000, duration: '1 Bulan (30 Hari)', desc: 'Unlimited Project, Dynamic Tunnel, Auto-Pinger Google' },
            vpro:    { name: 'VPro Sultan', price: 6000000, duration: '1 Bulan (30 Hari)', desc: 'Anti-Cloaking Googlebot Bypass, Multi-Domain Network, Telegram 24/7' }
        },
        uniqueCode: Math.floor(Math.random() * 899) + 100,
        get totalPay() {
            return this.planDetails[this.selectedPlan].price + this.uniqueCode;
        },
        formatRupiah(num) {
            return 'Rp ' + num.toLocaleString('id-ID');
        }
     }">

    <!-- Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/25">
                    <i class="fa-solid fa-credit-card text-lg"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Member Area</h2>
                    <span class="text-[11px] text-amber-400 font-bold">Billing & Upgrade</span>
                </div>
            </div>

            <nav class="space-y-1.5 pt-4">
                <a href="/user/dashboard.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-house w-4 text-center"></i>
                    <span>Dashboard Utama</span>
                </a>
                <a href="/user/projects.php" class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-layer-group w-4 text-center"></i>
                        <span>Daftar Project Saya</span>
                    </div>
                </a>
                <a href="/user/billing.php" class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-brand-600/20 border border-brand-500/40 text-brand-300 font-bold text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-qrcode w-4 text-center text-amber-400"></i>
                        <span>Bayar & Upgrade Kuota</span>
                    </div>
                    <span class="px-1.5 py-0.5 rounded-full bg-amber-500/30 text-amber-300 text-[9px] font-black">QR</span>
                </a>
                <a href="/user/vip_seo.php" class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-wand-magic-sparkles w-4 text-center text-amber-300"></i>
                        <span>VIP SEO Suite</span>
                    </div>
                </a>
            </nav>
        </div>

        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <a href="/auth/logout.php" class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </a>
        </div>
    </aside>

    <!-- Main Workspace Content -->
    <div class="flex-1 flex flex-col min-w-0">
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <h1 class="font-bold text-base text-white leading-none">Pembayaran & Perpanjangan Kuota</h1>
            </div>

            <div class="flex items-center gap-3">
                <span class="text-xs text-slate-400">Status Akun:</span>
                <span class="px-3 py-1 rounded-full bg-brand-500/20 border border-brand-500/40 text-brand-300 font-bold text-xs uppercase">
                    <?= e($quota['plan_name']) ?>
                </span>
            </div>
        </header>

        <main class="flex-1 p-4 lg:p-8 max-w-6xl w-full mx-auto space-y-8">
            
            <?php if ($successMsg): ?>
                <div class="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-3 shadow-lg">
                    <i class="fa-solid fa-circle-check text-emerald-400 text-xl flex-shrink-0"></i>
                    <div><?= $successMsg ?></div>
                </div>
            <?php endif; ?>

            <?php if ($errorMsg): ?>
                <div class="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3 shadow-lg">
                    <i class="fa-solid fa-triangle-exclamation text-rose-400 text-xl flex-shrink-0"></i>
                    <div><?= e($errorMsg) ?></div>
                </div>
            <?php endif; ?>

            <!-- Pilih Paket Pembayaran -->
            <div class="space-y-4">
                <div>
                    <h2 class="text-xl font-black text-white flex items-center gap-2">
                        <i class="fa-solid fa-wallet text-amber-400"></i> Pilih Paket Berlangganan / Perpanjangan
                    </h2>
                    <p class="text-xs text-slate-400 mt-1">Pilih paket untuk mengaktifkan kembali kredit kloning dan fitur VIP Anda.</p>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- Option 1: 7 Hari Rp 150.000 -->
                    <div @click="selectedPlan = 'trial7'" 
                         :class="selectedPlan === 'trial7' ? 'border-brand-500 bg-brand-950/30 ring-2 ring-brand-500/20' : 'border-slate-800 bg-slate-900/60'"
                         class="p-4 rounded-2xl border cursor-pointer transition-all hover:border-brand-500/50 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-slate-300 uppercase">Paket 7 Hari</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-brand-500/20 text-brand-300 font-bold">1 Minggu</span>
                        </div>
                        <div class="text-xl font-black text-white">Rp 150.000</div>
                        <p class="text-[11px] text-slate-400">30 Project & 60x kloning AI.</p>
                    </div>

                    <!-- Option 2: Lite Rp 350.000 -->
                    <div @click="selectedPlan = 'lite'" 
                         :class="selectedPlan === 'lite' ? 'border-sky-500 bg-sky-950/30 ring-2 ring-sky-500/20' : 'border-slate-800 bg-slate-900/60'"
                         class="p-4 rounded-2xl border cursor-pointer transition-all hover:border-sky-500/50 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-sky-300 uppercase">Paket Lite</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-bold">2 Minggu</span>
                        </div>
                        <div class="text-xl font-black text-white">Rp 350.000</div>
                        <p class="text-[11px] text-slate-400">75 Project & 150x kloning AI.</p>
                    </div>

                    <!-- Option 3: Elite Rp 550.000 -->
                    <div @click="selectedPlan = 'elite'" 
                         :class="selectedPlan === 'elite' ? 'border-emerald-500 bg-emerald-950/30 ring-2 ring-emerald-500/20' : 'border-slate-800 bg-slate-900/60'"
                         class="p-4 rounded-2xl border cursor-pointer transition-all hover:border-emerald-500/50 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-emerald-300 uppercase">Paket Elite</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">1 Bulan</span>
                        </div>
                        <div class="text-xl font-black text-white">Rp 550.000</div>
                        <p class="text-[11px] text-slate-400">150 Project & 300x kloning AI.</p>
                    </div>

                    <!-- Option 4: Premium Rp 1.000.000 -->
                    <div @click="selectedPlan = 'premium'" 
                         :class="selectedPlan === 'premium' ? 'border-indigo-500 bg-indigo-950/30 ring-2 ring-indigo-500/20' : 'border-slate-800 bg-slate-900/60'"
                         class="p-4 rounded-2xl border cursor-pointer transition-all hover:border-indigo-500/50 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-indigo-300 uppercase">Paket Premium</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold">1 Bulan</span>
                        </div>
                        <div class="text-xl font-black text-white">Rp 1.000.000</div>
                        <p class="text-[11px] text-slate-400">300 Project, Schema 5-Star & Pinger.</p>
                    </div>

                    <!-- Option 5: Diamond Rp 2.000.000 -->
                    <div @click="selectedPlan = 'diamond'" 
                         :class="selectedPlan === 'diamond' ? 'border-cyan-500 bg-cyan-950/30 ring-2 ring-cyan-500/20' : 'border-slate-800 bg-slate-900/60'"
                         class="p-4 rounded-2xl border cursor-pointer transition-all hover:border-cyan-500/50 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-cyan-300 uppercase">Paket Diamond</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold">💎 1 Bulan</span>
                        </div>
                        <div class="text-xl font-black text-white">Rp 2.000.000</div>
                        <p class="text-[11px] text-slate-400">600 Project, Multi-Domain & AI Priority.</p>
                    </div>

                    <!-- Option 6: VIP Ultra-Rank Rp 4.000.000 -->
                    <div @click="selectedPlan = 'vip'" 
                         :class="selectedPlan === 'vip' ? 'border-amber-500 bg-amber-950/30 ring-2 ring-amber-500/20' : 'border-slate-800 bg-slate-900/60'"
                         class="p-4 rounded-2xl border cursor-pointer transition-all hover:border-amber-500/50 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-amber-300 uppercase">VIP Ultra-Rank</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">⭐ Sultan</span>
                        </div>
                        <div class="text-xl font-black text-white">Rp 4.000.000</div>
                        <p class="text-[11px] text-slate-400">Unlimited Project, Dynamic Tunnel & Fast Index.</p>
                    </div>

                    <!-- Option 7: VPro Sultan Rp 6.000.000 -->
                    <div @click="selectedPlan = 'vpro'" 
                         :class="selectedPlan === 'vpro' ? 'border-purple-500 bg-purple-950/30 ring-2 ring-purple-500/20' : 'border-slate-800 bg-slate-900/60'"
                         class="p-4 rounded-2xl border cursor-pointer transition-all hover:border-purple-500/50 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-purple-300 uppercase">VPro Sultan</span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-bold">👑 Ultimate</span>
                        </div>
                        <div class="text-xl font-black text-white">Rp 6.000.000</div>
                        <p class="text-[11px] text-slate-400">Anti-Cloaking Googlebot, Webhook 24/7.</p>
                    </div>
                </div>
            </div>

            <!-- Box QR Code & Detail Pembayaran -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                <!-- Sisi Kiri: Tampilan QR Code QRIS & Nomor Rekening -->
                <div class="lg:col-span-5 glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900/80 text-center space-y-4 shadow-2xl">
                    <span class="px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-xs font-bold uppercase tracking-wider inline-block">
                        Scan QRIS / Transfer Bank
                    </span>

                    <div class="p-4 bg-white rounded-2xl inline-block shadow-inner mx-auto">
                        <?php if (!empty($qrisImagePath) && file_exists(__DIR__ . '/..' . $qrisImagePath)): ?>
                            <!-- Custom QRIS Image uploaded by Admin -->
                            <img src="<?= e($qrisImagePath) ?>" 
                                 alt="QRIS Pembayaran FLASH" class="w-48 h-48 mx-auto object-contain">
                        <?php else: ?>
                            <!-- Dynamic QR Code generator via HTTPS API -->
                            <img :src="'https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=4&data=' + encodeURIComponent('FLASH_PAYMENT_' + selectedPlan + '_' + totalPay)" 
                                 alt="QRIS Pembayaran FLASH" class="w-48 h-48 mx-auto object-contain">
                        <?php endif; ?>
                    </div>

                    <div class="space-y-1">
                        <div class="text-xs text-slate-400">Total Nominal Pembayaran:</div>
                        <div class="text-3xl font-black text-amber-300 font-mono tracking-tight" x-text="formatRupiah(totalPay)"></div>
                        <div class="text-[11px] text-slate-500">*Pastikan transfer sesuai 3 digit kode unik (<span x-text="uniqueCode" class="text-amber-400 font-bold"></span>)</div>
                    </div>

                    <!-- Rekening Bank Alternatif -->
                    <div class="pt-3 border-t border-slate-800 text-left space-y-2 text-xs">
                        <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                            <div>
                                <span class="font-bold text-white block"><?= e($bankName) ?></span>
                                <span class="text-amber-400 font-mono font-bold text-sm tracking-wider"><?= e($bankAccNumber) ?></span>
                            </div>
                            <span class="text-[11px] text-slate-400">a/n <?= e($bankAccName) ?></span>
                        </div>
                    </div>
                </div>

                <!-- Sisi Kanan: Form Konfirmasi / Upload Bukti TF & Tombol Telegram -->
                <div class="lg:col-span-7 glass-card p-6 sm:p-8 rounded-3xl border border-slate-800 bg-slate-900/80 space-y-6 shadow-2xl">
                    <div>
                        <h3 class="text-lg font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-file-invoice text-brand-400"></i> Konfirmasi Bukti Transfer
                        </h3>
                        <p class="text-xs text-slate-400 mt-1">Setelah melakukan transfer via QRIS atau Bank, pilih salah satu metode konfirmasi berikut:</p>
                    </div>

                    <!-- METODE A: Konfirmasi Cepat via Bot Telegram -->
                    <div class="p-4 rounded-2xl bg-sky-500/10 border border-sky-500/30 space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-sky-300 flex items-center gap-1.5">
                                <i class="fa-brands fa-telegram text-base"></i> Opsi 1: Konfirmasi Instan via Bot Telegram
                            </span>
                            <span class="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-200 font-bold">1-Klik</span>
                        </div>
                        <p class="text-[11px] text-slate-400">
                            Buka Bot Telegram <b>@<?= e($tgBot) ?></b>, kirimkan foto struk pembayaran Anda dan invoice akan langsung diverifikasi oleh sistem / Admin.
                        </p>
                        <a :href="'https://t.me/<?= e($tgBot) ?>?start=pay_' + selectedPlan + '_' + totalPay" target="_blank"
                           class="w-full py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md">
                            <i class="fa-brands fa-telegram text-base"></i>
                            <span>Kirim Bukti TF ke Bot Telegram @<?= e($tgBot) ?></span>
                        </a>
                    </div>

                    <!-- METODE B: Upload Bukti TF di Website -->
                    <form action="/user/billing.php" method="POST" enctype="multipart/form-data" class="space-y-4 pt-2 border-t border-slate-800">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="plan" :value="selectedPlan">

                        <div>
                            <span class="text-xs font-bold text-white block mb-1">Opsi 2: Unggah Bukti Transfer di Sini</span>
                            <p class="text-[11px] text-slate-400 mb-2">Unggah tangkapan layar (screenshot) bukti transfer mobile banking / e-wallet Anda.</p>
                            
                            <input type="file" name="proof_file" required accept="image/*"
                                   class="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-300 text-xs file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-brand-600 file:text-white hover:file:bg-brand-500">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1">Username Telegram / Kontak WhatsApp (Opsional)</label>
                            <input type="text" name="telegram_username" placeholder="@username_anda atau 0812xxxx" 
                                   class="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 text-xs focus:outline-none focus:border-brand-500">
                        </div>

                        <button type="submit" 
                                class="w-full py-3 px-4 bg-gradient-to-r from-brand-600 to-indigo-600 hover:opacity-95 text-white font-bold rounded-xl text-xs shadow-lg shadow-brand-500/20 transition-all flex items-center justify-center gap-2">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                            <span>Kirim Bukti Pembayaran untuk Diverifikasi Admin</span>
                        </button>
                    </form>
                </div>

            </div>

            <!-- Riwayat Pembayaran Pengguna -->
            <div class="space-y-4 pt-6">
                <h3 class="text-base font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-clock-rotate-left text-slate-400"></i> Riwayat Pengajuan Pembayaran Anda
                </h3>

                <?php if (empty($paymentHistory)): ?>
                    <div class="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 text-center text-slate-500 text-xs">
                        Belum ada riwayat pembayaran.
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60">
                        <table class="w-full text-left text-xs text-slate-300">
                            <thead class="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                                <tr>
                                    <th class="p-3.5">Invoice</th>
                                    <th class="p-3.5">Paket</th>
                                    <th class="p-3.5">Total Bayar</th>
                                    <th class="p-3.5">Tanggal</th>
                                    <th class="p-3.5">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-800/80">
                                <?php foreach ($paymentHistory as $p): ?>
                                    <tr>
                                        <td class="p-3.5 font-mono font-bold text-white"><?= e($p['invoice_id']) ?></td>
                                        <td class="p-3.5 uppercase font-semibold text-brand-300"><?= e($p['plan_name']) ?></td>
                                        <td class="p-3.5 font-mono text-amber-300">Rp <?= number_format($p['total_amount'], 0, ',', '.') ?></td>
                                        <td class="p-3.5 text-slate-400"><?= date('d M Y H:i', strtotime($p['created_at'])) ?></td>
                                        <td class="p-3.5">
                                            <?php if ($p['status'] === 'approved'): ?>
                                                <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">Disetujui (Aktif)</span>
                                            <?php elseif ($p['status'] === 'rejected'): ?>
                                                <span class="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold text-[10px]">Ditolak</span>
                                            <?php else: ?>
                                                <span class="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold text-[10px]">Menunggu Verifikasi</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
