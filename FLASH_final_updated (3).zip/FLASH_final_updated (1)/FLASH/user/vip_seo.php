<?php
// user/vip_seo.php - Exclusive VIP SEO Suite & Code Optimizer for FLASH Platform
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/tunnel_helper.php';
require_login();

$user = current_user();
$quota = get_user_quota_info($user);

// Cek apakah user adalah VIP atau Admin
$isVip = $quota['is_vip'];

$pageTitle = 'VIP SEO Suite & Code Optimizer - FLASH';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" 
     x-data="{ 
        sidebarOpen: false, 
        activeTab: 'optimizer',
        pingUrl: '',
        pingLoading: false,
        pingResult: null,
        pingError: '',
        auditUrl: '',
        auditLoading: false,
        auditResult: null,
        auditError: '',
        rawCodeInput: '',
        cleanCodeOutput: '',
        isOptimizing: false,
        codeStats: null,
        optimizeCode() {
            if (!this.rawCodeInput.trim()) return;
            this.isOptimizing = true;
            setTimeout(() => {
                let code = this.rawCodeInput;
                const originalLength = code.length;
                
                // 1. Bersihkan sisa template tag {{ ... }}
                code = code.replace(/\{\{[^}]+\}\}/g, '');
                // 2. Bersihkan komentar HTML kecuali conditional IE atau AMP boilerplate
                code = code.replace(/<!--(?!\[if|<!|\s*⚡|\s*amp)(.*?)-->/gs, '');
                // 3. Bersihkan spasi dan baris kosong berlebih
                code = code.replace(/^\s*[\r\n]/gm, '');
                // 4. Inject Schema.org AggregateRating bintang 5 jika belum ada
                if (!code.includes('AggregateRating') && code.includes('</head>')) {
                    const schemaSnippet = `\n<script type=\"application/ld+json\">\n{\n  \"@context\": \"https://schema.org\",\n  \"@type\": \"ItemPage\",\n  \"aggregateRating\": {\n    \"@type\": \"AggregateRating\",\n    \"ratingValue\": \"4.9\",\n    \"reviewCount\": \"1890\",\n    \"bestRating\": \"5\",\n    \"worstRating\": \"1\"\n  }\n}\n<\/script>\n`;
                    code = code.replace('</head>', schemaSnippet + '</head>');
                }

                this.cleanCodeOutput = code;
                this.codeStats = {
                    originalSize: (originalLength / 1024).toFixed(2) + ' KB',
                    cleanSize: (code.length / 1024).toFixed(2) + ' KB',
                    saved: ((originalLength - code.length) / 1024).toFixed(2) + ' KB'
                };
                this.isOptimizing = false;
            }, 400);
        },
        sendFastPing() {
            if (!this.pingUrl) {
                this.pingError = 'Masukkan URL atau Sitemap yang ingin diping.';
                return;
            }
            this.pingError = '';
            this.pingLoading = true;
            this.pingResult = null;

            fetch('/api/vip_seo_ping.php?action=ping_search_engines', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ target_url: this.pingUrl })
            })
            .then(res => res.json())
            .then(data => {
                this.pingLoading = false;
                if (data.success) {
                    this.pingResult = data;
                } else {
                    this.pingError = data.message || 'Gagal mengirim sinyal ping.';
                }
            })
            .catch(err => {
                this.pingLoading = false;
                this.pingError = 'Koneksi ke server gagal.';
            });
        },
        auditSeo() {
            if (!this.auditUrl) {
                this.auditError = 'Masukkan URL yang ingin diaudit.';
                return;
            }
            this.auditError = '';
            this.auditLoading = true;
            this.auditResult = null;

            fetch('/api/vip_seo_ping.php?action=analyze_seo', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ target_url: this.auditUrl })
            })
            .then(res => res.json())
            .then(data => {
                this.auditLoading = false;
                if (data.success) {
                    this.auditResult = data;
                } else {
                    this.auditError = data.message || 'Audit gagal dijalankan.';
                }
            })
            .catch(err => {
                this.auditLoading = false;
                this.auditError = 'Koneksi ke server gagal.';
            });
        }
     }">

    <!-- Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <!-- Brand Logo -->
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/25">
                    <i class="fa-solid fa-crown text-lg text-amber-300"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Member Area</h2>
                    <span class="text-[11px] text-amber-400 font-bold">VIP SEO Portal</span>
                </div>
            </div>

            <!-- Navigation Links -->
            <nav class="space-y-1.5 pt-4">
                <a href="/user/dashboard.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-house w-4 text-center"></i>
                    <span>Dashboard Utama</span>
                </a>

                <a href="/user/projects.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-layer-group w-4 text-center"></i>
                        <span>Daftar Project Saya</span>
                    </div>
                    <i class="fa-solid fa-angle-right text-[10px]"></i>
                </a>

                <a href="/user/tunnel.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-network-wired w-4 text-center text-amber-400"></i>
                        <span>Tunnel & Sitemap</span>
                    </div>
                    <span class="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">Auto</span>
                </a>

                <a href="/user/vip_seo.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-wand-magic-sparkles w-4 text-center text-amber-300"></i>
                        <span>VIP SEO Suite</span>
                    </div>
                    <span class="px-1.5 py-0.5 rounded-full bg-amber-500/30 text-amber-200 text-[9px] font-black">VIP</span>
                </a>

                <a href="/user/dashboard.php?tab=news" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-newspaper w-4 text-center"></i>
                        <span>Berita & Pengumuman</span>
                    </div>
                </a>
            </nav>
        </div>

        <!-- Sidebar Footer -->
        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <a href="/auth/logout.php" class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </a>
        </div>
    </aside>

    <!-- Main Workspace Content -->
    <div class="flex-1 flex flex-col min-w-0">
        
        <!-- Header -->
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-black uppercase border border-amber-500/30">SUITE EKSKLUSIF</span>
                    <h1 class="font-bold text-base text-white leading-none">VIP SEO & Code Suite</h1>
                </div>
            </div>

            <div class="flex items-center gap-3">
                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold">
                    <i class="fa-solid fa-crown text-[10px]"></i> VIP Ultra-Rank Active
                </span>
            </div>
        </header>

        <!-- Main Body -->
        <main class="flex-1 p-4 lg:p-8 max-w-6xl w-full mx-auto space-y-8">
            
            <!-- VIP Hero Banner -->
            <div class="p-6 lg:p-8 rounded-3xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/60 border border-amber-500/30 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
                <div class="space-y-2">
                    <div class="flex items-center gap-2">
                        <span class="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-extrabold uppercase tracking-wide">
                            Fitur Premium Rp 4.000.000 / Bulan
                        </span>
                        <span class="text-xs text-slate-400">• Standar Algoritma Google 2026</span>
                    </div>
                    <h2 class="text-2xl lg:text-3xl font-black text-white">VIP SEO & Clean Code Engine</h2>
                    <p class="text-slate-400 text-xs sm:text-sm max-w-xl leading-relaxed">
                        Optimalkan kode sumber, bersihkan sisa tracker kompetitor, suntikkan Schema Bintang 5 instan, dan percepat perayapan Googlebot dengan 1-klik Pinger.
                    </p>
                </div>

                <div class="flex items-center gap-3">
                    <button @click="activeTab = 'optimizer'" 
                            :class="activeTab === 'optimizer' ? 'bg-amber-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-300'"
                            class="px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md">
                        <i class="fa-solid fa-code"></i> Code Optimizer
                    </button>
                    <button @click="activeTab = 'pinger'" 
                            :class="activeTab === 'pinger' ? 'bg-amber-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-300'"
                            class="px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md">
                        <i class="fa-solid fa-bolt"></i> Fast Pinger & Audit
                    </button>
                </div>
            </div>

            <!-- TAB 1: VIP CODE OPTIMIZER & SCHEMA INJECTOR -->
            <div x-show="activeTab === 'optimizer'" class="space-y-6">
                <div class="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900/60 space-y-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-base font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-wand-magic-sparkles text-amber-400"></i> Pembersih Kode & Schema Bintang 5 Otomatis
                            </h3>
                            <p class="text-xs text-slate-400 mt-0.5">Tempel kode HTML atau AMP Anda di bawah untuk dibersihkan secara instan.</p>
                        </div>
                        <template x-if="codeStats">
                            <span class="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full font-mono font-bold">
                                Hemat: <span x-text="codeStats.saved"></span> (<span x-text="codeStats.cleanSize"></span>)
                            </span>
                        </template>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Input Raw Code -->
                        <div class="space-y-2">
                            <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Kode Sumber Awal (Raw HTML/AMP)</label>
                            <textarea x-model="rawCodeInput" rows="12"
                                      placeholder="Tempel kode HTML di sini (bisa berisi komentar, whitespace, atau tag template)..."
                                      class="w-full p-3.5 bg-slate-950 border border-slate-800 rounded-2xl text-slate-200 font-mono text-xs focus:outline-none focus:border-amber-500/50 resize-none"></textarea>
                        </div>

                        <!-- Output Clean Code -->
                        <div class="space-y-2">
                            <div class="flex items-center justify-between">
                                <label class="block text-xs font-semibold text-amber-300 uppercase tracking-wider">Hasil Bersih & Terverifikasi (VIP)</label>
                                <button type="button" @click="navigator.clipboard.writeText(cleanCodeOutput); alert('Kode berhasil disalin!')" 
                                        x-show="cleanCodeOutput"
                                        class="text-[11px] text-amber-400 hover:text-white font-bold cursor-pointer">
                                    <i class="fa-regular fa-copy mr-1"></i> Salin Kode
                                </button>
                            </div>
                            <textarea x-model="cleanCodeOutput" readonly rows="12"
                                      placeholder="Kode yang dioptimalkan, bersih dari syntax sisa, dan disuntikkan Schema.org AggregateRating akan muncul di sini..."
                                      class="w-full p-3.5 bg-slate-950 border border-amber-500/30 rounded-2xl text-amber-100 font-mono text-xs focus:outline-none resize-none"></textarea>
                        </div>
                    </div>

                    <div class="flex items-center justify-end gap-3 pt-2">
                        <button type="button" @click="rawCodeInput = ''; cleanCodeOutput = ''; codeStats = null;" class="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold">
                            Reset
                        </button>
                        <button type="button" @click="optimizeCode()" 
                                :disabled="isOptimizing || !rawCodeInput.trim()"
                                class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-brand-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 hover:opacity-95 transition-all flex items-center gap-2 cursor-pointer">
                            <i class="fa-solid fa-bolt-lightning"></i>
                            <span x-text="isOptimizing ? 'Memproses...' : 'Optimalkan & Suntikkan Schema 5-Star'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- TAB 2: VIP FAST PINGER & SEO AUDIT -->
            <div x-show="activeTab === 'pinger'" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <!-- Fast Pinger Widget -->
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900/60 space-y-4">
                        <div>
                            <span class="text-[10px] font-bold text-amber-400 uppercase bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">INDEXNOW API</span>
                            <h3 class="text-base font-bold text-white mt-1">Google & Bing Fast Index Pinger</h3>
                            <p class="text-xs text-slate-400 mt-1">Kirim sinyal perayapan kilat agar halaman baru Anda segera dirayapi mesin pencari.</p>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-xs font-semibold text-slate-300">URL Halaman atau Sitemap</label>
                            <input type="url" x-model="pingUrl" placeholder="https://domainanda.com/sitemap.xml" 
                                   class="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 text-xs font-mono focus:outline-none focus:border-amber-500/50">
                        </div>

                        <div x-show="pingError" class="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs" x-text="pingError"></div>

                        <button type="button" @click="sendFastPing()" :disabled="pingLoading"
                                class="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer">
                            <i class="fa-solid fa-paper-plane"></i>
                            <span x-text="pingLoading ? 'Mengirim Sinyal Pinger...' : 'Kirim Sinyal Ping ke Google & Bing'"></span>
                        </button>

                        <!-- Ping Success Result -->
                        <template x-if="pingResult">
                            <div class="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs space-y-2">
                                <div class="flex items-center justify-between font-bold text-emerald-300">
                                    <span><i class="fa-solid fa-circle-check mr-1.5"></i> Sinyal Terkirim!</span>
                                    <span class="font-mono text-[10px]" x-text="pingResult.timestamp"></span>
                                </div>
                                <div class="text-[11px] text-slate-300 space-y-1">
                                    <div>Google Pinger: <b class="text-white" x-text="pingResult.ping_results.google.status"></b> (HTTP <span x-text="pingResult.ping_results.google.http_code"></span>)</div>
                                    <div>Bing IndexNow: <b class="text-white" x-text="pingResult.ping_results.bing.status"></b> (HTTP <span x-text="pingResult.ping_results.bing.http_code"></span>)</div>
                                </div>
                            </div>
                        </template>
                    </div>

                    <!-- Instant SEO Quality Audit -->
                    <div class="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900/60 space-y-4">
                        <div>
                            <span class="text-[10px] font-bold text-sky-400 uppercase bg-sky-500/10 px-2 py-0.5 rounded-md border border-sky-500/20">LIVE AUDITOR</span>
                            <h3 class="text-base font-bold text-white mt-1">SEO Quality & Schema Auditor</h3>
                            <p class="text-xs text-slate-400 mt-1">Analisis validitas tag canonical, relasi AMP, dan kelengkapan Schema JSON-LD.</p>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-xs font-semibold text-slate-300">URL Target yang Ingin Diuji</label>
                            <input type="url" x-model="auditUrl" placeholder="https://domainanda.com/landing-page" 
                                   class="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 text-xs font-mono focus:outline-none focus:border-sky-500/50">
                        </div>

                        <div x-show="auditError" class="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs" x-text="auditError"></div>

                        <button type="button" @click="auditSeo()" :disabled="auditLoading"
                                class="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer">
                            <i class="fa-solid fa-magnifying-glass-chart"></i>
                            <span x-text="auditLoading ? 'Menganalisis Kode...' : 'Jalankan Live Audit SEO'"></span>
                        </button>

                        <!-- Audit Result -->
                        <template x-if="auditResult">
                            <div class="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                                <div class="flex items-center justify-between">
                                    <span class="font-bold text-white">Skor Kelayakan SEO:</span>
                                    <span class="text-base font-black font-mono" :class="auditResult.seo_score >= 80 ? 'text-emerald-400' : 'text-amber-400'" x-text="auditResult.seo_score + ' / 100'"></span>
                                </div>
                                <div class="space-y-1 text-[11px] text-slate-300 pt-1 border-t border-slate-800/80">
                                    <div class="flex items-center justify-between">
                                        <span>Format Google AMP:</span>
                                        <b :class="auditResult.is_amp ? 'text-emerald-400' : 'text-slate-400'" x-text="auditResult.is_amp ? 'Valid ⚡' : 'LP Biasa'"></b>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <span>Schema JSON-LD:</span>
                                        <b :class="auditResult.has_schema_jsonld ? 'text-emerald-400' : 'text-rose-400'" x-text="auditResult.has_schema_jsonld ? 'Terdeteksi' : 'Tidak Ada'"></b>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <span>Schema Review / Rating:</span>
                                        <b :class="auditResult.has_review_schema ? 'text-emerald-400' : 'text-rose-400'" x-text="auditResult.has_review_schema ? '5-Star Ready' : 'Belum Ada'"></b>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>

                </div>
            </div>

        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
