<?php
// user/projects.php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/tunnel_helper.php';
require_login();

$user = current_user();

// Fetch news count for sidebar
$stmtNews = $pdo->query("SELECT COUNT(*) as count FROM news");
$newsCount = $stmtNews->fetch()['count'];

// Handle Form Actions (Create, Delete, Toggle Publish)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        set_flash('error', 'Validasi token CSRF gagal.');
        header('Location: /user/projects.php');
        exit;
    }

    $action = $_POST['action'] ?? '';

    // Action 1: Create New Project
    if ($action === 'create_project') {
        $name = trim($_POST['name'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $type = in_array($_POST['type'] ?? '', ['amp', 'lp']) ? $_POST['type'] : 'amp';

        $template_id = intval($_POST['template_id'] ?? 1);

        if (empty($slug)) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        }

        if (empty($name) || empty($slug)) {
            set_flash('error', 'Nama project dan slug wajib diisi.');
        } else {
            // Check slug uniqueness
            $stmtCheck = $pdo->prepare("SELECT id FROM projects WHERE slug = ?");
            $stmtCheck->execute([$slug]);
            if ($stmtCheck->fetch()) {
                $slug = $slug . '-' . rand(100, 999);
            }

            $stmtIns = $pdo->prepare("INSERT INTO projects 
                (user_id, name, slug, type, template_id, canonical_url, amp_url, banner_url, logo_url, title, meta_description, article_content, faq_json, reviews_json, status) 
                VALUES (?, ?, ?, ?, ?, '', '', '', '', '', '', '', '[]', '[]', 'draft')");

            $stmtIns->execute([
                $user['id'], $name, $slug, $type, $template_id
            ]);

            $newId = $pdo->lastInsertId();
            set_flash('success', 'Project baru "' . $name . '" berhasil dibuat! Silakan edit di Builder.');
            header('Location: /user/builder.php?id=' . $newId);
            exit;
        }
    }

    // Action 2: Delete Project
    if ($action === 'delete_project') {
        $projId = intval($_POST['project_id'] ?? 0);
        $stmtDel = $pdo->prepare("DELETE FROM projects WHERE id = ? AND user_id = ?");
        $stmtDel->execute([$projId, $user['id']]);
        set_flash('success', 'Project berhasil dihapus.');
        header('Location: /user/projects.php');
        exit;
    }

    // Action 3: Toggle Publish Status 1-Klik
    if ($action === 'toggle_publish') {
        $projId = intval($_POST['project_id'] ?? 0);
        $stmtFetch = $pdo->prepare("SELECT status, name FROM projects WHERE id = ? AND user_id = ?");
        $stmtFetch->execute([$projId, $user['id']]);
        $proj = $stmtFetch->fetch();

        if ($proj) {
            $newStatus = $proj['status'] === 'published' ? 'draft' : 'published';
            $stmtUpd = $pdo->prepare("UPDATE projects SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmtUpd->execute([$newStatus, $projId]);

            $statusText = $newStatus === 'published' ? 'diterbitkan 1-klik!' : 'diubah menjadi Draft.';
            set_flash('success', 'Project "' . $proj['name'] . '" berhasil ' . $statusText);
        }
        header('Location: /user/projects.php');
        exit;
    }

    // Action 4: Set as Tunnel & Index Template
    if ($action === 'set_as_tunnel_template') {
        $projId = intval($_POST['project_id'] ?? 0);
        $stmtFetch = $pdo->prepare("SELECT id, name FROM projects WHERE id = ? AND user_id = ?");
        $stmtFetch->execute([$projId, $user['id']]);
        $proj = $stmtFetch->fetch();

        if ($proj) {
            save_tunnel_settings($pdo, [
                'tunnel_template_mode' => 'project',
                'tunnel_project_id'    => strval($projId)
            ]);
            set_flash('success', 'Halaman Index & Tunnel berhasil diubah untuk mengikuti project "' . $proj['name'] . '"!');
        }
        header('Location: /user/projects.php');
        exit;
    }
}

// Fetch user projects
$stmtList = $pdo->prepare("SELECT projects.*, templates.name as template_name FROM projects LEFT JOIN templates ON projects.template_id = templates.id WHERE projects.user_id = ? ORDER BY projects.id DESC");
$stmtList->execute([$user['id']]);
$projects = $stmtList->fetchAll();

// Fetch current Tunnel settings
$tunnelSettings = get_tunnel_settings($pdo);
$activeTunnelProjId = intval($tunnelSettings['tunnel_project_id'] ?? 0);
$isProjectMode = ($tunnelSettings['tunnel_template_mode'] ?? 'project') === 'project';

// Fetch templates for project creation modal
$stmtTpl = $pdo->query("SELECT id, name, type FROM templates ORDER BY type ASC, name ASC");
$templates = $stmtTpl->fetchAll();

$initialTemplateId = intval($_GET['use_template'] ?? 0);
$initialType = in_array($_GET['type'] ?? '', ['amp', 'lp']) ? $_GET['type'] : '';
if ($initialTemplateId > 0 && empty($initialType)) {
    foreach ($templates as $t) {
        if ($t['id'] == $initialTemplateId) {
            $initialType = $t['type'] ?? 'amp';
            break;
        }
    }
}
$autoOpenModal = $initialTemplateId > 0;

// Fetch site domain setting
$stmtDom = $pdo->prepare("SELECT value FROM settings WHERE key = 'site_domain'");
$stmtDom->execute();
$siteDomain = $stmtDom->fetchColumn() ?: 'http://localhost:8000';

$pageTitle = 'Daftar Project Saya';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" x-data="{ 
    sidebarOpen: false, 
    modalNewProject: <?= $autoOpenModal ? 'true' : 'false' ?>,
    selectedType: '<?= $initialType ?: 'amp' ?>',
    selectedTemplateId: '<?= $initialTemplateId ?: '' ?>'
}">
    
    <!-- Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/25">
                    <i class="fa-solid fa-cube text-lg"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Member Area</h2>
                    <span class="text-[11px] text-slate-400">Portal Pengguna</span>
                </div>
            </div>

            <nav class="space-y-1.5 pt-4">
                <a href="/user/dashboard.php?tab=overview" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-house w-4 text-center"></i>
                    <span>Dashboard Utama</span>
                </a>

                <a href="/user/projects.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-layer-group w-4 text-center"></i>
                        <span>Daftar Project Saya</span>
                    </div>
                    <i class="fa-solid fa-angle-right text-[10px]"></i>
                </a>

                <a href="/user/tunnel.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-network-wired w-4 text-center text-amber-400"></i>
                        <span>Tunnel & Sitemap</span>
                    </div>
                    <span class="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">Auto</span>
                </a>

                <a href="/user/dashboard.php?tab=news" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-newspaper w-4 text-center"></i>
                        <span>Berita & Pengumuman</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= $newsCount ?></span>
                </a>

                <a href="/user/dashboard.php?tab=profile" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-regular fa-id-card w-4 text-center"></i>
                    <span>Profil Saya</span>
                </a>
            </nav>

            <?php if ($user['role'] === 'admin'): ?>
                <div class="pt-6 border-t border-slate-800/80">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-amber-400/90 block mb-2 px-1">Akses Khusus Admin</span>
                    <a href="/admin/dashboard.php" class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 hover:text-amber-200 text-xs font-semibold transition-all group">
                        <div class="flex items-center gap-3">
                            <i class="fa-solid fa-shield-halved text-amber-400 group-hover:rotate-12 transition-transform"></i>
                            <span>Ke Dashboard Admin</span>
                        </div>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <button type="button" 
                    @click="customConfirm({
                        title: 'Konfirmasi Keluar',
                        message: 'Apakah Anda yakin ingin keluar dari sistem?',
                        variant: 'warning',
                        icon: 'fa-arrow-right-from-bracket',
                        confirmText: 'Ya, Keluar',
                        onConfirm: () => window.location.href = '/auth/logout.php'
                    })"
                    class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </button>
        </div>
    </aside>

    <!-- Main Workspace -->
    <div class="flex-1 flex flex-col min-w-0">
        
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <h1 class="font-bold text-base text-white leading-none">Daftar Project Saya</h1>
            </div>

            <button @click="modalNewProject = true" class="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-lg shadow-brand-500/20 flex items-center gap-2 cursor-pointer">
                <i class="fa-solid fa-plus"></i> Buat Project Baru
            </button>
        </header>

        <main class="flex-1 p-4 lg:p-8 max-w-6xl w-full mx-auto space-y-8">
            
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                    <h2 class="text-xl font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-folder-open text-brand-400"></i> Kelola Project Landing Page & AMP
                    </h2>
                    <p class="text-xs text-slate-400 mt-1">Gunakan Landing Page & AMP Builder untuk mengedit link canonical, banner, serta konten AI</p>
                </div>
                <span class="px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-300 text-xs font-semibold">
                    Total: <?= count($projects) ?> Project
                </span>
            </div>

            <!-- Project Cards Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php if (empty($projects)): ?>
                    <div class="col-span-2 p-12 text-center text-slate-500 text-sm glass-card rounded-3xl space-y-4">
                        <i class="fa-solid fa-folder-plus text-4xl text-slate-600 block"></i>
                        <p>Belum ada project yang dibuat. Klik tombol di bawah untuk membuat project pertama Anda!</p>
                        <button @click="modalNewProject = true" class="px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-lg shadow-brand-500/20 inline-flex items-center gap-2">
                            <i class="fa-solid fa-plus"></i> Buat Project Pertama
                        </button>
                    </div>
                <?php else: ?>
                    <?php foreach ($projects as $p): ?>
                        <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4 flex flex-col justify-between hover:border-slate-700 transition-all">
                            <div class="space-y-3">
                                <div class="flex items-center justify-between">
                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider <?= $p['type'] === 'amp' ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20' : 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20' ?>">
                                        <i class="fa-solid <?= $p['type'] === 'amp' ? 'fa-bolt' : 'fa-globe' ?> mr-1"></i> <?= strtoupper($p['type']) ?> BUILDER
                                    </span>

                                    <div class="flex items-center gap-1.5 flex-wrap justify-end">
                                        <!-- Google Purified Badge -->
                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-semibold" title="Bebas pelacak & copyright, Schema.org SEO valid">
                                            <i class="fa-solid fa-shield-halved text-[9px]"></i> Google Purified
                                        </span>

                                        <!-- Status Badge -->
                                        <?php if ($p['status'] === 'published'): ?>
                                            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                                                <i class="fa-solid fa-circle text-[6px] text-emerald-400 animate-pulse"></i> Published
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-400 text-xs font-semibold">
                                                Draft
                                            </span>
                                        <?php endif; ?>

                                        <!-- Active Tunnel Template Badge -->
                                        <?php if ($isProjectMode && $activeTunnelProjId == $p['id']): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-bold" title="Project ini digunakan sebagai tampilan aktif Index & Tunnel">
                                                <i class="fa-solid fa-star text-amber-400 text-[9px]"></i> Template Index & Tunnel Aktif
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div>
                                    <h3 class="text-lg font-bold text-white"><?= e($p['name']) ?></h3>
                                    <div class="flex items-center gap-2 mt-0.5">
                                        <span class="text-xs text-brand-400 font-mono">/s/<?= e($p['slug']) ?></span>
                                        <span class="text-[10px] text-slate-500 font-mono">(atau /p.php?s=<?= e($p['slug']) ?>)</span>
                                    </div>
                                </div>

                                <p class="text-xs text-slate-400 line-clamp-2"><?= e($p['title']) ?></p>

                                <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-800/80 space-y-1 text-[11px] font-mono text-slate-400">
                                    <div class="truncate"><strong class="text-slate-500">Template:</strong> <?= e($p['template_name'] ?? 'Custom/Unknown') ?></div>
                                    <div class="truncate"><strong class="text-slate-500">Canonical:</strong> <?= e($p['canonical_url']) ?></div>
                                    <div class="truncate"><strong class="text-slate-500">AMP URL:</strong> <?= e($p['amp_url']) ?></div>
                                </div>
                            </div>

                            <!-- Actions Footer -->
                            <div class="pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                                <div class="flex items-center gap-2 flex-wrap">
                                    <!-- Salin Link Publik (Purified) -->
                                    <button type="button" 
                                            @click="
                                                const pubUrl = window.location.origin + '/s/<?= e($p['slug']) ?>';
                                                navigator.clipboard.writeText(pubUrl);
                                                showToast('success', 'Link Publik Purified berhasil disalin: ' + pubUrl);
                                            "
                                            title="Salin link publik untuk dikirim ke orang lain"
                                            class="px-3 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer">
                                        <i class="fa-solid fa-share-nodes text-emerald-400"></i>
                                        <span>Salin Link Publik (Purified)</span>
                                    </button>

                                    <!-- Edit in Builder -->
                                    <a href="/user/builder.php?id=<?= $p['id'] ?>" 
                                       class="px-3 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-all">
                                        <i class="fa-solid fa-pen-to-square"></i> Open Builder
                                    </a>

                                    <!-- Preview Link -->
                                    <a href="/p.php?s=<?= e($p['slug']) ?>" target="_blank"
                                       class="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-all">
                                        <i class="fa-solid fa-eye"></i> Live Preview
                                    </a>

                                    <!-- Unduh ZIP Installer Mandiri (LP / AMP) -->
                                    <a href="/api/export_package.php?type=<?= $p['type'] ?>&id=<?= $p['id'] ?>" 
                                       title="Unduh paket ZIP installer mandiri (index.html, .htaccess, panduan). Otomatis terhapus setelah 24 jam."
                                       class="px-3 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer">
                                        <i class="fa-solid fa-file-zipper text-indigo-400"></i>
                                        <span>Unduh ZIP (<?= strtoupper($p['type']) ?>)</span>
                                    </a>
                                </div>

                                <div class="flex items-center gap-2 flex-wrap">
                                    <!-- Set as Tunnel Template 1-Klik -->
                                    <?php if (!$isProjectMode || $activeTunnelProjId != $p['id']): ?>
                                        <form action="/user/projects.php" method="POST" class="inline">
                                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                            <input type="hidden" name="action" value="set_as_tunnel_template">
                                            <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
                                            <button type="submit" 
                                                    title="Gunakan tampilan LP ini untuk halaman Index & Tunnel"
                                                    class="px-3 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer">
                                                <i class="fa-solid fa-bolt-lightning text-amber-400"></i> 
                                                <span>Set ke Index & Tunnel</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                    <!-- Toggle Publish 1-Klik -->
                                    <form action="/user/projects.php" method="POST" class="inline">
                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                        <input type="hidden" name="action" value="toggle_publish">
                                        <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
                                        <button type="submit" 
                                                title="<?= $p['status'] === 'published' ? 'Set to Draft' : 'Publish 1-Klik' ?>"
                                                class="px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer <?= $p['status'] === 'published' ? 'bg-slate-800 border-slate-700 text-amber-400' : 'bg-emerald-600/20 hover:bg-emerald-600/30 border-emerald-500/30 text-emerald-300' ?>">
                                            <i class="fa-solid <?= $p['status'] === 'published' ? 'fa-globe-slash' : 'fa-rocket' ?>"></i> 
                                            <span><?= $p['status'] === 'published' ? 'Unpublish' : 'Publish 1-Klik' ?></span>
                                        </button>
                                    </form>

                                    <!-- Delete Project -->
                                    <form action="/user/projects.php" method="POST" class="inline"
                                          @submit.prevent="customConfirm({
                                              title: 'Hapus Project',
                                              message: 'Apakah Anda yakin ingin menghapus project <?= e($p['name']) ?>?',
                                              variant: 'danger',
                                              icon: 'fa-trash',
                                              confirmText: 'Ya, Hapus',
                                              onConfirm: () => $el.submit()
                                          })">
                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                        <input type="hidden" name="action" value="delete_project">
                                        <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
                                        <button type="submit" class="p-2 rounded-xl bg-slate-800 hover:bg-rose-600/20 text-rose-400 hover:text-rose-300 border border-slate-700 text-xs transition-all cursor-pointer">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

        </main>
    </div>

    <!-- MODAL: Buat Project Baru -->
    <div x-show="modalNewProject" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" 
         x-cloak>
        
        <div @click.away="modalNewProject = false" 
             class="glass-card w-full max-w-lg p-6 rounded-3xl border border-slate-700 shadow-2xl space-y-6">
            
            <div class="flex items-center justify-between border-b border-slate-800 pb-4">
                <h3 class="text-lg font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-plus text-brand-400"></i> Buat Project Baru
                </h3>
                <button @click="modalNewProject = false" class="text-slate-400 hover:text-white">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <form action="/user/projects.php" method="POST" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="create_project">
                
                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Nama Project</label>
                    <input type="text" name="name" required placeholder="Contoh: Slot Gacor 2026"
                           class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Custom Slug URL</label>
                    <input type="text" name="slug" placeholder="slot-gacor-2026 (Opsional)"
                           class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm font-mono focus:outline-none focus:border-brand-500">
                    <p class="text-[11px] text-slate-500 mt-1">Kosongkan untuk otomatis membuat slug dari nama project.</p>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Tipe Project</label>
                    <select name="type" x-model="selectedType" class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        <option value="amp">⚡ Google AMP Page (Kecepatan Maksimal & Mobile SEO)</option>
                        <option value="lp">🌐 Landing Page Standar (LP / HTML5 Bebas)</option>
                    </select>
                    <p class="text-[11px] text-slate-500 mt-1" x-text="selectedType === 'amp' ? '⚡ Format AMP resmi dengan validasi kilat dan SEO mobile optimal.' : '🌐 Format Landing Page HTML5 dengan kebebasan script dan animasi penuh.'"></p>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Pilihan Template Website</label>
                    <select name="template_id" x-model="selectedTemplateId" required class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500 font-sans">
                        <option value="" disabled>-- Pilih Template Yang Sesuai --</option>
                        
                        <optgroup label="⚡ Kategori: Google AMP Templates">
                            <?php foreach ($templates as $t): if (($t['type'] ?? 'amp') === 'amp'): ?>
                                <option value="<?= $t['id'] ?>" :class="selectedType === 'lp' ? 'text-slate-500' : 'text-slate-100'">
                                    [AMP] <?= e($t['name']) ?>
                                </option>
                            <?php endif; endforeach; ?>
                        </optgroup>

                        <optgroup label="🌐 Kategori: Landing Page (LP) Templates">
                            <?php foreach ($templates as $t): if (($t['type'] ?? 'amp') === 'lp'): ?>
                                <option value="<?= $t['id'] ?>" :class="selectedType === 'amp' ? 'text-slate-500' : 'text-slate-100'">
                                    [LP] <?= e($t['name']) ?>
                                </option>
                            <?php endif; endforeach; ?>
                        </optgroup>
                    </select>
                    <p class="text-[11px] text-slate-500 mt-1">Pilihlah template bertanda <span class="text-amber-400 font-semibold">[AMP]</span> untuk AMP, atau <span class="text-blue-400 font-semibold">[LP]</span> untuk Landing Page.</p>
                </div>

                <div class="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
                    <button type="button" @click="modalNewProject = false" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700">
                        Batal
                    </button>
                    <button type="submit" class="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold shadow-lg shadow-brand-500/20">
                        Buat & Buka Builder
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
