<?php
// user/templates.php
require_once __DIR__ . '/../includes/auth.php';
require_login();

$user = current_user();

// Fetch templates from database
$stmtTpl = $pdo->query("SELECT * FROM templates ORDER BY id DESC");
$templates = $stmtTpl->fetchAll();

$ampCount = 0;
$lpCount = 0;
foreach ($templates as $t) {
    if (($t['type'] ?? 'amp') === 'amp') $ampCount++;
    else $lpCount++;
}

$pageTitle = 'Template Manager — Galeri AMP & LP';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" x-data="{ sidebarOpen: false, filterType: 'all' }">
    
    <!-- Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/25">
                    <i class="fa-solid fa-cube text-lg"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Member Area</h2>
                    <span class="text-[11px] text-slate-400">Portal Pengguna</span>
                </div>
            </div>

            <nav class="space-y-1.5 pt-4">
                <a href="/user/dashboard.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-house w-4 text-center"></i>
                    <span>Dashboard Utama</span>
                </a>

                <a href="/user/projects.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-layer-group w-4 text-center"></i>
                    <span>Daftar Project Saya</span>
                </a>

                <a href="/user/templates.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold text-xs transition-all text-left">
                    <i class="fa-solid fa-table-cells-large w-4 text-center"></i>
                    <span>Template Manager</span>
                </a>
            </nav>

            <?php if ($user['role'] === 'admin'): ?>
                <div class="pt-6 border-t border-slate-800/80">
                    <a href="/admin/dashboard.php" class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold">
                        <div class="flex items-center gap-3">
                            <i class="fa-solid fa-shield-halved text-amber-400"></i>
                            <span>Ke Dashboard Admin</span>
                        </div>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <button type="button" 
                    @click="customConfirm({
                        title: 'Konfirmasi Keluar',
                        message: 'Apakah Anda yakin ingin keluar dari sistem?',
                        variant: 'warning',
                        icon: 'fa-arrow-right-from-bracket',
                        confirmText: 'Ya, Keluar',
                        onConfirm: () => window.location.href = '/auth/logout.php'
                    })"
                    class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </button>
        </div>
    </aside>

    <!-- Main Workspace -->
    <div class="flex-1 flex flex-col min-w-0">
        
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <h1 class="font-bold text-base text-white leading-none">Template Manager</h1>
            </div>

            <a href="/user/projects.php" class="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-lg shadow-brand-500/20 flex items-center gap-2">
                <i class="fa-solid fa-plus"></i> Buat Project Baru
            </a>
        </header>

        <main class="flex-1 p-4 lg:p-8 max-w-6xl w-full mx-auto space-y-8">
            
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                <div>
                    <h2 class="text-xl font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-palette text-brand-400"></i> Galeri Template Khusus AMP & Landing Page
                    </h2>
                    <p class="text-xs text-slate-400 mt-1">Pilih template berkecepatan tinggi, tervalidasi Google AMP atau Landing Page (LP) HTML5</p>
                </div>

                <!-- Tabs Filter Khusus AMP vs LP -->
                <div class="flex items-center gap-2 p-1.5 bg-slate-900 rounded-2xl border border-slate-800 self-start md:self-auto">
                    <button @click="filterType = 'all'" 
                            :class="filterType === 'all' ? 'bg-brand-600 text-white shadow-lg shadow-brand-500/25 font-bold' : 'text-slate-400 hover:text-white'"
                            class="px-3.5 py-1.5 rounded-xl text-xs transition-all flex items-center gap-2">
                        <i class="fa-solid fa-border-all text-[11px]"></i>
                        <span>Semua</span>
                        <span class="px-1.5 py-0.2 rounded-full text-[10px]" :class="filterType === 'all' ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'"><?= count($templates) ?></span>
                    </button>

                    <button @click="filterType = 'amp'" 
                            :class="filterType === 'amp' ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/25' : 'text-slate-400 hover:text-amber-300'"
                            class="px-3.5 py-1.5 rounded-xl text-xs transition-all flex items-center gap-2">
                        <i class="fa-solid fa-bolt text-[11px]"></i>
                        <span>Google AMP</span>
                        <span class="px-1.5 py-0.2 rounded-full text-[10px]" :class="filterType === 'amp' ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'"><?= $ampCount ?></span>
                    </button>

                    <button @click="filterType = 'lp'" 
                            :class="filterType === 'lp' ? 'bg-blue-600 text-white font-bold shadow-lg shadow-blue-500/25' : 'text-slate-400 hover:text-blue-300'"
                            class="px-3.5 py-1.5 rounded-xl text-xs transition-all flex items-center gap-2">
                        <i class="fa-solid fa-globe text-[11px]"></i>
                        <span>Landing Page (LP)</span>
                        <span class="px-1.5 py-0.2 rounded-full text-[10px]" :class="filterType === 'lp' ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'"><?= $lpCount ?></span>
                    </button>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                <?php if (empty($templates)): ?>
                    <div class="col-span-full py-12 text-center glass-card rounded-3xl border border-slate-800">
                        <i class="fa-solid fa-layer-group text-4xl text-slate-600 mb-3"></i>
                        <p class="text-slate-400 text-sm">Belum ada template tersedia.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($templates as $tpl): 
                        $tType = $tpl['type'] ?? 'amp';
                        $isAmp = ($tType === 'amp');
                    ?>
                        <div x-show="filterType === 'all' || filterType === '<?= $tType ?>'" 
                             x-transition
                             class="glass-card rounded-3xl border border-slate-800 overflow-hidden hover:border-slate-700 transition-all flex flex-col justify-between group">
                            
                            <div class="space-y-4">
                                <!-- Card Header Graphic -->
                                <div class="h-44 relative overflow-hidden border-b border-slate-800 p-5 flex flex-col justify-between <?= $isAmp ? 'bg-gradient-to-br from-amber-950/40 via-slate-950 to-slate-900' : 'bg-gradient-to-br from-blue-950/40 via-slate-950 to-indigo-950' ?>">
                                    <div class="flex items-center justify-between">
                                        <?php if ($isAmp): ?>
                                            <span class="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase tracking-wider border border-amber-500/40 flex items-center gap-1.5 shadow-sm">
                                                <i class="fa-solid fa-bolt text-amber-400"></i> GOOGLE AMP
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold uppercase tracking-wider border border-blue-500/40 flex items-center gap-1.5 shadow-sm">
                                                <i class="fa-solid fa-globe text-blue-400"></i> LANDING PAGE (LP)
                                            </span>
                                        <?php endif; ?>

                                        <span class="text-[10px] font-mono text-slate-500 bg-slate-900/80 px-2 py-0.5 rounded-md border border-slate-800">
                                            #<?= $tpl['id'] ?>
                                        </span>
                                    </div>

                                    <div>
                                        <h3 class="text-base font-extrabold text-white group-hover:text-brand-300 transition-colors line-clamp-2">
                                            <?= e($tpl['name']) ?>
                                        </h3>
                                        <span class="text-[11px] <?= $isAmp ? 'text-amber-400/80' : 'text-blue-400/80' ?>">
                                            <?= $isAmp ? '⚡ Validasi Komponen AMP Resmi' : '🌐 HTML5 Standar Fleksibel' ?>
                                        </span>
                                    </div>
                                </div>

                                <div class="p-5 pt-0 space-y-3">
                                    <p class="text-xs text-slate-400 leading-relaxed line-clamp-3">
                                        <?= !empty($tpl['description']) ? e($tpl['description']) : ($isAmp ? 'Template optimalisasi kecepatan tinggi Google AMP dengan canonical switcher otomatis dan tombol CTA glow.' : 'Template Landing Page modern HTML5 responsif dengan struktur rapi dan konversi tinggi.') ?>
                                    </p>

                                    <!-- Feature Tags -->
                                    <div class="flex flex-wrap gap-1.5 pt-1">
                                        <?php if ($isAmp): ?>
                                            <span class="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 text-[10px] font-semibold border border-amber-500/20">
                                                <i class="fa-solid fa-bolt text-[9px] mr-1"></i> AMP Ready
                                            </span>
                                            <span class="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px] font-semibold">
                                                <i class="fa-solid fa-link text-indigo-400 text-[9px] mr-1"></i> Canonical
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-300 text-[10px] font-semibold border border-blue-500/20">
                                                <i class="fa-solid fa-code text-[9px] mr-1"></i> HTML5 LP
                                            </span>
                                            <span class="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px] font-semibold">
                                                <i class="fa-solid fa-mobile-screen text-emerald-400 text-[9px] mr-1"></i> Responsif
                                            </span>
                                        <?php endif; ?>
                                        <span class="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px] font-semibold">
                                            <i class="fa-solid fa-image text-purple-400 text-[9px] mr-1"></i> Icon & SEO
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="p-5 pt-0">
                                <a href="/user/projects.php?use_template=<?= $tpl['id'] ?>&type=<?= $tType ?>" 
                                   class="w-full py-2.5 rounded-xl <?= $isAmp ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow-amber-500/20' : 'bg-brand-600 hover:bg-brand-500 text-white font-semibold shadow-brand-500/20' ?> text-xs shadow-lg flex items-center justify-center gap-2 transition-all">
                                    <i class="fa-solid fa-wand-magic-sparkles"></i> Gunakan Template <?= $isAmp ? 'AMP' : 'LP' ?>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

            </div>

        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
