<?php
// user/dashboard.php
require_once __DIR__ . '/../includes/auth.php';
require_login();

$user = current_user();

// Ambil Berita & Pengumuman dari Database
$stmtNews = $pdo->query("SELECT id, title, content, category, author_name, created_at FROM news ORDER BY id DESC");
$latestNews = $stmtNews->fetchAll();

$pageTitle = 'Dashboard Member';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" 
     x-data="{ 
        sidebarOpen: false, 
        activeTab: new URLSearchParams(window.location.search).get('tab') || localStorage.getItem('userActiveTab') || 'overview' 
     }"
     x-init="$watch('activeTab', val => {
         localStorage.setItem('userActiveTab', val);
         window.history.replaceState(null, '', '?tab=' + val);
     })">
    
    <!-- Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <!-- Brand Logo -->
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/25">
                    <i class="fa-solid fa-cube text-lg"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Member Area</h2>
                    <span class="text-[11px] text-slate-400">Portal Pengguna</span>
                </div>
            </div>

            <!-- Navigation Links -->
            <nav class="space-y-1.5 pt-4">
                <button @click="activeTab = 'overview'" 
                        :class="activeTab === 'overview' ? 'bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-xs transition-all text-left">
                    <i class="fa-solid fa-house w-4 text-center"></i>
                    <span>Dashboard Utama</span>
                </button>

                <a href="/user/projects.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-layer-group w-4 text-center"></i>
                        <span>Daftar Project Saya</span>
                    </div>
                    <i class="fa-solid fa-angle-right text-[10px]"></i>
                </a>

                <a href="/user/tunnel.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-network-wired w-4 text-center text-amber-400"></i>
                        <span>Tunnel & Sitemap</span>
                    </div>
                    <span class="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">Auto</span>
                </a>

                <button @click="activeTab = 'news'" 
                        :class="activeTab === 'news' ? 'bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-newspaper w-4 text-center"></i>
                        <span>Berita & Pengumuman</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= count($latestNews) ?></span>
                </button>

                <button @click="activeTab = 'profile'" 
                        :class="activeTab === 'profile' ? 'bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-xs transition-all text-left">
                    <i class="fa-regular fa-id-card w-4 text-center"></i>
                    <span>Profil Saya</span>
                </button>
            </nav>

            <!-- Khusus Admin: Tombol Menuju Admin Dashboard -->
            <?php if ($user['role'] === 'admin'): ?>
                <div class="pt-6 border-t border-slate-800/80">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-amber-400/90 block mb-2 px-1">Akses Khusus Admin</span>
                    <a href="/admin/dashboard.php" 
                       class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 hover:text-amber-200 text-xs font-semibold transition-all group">
                        <div class="flex items-center gap-3">
                            <i class="fa-solid fa-shield-halved text-amber-400 group-hover:rotate-12 transition-transform"></i>
                            <span>Ke Dashboard Admin</span>
                        </div>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar Footer / Logout -->
        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <button type="button" 
                    @click="customConfirm({
                        title: 'Konfirmasi Keluar',
                        message: 'Apakah Anda yakin ingin keluar dari sistem?',
                        variant: 'warning',
                        icon: 'fa-arrow-right-from-bracket',
                        confirmText: 'Ya, Keluar',
                        onConfirm: () => window.location.href = '/auth/logout.php'
                    })"
                    class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </button>
        </div>
    </aside>

    <!-- Main Workspace Content -->
    <div class="flex-1 flex flex-col min-w-0">
        
        <!-- Top Navigation Bar -->
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <h1 class="font-bold text-base text-white leading-none">User Portal</h1>
            </div>

            <div class="flex items-center gap-3">
                <?php if ($user['role'] === 'admin'): ?>
                    <a href="/admin/dashboard.php" class="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:bg-amber-500/20 transition-all">
                        <i class="fa-solid fa-shield-cat"></i> Admin Mode
                    </a>
                <?php endif; ?>

                <div class="flex items-center gap-3 bg-slate-800/60 border border-slate-700/50 py-1 px-3 rounded-full">
                    <div class="w-7 h-7 rounded-full bg-brand-600/30 border border-brand-500/40 text-brand-300 font-bold flex items-center justify-center text-xs uppercase">
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    </div>
                    <span class="text-xs font-semibold text-slate-200"><?= e($user['name']) ?></span>
                </div>
            </div>
        </header>

        <!-- Dynamic Main Content Area -->
        <main class="flex-1 p-4 lg:p-8 max-w-6xl w-full mx-auto space-y-8">
            
            <!-- TAB 1: OVERVIEW -->
            <div x-show="activeTab === 'overview'" class="space-y-8">
                <!-- Welcome Banner -->
                <div class="p-6 lg:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/60 border border-slate-800 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
                    <div class="space-y-2">
                        <div class="flex flex-wrap items-center gap-2">
                            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold">
                                <i class="fa-solid fa-circle text-[8px] text-emerald-400 animate-pulse"></i> Sesi Login Aktif
                            </span>
                            <?php if ($user['role'] === 'admin'): ?>
                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
                                    <i class="fa-solid fa-crown text-[10px]"></i> Akses Administrator (Lifetime)
                                </span>
                            <?php elseif ($user['role'] === 'vpro'): ?>
                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/40 text-purple-300 text-xs font-bold">
                                    <i class="fa-solid fa-gem text-[10px]"></i> VPro Sultan Aktif (Unlimited)
                                </span>
                            <?php elseif ($user['role'] === 'vip'): ?>
                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold">
                                    <i class="fa-solid fa-crown text-[10px]"></i> VIP Ultra-Rank Aktif
                                </span>
                            <?php elseif ($user['role'] === 'trial7'): ?>
                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/20 border border-brand-500/40 text-brand-300 text-xs font-bold">
                                    <i class="fa-solid fa-calendar-check text-[10px]"></i> Paket 7 Hari Aktif
                                </span>
                            <?php elseif (is_trial_active($user)): ?>
                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
                                    <i class="fa-solid fa-clock text-[10px]"></i> Trial Gratis 1 Hari (24 Jam): <?= get_trial_time_remaining($user) ?> tersisa
                                </span>
                            <?php else: ?>
                                <a href="/user/billing.php" class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold hover:bg-rose-500/30 transition-all">
                                    <i class="fa-solid fa-triangle-exclamation text-[10px]"></i> Masa Trial Habis — Bayar / Upgrade
                                </a>
                            <?php endif; ?>
                        </div>
                        <h2 class="text-2xl lg:text-3xl font-extrabold text-white">Selamat Datang, <?= e($user['name']) ?>!</h2>
                        <p class="text-slate-400 text-sm max-w-lg">Anda berhasil masuk sebagai pengguna dengan role <span class="text-brand-300 font-semibold uppercase"><?= e($user['role']) ?></span>. Nikmati kemudahan builder LP & AMP tanpa batasan.</p>
                    </div>

                    <?php if ($user['role'] === 'admin'): ?>
                        <a href="/admin/dashboard.php" 
                           class="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-xl shadow-amber-500/10 flex items-center gap-2 transition-all whitespace-nowrap">
                            <i class="fa-solid fa-shield-halved"></i> Dashboard Admin
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Latest News Preview Widget -->
                <div class="space-y-4">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-newspaper text-brand-400"></i> Pengumuman & Berita Terbaru
                        </h3>
                        <button @click="activeTab = 'news'" class="text-xs text-brand-400 hover:text-brand-300 font-semibold cursor-pointer">Lihat Semua <i class="fa-solid fa-arrow-right text-[10px]"></i></button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <?php if (empty($latestNews)): ?>
                            <div class="col-span-2 p-8 text-center text-slate-500 text-sm glass-card rounded-2xl">Belum ada pengumuman terbaru.</div>
                        <?php else: ?>
                            <?php foreach (array_slice($latestNews, 0, 2) as $n): ?>
                                <div class="glass-card p-6 rounded-2xl border border-slate-800 space-y-3">
                                    <div class="flex items-center justify-between">
                                        <span class="px-2.5 py-0.5 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-300 text-[10px] font-semibold uppercase">
                                            <?= e($n['category']) ?>
                                        </span>
                                        <span class="text-[11px] text-slate-400"><?= date('d M Y', strtotime($n['created_at'])) ?></span>
                                    </div>
                                    <h4 class="font-bold text-slate-100 text-sm leading-snug"><?= e($n['title']) ?></h4>
                                    <p class="text-xs text-slate-400 line-clamp-2 leading-relaxed"><?= e($n['content']) ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- TAB 2: NEWS & ANNOUNCEMENTS -->
            <div x-show="activeTab === 'news'" class="space-y-6" style="display: none;">
                <div class="border-b border-slate-800 pb-4">
                    <h2 class="text-xl font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-bullhorn text-brand-400"></i> Berita & Informasi Resmi
                    </h2>
                    <p class="text-xs text-slate-400 mt-1">Dapatkan pembaruan sistem dan pengumuman terbaru</p>
                </div>

                <div class="space-y-4">
                    <?php if (empty($latestNews)): ?>
                        <div class="p-8 text-center text-slate-500 text-sm glass-card rounded-2xl">Belum ada berita atau pengumuman.</div>
                    <?php else: ?>
                        <?php foreach ($latestNews as $n): ?>
                            <div class="glass-card p-6 rounded-3xl border border-slate-800/80 space-y-3 hover:border-slate-700 transition-all">
                                <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/60 pb-3">
                                    <div class="flex items-center gap-2">
                                        <span class="px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-300 text-xs font-semibold">
                                            <?= e($n['category']) ?>
                                        </span>
                                        <span class="text-xs text-slate-400">Oleh: <strong class="text-slate-300"><?= e($n['author_name']) ?></strong></span>
                                    </div>
                                    <span class="text-xs text-slate-500"><i class="fa-regular fa-clock mr-1"></i><?= date('d M Y, H:i', strtotime($n['created_at'])) ?></span>
                                </div>
                                <h3 class="text-lg font-bold text-white"><?= e($n['title']) ?></h3>
                                <p class="text-sm text-slate-300 leading-relaxed"><?= nl2br(e($n['content'])) ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- TAB 3: PROFILE -->
            <div x-show="activeTab === 'profile'" class="space-y-6" style="display: none;">
                <div class="border-b border-slate-800 pb-4">
                    <h2 class="text-xl font-bold text-white flex items-center gap-2">
                        <i class="fa-regular fa-id-card text-brand-400"></i> Detail Profil Saya
                    </h2>
                    <p class="text-xs text-slate-400 mt-1">Informasi identitas dan status akun</p>
                </div>

                <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4 max-w-xl">
                    <div class="flex justify-between py-3 border-b border-slate-800">
                        <span class="text-xs text-slate-400">Nama Lengkap</span>
                        <span class="text-sm font-semibold text-white"><?= e($user['name']) ?></span>
                    </div>

                    <div class="flex justify-between py-3 border-b border-slate-800">
                        <span class="text-xs text-slate-400">Alamat Email</span>
                        <span class="text-sm font-mono text-indigo-300"><?= e($user['email']) ?></span>
                    </div>

                    <div class="flex justify-between py-3 border-b border-slate-800">
                        <span class="text-xs text-slate-400">Role / Hak Akses</span>
                        <span class="px-3 py-1 rounded-full text-xs font-bold uppercase <?= $user['role'] === 'admin' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' ?>">
                            <?= e($user['role']) ?>
                        </span>
                    </div>

                    <div class="flex justify-between py-3">
                        <span class="text-xs text-slate-400">Terdaftar Sejak</span>
                        <span class="text-xs text-slate-300"><?= date('d F Y, H:i', strtotime($user['created_at'])) ?></span>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
