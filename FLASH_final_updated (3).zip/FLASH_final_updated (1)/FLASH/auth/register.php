<?php
// auth/register.php
require_once __DIR__ . '/../includes/auth.php';

if (is_logged_in()) {
    header('Location: /user/dashboard.php');
    exit;
}

// Ambil konfigurasi bot Telegram dari settings
$stmtSet = $pdo->prepare("SELECT value FROM settings WHERE key = ?");
$stmtSet->execute(['telegram_bot_username']);
$tgBotUsername = $stmtSet->fetchColumn() ?: 'FlashOfficialBot';

$stmtSet->execute(['telegram_otp_enabled']);
$tgOtpRequired = ($stmtSet->fetchColumn() === '1');

$error = '';
$nameInput = '';
$emailInput = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nameInput = trim($_POST['name'] ?? '');
    $emailInput = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $token = $_POST['csrf_token'] ?? '';
    $tokenSync = trim($_POST['token_sync'] ?? '');
    $otpCode = trim($_POST['otp_code'] ?? '');

    if (!verify_csrf_token($token)) {
        $error = 'Validasi keamanan (CSRF Token) gagal. Silakan muat ulang halaman.';
    } elseif (empty($nameInput) || empty($emailInput) || empty($password)) {
        $error = 'Semua bidang wajib diisi.';
    } elseif (!filter_var($emailInput, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format alamat email tidak valid.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal harus 6 karakter.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Konfirmasi password tidak cocok.';
    } else {
        // Jika OTP token_sync diisi atau OTP diwajibkan sistem
        if (!empty($tokenSync) || $tgOtpRequired) {
            if (empty($tokenSync) || empty($otpCode)) {
                $error = 'Verifikasi kode OTP Telegram diperlukan untuk menyelesaikan pendaftaran.';
            } else {
                $stmtOtp = $pdo->prepare("SELECT * FROM telegram_otps WHERE token_sync = ? AND email = ? ORDER BY id DESC LIMIT 1");
                $stmtOtp->execute([$tokenSync, $emailInput]);
                $otpRow = $stmtOtp->fetch();

                if (!$otpRow) {
                    $error = 'Sesi verifikasi OTP Telegram tidak ditemukan untuk email ini.';
                } elseif (strtotime($otpRow['expires_at']) < time()) {
                    $error = 'Kode OTP Telegram telah kadaluarsa. Silakan minta kode baru.';
                } elseif ($otpRow['otp_code'] !== $otpCode) {
                    $error = 'Kode OTP salah. Pastikan Anda memasukkan 6 digit kode dari Bot Telegram.';
                } else {
                    // Tandai OTP telah digunakan
                    $pdo->prepare("UPDATE telegram_otps SET is_verified = 1 WHERE id = ?")->execute([$otpRow['id']]);
                }
            }
        }

        if (empty($error)) {
            // Cek apakah email sudah terdaftar
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$emailInput]);
            if ($stmt->fetch()) {
                $error = 'Email tersebut sudah terdaftar. Gunakan email lain.';
            } else {
                // Hash password dan simpan ke database dengan Trial 1 Hari (24 Jam) Gratis
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, trial_expires_at, created_at) VALUES (?, ?, ?, 'user', datetime('now', '+1 day'), datetime('now'))");
                
                if ($stmt->execute([$nameInput, $emailInput, $hashedPassword])) {
                    set_flash('success', 'Registrasi berhasil! Anda mendapatkan Masa Uji Coba (Trial) 1 Hari Gratis. Silakan masuk.');
                    header('Location: /auth/login.php');
                    exit;
                } else {
                    $error = 'Terjadi kesalahan sistem saat membuat akun. Coba lagi.';
                }
            }
        }
    }
}

$pageTitle = 'Daftar Akun Baru - FLASH';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen flex items-center justify-center px-4 py-12 relative overflow-hidden bg-slate-950"
     x-data="{ 
        showPass: false,
        useTelegramOtp: <?= $tgOtpRequired ? 'true' : 'false' ?>,
        botUsername: '<?= e($tgBotUsername) ?>',
        otpTokenSync: '',
        otpDeepLink: '',
        otpCodeInput: '',
        isRequestingOtp: false,
        otpSent: false,
        devCode: null,
        otpError: '',
        requestTelegramOtp() {
            const emailVal = document.getElementById('regEmail').value.trim();
            if (!emailVal || !emailVal.includes('@')) {
                this.otpError = 'Masukkan email yang valid terlebih dahulu untuk menerima kode OTP Telegram.';
                return;
            }
            this.otpError = '';
            this.isRequestingOtp = true;
            
            fetch('/api/telegram_otp.php?action=generate_token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ email: emailVal })
            })
            .then(res => res.json())
            .then(data => {
                this.isRequestingOtp = false;
                if (data.success) {
                    this.otpTokenSync = data.token_sync;
                    this.otpDeepLink = data.deep_link;
                    this.devCode = data.dev_code;
                    this.otpSent = true;
                    // Buka link bot otomatis di tab baru
                    window.open(data.deep_link, '_blank');
                } else {
                    this.otpError = data.message || 'Gagal membuat token OTP.';
                }
            })
            .catch(err => {
                this.isRequestingOtp = false;
                this.otpError = 'Koneksi ke server gagal. Coba lagi.';
            });
        }
     }">
    <!-- Glowing background accents -->
    <div class="absolute -top-40 -right-40 w-96 h-96 bg-brand-600/20 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute -bottom-40 -left-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>

    <div class="w-full max-w-md space-y-6 relative z-10">
        <!-- Back to Home -->
        <div class="text-center">
            <a href="/" class="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors bg-slate-900/60 border border-slate-800 px-3 py-1.5 rounded-full mb-3">
                <i class="fa-solid fa-arrow-left text-brand-400"></i>
                <span>Kembali ke Beranda FLASH</span>
            </a>
        </div>

        <!-- Logo / Brand Header -->
        <div class="text-center">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-amber-500 shadow-xl shadow-brand-500/30 mb-3">
                <i class="fa-solid fa-bolt-lightning text-3xl text-amber-300"></i>
            </div>
            <h2 class="text-3xl font-black text-white tracking-tight">Daftar Akun Baru</h2>
            <p class="text-slate-400 text-xs sm:text-sm mt-1">Dapatkan akses langsung seluruh fitur kloning & builder FLASH</p>
            
            <div class="pt-2">
                <span class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold shadow-sm">
                    <i class="fa-solid fa-gift text-amber-300"></i> Masa Uji Coba Gratis 1 Hari (24 Jam)
                </span>
            </div>
        </div>

        <!-- Error Alert -->
        <?php if ($error): ?>
            <div class="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3 shadow-lg backdrop-blur-md">
                <i class="fa-solid fa-circle-exclamation text-rose-400 text-lg flex-shrink-0"></i>
                <span><?= e($error) ?></span>
            </div>
        <?php endif; ?>

        <!-- Register Card -->
        <div class="glass-card p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl bg-slate-900/70">
            <form action="/auth/register.php" method="POST" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="token_sync" :value="otpTokenSync">

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Nama Lengkap</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                            <i class="fa-regular fa-user text-sm"></i>
                        </span>
                        <input type="text" name="name" value="<?= e($nameInput) ?>" required autofocus
                               placeholder="Nama Lengkap Anda"
                               class="w-full pl-10 pr-4 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Alamat Email</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                            <i class="fa-regular fa-envelope text-sm"></i>
                        </span>
                        <input type="email" id="regEmail" name="email" value="<?= e($emailInput) ?>" required 
                               placeholder="nama@email.com"
                               class="w-full pl-10 pr-4 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                            <i class="fa-solid fa-lock text-sm"></i>
                        </span>
                        <input :type="showPass ? 'text' : 'password'" name="password" required 
                               placeholder="Minimal 6 karakter"
                               class="w-full pl-10 pr-10 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all">
                        <button type="button" @click="showPass = !showPass" class="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-500 hover:text-slate-300 cursor-pointer">
                            <i class="fa-solid" :class="showPass ? 'fa-eye-slash' : 'fa-eye'"></i>
                        </button>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Konfirmasi Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                            <i class="fa-solid fa-check-double text-sm"></i>
                        </span>
                        <input :type="showPass ? 'text' : 'password'" name="confirm_password" required 
                               placeholder="Ulangi password di atas"
                               class="w-full pl-10 pr-4 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all">
                    </div>
                </div>

                <!-- Telegram OTP Verification Accordion / Section -->
                <div class="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
                    <div class="flex items-center justify-between">
                        <label class="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-300">
                            <input type="checkbox" x-model="useTelegramOtp" class="rounded border-slate-700 text-brand-500 focus:ring-brand-500/30">
                            <span class="flex items-center gap-1.5">
                                <i class="fa-brands fa-telegram text-sky-400 text-sm"></i>
                                <span>Verifikasi Cepat via Bot Telegram</span>
                            </span>
                        </label>
                        <span class="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-300 font-bold">1-Klik</span>
                    </div>

                    <div x-show="useTelegramOtp" x-collapse class="space-y-3 pt-2 border-t border-slate-800/80 text-xs">
                        <p class="text-slate-400 leading-relaxed text-[11px]">
                            Klik tombol di bawah untuk membuka Bot Telegram <b>@<span x-text="botUsername"></span></b>, tekan <span class="text-white font-bold">START</span>, lalu masukkan 6 digit kode OTP yang Anda terima.
                        </p>

                        <!-- Error Box for OTP -->
                        <div x-show="otpError" class="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[11px] flex items-center gap-2">
                            <i class="fa-solid fa-circle-exclamation text-rose-400"></i>
                            <span x-text="otpError"></span>
                        </div>

                        <!-- Action Button to Request OTP & Open Bot -->
                        <div class="flex flex-col sm:flex-row gap-2">
                            <button type="button" 
                                    @click="requestTelegramOtp()"
                                    :disabled="isRequestingOtp"
                                    class="flex-1 py-2.5 px-3 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-sky-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer">
                                <i class="fa-brands fa-telegram text-sky-400"></i>
                                <span x-text="otpSent ? 'Minta Ulang Kode OTP' : 'Dapatkan Kode via Bot Telegram'"></span>
                            </button>
                        </div>

                        <!-- Dev Code Hint if Telegram Bot Token is in local/mock mode -->
                        <template x-if="devCode">
                            <div class="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] flex items-center justify-between">
                                <span><i class="fa-solid fa-key mr-1"></i> Kode OTP Uji Coba: <b class="tracking-widest text-white" x-text="devCode"></b></span>
                                <button type="button" @click="otpCodeInput = devCode" class="underline text-[10px] hover:text-white">Gunakan</button>
                            </div>
                        </template>

                        <!-- Input Kode OTP -->
                        <div x-show="otpSent" class="space-y-1">
                            <label class="block text-[11px] font-semibold text-slate-300">Masukkan 6-Digit Kode OTP</label>
                            <input type="text" name="otp_code" x-model="otpCodeInput" maxlength="6"
                                   placeholder="Contoh: 123456"
                                   class="w-full text-center tracking-widest font-mono text-base font-bold py-2.5 bg-slate-900 border border-sky-500/40 rounded-xl text-sky-300 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-sky-500/30">
                        </div>
                    </div>
                </div>

                <button type="submit" 
                        class="w-full py-3.5 px-4 bg-gradient-to-r from-brand-600 via-indigo-600 to-amber-500 hover:opacity-95 text-white font-bold rounded-xl text-sm shadow-lg shadow-brand-500/25 transition-all transform active:scale-[0.98] mt-2 cursor-pointer pt-3">
                    <span>Daftar & Mulai Trial 1 Hari (24 Jam)</span> <i class="fa-solid fa-arrow-right ml-2 text-xs"></i>
                </button>
            </form>
        </div>

        <p class="text-center text-xs sm:text-sm text-slate-400">
            Sudah memiliki akun? 
            <a href="/auth/login.php" class="text-brand-400 hover:text-brand-300 font-bold transition-colors underline underline-offset-4">
                Masuk di sini
            </a>
        </p>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
