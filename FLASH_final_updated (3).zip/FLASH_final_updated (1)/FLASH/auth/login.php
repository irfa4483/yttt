<?php
// auth/login.php
require_once __DIR__ . '/../includes/auth.php';

// Jika sudah login, langsung alihkan ke dashboard user
if (is_logged_in()) {
    header('Location: /user/dashboard.php');
    exit;
}

$error = get_flash('error');
$success = get_flash('success');
$emailInput = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emailInput = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $token = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($token)) {
        $error = 'Validasi keamanan (CSRF Token) gagal. Silakan coba lagi.';
    } elseif (empty($emailInput) || empty($password)) {
        $error = 'Email dan password tidak boleh kosong.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$emailInput]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Proteksi Session Fixation
            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['id'];
            set_flash('success', 'Selamat datang kembali, ' . $user['name'] . '!');

            // Alihkan semua user ke Dashboard User terlebih dahulu
            header('Location: /user/dashboard.php');
            exit;
        } else {
            $error = 'Email atau password yang Anda masukkan salah.';
        }
    }
}

$pageTitle = 'Masuk ke Akun';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen flex items-center justify-center px-4 py-12 relative overflow-hidden bg-slate-950">
    <!-- Glowing background accents -->
    <div class="absolute -top-40 -left-40 w-96 h-96 bg-brand-600/20 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

    <div class="w-full max-w-md space-y-6 relative z-10">
        <!-- Back to Home -->
        <div class="text-center">
            <a href="/" class="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors bg-slate-900/60 border border-slate-800 px-3 py-1.5 rounded-full mb-3">
                <i class="fa-solid fa-arrow-left text-brand-400"></i>
                <span>Kembali ke Beranda FLASH</span>
            </a>
        </div>

        <!-- Logo / Brand Header -->
        <div class="text-center">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-amber-500 shadow-xl shadow-brand-500/30 mb-3">
                <i class="fa-solid fa-bolt-lightning text-3xl text-amber-300"></i>
            </div>
            <h2 class="text-3xl font-black text-white tracking-tight">Masuk ke Akun</h2>
            <p class="text-slate-400 text-xs sm:text-sm mt-1">Akses dashboard builder & kelola landing page Anda</p>
        </div>

        <!-- Notification Alerts -->
        <?php if ($error): ?>
            <div class="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3 shadow-lg backdrop-blur-md">
                <i class="fa-solid fa-circle-exclamation text-rose-400 text-lg flex-shrink-0"></i>
                <span><?= e($error) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-3 shadow-lg backdrop-blur-md">
                <i class="fa-solid fa-circle-check text-emerald-400 text-lg flex-shrink-0"></i>
                <span><?= e($success) ?></span>
            </div>
        <?php endif; ?>

        <!-- Login Card -->
        <div class="glass-card p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl bg-slate-900/70">
            <form action="/auth/login.php" method="POST" class="space-y-4" x-data="{ showPass: false }">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Alamat Email</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                            <i class="fa-regular fa-envelope text-sm"></i>
                        </span>
                        <input type="email" name="email" value="<?= e($emailInput) ?>" required autofocus
                               placeholder="nama@email.com"
                               class="w-full pl-10 pr-4 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                            <i class="fa-solid fa-lock text-sm"></i>
                        </span>
                        <input :type="showPass ? 'text' : 'password'" name="password" required 
                               placeholder="••••••••"
                               class="w-full pl-10 pr-10 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all">
                        <button type="button" @click="showPass = !showPass" class="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-500 hover:text-slate-300 cursor-pointer">
                            <i class="fa-solid" :class="showPass ? 'fa-eye-slash' : 'fa-eye'"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" 
                        class="w-full py-3.5 px-4 bg-gradient-to-r from-brand-600 via-indigo-600 to-amber-500 hover:opacity-95 text-white font-bold rounded-xl text-sm shadow-lg shadow-brand-500/25 transition-all transform active:scale-[0.98] cursor-pointer pt-3">
                    <span>Masuk Sekarang</span> <i class="fa-solid fa-arrow-right ml-2 text-xs"></i>
                </button>
            </form>
        </div>

        <p class="text-center text-xs sm:text-sm text-slate-400">
            Belum memiliki akun? 
            <a href="/auth/register.php" class="text-amber-400 hover:text-amber-300 font-bold transition-colors underline underline-offset-4">
                Daftar Akun Baru (Trial 1 Hari Gratis)
            </a>
        </p>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
