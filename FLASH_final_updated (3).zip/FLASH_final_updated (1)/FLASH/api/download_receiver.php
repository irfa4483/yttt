<?php
// api/download_receiver.php - Download pre-configured receiver shell
require_once __DIR__ . '/../includes/auth.php';
require_login();

$projectId = intval($_GET['project_id'] ?? 0);
$token = trim($_GET['token'] ?? '');

if (empty($token)) {
    // Generate secure default token based on user id and project id
    $user = current_user();
    $token = 'flash_' . substr(md5($user['id'] . '_' . $projectId . '_secure_salt_2026'), 0, 16);
}

$receiverTemplatePath = __DIR__ . '/../cdn/receiver.php';
if (!file_exists($receiverTemplatePath)) {
    die("Berkas receiver template tidak ditemukan.");
}

$code = file_get_contents($receiverTemplatePath);
// Inject preset token
$code = str_replace("{{DEPLOY_KEY}}", addslashes($token), $code);

// Trigger file download
header('Content-Type: application/x-httpd-php');
header('Content-Disposition: attachment; filename="receiver.php"');
header('Content-Length: ' . strlen($code));
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

echo $code;
exit;
