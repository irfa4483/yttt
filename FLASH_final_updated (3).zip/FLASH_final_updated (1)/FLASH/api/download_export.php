<?php
// api/download_export.php - Secure ZIP Installer Downloader
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/export_helper.php';

require_login();

// Jalankan auto-cleanup untuk menghapus file yang berumur lebih dari 24 jam
cleanup_expired_exports(86400);

$filename = basename(trim($_GET['file'] ?? ''));

if (empty($filename) || !str_ends_with(strtolower($filename), '.zip')) {
    http_response_code(400);
    die("Permintaan berkas tidak valid.");
}

$filePath = __DIR__ . '/../exports/' . $filename;

if (!file_exists($filePath)) {
    http_response_code(404);
    die("Berkas unduhan tidak ditemukan atau telah kedaluwarsa (otomatis dihapus setelah 24 jam). Silakan generate ulang dari panel.");
}

// Cek apakah file sudah kedaluwarsa (>24 jam)
if ((time() - filemtime($filePath)) >= 86400) {
    @unlink($filePath);
    http_response_code(410);
    die("Berkas ini telah melewati batas masa simpan 24 jam dan telah dihapus secara otomatis. Silakan generate ulang.");
}

header('Content-Description: File Transfer');
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($filePath));
flush();
readfile($filePath);
exit;
