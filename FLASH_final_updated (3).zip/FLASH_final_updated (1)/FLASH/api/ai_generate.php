<?php
// api/ai_generate.php
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json; charset=utf-8');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Anda harus login untuk menggunakan AI Generator.']);
    exit;
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

$type = $data['type'] ?? 'title_meta';
$topic = trim($data['topic'] ?? 'Slot & Casino Online');

if (empty($topic)) {
    echo json_encode(['success' => false, 'message' => 'Topik tidak boleh kosong.']);
    exit;
}

// Fetch AI settings from database (Prioritas: Kunci Khusus Builder)
$stmtKey = $pdo->prepare("SELECT value FROM settings WHERE key = ?");

$stmtKey->execute(['ai_provider']);
$provider = $stmtKey->fetchColumn() ?: 'gemini';

// Prioritaskan API Key khusus Builder agar kuota tidak tercampur dengan Cloaking
$stmtKey->execute(['ai_api_key_builder']);
$apiKey = $stmtKey->fetchColumn() ?: '';
if (empty($apiKey)) {
    $stmtKey->execute(['ai_api_key']);
    $apiKey = $stmtKey->fetchColumn() ?: '';
}

$stmtKey->execute(['ai_model']);
$model = $stmtKey->fetchColumn() ?: 'gemini-3.6-flash';

// Jika API Key tidak ada, kembalikan error
if (empty($apiKey)) {
    echo json_encode(['success' => false, 'message' => 'API Key AI belum dikonfigurasi. Silakan atur di Pengaturan Admin.']);
    exit;
}

// Jika API Key tersedia, panggil External AI Service
try {
    if ($provider === 'gemini') {
        if ($type === 'title_meta') {
            $prompt = "Kamu adalah Google SEO & Conversion Copywriter handal. Buatkan judul SEO (Title 50-65 karakter yang memikat dan mengandung kata kunci) dan meta description (130-155 karakter yang persuasif, mengajak klik dan memenuhi standar Google) tentang topik / brand: '$topic'. "
                    . "Format output WAJIB JSON persis seperti ini: {\"title\": \"...\", \"meta_description\": \"...\", \"keywords\": \"...\"}";
        } elseif ($type === 'reviews') {
            $prompt = "Buatkan 4 ulasan/review testimoni pengguna bintang 5 berbahasa Indonesia tentang brand / situs: '$topic'. "
                    . "Format output WAJIB JSON persis seperti ini: {\"reviews\": [{\"name\": \"...\", \"location\": \"...\", \"rating\": \"5\", \"text\": \"...\"}]}";
        } elseif ($type === 'clone_assistant') {
            $prompt = "Kamu adalah pakar optimasi Landing Page & Google SEO. Analisis dan berikan ide nama brand baru yang keren, judul SEO yang menaikkan CTR pencarian Google, meta description berstandar Google, alt banner promosi, alt logo brand, dan 3 FAQ interaktif berdasarkan input brand / topik berikut: '$topic'. "
                    . "Format output WAJIB JSON persis: {\"brand_name\": \"...\", \"title\": \"...\", \"meta_description\": \"...\", \"banner_title\": \"...\", \"logo_title\": \"...\", \"faqs\": [{\"question\": \"...\", \"answer\": \"...\"}]}";
        } else {
            $prompt = "Buatkan artikel HTML 3 paragraf, 3 item FAQ, dan 3 ulasan review berbahasa Indonesia tentang topik: '$topic'. "
                    . "Format output WAJIB JSON persis seperti ini: {\"article_content\": \"<h3>...</h3><p>...</p>\", \"faqs\": [{\"question\": \"...\", \"answer\": \"...\"}], \"reviews\": [{\"name\": \"...\", \"location\": \"...\", \"rating\": \"5\", \"text\": \"...\"}]}";
        }

        // Coba model prioritas kecepatan: gemini-3-flash-preview, gemini-3.5-flash, gemini-3.8-flash
        $modelsToTry = array_unique([$model, 'gemini-3-flash-preview', 'gemini-3.5-flash', 'gemini-3.8-flash']);

        foreach ($modelsToTry as $mTry) {
            $generateUrl = "https://generativelanguage.googleapis.com/v1beta/models/"
                         . urlencode($mTry) . ":generateContent?key=" . urlencode($apiKey);

            $generatePayload = json_encode([
                'contents' => [
                    ['parts' => [['text' => $prompt]]]
                ],
                'generationConfig' => [
                    'responseMimeType' => 'application/json'
                ]
            ]);

            $ch2 = curl_init($generateUrl);
            curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch2, CURLOPT_POST, true);
            curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch2, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch2, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch2, CURLOPT_POSTFIELDS, $generatePayload);
            curl_setopt($ch2, CURLOPT_TIMEOUT, 15);

            $response2 = curl_exec($ch2);
            $httpCode2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
            curl_close($ch2);

            if ($httpCode2 === 200 && $response2) {
                $resData2 = json_decode($response2, true);
                $aiText2 = $resData2['candidates'][0]['content']['parts'][0]['text'] ?? '';

                if (!empty($aiText2)) {
                    $aiText2 = preg_replace('/^```json\s*|\s*```$/i', '', trim($aiText2));
                    $jsonParsed2 = json_decode($aiText2, true);
                    if ($jsonParsed2) {
                        $jsonParsed2['success'] = true;
                        echo json_encode($jsonParsed2, JSON_UNESCAPED_UNICODE);
                        exit;
                    }
                }
            }
        }
    }
} catch (Exception $e) {
    // Log exception silently
}

// Jika API Call gagal
echo json_encode(['success' => false, 'message' => 'Gagal terhubung ke layanan AI. Pastikan API Key valid atau coba beberapa saat lagi.']);
