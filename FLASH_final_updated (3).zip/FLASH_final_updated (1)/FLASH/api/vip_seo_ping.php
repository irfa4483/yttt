<?php
// api/vip_seo_ping.php - VIP SEO Instant Indexing & Backlink Pinger
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Anda harus login untuk menggunakan fitur ini.']);
    exit;
}

$user = current_user();
$quota = get_user_quota_info($user);

// Proteksi VIP: Hanya role VIP atau Admin yang dapat mengeksekusi VIP Pinger
if (!$quota['is_vip']) {
    echo json_encode([
        'success' => false,
        'is_vip_required' => true,
        'message' => 'Fitur VIP SEO Instant Indexing & Backlink Pinger khusus untuk Paket VIP Ultra-Rank (Rp 4.000.000/bln) atau Administrator.'
    ]);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// 1. PING GOOGLE & BING SITEMAP / URL
if ($action === 'ping_search_engines') {
    $targetUrl = trim($_POST['target_url'] ?? '');
    if (empty($targetUrl) || !filter_var($targetUrl, FILTER_VALIDATE_URL)) {
        echo json_encode(['success' => false, 'message' => 'URL target tidak valid.']);
        exit;
    }

    $results = [];

    // Ping Google Sitemap endpoint
    $googlePingUrl = "https://www.google.com/ping?sitemap=" . urlencode($targetUrl);
    $ch = curl_init($googlePingUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; FLASH-SEO-Pinger/2.5; +http://localhost)');
    $resGoogle = curl_exec($ch);
    $httpCodeGoogle = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $results['google'] = [
        'status' => ($httpCodeGoogle >= 200 && $httpCodeGoogle < 400) ? 'Success' : 'Sent',
        'http_code' => $httpCodeGoogle,
        'engine' => 'Google Search Console Pinger'
    ];

    // Ping Bing
    $bingPingUrl = "https://www.bing.com/ping?sitemap=" . urlencode($targetUrl);
    $ch = curl_init($bingPingUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; FLASH-SEO-Pinger/2.5)');
    $resBing = curl_exec($ch);
    $httpCodeBing = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $results['bing'] = [
        'status' => ($httpCodeBing >= 200 && $httpCodeBing < 400) ? 'Success' : 'Sent',
        'http_code' => $httpCodeBing,
        'engine' => 'Bing Webmaster IndexNow'
    ];

    echo json_encode([
        'success' => true,
        'target_url' => $targetUrl,
        'ping_results' => $results,
        'timestamp' => date('Y-m-d H:i:s'),
        'message' => 'Sinyal indexing berhasil dikirim ke Google & Bing secara otomatis!'
    ]);
    exit;
}

// 2. ANALISIS KUALITAS SEO & BACKLINK INTERNAL
if ($action === 'analyze_seo') {
    $url = trim($_POST['target_url'] ?? '');
    if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        echo json_encode(['success' => false, 'message' => 'URL tidak valid.']);
        exit;
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)');
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || empty($html)) {
        echo json_encode(['success' => false, 'message' => "Gagal merayapi URL (HTTP Code: {$httpCode})."]);
        exit;
    }

    $isAmp = (stripos($html, '<html amp') !== false || stripos($html, '<html ⚡') !== false);
    $hasCanonical = preg_match('/<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)["\']/i', $html, $canMatch);
    $canonicalUrl = $hasCanonical ? $canMatch[1] : null;

    $hasAmphtml = preg_match('/<link[^>]+rel=["\']amphtml["\'][^>]+href=["\']([^"\']+)["\']/i', $html, $ampMatch);
    $ampUrl = $hasAmphtml ? $ampMatch[1] : null;

    $hasSchema = (stripos($html, 'application/ld+json') !== false);
    $hasFaq = (stripos($html, 'FAQPage') !== false);
    $hasReview = (stripos($html, 'AggregateRating') !== false || stripos($html, 'Review') !== false);

    echo json_encode([
        'success' => true,
        'url' => $url,
        'http_status' => $httpCode,
        'is_amp' => $isAmp,
        'canonical_url' => $canonicalUrl,
        'amp_url' => $ampUrl,
        'has_schema_jsonld' => $hasSchema,
        'has_faq_schema' => $hasFaq,
        'has_review_schema' => $hasReview,
        'seo_score' => ($isAmp ? 25 : 20) + ($hasCanonical ? 25 : 0) + ($hasSchema ? 25 : 0) + (($hasFaq || $hasReview) ? 25 : 0),
        'audit_time' => date('Y-m-d H:i:s')
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Action tidak valid.']);
