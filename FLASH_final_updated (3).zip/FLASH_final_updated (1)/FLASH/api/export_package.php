<?php
// api/export_package.php - Export Package Trigger
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/export_helper.php';

require_login();
$user = current_user();

$type = $_GET['type'] ?? '';
$projectId = intval($_GET['id'] ?? 0);
$isJson = isset($_GET['json']) && $_GET['json'] === '1';

$res = null;

if ($type === 'tunnel') {
    $res = create_tunnel_export_zip($pdo);
} elseif ($type === 'lp') {
    $res = create_lp_export_zip($pdo, $projectId, $user['id']);
} elseif ($type === 'amp') {
    $res = create_amp_export_zip($pdo, $projectId, $user['id']);
} else {
    $res = ['success' => false, 'message' => 'Tipe paket ekspor tidak dikenal.'];
}

if ($isJson) {
    header('Content-Type: application/json');
    echo json_encode($res);
    exit;
}

if ($res['success']) {
    set_flash('success', "Paket installer ZIP ({$res['filename']}, {$res['filesize']}) berhasil dibuat! Mengunduh otomatis...");
    header('Location: ' . $res['download_url']);
    exit;
} else {
    set_flash('error', $res['message']);
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/user/dashboard.php'));
    exit;
}
