<?php
// api/test_tunnel_keyword.php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/tunnel_helper.php';

if (!is_logged_in()) {
    echo json_encode(['found' => false, 'message' => 'Silakan login terlebih dahulu.']);
    exit;
}

$kw = trim($_GET['kw'] ?? '');
if ($kw === '') {
    echo json_encode(['found' => false, 'message' => 'Kata kunci tidak boleh kosong.']);
    exit;
}

$settings = get_tunnel_settings($pdo);
$strict = ($settings['tunnel_strict_keywords'] ?? '1') === '1';

$brand = match_tunnel_keyword($kw, $strict);

if ($brand) {
    echo json_encode([
        'found' => true,
        'brand' => $brand,
        'message' => 'Kata kunci VALID dan terdaftar di database! Siap dirender di tunnel.'
    ]);
} else {
    echo json_encode([
        'found' => false,
        'message' => 'Kata kunci TIDAK DITEMUKAN di daftar.txt. Jika validasi ketat aktif, URL ini akan merespon 404.'
    ]);
}
