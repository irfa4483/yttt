<?php
// api/deploy_remote.php - Remote Deploy via Shell Receiver
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/export_helper.php';

header('Content-Type: application/json; charset=utf-8');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Sesi login telah berakhir. Silakan login kembali.']);
    exit;
}

$user = current_user();

// Read JSON input or POST
$raw = file_get_contents('php://input');
$data = json_decode($raw, true) ?: $_POST;

$action       = strtolower(trim($data['action'] ?? 'deploy'));
$projectId    = intval($data['project_id'] ?? 0);
$receiverUrl  = trim($data['receiver_url'] ?? '');
$deployKey    = trim($data['deploy_key'] ?? '');
$targetFolder = trim($data['target_folder'] ?? '');
$indexType    = strtolower(trim($data['index_type'] ?? 'html'));
$selfDestruct = !empty($data['self_destruct']) ? '1' : '0';

if (empty($receiverUrl)) {
    echo json_encode(['success' => false, 'message' => 'URL Shell Receiver tidak boleh kosong (contoh: https://domain-anda.com/receiver.php).']);
    exit;
}

// Validasi format URL
if (!filter_var($receiverUrl, FILTER_VALIDATE_URL)) {
    echo json_encode(['success' => false, 'message' => 'Format URL Shell Receiver tidak valid. Harus diawali http:// atau https://']);
    exit;
}

// 1. ACTION: PING / TEST KONEKSI REMOTE SHELL
if ($action === 'ping' || $action === 'test') {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $receiverUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'action' => 'ping',
        'token'  => $deployKey
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 12);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'FLASH-Deploy-Agent/2.0');

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($response === false || !empty($curlErr)) {
        echo json_encode([
            'success' => false,
            'message' => "Gagal menghubungi URL Shell: {$curlErr}. Pastikan berkas receiver.php telah diunggah ke hosting."
        ]);
        exit;
    }

    $jsonRes = json_decode($response, true);
    if ($httpCode === 403 || (isset($jsonRes['success']) && !$jsonRes['success'])) {
        echo json_encode([
            'success' => false,
            'message' => $jsonRes['message'] ?? 'Koneksi ditolak oleh receiver. Pastikan Deploy Key / Token keamanan benar.'
        ]);
        exit;
    }

    echo json_encode([
        'success'   => true,
        'message'   => 'Receiver Shell online & terverifikasi siap menerima upload berkas!',
        'details'   => $jsonRes
    ]);
    exit;
}

// 2. ACTION: FULL AUTO DEPLOY
// Ambil data proyek dari database
$stmtProj = $pdo->prepare("SELECT * FROM projects WHERE id = ? AND (user_id = ? OR ? = 'admin')");
$stmtProj->execute([$projectId, $user['id'], $user['role']]);
$project = $stmtProj->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    echo json_encode(['success' => false, 'message' => 'Proyek tidak ditemukan atau Anda tidak memiliki akses.']);
    exit;
}

// Ekstrak target domain dari receiver URL
$parsedUrl = parse_url($receiverUrl);
$scheme = $parsedUrl['scheme'] ?? 'https';
$host   = $parsedUrl['host'] ?? '';
$port   = isset($parsedUrl['port']) ? ':' . $parsedUrl['port'] : '';
$targetDomain = "{$scheme}://{$host}{$port}";

// Tentukan apakah deploy ke root halaman utama atau ke subfolder tertentu
$cleanFolder = '';
if (!empty($targetFolder) && $targetFolder !== '/' && $targetFolder !== '.') {
    $cleanFolder = trim(str_replace(['..', "\0"], '', $targetFolder), "/\\");
}
$targetPageUrl = !empty($cleanFolder) ? "{$targetDomain}/{$cleanFolder}/" : "{$targetDomain}/";

// Ambil HTML proyek
$html = '';
if (!empty(trim($project['article_content'] ?? ''))) {
    $html = $project['article_content'];
} else {
    $tid = intval($project['template_id'] ?? 1);
    $stmtTpl = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
    $stmtTpl->execute([$tid]);
    $tplFile = $stmtTpl->fetchColumn();
    if ($tplFile && file_exists(__DIR__ . '/../cdn/templates/' . $tplFile)) {
        $html = file_get_contents(__DIR__ . '/../cdn/templates/' . $tplFile);
    }
}

if (empty($html)) {
    echo json_encode(['success' => false, 'message' => 'Konten proyek Landing Page kosong. Silakan simpan perubahan terlebih dahulu.']);
    exit;
}

// 1. Sinkronisasi HTML & bersihkan dari seluruh kode tag template
$html = sync_and_clean_project_html($html, $project);

// Ganti canonical URL ke target domain / folder yang dinaikkan
$project['canonical_url'] = $targetPageUrl;

$targetUrl = $targetPageUrl;
$loginUrl  = !empty($project['login_url']) ? $project['login_url'] : $targetUrl;
$regUrl    = !empty($project['register_url']) ? $project['register_url'] : $targetUrl;
$brand     = !empty($project['brand_name']) ? $project['brand_name'] : $project['name'];

$replaceTags = [
    '{{ brand_name }}'      => $brand,
    '{{ name }}'            => $project['name'],
    '{{ title }}'           => $project['title'] ?: ($brand . ' - Official Landing Page'),
    '{{ meta_description }}'=> $project['meta_description'] ?: '',
    '{{ canonical_url }}'   => $targetPageUrl,
    '{{ amp_url }}'         => $project['amp_url'] ?: ($targetPageUrl . 'amp'),
    '{{ login_url }}'       => $loginUrl,
    '{{ register_url }}'    => $regUrl,
    '{{ logo_url }}'        => $project['logo_url'] ?: '',
    '{{ banner_url }}'      => $project['banner_url'] ?: '',
    '{{ favicon_url }}'     => $project['favicon_url'] ?: '',
    '{{ gif_url }}'         => $project['gif_url'] ?: ($project['banner_url'] ?: ''),
    '{{ block:faqs }}'      => '',
    '{{ block:reviews }}'   => '',
    '{{ block:article }}'   => ''
];
$html = strtr($html, $replaceTags);

// Purify standar Google SEO
$html = purify_html_for_google($html, false, $project);
// Pastikan 100% bebas kode template
$html = preg_replace('/\{\{\s*[a-zA-Z0-9_:]+\s*(?:\|[^\r\n\}]{0,600}?)?\}\}/', '', $html) ?? $html;
$html = preg_replace('/(?:\'|\")\s*\)\s*\}\}/', '', $html) ?? $html;

// 2. Buat sitemap.xml otomatis khusus domain target & path yang dinaikkan
$todayDate = date('Y-m-d');
$ampUrl = !empty($project['amp_url']) ? $project['amp_url'] : ($targetPageUrl . 'amp');

$sitemapXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
$sitemapXml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"\n";
$sitemapXml .= "        xmlns:xhtml=\"http://www.w3.org/1999/xhtml\">\n";
$sitemapXml .= "  <url>\n";
$sitemapXml .= "    <loc>" . htmlspecialchars($targetPageUrl, ENT_XML1, 'UTF-8') . "</loc>\n";
$sitemapXml .= "    <lastmod>{$todayDate}</lastmod>\n";
$sitemapXml .= "    <changefreq>daily</changefreq>\n";
$sitemapXml .= "    <priority>1.0</priority>\n";
if (!empty($project['amp_url'])) {
    $sitemapXml .= "    <xhtml:link rel=\"amphtml\" href=\"" . htmlspecialchars($ampUrl, ENT_XML1, 'UTF-8') . "\" />\n";
}
$sitemapXml .= "  </url>\n";
if (!empty($project['amp_url'])) {
    $sitemapXml .= "  <url>\n";
    $sitemapXml .= "    <loc>" . htmlspecialchars($ampUrl, ENT_XML1, 'UTF-8') . "</loc>\n";
    $sitemapXml .= "    <lastmod>{$todayDate}</lastmod>\n";
    $sitemapXml .= "    <changefreq>daily</changefreq>\n";
    $sitemapXml .= "    <priority>0.9</priority>\n";
    $sitemapXml .= "  </url>\n";
}
$sitemapXml .= "</urlset>";

// 3. Buat robots.txt otomatis mereferensikan domain target
$robotsTxt = "User-agent: *\n";
$robotsTxt .= "Allow: /\n\n";
$robotsTxt .= "Sitemap: {$targetDomain}/sitemap.xml\n";

// 4. .htaccess standar Google SEO
$htaccess = get_standalone_htaccess(false);

// Kirim payload ke receiver shell via POST
$postData = [
    'action'           => 'deploy',
    'token'            => $deployKey,
    'tebas_index'      => '1',
    'target_folder'    => $cleanFolder,
    'index_type'       => $indexType,
    'index_content'    => $html,
    'sitemap_content'  => $sitemapXml,
    'robots_content'   => $robotsTxt,
    'htaccess_content' => $htaccess,
    'self_destruct'    => $selfDestruct
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $receiverUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 12);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'FLASH-Deploy-Agent/2.0');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($response === false || !empty($curlErr)) {
    echo json_encode([
        'success' => false,
        'message' => "Gagal mengirim berkas ke receiver: {$curlErr} (HTTP Code: {$httpCode})"
    ]);
    exit;
}

$jsonRes = json_decode($response, true);
if (!$jsonRes || empty($jsonRes['success'])) {
    echo json_encode([
        'success' => false,
        'message' => $jsonRes['message'] ?? "Respon gagal dari receiver remote shell (HTTP {$httpCode}).",
        'raw'     => substr($response, 0, 300)
    ]);
    exit;
}

// Update canonical URL proyek ke URL halaman yang dinaikkan
if (empty($project['canonical_url']) || strpos($project['canonical_url'], 'localhost') !== false || !empty($cleanFolder)) {
    $stmtUpd = $pdo->prepare("UPDATE projects SET canonical_url = ? WHERE id = ?");
    $stmtUpd->execute([$targetPageUrl, $projectId]);
}

echo json_encode([
    'success'         => true,
    'message'         => !empty($cleanFolder)
        ? "Selamat! Halaman berhasil ditebas & dinaikkan di path /{$cleanFolder}/ pada domain target."
        : 'Selamat! Halaman utama domain target berhasil ditebas & dipasang 100% aktif.',
    'target_domain'   => $targetDomain,
    'target_folder'   => $cleanFolder ?: '/',
    'site_url'        => $targetPageUrl,
    'sitemap_url'     => $targetDomain . '/sitemap.xml',
    'robots_url'      => $targetDomain . '/robots.txt',
    'deployed_files'  => $jsonRes['written_files'] ?? ['index.html', 'index.php (ditebas)', 'sitemap.xml', 'robots.txt'],
    'deployed_path'   => $jsonRes['deployed_path'] ?? '',
    'self_destruct'   => !empty($jsonRes['self_destruct'])
]);
exit;
