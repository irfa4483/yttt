<?php
// FLASH/api/clone_url.php
// Clones & Scans any external LP / AMP URL with:
// - Smart cURL multi-hop crawler (HTTP 3xx + Meta Refresh + JS Redirect + Fullscreen Iframe + Multi-UA Cloaking bypass)
// - Auto-detection of AMP vs LP page format & cross-discovery of paired LP (canonical) <-> AMP (amphtml)
// - Honest reporting ("Tidak ada" when an element genuinely does not exist on target)
// - AI (Gemini) + Rule-based deep detection of ALL old brand names (including cloned/hidden leftovers)
// - 100% clean output with zero leftover template syntax {{ ... }}

error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');
@ini_set('pcre.backtrack_limit', '10000000');
@ini_set('pcre.recursion_limit', '10000000');
@ini_set('memory_limit', '512M');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/content_generator.php';
require_once __DIR__ . '/../includes/purify_seo.php';

header('Content-Type: application/json; charset=utf-8');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Anda harus login untuk menggunakan fitur ini.']);
    exit;
}

$user = current_user();
$rawInput = file_get_contents('php://input');
$data = !empty($rawInput) ? json_decode($rawInput, true) : ($GLOBALS['test_clone_data'] ?? []);
if (!is_array($data)) $data = [];

$rawUrlInput  = trim($data['url'] ?? '');
if (!empty($rawUrlInput) && !preg_match('#^https?://#i', $rawUrlInput)) {
    $rawUrlInput = 'https://' . ltrim($rawUrlInput, '/');
}
$targetUrl    = $rawUrlInput;
$actionMode   = trim($data['action'] ?? 'clone'); // 'scan' | 'clone'
$sourceMode   = trim($data['source_mode'] ?? 'auto'); // 'auto' | 'lp' | 'amp'
$crawlerAgent = trim($data['crawler_agent'] ?? 'auto'); // 'auto' | 'googlebot' | 'mobile' | 'desktop'
$projId       = intval($data['project_id'] ?? 0);
$brandName    = trim($data['brand_name'] ?? '');
$loginUrl     = trim($data['login_url'] ?? '');
$regUrl       = trim($data['register_url'] ?? '');
$canUrl       = trim($data['canonical_url'] ?? '');
$ampUrl       = trim($data['amp_url'] ?? '');
$customTitle  = trim($data['title'] ?? '');
$customDesc   = trim($data['meta_description'] ?? '');
$customBanner = trim($data['banner_url'] ?? '');
$customLogo   = trim($data['logo_url'] ?? '');
$customFavicon = trim($data['favicon_url'] ?? '');
$customGif    = trim($data['gif_url'] ?? '');
$hasCustomReviews = isset($data['reviews']) && is_array($data['reviews']);
$customReviews    = $hasCustomReviews ? $data['reviews'] : [];
$hasCustomFaqs    = isset($data['faqs']) && is_array($data['faqs']);
$customFaqs       = $hasCustomFaqs ? $data['faqs'] : [];
$asTemplate   = !empty($data['save_as_template']);
$targetType   = trim($data['type'] ?? ''); // '', 'amp', 'lp'

if (empty($targetUrl) || !filter_var($targetUrl, FILTER_VALIDATE_URL)) {
    echo json_encode(['success' => false, 'message' => 'URL target tidak valid. Harap masukkan URL lengkap (contoh: https://target.com).']);
    exit;
}

// Cek Batasan Kuota Kloning Pengguna Biasa vs VIP
$quota = get_user_quota_info($user);
if ($quota && !$quota['can_clone'] && $actionMode === 'clone') {
    echo json_encode([
        'success' => false,
        'quota_exceeded' => true,
        'plan_name' => $quota['plan_name'],
        'used' => $quota['used_clones'],
        'max' => $quota['max_clones'],
        'message' => "Batas kuota kloning akun Anda ({$quota['plan_name']}) telah habis ({$quota['used_clones']}/{$quota['max_clones']}). Silakan tingkatkan ke Paket VIP Ultra-Rank (Rp 4.000.000/bln) untuk akses Tanpa Batas (Unlimited)!"
    ]);
    exit;
}

// -----------------------------------------------------------------------------
// URL & HTML Helper Utilities
// -----------------------------------------------------------------------------
function resolve_url($rel, $base) {
    $rel = trim($rel);
    if (empty($rel)) return '';
    if (substr($rel, 0, 5) === 'data:') return $rel;
    if (substr($rel, 0, 2) === '//') {
        $scheme = parse_url($base, PHP_URL_SCHEME) ?: 'https';
        return $scheme . ':' . $rel;
    }
    if (parse_url($rel, PHP_URL_SCHEME) != '') return $rel;
    if ($rel[0] === '#' || stripos($rel, 'javascript:') === 0 || stripos($rel, 'mailto:') === 0 || stripos($rel, 'tel:') === 0) {
        return $rel;
    }

    $baseParts = parse_url($base);
    $scheme = $baseParts['scheme'] ?? 'https';
    $host   = $baseParts['host'] ?? '';
    $port   = isset($baseParts['port']) ? ':' . $baseParts['port'] : '';
    $path   = $baseParts['path'] ?? '/';

    if ($rel[0] === '/') {
        return "$scheme://$host$port$rel";
    }

    $dir = dirname($path);
    if ($dir === '\\' || $dir === '.') $dir = '';
    return "$scheme://$host$port" . ($dir ? rtrim($dir, '/') . '/' : '/') . $rel;
}

function parse_tag_attributes($tagHtml) {
    $attrs = [];
    if (preg_match_all('/([a-zA-Z0-9_:\-]+)\s*(?:=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'=<>`]+)))?/s', $tagHtml, $m, PREG_SET_ORDER)) {
        foreach ($m as $idx => $part) {
            if ($idx === 0) continue; // skip tag name
            $key = strtolower($part[1]);
            $val = $part[2] ?? ($part[3] ?? ($part[4] ?? ''));
            $attrs[$key] = html_entity_decode($val, ENT_QUOTES, 'UTF-8');
        }
    }
    return $attrs;
}

function extract_link_tag_href($html, $relPattern) {
    if (!preg_match_all('/<link\b[^>]*>/is', $html, $mLinks)) return '';
    foreach ($mLinks[0] as $tag) {
        $attrs = parse_tag_attributes($tag);
        $rel = strtolower(trim($attrs['rel'] ?? ''));
        $href = trim($attrs['href'] ?? '');
        if (!empty($rel) && !empty($href) && preg_match($relPattern, $rel)) {
            return $href;
        }
    }
    return '';
}

function extract_meta_content($html, $attrKey, $valPattern) {
    if (!preg_match_all('/<meta\b[^>]*>/is', $html, $mMetas)) return '';
    foreach ($mMetas[0] as $tag) {
        $attrs = parse_tag_attributes($tag);
        $k = strtolower(trim($attrs[$attrKey] ?? ''));
        $c = trim($attrs['content'] ?? '');
        if (!empty($k) && $c !== '' && preg_match($valPattern, $k)) {
            return $c;
        }
    }
    return '';
}

function detect_is_amp_html($html) {
    if (empty($html)) return false;
    if (preg_match('/<html\b[^>]*\b(?:amp|⚡|⚡4ads|amp4ads|i-amphtml)\b/iu', $html)) return true;
    if (preg_match('/<html\b[^>]*\s⚡(?:\s|>|=)/u', $html)) return true;
    if (stripos($html, 'amp-boilerplate') !== false) return true;
    if (stripos($html, 'cdn.ampproject.org/v0') !== false) return true;
    if (stripos($html, '<amp-img') !== false || stripos($html, '<amp-anim') !== false || stripos($html, '<amp-carousel') !== false) return true;
    return false;
}

function is_blocked_or_challenge_html($html, $httpCode) {
    if ($httpCode >= 400 || empty($html)) return true;
    $lower = strtolower(substr($html, 0, 8000));
    if (strpos($lower, 'just a moment...') !== false && (strpos($lower, 'cf-browser-verification') !== false || strpos($lower, 'challenge-platform') !== false || strpos($lower, 'cloudflare') !== false)) {
        return true;
    }
    if (strpos($lower, 'attention required! | cloudflare') !== false) return true;
    if (strpos($lower, '<title>403 forbidden</title>') !== false || strpos($lower, '<title>access denied</title>') !== false) return true;
    return false;
}

function score_lp_amp_html($html, $httpCode) {
    if ($httpCode >= 400 || empty($html)) return -1000;
    if (is_blocked_or_challenge_html($html, $httpCode)) return -500;

    $score = 10;
    $len = strlen($html);
    if ($len > 1500) $score += 20;
    if ($len > 8000) $score += 20;

    $visible = trim(preg_replace('/\s+/', ' ', strip_tags(preg_replace('/<(script|style)\b[^>]*>.*?<\/\1>/is', ' ', $html))));
    if (strlen($visible) > 300) $score += 25;
    if (strlen($visible) > 1200) $score += 15;

    if (detect_is_amp_html($html)) $score += 45;

    if (preg_match('/<title[^>]*>([^<]+)<\/title>/is', $html, $mt) && strlen(trim($mt[1])) > 2) $score += 20;
    if (extract_meta_content($html, 'name', '/^description$/i') !== '') $score += 15;
    if (extract_link_tag_href($html, '/^canonical$/i') !== '') $score += 15;
    if (extract_link_tag_href($html, '/^amphtml$/i') !== '') $score += 15;

    if (preg_match('/login|daftar|register|masuk|slot|gacor|bonus|promo|alternatif/i', $html)) $score += 25;
    if (preg_match_all('/<(?:img|amp-img|amp-anim)\b/i', $html) >= 2) $score += 15;

    return $score;
}

// -----------------------------------------------------------------------------
// 1. Smart Multi-Hop & Anti-Cloaking cURL Crawler
// -----------------------------------------------------------------------------
function make_curl_handle($url, $userAgent, $referer = 'https://www.google.co.id/', $followRedirects = false, $timeout = 12) {
    if (!preg_match('#^https?://#i', $url)) {
        $url = 'https://' . $url;
    }
    $ch = curl_init($url);
    $headers = [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'Upgrade-Insecure-Requests: 1',
    ];
    if (!empty($referer)) {
        $headers[] = 'Referer: ' . $referer;
    }

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $followRedirects);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 8);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 7);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIEFILE, '');
    curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    return $ch;
}

function parse_curl_response($rawResponse, $ch, $requestedUrl) {
    $httpCode     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize   = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $effectiveUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $requestedUrl;
    $err          = curl_error($ch);

    if ($rawResponse === false || $rawResponse === '') {
        return [
            'url'               => $effectiveUrl,
            'http_code'         => $httpCode,
            'headers'           => '',
            'body'              => '',
            'redirect_location' => '',
            'refresh_url'       => '',
            'error'             => $err
        ];
    }

    $headerStr = substr($rawResponse, 0, $headerSize);
    $body      = substr($rawResponse, $headerSize);

    $location = '';
    $refresh  = '';
    // Ambil header block terakhir bila redirect diikuti otomatis
    $headerBlocks = preg_split("/\r\n\r\n|\n\n|\r\r/", trim($headerStr));
    $lastHeaders  = end($headerBlocks) ?: $headerStr;
    if (preg_match('/^Location:\s*(.+)$/mi', $lastHeaders, $mLoc)) {
        $location = resolve_url(trim($mLoc[1]), $effectiveUrl);
    }
    if (preg_match('/^Refresh:\s*\d+\s*;\s*url\s*=\s*["\']?([^"\'\r\n]+)["\']?/mi', $lastHeaders, $mRef)) {
        $refresh = resolve_url(trim($mRef[1]), $effectiveUrl);
    }

    return [
        'url'               => $effectiveUrl,
        'http_code'         => $httpCode,
        'headers'           => $lastHeaders,
        'body'              => $body,
        'redirect_location' => $location,
        'refresh_url'       => $refresh,
        'error'             => $err
    ];
}

function extract_client_side_redirect($html, $baseUrl) {
    if (empty($html)) return null;

    // 1. HTML Meta Refresh (<meta http-equiv="refresh" content="0;url=...">)
    if (preg_match_all('/<meta\b[^>]*>/is', $html, $mMetas)) {
        foreach ($mMetas[0] as $tag) {
            $attrs = parse_tag_attributes($tag);
            $equiv = strtolower(trim($attrs['http-equiv'] ?? ''));
            $content = trim($attrs['content'] ?? '');
            if ($equiv === 'refresh' && preg_match('/url\s*=\s*["\']?([^"\'\s;>]+)["\']?/i', $content, $mUrl)) {
                $dest = resolve_url(trim($mUrl[1]), $baseUrl);
                if (!empty($dest) && $dest !== $baseUrl && preg_match('#^https?://#i', $dest)) {
                    return ['type' => 'META_REFRESH', 'url' => $dest];
                }
            }
        }
    }

    // Hitung panjang teks terlihat (bukan script/style) untuk mendeteksi halaman wrapper/cloaking/redirect tipis
    $stripped = trim(preg_replace('/\s+/', ' ', strip_tags(preg_replace('/<(script|style|noscript)\b[^>]*>.*?<\/\1>/is', ' ', $html))));
    $isThinRedirectWrapper = (strlen($stripped) < 550);

    // 2. JavaScript Redirect (window.location / location.replace / location.assign / top.location / atob)
    if ($isThinRedirectWrapper || !detect_is_amp_html($html)) {
        // Cek hanya di dalam <script> yang bukan script analytics/config besar
        if (preg_match_all('/<script\b([^>]*)>(.*?)<\/script>/is', $html, $mScripts, PREG_SET_ORDER)) {
            foreach ($mScripts as $sc) {
                $attrs = $sc[1];
                $code  = $sc[2];
                if (stripos($attrs, 'ld+json') !== false || strlen($code) > 25000) continue;

                // Hanya anggap sebagai auto-redirect jika halaman memang wrapper tipis ATAU script memanggil redirect langsung (bukan di dalam onclick button / event handler)
                $hasOnEventOnly = (preg_match('/addEventListener|onclick|function\s+open/i', $code) && !$isThinRedirectWrapper);
                if ($hasOnEventOnly) continue;

                if (preg_match('/(?:window|top|self)?\.?location\.(?:replace|assign)\s*\(\s*atob\(\s*([\'"])([A-Za-z0-9+\/=]+)\1\s*\)\s*\)/i', $code, $mB64)) {
                    $decoded = base64_decode($mB64[2], true);
                    if ($decoded && preg_match('#^https?://#i', $decoded)) {
                        $dest = resolve_url(trim($decoded), $baseUrl);
                        if ($dest !== $baseUrl) return ['type' => 'JS_BASE64_REDIRECT', 'url' => $dest];
                    }
                }
                if (preg_match('/(?:window|top|self)?\.?location(?:\.href)?\s*=\s*atob\(\s*([\'"])([A-Za-z0-9+\/=]+)\1\s*\)/i', $code, $mB64b)) {
                    $decoded = base64_decode($mB64b[2], true);
                    if ($decoded && preg_match('#^https?://#i', $decoded)) {
                        $dest = resolve_url(trim($decoded), $baseUrl);
                        if ($dest !== $baseUrl) return ['type' => 'JS_BASE64_REDIRECT', 'url' => $dest];
                    }
                }
                if ($isThinRedirectWrapper || preg_match('/(?:^|[;\s\{\r\n])(?:window|top|self)?\.?location(?:\.href|\.(?:replace|assign))?\s*[=(]|^\s*(?:\(\s*function|\$?\(|setTimeout|window\.onload|document\.addEventListener\s*\(\s*[\'"]DOMContentLoaded)/i', trim($code))) {
                    if (preg_match('/(?:window|top|self)?\.?location(?:\.href)?\s*=\s*([\'"])([^\'"]+)\1/i', $code, $mJs)) {
                        $candUrl = str_replace('\\/', '/', trim($mJs[2]));
                        if ($isThinRedirectWrapper || preg_match('#^(?:https?:)?//#i', $candUrl) || substr($candUrl, 0, 1) === '/') {
                            $dest = resolve_url($candUrl, $baseUrl);
                            if (!empty($dest) && $dest !== $baseUrl && preg_match('#^https?://#i', $dest) && stripos($dest, 'google.') === false) {
                                return ['type' => 'JS_REDIRECT', 'url' => $dest];
                            }
                        }
                    }
                    if (preg_match('/(?:window|top|self)?\.?location\.(?:replace|assign)\s*\(\s*([\'"])([^\'"]+)\1\s*\)/i', $code, $mJs2)) {
                        $candUrl = str_replace('\\/', '/', trim($mJs2[2]));
                        if ($isThinRedirectWrapper || preg_match('#^(?:https?:)?//#i', $candUrl) || substr($candUrl, 0, 1) === '/') {
                            $dest = resolve_url($candUrl, $baseUrl);
                            if (!empty($dest) && $dest !== $baseUrl && preg_match('#^https?://#i', $dest) && stripos($dest, 'google.') === false) {
                                return ['type' => 'JS_REDIRECT', 'url' => $dest];
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. Fullscreen / Cloaking Frame Wrapper (<iframe src="..."> or <frame src="..."> when page body has no real text)
    if ($isThinRedirectWrapper && preg_match('/<(?:iframe|frame)\b[^>]*src=["\']([^"\']+)["\'][^>]*>/is', $html, $mFrame)) {
        $fSrc = resolve_url(trim($mFrame[1]), $baseUrl);
        if (!empty($fSrc) && preg_match('#^https?://#i', $fSrc) && $fSrc !== $baseUrl && !preg_match('/googletagmanager|facebook|youtube|vimeo|recaptcha|hcaptcha|cloudflare/i', $fSrc)) {
            return ['type' => 'IFRAME_WRAPPER', 'url' => $fSrc];
        }
    }

    return null;
}

function follow_all_redirects($startUrl, $userAgent, $referer = 'https://www.google.co.id/', $maxHops = 6) {
    $currUrl = $startUrl;
    $visited = [];
    $trace   = [];
    $lastResp = null;

    for ($hop = 0; $hop < $maxHops; $hop++) {
        if (isset($visited[$currUrl])) break;
        $visited[$currUrl] = true;

        $ch = make_curl_handle($currUrl, $userAgent, $referer, false, 12);
        $raw = curl_exec($ch);
        $resp = parse_curl_response($raw, $ch, $currUrl);
        curl_close($ch);
        $lastResp = $resp;

        // HTTP 3xx Redirect Location header
        if ($resp['http_code'] >= 300 && $resp['http_code'] < 400 && !empty($resp['redirect_location'])) {
            $next = $resp['redirect_location'];
            $trace[] = ['step' => 'HTTP_' . $resp['http_code'], 'from' => $currUrl, 'to' => $next];
            $referer = $currUrl;
            $currUrl = $next;
            continue;
        }

        // HTTP Refresh header
        if (!empty($resp['refresh_url'])) {
            $next = $resp['refresh_url'];
            $trace[] = ['step' => 'HTTP_REFRESH', 'from' => $currUrl, 'to' => $next];
            $referer = $currUrl;
            $currUrl = $next;
            continue;
        }

        // Client-side redirect (Meta refresh / JS location / wrapper iframe)
        if ($resp['http_code'] >= 200 && $resp['http_code'] < 400 && !empty($resp['body'])) {
            $clientRedir = extract_client_side_redirect($resp['body'], $currUrl);
            if ($clientRedir && !empty($clientRedir['url']) && !isset($visited[$clientRedir['url']])) {
                $trace[] = ['step' => $clientRedir['type'], 'from' => $currUrl, 'to' => $clientRedir['url']];
                $referer = $currUrl;
                $currUrl = $clientRedir['url'];
                continue;
            }
        }
        break;
    }

    return [
        'initial_url' => $startUrl,
        'final_url'   => $lastResp['url'] ?? $currUrl,
        'http_code'   => $lastResp['http_code'] ?? 0,
        'html'        => $lastResp['body'] ?? '',
        'trace'       => $trace,
        'error'       => $lastResp['error'] ?? ''
    ];
}

function smart_crawl_target($targetUrl) {
    $profiles = [
        'Mobile Chrome (Google Referer)' => [
            'ua' => 'Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36',
            'ref' => 'https://www.google.co.id/'
        ],
        'Googlebot Smartphone' => [
            'ua' => 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
            'ref' => 'https://www.google.com/'
        ],
        'Desktop Chrome' => [
            'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
            'ref' => 'https://www.google.com/'
        ],
    ];

    // Langkah 1: Probe 3 User-Agent secara paralel lewat curl_multi untuk deteksi Cloaking secara cepat (< 12 detik)
    $mh = curl_multi_init();
    $handles = [];
    foreach ($profiles as $label => $cfg) {
        $ch = make_curl_handle($targetUrl, $cfg['ua'], $cfg['ref'], true, 14);
        curl_multi_add_handle($mh, $ch);
        $handles[$label] = $ch;
    }

    $running = null;
    do {
        $mrc = curl_multi_exec($mh, $running);
        if ($running > 0) curl_multi_select($mh, 0.5);
    } while ($running > 0 && $mrc === CURLM_OK);

    $candidates = [];
    foreach ($handles as $label => $ch) {
        $raw = curl_multi_getcontent($ch);
        $parsed = parse_curl_response($raw, $ch, $targetUrl);
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);

        // Jika hasil probe mengandung client-side redirect (meta refresh / JS / iframe), ikuti hop penuh menggunakan UA profil tersebut
        $trace = [];
        if ($parsed['url'] !== $targetUrl) {
            $trace[] = ['step' => 'HTTP_REDIRECT', 'from' => $targetUrl, 'to' => $parsed['url']];
        }
        if (!empty($parsed['body'])) {
            $redir = extract_client_side_redirect($parsed['body'], $parsed['url']);
            if ($redir) {
                $fullFollow = follow_all_redirects($redir['url'], $profiles[$label]['ua'], $parsed['url'], 5);
                array_unshift($fullFollow['trace'], ['step' => $redir['type'], 'from' => $parsed['url'], 'to' => $redir['url']]);
                $trace = array_merge($trace, $fullFollow['trace']);
                if (!empty($fullFollow['html']) && $fullFollow['http_code'] >= 200 && $fullFollow['http_code'] < 400) {
                    $parsed['url']       = $fullFollow['final_url'];
                    $parsed['http_code'] = $fullFollow['http_code'];
                    $parsed['body']      = $fullFollow['html'];
                    $parsed['error']     = $fullFollow['error'];
                }
            }
        }

        $score = score_lp_amp_html($parsed['body'], $parsed['http_code']);
        $isAmp = detect_is_amp_html($parsed['body']);
        preg_match('/<title[^>]*>(.*?)<\/title>/is', $parsed['body'], $mT);
        $titleSnap = trim(html_entity_decode(strip_tags($mT[1] ?? '')));

        $candidates[$label] = [
            'profile'   => $label,
            'final_url' => $parsed['url'],
            'http_code' => $parsed['http_code'],
            'html'      => $parsed['body'],
            'trace'     => $trace,
            'score'     => $score,
            'is_amp'    => $isAmp,
            'title'     => $titleSnap,
            'error'     => $parsed['error']
        ];
    }
    curl_multi_close($mh);

    // Fallback file_get_contents jika semua cURL gagal
    $best = null;
    foreach ($candidates as $cand) {
        if ($best === null || $cand['score'] > $best['score']) {
            $best = $cand;
        }
    }

    if (!$best || $best['http_code'] >= 400 || empty($best['html'])) {
        $opts = [
            'http' => [
                'method' => 'GET',
                'header' => "User-Agent: {$profiles['Mobile Chrome (Google Referer)']['ua']}\r\nAccept: text/html,application/xhtml+xml\r\nReferer: https://www.google.co.id/\r\n",
                'timeout' => 15,
                'follow_location' => 1
            ],
            'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
        ];
        $fgc = @file_get_contents($targetUrl, false, stream_context_create($opts));
        if ($fgc !== false && !empty($fgc)) {
            $best = [
                'profile'   => 'Stream Fallback',
                'final_url' => $targetUrl,
                'http_code' => 200,
                'html'      => $fgc,
                'trace'     => [],
                'score'     => score_lp_amp_html($fgc, 200),
                'is_amp'    => detect_is_amp_html($fgc),
                'title'     => '',
                'error'     => ''
            ];
        }
    }

    // Deteksi apakah terjadi Cloaking antar User-Agent (misal Desktop vs Mobile/Googlebot berbeda domain, format AMP/LP, atau judul)
    $cloakingDetected = false;
    $cloakingNote = '';
    $desktop = $candidates['Desktop Chrome'] ?? null;
    $mobile  = $candidates['Mobile Chrome (Google Referer)'] ?? null;
    $gbot    = $candidates['Googlebot Smartphone'] ?? null;

    if ($desktop && $best && $desktop['profile'] !== $best['profile']) {
        $deskHost = parse_url($desktop['final_url'], PHP_URL_HOST);
        $bestHost = parse_url($best['final_url'], PHP_URL_HOST);
        if ($desktop['score'] < 0 && $best['score'] > 30) {
            $cloakingDetected = true;
            $cloakingNote = "Cloaking Bypass: Desktop biasa mendapat HTTP {$desktop['http_code']}/blokir, namun '{$best['profile']}' berhasil membuka halaman LP/AMP asli.";
        } elseif ($deskHost !== $bestHost || $desktop['is_amp'] !== $best['is_amp'] || (strlen($desktop['title']) > 3 && strlen($best['title']) > 3 && strcasecmp($desktop['title'], $best['title']) !== 0)) {
            $cloakingDetected = true;
            $cloakingNote = "Cloaking Terdeteksi: '{$best['profile']}' menyajikan versi " . ($best['is_amp'] ? 'AMP' : 'LP') . " berbeda dari '{$desktop['profile']}'.";
        }
    }

    // Cek juga apakah Googlebot vs Mobile berbeda (misal Googlebot dikasih AMP atau whitehat, Mobile dikasih LP)
    $uaAmpCand = null;
    $uaLpCand  = null;
    foreach ($candidates as $cand) {
        if ($cand['http_code'] === 200 && $cand['score'] > 20) {
            if ($cand['is_amp'] && ($uaAmpCand === null || $cand['score'] > $uaAmpCand['score'])) {
                $uaAmpCand = $cand;
            } elseif (!$cand['is_amp'] && ($uaLpCand === null || $cand['score'] > $uaLpCand['score'])) {
                $uaLpCand = $cand;
            }
        }
    }

    return [
        'winner'            => $best,
        'candidates'        => $candidates,
        'ua_lp_candidate'   => $uaLpCand,
        'ua_amp_candidate'  => $uaAmpCand,
        'cloaking_detected' => $cloakingDetected,
        'cloaking_note'     => $cloakingNote
    ];
}

// -----------------------------------------------------------------------------
// Eksekusi Crawl Utama + Paired Canonical (LP) <-> AMPHTML Discovery
// -----------------------------------------------------------------------------
$crawlBundle = smart_crawl_target($targetUrl);
$winner      = $crawlBundle['winner'];

if (!$winner || $winner['http_code'] >= 400 || empty($winner['html'])) {
    $httpCode = $winner['http_code'] ?? 0;
    $curlErr  = $winner['error'] ?? '';
    echo json_encode([
        'success' => false,
        'message' => 'Gagal mengunduh halaman dari URL tersebut (HTTP Code: ' . $httpCode . ($curlErr ? ' - ' . $curlErr : '') . '). Pastikan situs target dapat diakses publik atau tidak memblokir penuh IP server.'
    ]);
    exit;
}

$winnerIsAmp = $winner['is_amp'];
$winnerCanTag = resolve_url(extract_link_tag_href($winner['html'], '/^canonical$/i'), $winner['final_url']);
$winnerAmpTag = resolve_url(extract_link_tag_href($winner['html'], '/^(?:amphtml|alternate\s+amp)$/i'), $winner['final_url']);

// Catat LP & AMP version jika ditemukan lewat cURL UA lain atau link paired canonical/amphtml
$lpVersion  = $crawlBundle['ua_lp_candidate'];
$ampVersion = $crawlBundle['ua_amp_candidate'];

if ($winnerIsAmp && !empty($winnerCanTag) && rtrim($winnerCanTag, '/') !== rtrim($winner['final_url'], '/')) {
    // Halaman target adalah AMP dan menunjuk canonical ke URL LP -> cURL LP tersebut (coba Mobile lalu Googlebot jika cloaked)!
    if (!$lpVersion || rtrim($lpVersion['final_url'], '/') !== rtrim($winnerCanTag, '/')) {
        $pairedLp = follow_all_redirects($winnerCanTag, 'Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36', 'https://www.google.co.id/', 4);
        if ($pairedLp['http_code'] !== 200 || empty($pairedLp['html']) || is_blocked_or_challenge_html($pairedLp['html'], $pairedLp['http_code'])) {
            $pairedLp = follow_all_redirects($winnerCanTag, 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 'https://www.google.com/', 4);
        }
        if ($pairedLp['http_code'] === 200 && !empty($pairedLp['html']) && !is_blocked_or_challenge_html($pairedLp['html'], 200)) {
            $pairedScore = score_lp_amp_html($pairedLp['html'], 200);
            if ($pairedScore > 15 && !detect_is_amp_html($pairedLp['html'])) {
                $lpVersion = [
                    'profile'   => 'Paired Canonical LP',
                    'final_url' => $pairedLp['final_url'],
                    'http_code' => $pairedLp['http_code'],
                    'html'      => $pairedLp['html'],
                    'trace'     => $pairedLp['trace'],
                    'score'     => $pairedScore,
                    'is_amp'    => false,
                    'from_paired_link' => true
                ];
            }
        }
    }
} elseif (!$winnerIsAmp && !empty($winnerAmpTag) && rtrim($winnerAmpTag, '/') !== rtrim($winner['final_url'], '/')) {
    // Halaman target adalah LP dan menunjuk amphtml ke URL AMP -> cURL AMP tersebut untuk verifikasi!
    if (!$ampVersion || rtrim($ampVersion['final_url'], '/') !== rtrim($winnerAmpTag, '/')) {
        $pairedAmp = follow_all_redirects($winnerAmpTag, 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 'https://www.google.com/', 4);
        if ($pairedAmp['http_code'] === 200 && !empty($pairedAmp['html']) && !is_blocked_or_challenge_html($pairedAmp['html'], 200)) {
            $ampVersion = [
                'profile'   => 'Paired AMPHTML',
                'final_url' => $pairedAmp['final_url'],
                'http_code' => $pairedAmp['http_code'],
                'html'      => $pairedAmp['html'],
                'trace'     => $pairedAmp['trace'],
                'score'     => score_lp_amp_html($pairedAmp['html'], 200),
                'is_amp'    => detect_is_amp_html($pairedAmp['html']),
                'from_paired_link' => true
            ];
        }
    }
}

// Pilih versi HTML aktif sesuai permintaan user ($sourceMode: 'auto' | 'lp' | 'amp')
$activeSource = $winner;
if ($sourceMode === 'lp' && $lpVersion) {
    $activeSource = $lpVersion;
} elseif ($sourceMode === 'amp' && $ampVersion) {
    $activeSource = $ampVersion;
}

$rawHtml      = $activeSource['html'];
// Jika halaman target mentah masih mengandung tag template {{ ... | default(...) }}, evaluasi ke nilai default-nya lebih dulu agar ekstraksi URL/Title/Meta akurat
if (strpos($rawHtml, '{{') !== false && function_exists('flash_eval_template_expr')) {
    $rawHtml = preg_replace_callback('/\{\{\s*(?!block:)([a-zA-Z_][a-zA-Z0-9_:]*[^\}\{\r\n]{0,500})\}\}/', function($m) {
        return flash_eval_template_expr($m[1], []);
    }, $rawHtml) ?? $rawHtml;
}
$effectiveUrl = $activeSource['final_url'];
$redirectTrace = $activeSource['trace'] ?? [];

// -----------------------------------------------------------------------------
// 2. Deteksi AMP vs LP yang Akurat
// -----------------------------------------------------------------------------
$detectedIsAmp = detect_is_amp_html($rawHtml);
$isAmp = ($targetType === 'amp') ? true : (($targetType === 'lp') ? false : $detectedIsAmp);
$detectedPageFormat = $detectedIsAmp ? 'amp' : 'lp';

// -----------------------------------------------------------------------------
// 3. Ekstraksi Jujur & Teliti (Title, Deskripsi, Canonical, AMP, Login, Daftar)
//    Prinsip: Jika tidak ditemukan di halaman, laporkan "Tidak ada" (found=false)
// -----------------------------------------------------------------------------
// Title
$extractedTitle = '';
if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $rawHtml, $mTitle)) {
    $extractedTitle = trim(html_entity_decode(strip_tags($mTitle[1]), ENT_QUOTES, 'UTF-8'));
}
if (empty($extractedTitle)) {
    $ogTitle = extract_meta_content($rawHtml, 'property', '/^og:title$/i');
    if (!empty($ogTitle)) $extractedTitle = trim($ogTitle);
}
if (empty($extractedTitle)) {
    $twTitle = extract_meta_content($rawHtml, 'name', '/^twitter:title$/i');
    if (!empty($twTitle)) $extractedTitle = trim($twTitle);
}

// Meta Description
$extractedDesc = extract_meta_content($rawHtml, 'name', '/^description$/i');
if (empty($extractedDesc)) {
    $extractedDesc = extract_meta_content($rawHtml, 'property', '/^og:description$/i');
}
if (empty($extractedDesc)) {
    $extractedDesc = extract_meta_content($rawHtml, 'name', '/^twitter:description$/i');
}
$extractedDesc = trim($extractedDesc);

// Canonical LP URL & AMP URL (Attribute-order independent!)
$canonicalTagHref = resolve_url(extract_link_tag_href($rawHtml, '/^canonical$/i'), $effectiveUrl);
$ogUrlTag         = resolve_url(extract_meta_content($rawHtml, 'property', '/^og:url$/i'), $effectiveUrl);
$ampHtmlTagHref   = resolve_url(extract_link_tag_href($rawHtml, '/^amphtml$/i'), $effectiveUrl);
$altAmpHref       = '';
if (empty($ampHtmlTagHref) && preg_match_all('/<link\b[^>]*>/is', $rawHtml, $mAltLinks)) {
    foreach ($mAltLinks[0] as $lt) {
        $la = parse_tag_attributes($lt);
        if (stripos($la['rel'] ?? '', 'amp') !== false && !empty($la['href'])) {
            $altAmpHref = resolve_url($la['href'], $effectiveUrl);
            break;
        }
    }
}

$rawTargetCanonical = $canonicalTagHref ?: $ogUrlTag;
$canonicalTagFound  = !empty($canonicalTagHref) || !empty($ogUrlTag);

// Deteksi status LP & AMP secara jelas
$lpDetectedUrl = '';
if (!$detectedIsAmp) {
    $lpDetectedUrl = $canonicalTagHref ?: $effectiveUrl;
} elseif ($lpVersion) {
    $lpDetectedUrl = $lpVersion['final_url'];
} elseif (!empty($rawTargetCanonical) && rtrim($rawTargetCanonical, '/') !== rtrim($effectiveUrl, '/')) {
    $lpDetectedUrl = $rawTargetCanonical;
}

$rawTargetAmp = '';
if ($detectedIsAmp) {
    $rawTargetAmp = $effectiveUrl;
} elseif (!empty($ampHtmlTagHref)) {
    $rawTargetAmp = $ampHtmlTagHref;
} elseif (!empty($altAmpHref)) {
    $rawTargetAmp = $altAmpHref;
} elseif ($ampVersion) {
    $rawTargetAmp = $ampVersion['final_url'];
}

$lpFound  = !empty($lpDetectedUrl);
$ampFound = !empty($rawTargetAmp);

// Nilai yang diisi ke input saat scan vs saat execute clone (jujur: jika tag canonical tidak ada, kosongkan saat scan!)
$detectedCanonicalForInput = $canonicalTagFound ? $rawTargetCanonical : '';
$extractedCanonical = !empty($canUrl) ? $canUrl : ($rawTargetCanonical ?: $effectiveUrl);
$extractedAmpUrl    = !empty($ampUrl) ? $ampUrl : $rawTargetAmp;

// Favicon / Icon (tanpa fallback palsu ke logo saat scan!)
$rawFaviconHref = extract_link_tag_href($rawHtml, '/^(?:shortcut\s+icon|icon|apple-touch-icon|apple-touch-icon-precomposed)$/i');
$extractedFavicon = $rawFaviconHref ? resolve_url($rawFaviconHref, $effectiveUrl) : '';

// -----------------------------------------------------------------------------
// 3b. Extract Login URL & Register / Link Alternatif URL (termasuk tombol bergambar!)
// -----------------------------------------------------------------------------
$extractedLoginUrl = '';
$extractedRegUrl   = '';
$ctaCandidates     = [];

if (preg_match_all('/<button\b([^>]*)onclick=["\'][^"\']*(?:window\.)?location(?:\.href)?\s*=\s*([\'"])(.*?)\2[^"\']*["\']([^>]*)>(.*?)<\/button>/is', $rawHtml, $mBtnLinks, PREG_SET_ORDER)) {
    foreach ($mBtnLinks as $bm) {
        $bUrl  = resolve_url(trim($bm[3]), $effectiveUrl);
        $bMeta = trim(strip_tags($bm[5])) . ' ' . $bm[1] . ' ' . $bm[4] . ' ' . $bm[5];
        if (empty($bUrl) || $bUrl === '#' || substr($bUrl, 0, 1) === '#' || stripos($bUrl, 'javascript:') === 0) continue;
        $ctaCandidates[] = ['text' => trim(strip_tags($bm[5])) ?: 'Button CTA', 'href' => $bUrl];
        if (empty($extractedLoginUrl) && (preg_match('/login|masuk|sign[\s\-]?in|member[\s\-]?area|\bauth\b/i', $bMeta) || preg_match('/login|masuk|signin|auth/i', $bUrl))) {
            $extractedLoginUrl = $bUrl;
        } elseif (empty($extractedRegUrl) && (preg_match('/daftar|register|sign[\s\-]?up|registrasi|join|alternatif|claim|bonus|main\s+sekarang/i', $bMeta) || preg_match('/daftar|register|signup|registrasi|alternatif|ref=/i', $bUrl))) {
            $extractedRegUrl = $bUrl;
        }
    }
}

if (preg_match_all('/<a\b([^>]*)href=["\']([^"\']*)["\']([^>]*)>(.*?)<\/a>/is', $rawHtml, $mAnchorLinks, PREG_SET_ORDER)) {
    foreach ($mAnchorLinks as $am) {
        $aUrl = trim($am[2]);
        if (preg_match('/\[.*?\]\((https?:\/\/[^\)]+)\)/i', $aUrl, $mMd)) {
            $aUrl = $mMd[1];
        }
        $aUrl = resolve_url($aUrl, $effectiveUrl);
        if (empty($aUrl) || $aUrl === '#' || substr($aUrl, 0, 1) === '#' || stripos($aUrl, 'javascript:') === 0 || stripos($aUrl, 'mailto:') === 0 || stripos($aUrl, 'tel:') === 0) continue;

        $visibleTxt = trim(strip_tags($am[4]));
        $altInside  = '';
        if (preg_match_all('/(?:alt|title|aria-label|src|class|id)=["\']([^"\']*)["\']/i', $am[0], $mAttrsInA)) {
            $altInside = implode(' ', $mAttrsInA[1]);
        }
        $combinedHint = $visibleTxt . ' ' . $altInside;

        if (count($ctaCandidates) < 20) {
            $ctaCandidates[] = ['text' => substr($visibleTxt ?: $altInside ?: 'Link', 0, 60), 'href' => $aUrl];
        }

        if (empty($extractedLoginUrl) && (preg_match('/login|masuk|sign[\s\-]?in|member[\s\-]?area|\bauth\b/i', $combinedHint) || preg_match('/login|masuk|signin|auth/i', $aUrl))) {
            $extractedLoginUrl = $aUrl;
        } elseif (empty($extractedRegUrl) && (preg_match('/daftar|register|sign[\s\-]?up|registrasi|join|claim|alternatif|rtp|livechat|bonus/i', $combinedHint) || preg_match('/register|daftar|signup|registrasi|alternatif|ref=|promo/i', $aUrl))) {
            $extractedRegUrl = $aUrl;
        }
    }
}

// Cek juga <form action="..."> jika ada form login/daftar
if ((empty($extractedLoginUrl) || empty($extractedRegUrl)) && preg_match_all('/<form\b[^>]*>/is', $rawHtml, $mForms)) {
    foreach ($mForms[0] as $fTag) {
        $fa = parse_tag_attributes($fTag);
        $fAct = resolve_url(trim($fa['action'] ?? ''), $effectiveUrl);
        if (empty($fAct) || $fAct === '#' || stripos($fAct, 'javascript:') === 0) continue;
        $fHint = ($fa['id'] ?? '') . ' ' . ($fa['class'] ?? '') . ' ' . ($fa['name'] ?? '') . ' ' . $fAct;
        if (empty($extractedLoginUrl) && preg_match('/login|masuk|signin|auth/i', $fHint)) {
            $extractedLoginUrl = $fAct;
        } elseif (empty($extractedRegUrl) && preg_match('/daftar|register|signup|registrasi/i', $fHint)) {
            $extractedRegUrl = $fAct;
        }
    }
}

// JANGAN memalsukan login/reg menggunakan canonical selama Scan jika benar-benar tidak ada!
$detectedLoginFound = !empty($extractedLoginUrl);
$detectedRegFound   = !empty($extractedRegUrl);

// -----------------------------------------------------------------------------
// 4. Ekstraksi Gambar, Banner, Logo, GIF & Video secara Jujur
// -----------------------------------------------------------------------------
$negativeFilter = '/(?:apple-touch-icon|playstore|google-en|app\.png|app-store|google-play|whatsapp|facebook|instagram|youtube|telegram|line|twitter|tiktok|vector|badge|rating|delivery|gift|kredivo|payment|qris|dana|ovo|gopay|bank|bca|bni|bri|mandiri|circle|bxl|app_store|download-apk|googleplay|flag|ind-flag|eng-flag|multistore|truck|open-new-tab|spacer\.gif|blank\.gif|1x1\.gif|loading\.svg|spinner)/i';

$targetHost = parse_url($effectiveUrl, PHP_URL_HOST);
$allMediaTags = [];
$rawImgs = [];

if (preg_match_all('/<(amp-img|amp-anim|img)\b[^>]*>/is', $rawHtml, $mImgTags, PREG_SET_ORDER)) {
    foreach ($mImgTags as $im) {
        $tagName = strtolower($im[1]);
        $fullTag = $im[0];
        $attrs   = parse_tag_attributes($fullTag);
        $srcRaw  = '';
        foreach (['data-src', 'data-original', 'data-lazy-src', 'data-lazy', 'src'] as $srcAttr) {
            if (!empty($attrs[$srcAttr]) && stripos($attrs[$srcAttr], 'data:image/') !== 0) {
                $srcRaw = trim($attrs[$srcAttr]);
                break;
            }
        }
        if (empty($srcRaw) && !empty($attrs['srcset'])) {
            $ssParts = preg_split('/\s*,\s*/', trim($attrs['srcset']));
            if (!empty($ssParts[0])) {
                $srcRaw = preg_split('/\s+/', trim($ssParts[0]))[0];
            }
        }
        if (empty($srcRaw) && !empty($attrs['src'])) {
            $srcRaw = trim($attrs['src']);
        }
        $fullImg = resolve_url($srcRaw, $effectiveUrl);
        if (empty($fullImg) || stripos($fullImg, 'data:image/') === 0) continue;

        $rawImgs[] = $fullImg;
        $allMediaTags[] = [
            'tag'  => $tagName,
            'full' => $fullTag,
            'src'  => $fullImg,
            'alt'  => trim($attrs['alt'] ?? ''),
            'cls'  => trim(($attrs['class'] ?? '') . ' ' . ($attrs['id'] ?? ''))
        ];
    }
}

// Cari juga background-image: url(...) untuk GIF / Banner CSS
$cssBgGif = '';
$cssBgBanner = '';
if (preg_match_all('/background(?:-image)?\s*:[^;{}]*url\((["\']?)([^)"\'\r\n]+)\1\)/i', $rawHtml, $mCssBg)) {
    foreach ($mCssBg[2] as $bgUrl) {
        $absBg = resolve_url(trim($bgUrl), $effectiveUrl);
        if (empty($absBg) || stripos($absBg, 'data:') === 0 || preg_match($negativeFilter, $absBg)) continue;
        if (empty($cssBgGif) && preg_match('/\.gif(\?.*)?$/i', $absBg)) {
            $cssBgGif = $absBg;
        } elseif (empty($cssBgBanner) && preg_match('/banner|hero|bg|slider|promo/i', $absBg)) {
            $cssBgBanner = $absBg;
        }
    }
}

// Extract Video (<amp-video src="..."> or <video src="..."> or <source src="...">)
preg_match_all('/<(?:amp-video|video|source)\b[^>]*src=["\']([^"\']*)["\'][^>]*>/is', $rawHtml, $mAllVideos);
$extractedVideo = !empty($mAllVideos[1][0]) ? resolve_url(trim($mAllVideos[1][0]), $effectiveUrl) : '';

$ogImageMeta = resolve_url(extract_meta_content($rawHtml, 'property', '/^og:image$/i'), $effectiveUrl);
$twImageMeta = resolve_url(extract_meta_content($rawHtml, 'name', '/^twitter:image$/i'), $effectiveUrl);

$extractedLogo   = '';
$extractedBanner = '';
$extractedGif    = '';

// 4a. Cari GIF, Banner, dan Logo secara terpisah & akurat
foreach ($allMediaTags as $mItem) {
    $fullTag = $mItem['full'];
    $fullImg = $mItem['src'];
    $metaStr = $fullTag . ' ' . $fullImg . ' ' . $mItem['alt'] . ' ' . $mItem['cls'];

    if (preg_match($negativeFilter, $fullImg) || preg_match($negativeFilter, $fullTag)) continue;

    $imgHost = parse_url($fullImg, PHP_URL_HOST);
    $isOwnDomain = !empty($targetHost) && ($imgHost === $targetHost || substr($imgHost, -strlen('.' . $targetHost)) === '.' . $targetHost);

    // 1. GIF (strictly only true GIF or <amp-anim>)
    if (empty($extractedGif) && ($mItem['tag'] === 'amp-anim' || preg_match('/\.gif(\?.*)?$/i', $fullImg))) {
        $extractedGif = $fullImg;
    }

    // 2. Logo Brand (strictly logo keywords or Organization schema)
    if (empty($extractedLogo) && preg_match('/\blogo\b|brand-logo|header-logo|navbar-brand|site-logo|img-logo/i', $metaStr)) {
        if ($isOwnDomain || empty($extractedLogo)) {
            $extractedLogo = $fullImg;
            continue; // Jangan jadikan logo yang sama sebagai banner pada pass utama
        }
    }

    // 3. Banner Utama
    if (empty($extractedBanner) && preg_match('/banner|slider|fotorama|hero|promo|jackpot|main-image|stickyimg|popup-image|featured|carousel|slide/i', $metaStr)) {
        if (!preg_match('/\.gif(\?.*)?$/i', $fullImg) || empty($extractedGif)) {
            $extractedBanner = $fullImg;
        }
    }
}

// Cek JSON-LD Organization.logo jika Logo belum ketemu
if (empty($extractedLogo) && preg_match('/"logo"\s*:\s*(?:\{[^}]*"url"\s*:\s*"([^"]+)"|"([^"]+)")/i', $rawHtml, $mJsonLogo)) {
    $jlLogo = resolve_url(trim($mJsonLogo[1] ?: $mJsonLogo[2]), $effectiveUrl);
    if (!empty($jlLogo) && preg_match('#^https?://#i', $jlLogo)) {
        $extractedLogo = $jlLogo;
    }
}

// Fallback Banner: gunakan og:image / twitter:image / css background / gambar besar non-logo (tapi JANGAN pakai logo yang sama sebagai banner!)
if (empty($extractedBanner)) {
    if (!empty($ogImageMeta) && $ogImageMeta !== $extractedLogo && !preg_match($negativeFilter, $ogImageMeta)) {
        $extractedBanner = $ogImageMeta;
    } elseif (!empty($twImageMeta) && $twImageMeta !== $extractedLogo && !preg_match($negativeFilter, $twImageMeta)) {
        $extractedBanner = $twImageMeta;
    } elseif (!empty($cssBgBanner) && $cssBgBanner !== $extractedLogo) {
        $extractedBanner = $cssBgBanner;
    } else {
        foreach ($allMediaTags as $mItem) {
            $fullImg = $mItem['src'];
            if ($fullImg === $extractedLogo || $fullImg === $extractedFavicon) continue;
            if (preg_match($negativeFilter, $fullImg) || preg_match($negativeFilter, $mItem['full']) || preg_match('/\.svg(\?.*)?$/i', $fullImg)) continue;
            // Lewati icon kecil (< 80px) bila tercantum atribut width/height kecil
            if (preg_match('/width=["\'](\d+)["\']/i', $mItem['full'], $mw) && intval($mw[1]) > 0 && intval($mw[1]) < 90) continue;
            $extractedBanner = $fullImg;
            break;
        }
    }
}

// Fallback GIF dari CSS atau og:image
if (empty($extractedGif)) {
    if (!empty($cssBgGif)) {
        $extractedGif = $cssBgGif;
    } elseif (!empty($ogImageMeta) && preg_match('/\.gif(\?.*)?$/i', $ogImageMeta)) {
        $extractedGif = $ogImageMeta;
    }
}

// Siapkan daftar kandidat gambar unik untuk ditampilkan/dianalisis AI
$candidateImgsSummary = [];
$seenCand = [];
foreach ($allMediaTags as $mItem) {
    if (isset($seenCand[$mItem['src']])) continue;
    if (preg_match($negativeFilter, $mItem['src'])) continue;
    $seenCand[$mItem['src']] = true;
    $candidateImgsSummary[] = [
        'src' => $mItem['src'],
        'alt' => substr($mItem['alt'], 0, 80),
        'tag' => $mItem['tag'] . ($mItem['cls'] ? '.' . substr($mItem['cls'], 0, 50) : '')
    ];
    if (count($candidateImgsSummary) >= 20) break;
}

// Override dengan custom input pengguna (bila diisi manual)
$finalBanner  = !empty($customBanner)  ? $customBanner  : $extractedBanner;
$finalLogo    = !empty($customLogo)    ? $customLogo    : $extractedLogo;
$finalFavicon = !empty($customFavicon) ? $customFavicon : $extractedFavicon;
$finalGif     = !empty($customGif)     ? $customGif     : $extractedGif;

// -----------------------------------------------------------------------------
// 5. Ekstraksi Menyeluruh SEMUA Nama Brand Lama (Rule-Based + Gemini AI)
//    Memastikan tidak ada brand sisa kloning yang tertinggal!
// -----------------------------------------------------------------------------
$genericStopWords = [
    'brand', 'situs', 'resmi', 'online', 'gacor', 'slot', 'togel', 'casino', 'poker', 'bola',
    'judi', 'live', 'login', 'daftar', 'register', 'alternatif', 'link', 'promo', 'bonus',
    'jackpot', 'maxwin', 'terpercaya', 'terbaik', 'terlengkap', 'hari', 'ini', 'indonesia',
    'mega', 'menu', 'col', 'level', 'item', 'home', 'page', 'website', 'official', 'admin',
    'member', 'vip', 'pro', 'amp', 'html', 'com', 'net', 'org', 'xyz', 'site', 'top', 'new',
    '2024', '2025', '2026', '2027', 'hotel', 'store', 'shop', 'cart', 'cdn', 'img', 'image',
    'jpg', 'png', 'gif', 'webp', 'svg', 'http', 'https', 'www', 'viewport', 'robots', 'index',
    'follow', 'content', 'type', 'text', 'utf', 'width', 'height', 'style', 'class', 'div',
    'span', 'button', 'true', 'false', 'null', 'gaming', 'play', 'bets', 'indo', 'asia', 'main',
    'data', 'info', 'club', 'city', 'news', 'blog', 'tech', 'corp', 'agen', 'bandar', 'rtp',
    'deposit', 'withdraw', 'dana', 'pulsa', 'server', 'thailand', 'kamboja', 'hongkong', 'sydney',
    'singapore', 'macau', 'platform', 'portal', 'mobile', 'desktop', 'aplikasi', 'apk', 'game',
    'localhost', 'utf8', 'utf16', 'md5', 'sha1', 'sha256', 'mp4', 'html5', 'css3', 'http2', 'ipv4', 'ipv6',
    'webp2', 'h264', 'rgb', 'win10', 'win11', 'ios', 'android', 'chrome', 'safari', 'google', 'adalah', 'dengan',
    'mitra', 'partner', 'anggota', 'pemain', 'player', 'semua', 'kita', 'kami', 'anda', 'mereka', 'dunia',
    'nusantara', 'negara', 'unggulan', 'favorit', 'populer', 'utama', 'terbaru', 'aman', 'nyaman', 'cepat', 'pasti'
];

$isGenericWord = function($w) use ($genericStopWords) {
    $lw = strtolower(trim($w));
    if (strlen($lw) < 3 || is_numeric($lw) || filter_var($lw, FILTER_VALIDATE_IP)) return true;
    return in_array($lw, $genericStopWords, true);
};

$detectedBrands = [];

// 5a. Dari Title (sebelum pemisah :, |, -, –, —, », •, $, /)
if (preg_match('/^([a-zA-Z0-9_\-\.\s&]{2,40}?)\s*(?:[:|\-–—»•$\/]|\bResmi\b|\bSlot\b|\bLogin\b|\bDaftar\b|\bSitus\b|\bTogel\b)/ui', $extractedTitle, $mB)) {
    $bRaw = trim($mB[1]);
    foreach (preg_split('/\s+(?:x|&amp;|&|vs|\+)\s+/i', $bRaw) as $bSub) {
        $bSub = trim($bSub);
        if (!$isGenericWord($bSub)) $detectedBrands[] = $bSub;
    }
    if (!$isGenericWord($bRaw) && stripos($bRaw, ' x ') === false && strpos($bRaw, '&') === false) {
        $detectedBrands[] = $bRaw;
    }
}

// 5b. Dari meta og:site_name, application-name, author, publisher
foreach (['og:site_name', 'application-name', 'author', 'publisher'] as $mKey) {
    $mv = extract_meta_content($rawHtml, (strpos($mKey, 'og:') === 0 ? 'property' : 'name'), '/^' . preg_quote($mKey, '/') . '$/i');
    $mv = trim($mv);
    if (!empty($mv) && strlen($mv) <= 35 && !$isGenericWord($mv)) {
        $detectedBrands[] = $mv;
    }
}

// 5c. Dari JSON-LD (@graph WebSite/Organization/Brand name)
if (preg_match_all('/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is', $rawHtml, $mJsonLdAll)) {
    foreach ($mJsonLdAll[1] as $jRaw) {
        $jDec = json_decode(trim($jRaw), true);
        if (is_array($jDec)) {
            $stack = [$jDec];
            while ($stack) {
                $curr = array_pop($stack);
                if (!is_array($curr)) continue;
                if (isset($curr['@type'], $curr['name']) && is_string($curr['name']) && in_array($curr['@type'], ['Organization', 'WebSite', 'Brand', 'OnlineBusiness', 'Store'])) {
                    $nm = trim($curr['name']);
                    if (strlen($nm) >= 3 && strlen($nm) <= 35 && !$isGenericWord($nm)) {
                        $detectedBrands[] = $nm;
                    }
                }
                foreach ($curr as $v) {
                    if (is_array($v)) $stack[] = $v;
                }
            }
        }
    }
}

// 5d. Dari deskripsi & body keywords ("terpercaya di X", "situs X", "bersama X", "© 2026 X")
if (preg_match_all('/(?:terpercaya\s+di|bersama|situs\s+resmi|agen\s+resmi|link\s+resmi|member|copyright|&copy;|©)\s*(?:20\d{2}\s*)?([A-Z0-9][a-zA-Z0-9_\-]{2,24})/i', $extractedDesc . "\n" . substr(strip_tags($rawHtml), 0, 20000), $mDescBrands)) {
    foreach ($mDescBrands[1] as $db) {
        $db = trim($db);
        if (!$isGenericWord($db)) {
            $detectedBrands[] = $db;
        }
    }
}

// Siapkan teks ringkasan halaman (headings & img alt) lebih dulu agar ikut dipindai token brand sisa kloning
$headingsArr = [];
if (preg_match_all('/<h[1-3]\b[^>]*>(.*?)<\/h[1-3]>/is', $rawHtml, $mHeads)) {
    foreach (array_slice($mHeads[1], 0, 12) as $hItem) {
        $ht = trim(preg_replace('/\s+/', ' ', html_entity_decode(strip_tags($hItem), ENT_QUOTES, 'UTF-8')));
        if (!empty($ht)) $headingsArr[] = substr($ht, 0, 120);
    }
}
$imgAltsArr = [];
foreach ($allMediaTags as $mItem) {
    if (!empty($mItem['alt'])) $imgAltsArr[] = substr($mItem['alt'], 0, 70);
}
$imgAltsArr = array_values(array_unique(array_slice($imgAltsArr, 0, 15)));

// 5e. Ekstrak token brand unik (kombinasi Huruf+Angka seperti SLOT777JP / garuda88 / KAWIJITU / BENTO4D) termasuk dari alt gambar & headings!
$plainVisibleText = preg_replace('/<(script|style)\b[^>]*>.*?<\/\1>/is', ' ', $rawHtml);
$plainVisibleText = trim(preg_replace('/\s+/', ' ', html_entity_decode(strip_tags($plainVisibleText), ENT_QUOTES, 'UTF-8')));
$brandCorpusText  = $extractedTitle . ' ' . $extractedDesc . ' ' . implode(' ', $headingsArr) . ' ' . implode(' ', $imgAltsArr) . ' ' . substr($plainVisibleText, 0, 25000);

if (preg_match_all('/\b([A-Za-z]{3,18}\d+[A-Za-z0-9]*|[A-Z]{4,18})\b/', $brandCorpusText, $mTok)) {
    $tokCounts = [];
    foreach ($mTok[1] as $tk) {
        if ($isGenericWord($tk)) continue;
        $k = strtoupper($tk);
        $tokCounts[$k] = ($tokCounts[$k] ?? 0) + 1;
    }
    arsort($tokCounts);
    foreach ($tokCounts as $tkUpper => $cnt) {
        if ($cnt >= 2 && count($detectedBrands) < 12) {
            $detectedBrands[] = $tkUpper;
        }
    }
}

// 5f. Dari Host / Domain URL target
$host = parse_url($effectiveUrl, PHP_URL_HOST) ?: parse_url($targetUrl, PHP_URL_HOST);
$targetHostDomain = $host;
if (!empty($host) && !filter_var($host, FILTER_VALIDATE_IP)) {
    $hParts = explode('.', $host);
    $hostBrandRaw = ($hParts[0] === 'www' || $hParts[0] === 'amp') ? ($hParts[1] ?? 'BRAND') : $hParts[0];
    if (!$isGenericWord($hostBrandRaw)) {
        $detectedBrands[] = strtoupper($hostBrandRaw);
        $detectedBrands[] = $hostBrandRaw;
    }
} else {
    $hostBrandRaw = '';
}

$finalTitle = !empty($customTitle) ? $customTitle : $extractedTitle;
$finalDesc  = !empty($customDesc)  ? $customDesc  : $extractedDesc;
$detectedBrandInitial = !empty($detectedBrands) ? reset($detectedBrands) : ($hostBrandRaw ?? 'BRAND');
$finalName = !empty($brandName) ? $brandName : $detectedBrandInitial;

// -----------------------------------------------------------------------------
// 5f-2. Ekstraksi Jujur Ulasan Pengguna (Reviews) & Detail-detail (<details> / FAQ)
// -----------------------------------------------------------------------------
$extractedBlocks  = extract_reviews_and_faqs_from_html($rawHtml, $detectedBrandInitial);
$extractedReviews = $extractedBlocks['reviews'] ?? [];
$extractedFaqs    = $extractedBlocks['faqs'] ?? [];

// Scan teks di dalam reviews & faqs untuk mendeteksi brand lama yang mungkin hanya muncul di testimoni/FAQ/JSON-LD
$extraBlocksText = '';
foreach ($extractedReviews as $erItem) {
    $extraBlocksText .= ' ' . ($erItem['text'] ?? '');
}
foreach ($extractedFaqs as $efItem) {
    $extraBlocksText .= ' ' . ($efItem['question'] ?? '') . ' ' . ($efItem['answer'] ?? '');
}
if ($extraBlocksText !== '' && preg_match_all('/\b([A-Za-z]{3,18}\d+[A-Za-z0-9]*|[A-Z]{4,18})\b/', $extraBlocksText, $mBlkTok)) {
    foreach ($mBlkTok[1] as $btk) {
        if (!$isGenericWord($btk) && count($detectedBrands) < 16) {
            $detectedBrands[] = strtoupper($btk);
        }
    }
}

// -----------------------------------------------------------------------------
// 5g. GEMINI AI DEEP INSPECTOR (Deteksi Format AMP/LP, Semua Brand Lama, Aset Media, Links, Ulasan & Detail/FAQ)
// -----------------------------------------------------------------------------
$useAi = isset($data['use_ai']) ? (bool)$data['use_ai'] : true;
// Prioritaskan API Key khusus Cloaking/Analisis agar kuota builder aman
$aiApiKey = $pdo->query("SELECT value FROM settings WHERE key='ai_api_key_cloaking'")->fetchColumn() ?: '';
if (empty($aiApiKey)) {
    $aiApiKey = $pdo->query("SELECT value FROM settings WHERE key='ai_api_key'")->fetchColumn() ?: '';
}
$aiModel  = $pdo->query("SELECT value FROM settings WHERE key='ai_model'")->fetchColumn() ?: 'gemini-3-flash-preview';

$aiJson = [];
$aiUsed = false;
$aiBrands = [];
$aiPageFormatReason = '';

if ($useAi && !empty($aiApiKey)) {
    try {
        $digest = [
            'crawled_url'             => $effectiveUrl,
            'dom_detected_format'     => $detectedIsAmp ? 'amp' : 'lp',
            'canonical_tag'           => $canonicalTagHref,
            'amphtml_tag'             => $ampHtmlTagHref,
            'title_tag'               => $extractedTitle,
            'meta_description'        => $extractedDesc,
            'favicon_tag'             => $extractedFavicon,
            'headings'                => $headingsArr,
            'img_alts'                => $imgAltsArr,
            'detected_brands_local'   => array_values(array_unique($detectedBrands)),
            'cta_links'               => array_slice($ctaCandidates, 0, 15),
            'image_candidates'        => $candidateImgsSummary,
            'extracted_reviews_local' => $extractedReviews,
            'extracted_faqs_local'    => $extractedFaqs,
            'body_text_excerpt'       => substr($plainVisibleText, 0, 2200) . (strlen($plainVisibleText) > 2500 ? ' ... ' . substr($plainVisibleText, -800) : '')
        ];
        $digestJson = json_encode($digest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $aiPrompt = "Kamu adalah Pakar SEO Teknis, Web Scraper Forensik & Audit AMP/Landing Page.
Analisa DATA HALAMAN TARGET di bawah ini secara JUJUR berdasarkan fakta pada data (JANGAN mengarang URL, ulasan pengguna, atau FAQ jika memang tidak ada — kembalikan string kosong \"\" atau array kosong []):

DATA HALAMAN:
{$digestJson}

Kembalikan HANYA JSON persis sesuai skema berikut:
{
  \"page_type\": \"amp atau lp\",
  \"page_type_reason\": \"penjelasan singkat kenapa AMP atau LP\",
  \"primary_old_brand\": \"nama brand utama yang sedang dipakai halaman target (atau kosong jika tidak ada)\",
  \"all_old_brands\": [\"daftar SEMUA nama brand lama, alias brand, nama situs lain yang masih terselip/sisa kloning di title/headings/body/alt/footer. Hanya nama brand, JANGAN masukkan kata umum seperti 'slot', 'gacor', 'resmi', 'login', 'daftar'.\"],
  \"title\": \"title halaman target apa adanya (atau optimalkan hanya jika sudah ada, kosongkan '' jika di data memang tidak ada title)\",
  \"meta_description\": \"meta deskripsi dari data target (kosongkan '' jika memang tidak ada deskripsi di halaman target)\",
  \"banner_url\": \"pilih HANYA dari image_candidates jika memang ada foto banner utama/promo/hero/slider, atau '' jika tidak ada\",
  \"logo_url\": \"pilih HANYA dari image_candidates jika memang ada logo brand, atau '' jika tidak ada\",
  \"favicon_url\": \"isi favicon_tag jika memang ada icon, atau '' jika tidak ada\",
  \"gif_url\": \"pilih HANYA URL .gif/amp-anim dari image_candidates jika ada animasi GIF, atau '' jika tidak ada\",
  \"login_url\": \"pilih HANYA dari cta_links jika ada link login/masuk, atau '' jika tidak ada\",
  \"register_url\": \"pilih HANYA dari cta_links jika ada link daftar/register/alternatif, atau '' jika tidak ada\",
  \"reviews\": [
    {\"name\": \"...\", \"location\": \"...\", \"rating\": 5, \"text\": \"...\"}
  ],
  \"faqs\": [
    {\"question\": \"...\", \"answer\": \"...\"}
  ]
}
PENTING:
- Untuk \"reviews\": kembalikan ulasan pengguna HANYA JIKA di halaman target (extracted_reviews_local atau body_text_excerpt) MEMANG ADA ulasan pengguna/testimoni asli. Jika tidak ada ulasan pengguna di halaman target, WAJIB kembalikan [] (JANGAN mengarang ulasan palsu!).
- Untuk \"faqs\": kembalikan detail/FAQ HANYA JIKA di halaman target (extracted_faqs_local atau body_text_excerpt) MEMANG ADA elemen detail/FAQ asli. Jika tidak ada detail/FAQ di halaman target, WAJIB kembalikan [] (JANGAN mengarang FAQ palsu!).";

        $aiUrl = "https://generativelanguage.googleapis.com/v1beta/models/" . urlencode($aiModel) . ":generateContent?key=" . urlencode($aiApiKey);
        $chAi = curl_init($aiUrl);
        curl_setopt($chAi, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($chAi, CURLOPT_POST, true);
        curl_setopt($chAi, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($chAi, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($chAi, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($chAi, CURLOPT_POSTFIELDS, json_encode([
            'contents' => [['parts' => [['text' => $aiPrompt]]]],
            'generationConfig' => ['responseMimeType' => 'application/json']
        ]));
        curl_setopt($chAi, CURLOPT_TIMEOUT, 14);
        $aiRaw = curl_exec($chAi);
        $aiCode = curl_getinfo($chAi, CURLINFO_HTTP_CODE);
        curl_close($chAi);

        if ($aiCode === 200 && !empty($aiRaw)) {
            $aiDec = json_decode($aiRaw, true);
            $aiTextContent = $aiDec['candidates'][0]['content']['parts'][0]['text'] ?? '';
            $parsedAi = json_decode(trim(preg_replace('/^```json\s*|\s*```$/i', '', $aiTextContent)), true);
            if (!empty($parsedAi) && is_array($parsedAi)) {
                $aiUsed = true;
                $aiJson = $parsedAi;

                if (!empty($parsedAi['page_type_reason'])) {
                    $aiPageFormatReason = trim($parsedAi['page_type_reason']);
                }
                if (!empty($parsedAi['primary_old_brand']) && !$isGenericWord($parsedAi['primary_old_brand'])) {
                    $detectedBrands[] = trim($parsedAi['primary_old_brand']);
                    if (empty($brandName)) {
                        $detectedBrandInitial = trim($parsedAi['primary_old_brand']);
                    }
                }
                if (!empty($parsedAi['all_old_brands']) && is_array($parsedAi['all_old_brands'])) {
                    foreach ($parsedAi['all_old_brands'] as $ab) {
                        $ab = trim((string)$ab);
                        if (strlen($ab) >= 3 && !$isGenericWord($ab)) {
                            $aiBrands[] = $ab;
                            $detectedBrands[] = $ab;
                        }
                    }
                }

                // Terima hasil AI hanya jika valid URL yang memang berasal dari halaman target (bukan karangan!)
                $candSrcSet = array_column($candidateImgsSummary, 'src');
                if (empty($customBanner) && empty($extractedBanner) && !empty($parsedAi['banner_url']) && in_array($parsedAi['banner_url'], $candSrcSet, true)) {
                    $finalBanner = trim($parsedAi['banner_url']);
                }
                if (empty($customLogo) && empty($extractedLogo) && !empty($parsedAi['logo_url']) && in_array($parsedAi['logo_url'], $candSrcSet, true)) {
                    $finalLogo = trim($parsedAi['logo_url']);
                }
                if (empty($customFavicon) && empty($extractedFavicon) && !empty($parsedAi['favicon_url']) && filter_var($parsedAi['favicon_url'], FILTER_VALIDATE_URL)) {
                    $finalFavicon = trim($parsedAi['favicon_url']);
                }
                if (empty($customGif) && empty($extractedGif) && !empty($parsedAi['gif_url']) && in_array($parsedAi['gif_url'], $candSrcSet, true)) {
                    $finalGif = trim($parsedAi['gif_url']);
                }

                $ctaHrefSet = array_column($ctaCandidates, 'href');
                if (empty($extractedLoginUrl) && !empty($parsedAi['login_url']) && in_array($parsedAi['login_url'], $ctaHrefSet, true)) {
                    $extractedLoginUrl = trim($parsedAi['login_url']);
                    $detectedLoginFound = true;
                }
                if (empty($extractedRegUrl) && !empty($parsedAi['register_url']) && in_array($parsedAi['register_url'], $ctaHrefSet, true)) {
                    $extractedRegUrl = trim($parsedAi['register_url']);
                    $detectedRegFound = true;
                }

                // Hanya gunakan hasil AI untuk reviews/faqs jika di halaman target memang terbukti ada teksnya (anti-halusinasi!)
                if (empty($extractedReviews) && !empty($parsedAi['reviews']) && is_array($parsedAi['reviews'])) {
                    foreach ($parsedAi['reviews'] as $ar) {
                        $rName = trim((string)($ar['name'] ?? ''));
                        $rText = trim((string)($ar['text'] ?? ''));
                        $rLoc  = trim((string)($ar['location'] ?? 'Indonesia'));
                        $rRate = max(1, min(5, intval($ar['rating'] ?? 5)));
                        if ($rName !== '' && $rText !== '' && stripos($plainVisibleText, $rName) !== false) {
                            $extractedReviews[] = [
                                'name'     => $rName,
                                'location' => $rLoc ?: 'Indonesia',
                                'rating'   => $rRate,
                                'text'     => $rText
                            ];
                        }
                    }
                }

                if (empty($extractedFaqs) && !empty($parsedAi['faqs']) && is_array($parsedAi['faqs'])) {
                    foreach ($parsedAi['faqs'] as $af) {
                        $q = trim((string)($af['question'] ?? ($af['q'] ?? '')));
                        $a = trim((string)($af['answer'] ?? ($af['a'] ?? '')));
                        $qProbe = substr($q, 0, min(24, strlen($q)));
                        if ($q !== '' && $a !== '' && strlen($qProbe) >= 5 && stripos($plainVisibleText, $qProbe) !== false) {
                            $extractedFaqs[] = ['question' => $q, 'answer' => $a, 'q' => $q, 'a' => $a];
                        }
                    }
                }
            }
        }
    } catch (Exception $e) {
        // Fallback ke rule-based jika AI timeout
    }
}

// Perluas variasi semua brand lama (dengan proteksi kata umum agar "slot" / "mega" tidak rusak)
$allBrandVariations = [];
$commonBrandSuffixes = ['BET', 'SLOT', 'GAMING', 'BOLA', 'TOTO', 'POKER', 'CASINO', 'VIP', 'OFFICIAL', 'JP', '88', '777', '188', '118', '168', '303', '99'];

foreach ($detectedBrands as $dbItem) {
    $dbItem = trim($dbItem);
    if (empty($dbItem) || $isGenericWord($dbItem)) continue;

    $allBrandVariations[] = $dbItem;
    $noSp = preg_replace('/[\s\-]+/', '', $dbItem);
    if (!$isGenericWord($noSp)) $allBrandVariations[] = $noSp;

    // Pisahkan huruf+angka (contoh: AIRBET88 -> AIRBET 88, AIRBET-88, AIRBET; tetapi BUKAN SLOT777 -> SLOT!)
    if (preg_match('/^([a-zA-Z]+)(\d+[a-zA-Z]*)$/', $noSp, $mV)) {
        $allBrandVariations[] = $mV[1] . ' ' . $mV[2];
        $allBrandVariations[] = $mV[1] . '-' . $mV[2];
        if (strlen($mV[1]) >= 4 && !$isGenericWord($mV[1])) {
            $allBrandVariations[] = $mV[1];
        }
    }

    // Pisahkan akhiran kata umum (contoh: KAWIJITU / BENTO4D / SLOT777JP -> KAWIJITU JP / BENTO4D / SLOT777)
    foreach ($commonBrandSuffixes as $cbs) {
        if (preg_match('/^(.{3,}?)(' . $cbs . ')$/i', $noSp, $mSw)) {
            $basePart = trim($mSw[1]);
            $sufPart  = trim($mSw[2]);
            if (strlen($basePart) >= 4 && !$isGenericWord($basePart)) {
                $allBrandVariations[] = $basePart . ' ' . $sufPart;
                $allBrandVariations[] = $basePart . '-' . $sufPart;
                $allBrandVariations[] = $basePart;
            }
        }
    }

    $camelSplit = trim(preg_replace('/([a-z])([A-Z])/', '$1 $2', $dbItem));
    if (strlen($camelSplit) >= 4 && !$isGenericWord($camelSplit)) {
        $allBrandVariations[] = $camelSplit;
    }
}

$detectedBrand = $detectedBrandInitial ?: 'BRAND';
$finalName = !empty($brandName) ? $brandName : $detectedBrand;

$allOldBrandsForDisplay = array_values(array_unique(array_filter(array_merge($allBrandVariations, $detectedBrands), function($v) use ($brandName, $isGenericWord) {
    $t = trim($v);
    if (!empty($brandName) && strcasecmp($t, $brandName) === 0) return false;
    if ($isGenericWord($t)) return false;
    return strlen($t) >= 3;
})));
usort($allOldBrandsForDisplay, function($a, $b) { return strlen($b) - strlen($a); });

$searchBrands = array_unique(array_filter(array_merge($allBrandVariations, $detectedBrands), function($v) use ($finalName, $isGenericWord) {
    $t = trim($v);
    if (strcasecmp($t, $finalName) === 0) return false;
    if ($isGenericWord($t)) return false;
    return strlen($t) >= 3;
}));
usort($searchBrands, function($a, $b) { return strlen($b) - strlen($a); });

if (!function_exists('smart_swap_brand_text')) {
    function smart_swap_brand_text($text, $searchWord, $replaceWith) {
        if (strlen($searchWord) <= 4) {
            return preg_replace('/\b' . preg_quote($searchWord, '/') . '\b/iu', $replaceWith, $text) ?? $text;
        }
        // Tangani spasi/nbsp/baris baru di tengah kata brand (misal "SLOT\n 777" atau "NUSA&nbsp;188")
        if (preg_match('/[\s\-]/', $searchWord)) {
            $tokens = preg_split('/[\s\-]+/', trim($searchWord));
            $pattern = implode('(?:\s|&nbsp;|&#160;|-)+', array_map(function($t) { return preg_quote($t, '/'); }, $tokens));
            return preg_replace('/' . $pattern . '/iu', $replaceWith, $text) ?? $text;
        }
        return str_ireplace($searchWord, $replaceWith, $text);
    }
}

// Ganti seluruh brand lama pada finalTitle & finalDesc jika user tidak memasukkan custom title/desc
if (empty($customTitle) && !empty($finalTitle)) {
    foreach ($searchBrands as $sb) {
        $finalTitle = smart_swap_brand_text($finalTitle, $sb, $finalName);
    }
}
if (empty($customDesc) && !empty($finalDesc)) {
    foreach ($searchBrands as $sb) {
        $finalDesc = smart_swap_brand_text($finalDesc, $sb, $finalName);
    }
}

// Ganti seluruh brand lama pada Ulasan Pengguna ($extractedReviews) & Detail/FAQ ($extractedFaqs) yang terdeteksi
foreach ($extractedReviews as &$erItem) {
    foreach (['name', 'location', 'text'] as $rk) {
        if (!empty($erItem[$rk])) {
            foreach ($searchBrands as $sb) {
                $erItem[$rk] = smart_swap_brand_text($erItem[$rk], $sb, $finalName);
            }
        }
    }
}
unset($erItem);

foreach ($extractedFaqs as &$efItem) {
    foreach (['question', 'answer', 'q', 'a'] as $fk) {
        if (!empty($efItem[$fk])) {
            foreach ($searchBrands as $sb) {
                $efItem[$fk] = smart_swap_brand_text($efItem[$fk], $sb, $finalName);
            }
        }
    }
}
unset($efItem);

$reviewsFound = !empty($extractedReviews);
$faqsFound    = !empty($extractedFaqs);

$finalType = $isAmp ? 'amp' : 'lp';

// Nilai untuk Scan (jujur: jika tidak ada ya kosong / "Tidak ada"!) vs Nilai Eksekusi Clone
$scanLoginVal    = $loginUrl ?: $extractedLoginUrl;
$scanRegVal      = $regUrl   ?: $extractedRegUrl;
$scanCanVal      = $canUrl   ?: $detectedCanonicalForInput;
$scanAmpVal      = $ampUrl   ?: $rawTargetAmp;

$finalLogin      = !empty($loginUrl) ? $loginUrl : (!empty($extractedLoginUrl) ? $extractedLoginUrl : (!empty($canUrl) ? $canUrl : $effectiveUrl));
$finalReg        = !empty($regUrl)   ? $regUrl   : (!empty($extractedRegUrl)   ? $extractedRegUrl   : (!empty($canUrl) ? $canUrl : $effectiveUrl));
$finalCanClean   = !empty($canUrl)   ? $canUrl   : ($rawTargetCanonical ?: $effectiveUrl);
$finalAmpClean   = !empty($ampUrl)   ? $ampUrl   : $rawTargetAmp; // Tidak memalsukan /amp jika memang tidak ada!

// Bangun laporan deteksi transparan & jujur
$detectionLogs = [
    'page_format'      => $detectedPageFormat,
    'format_reason'    => $aiPageFormatReason ?: ($detectedIsAmp ? 'Terdeteksi tag HTML AMP (amp/⚡ / ampproject.org / amp-boilerplate)' : 'Terdeteksi HTML5 Landing Page (LP) standar tanpa komponen AMP'),
    'lp_found'         => $lpFound,
    'lp_url'           => $lpDetectedUrl ?: '',
    'amp_found'        => $ampFound,
    'amp_url'          => $rawTargetAmp ?: '',
    'cloaking_detected'=> $crawlBundle['cloaking_detected'],
    'cloaking_note'    => $crawlBundle['cloaking_note'],
    'crawled_profile'  => $activeSource['profile'] ?? '',
    'redirect_trace'   => $redirectTrace,
    'effective_url'    => $effectiveUrl,
    'ai_used'          => $aiUsed,
    'ai_brands_found'  => $aiBrands,
    'all_brands_list'  => array_values($searchBrands),
    'target_brand'     => $detectedBrand,
    'brand_count'      => count($searchBrands),
    'elements' => [
        'format'      => ['found' => true, 'label' => 'Format Halaman', 'status' => $detectedIsAmp ? 'Google AMP' : 'Landing Page (LP)', 'value' => strtoupper($detectedPageFormat)],
        'lp_page'     => ['found' => $lpFound, 'label' => 'Halaman LP', 'status' => $lpFound ? 'Terdeteksi' : 'Tidak ada', 'value' => $lpDetectedUrl],
        'amp_page'    => ['found' => $ampFound, 'label' => 'Halaman / Link AMP', 'status' => $ampFound ? 'Terdeteksi' : 'Tidak ada', 'value' => $rawTargetAmp],
        'title'       => ['found' => !empty($extractedTitle), 'label' => 'Title', 'status' => !empty($extractedTitle) ? 'Terdeteksi' : 'Tidak ada', 'value' => $extractedTitle],
        'description' => ['found' => !empty($extractedDesc), 'label' => 'Deskripsi Meta', 'status' => !empty($extractedDesc) ? 'Terdeteksi' : 'Tidak ada', 'value' => $extractedDesc],
        'canonical'   => ['found' => $canonicalTagFound, 'label' => 'Canonical URL', 'status' => $canonicalTagFound ? 'Terdeteksi' : 'Tidak ada tag canonical', 'value' => $rawTargetCanonical],
        'amp_url'     => ['found' => $ampFound, 'label' => 'AMP URL', 'status' => $ampFound ? 'Terdeteksi' : 'Tidak ada', 'value' => $rawTargetAmp],
        'login'       => ['found' => $detectedLoginFound, 'label' => 'Link Login', 'status' => $detectedLoginFound ? 'Terdeteksi' : 'Tidak ada', 'value' => $extractedLoginUrl],
        'register'    => ['found' => $detectedRegFound, 'label' => 'Link Daftar / Alternatif', 'status' => $detectedRegFound ? 'Terdeteksi' : 'Tidak ada', 'value' => $extractedRegUrl],
        'banner'      => ['found' => !empty($finalBanner), 'label' => 'Foto / Gambar Banner', 'status' => !empty($finalBanner) ? 'Terdeteksi' : 'Tidak ada', 'value' => $finalBanner],
        'logo'        => ['found' => !empty($finalLogo), 'label' => 'Gambar Logo', 'status' => !empty($finalLogo) ? 'Terdeteksi' : 'Tidak ada', 'value' => $finalLogo],
        'favicon'     => ['found' => !empty($finalFavicon), 'label' => 'Icon / Favicon', 'status' => !empty($finalFavicon) ? 'Terdeteksi' : 'Tidak ada', 'value' => $finalFavicon],
        'gif'         => ['found' => !empty($finalGif), 'label' => 'Animasi GIF', 'status' => !empty($finalGif) ? 'Terdeteksi' : 'Tidak ada', 'value' => $finalGif],
        'video'       => ['found' => !empty($extractedVideo), 'label' => 'Video', 'status' => !empty($extractedVideo) ? 'Terdeteksi' : 'Tidak ada', 'value' => $extractedVideo],
        'reviews'     => ['found' => $reviewsFound, 'label' => 'Ulasan Pengguna', 'status' => $reviewsFound ? ('Terdeteksi (' . count($extractedReviews) . ' ulasan)') : 'Tidak ada', 'value' => $reviewsFound ? (count($extractedReviews) . ' ulasan') : ''],
        'faqs'        => ['found' => $faqsFound, 'label' => 'Detail / FAQ', 'status' => $faqsFound ? ('Terdeteksi (' . count($extractedFaqs) . ' item)') : 'Tidak ada', 'value' => $faqsFound ? (count($extractedFaqs) . ' item') : '']
    ]
];

// JIKA MODE SCAN SAJA: Kembalikan hasil deteksi jujur lengkap sebelum cloning diterapkan
if ($actionMode === 'scan') {
    echo json_encode([
        'success'        => true,
        'scan_only'      => true,
        'message'        => 'Scan selesai! Halaman terdeteksi sebagai ' . strtoupper($detectedPageFormat) . ($lpFound && $ampFound ? ' (LP & AMP keduanya terdeteksi!)' : ''),
        'detection_logs' => $detectionLogs,
        'detected'       => [
            'brand_name'       => $finalName,
            'target_brand'     => $detectedBrand,
            'all_old_brands'   => $allOldBrandsForDisplay,
            'type'             => $finalType,
            'page_format'      => $detectedPageFormat,
            'has_paired_lp'    => $lpFound,
            'paired_lp_url'    => $lpDetectedUrl,
            'has_paired_amp'   => $ampFound,
            'paired_amp_url'   => $rawTargetAmp,
            'title'            => $extractedTitle ? $finalTitle : '',
            'title_found'      => !empty($extractedTitle),
            'meta_description' => $extractedDesc ? $finalDesc : '',
            'desc_found'       => !empty($extractedDesc),
            'canonical_url'    => $scanCanVal,
            'canonical_found'  => $canonicalTagFound,
            'amp_url'          => $scanAmpVal,
            'amp_found'        => $ampFound,
            'login_url'        => $scanLoginVal,
            'login_found'      => $detectedLoginFound,
            'register_url'     => $scanRegVal,
            'register_found'   => $detectedRegFound,
            'banner_url'       => $finalBanner,
            'banner_found'     => !empty($finalBanner),
            'logo_url'         => $finalLogo,
            'logo_found'       => !empty($finalLogo),
            'favicon_url'      => $finalFavicon,
            'favicon_found'    => !empty($finalFavicon),
            'gif_url'          => $finalGif,
            'gif_found'        => !empty($finalGif),
            'video_url'        => $extractedVideo,
            'video_found'      => !empty($extractedVideo),
            'reviews'          => $extractedReviews,
            'reviews_found'    => $reviewsFound,
            'reviews_count'    => count($extractedReviews),
            'faqs'             => $extractedFaqs,
            'faqs_found'       => $faqsFound,
            'faqs_count'       => count($extractedFaqs),
            'images_count'     => count($candidateImgsSummary),
            'candidate_images' => array_slice($candidateImgsSummary, 0, 8)
        ]
    ]);
    exit;
}

// -----------------------------------------------------------------------------
// 6. Proses HTML Raw Secara Bersih (100% BEBAS KODE ANEH {{ ... }})
// -----------------------------------------------------------------------------
$processedHtml = $rawHtml;

// 6.0. Ubah seluruh path relatif menjadi URL absolut
$processedHtml = preg_replace_callback('/(src|href|data-src|data-lazy|data-original|data-lazy-src)=["\']([^"\']+)["\']/i', function($m) use ($effectiveUrl) {
    $attr = $m[1];
    $val  = trim($m[2]);
    if (strpos($val, '{{') !== false || substr($val, 0, 5) === 'data:' || substr($val, 0, 1) === '#' || stripos($val, 'javascript:') === 0) {
        return $m[0];
    }
    $abs = resolve_url($val, $effectiveUrl);
    return $attr . '="' . $abs . '"';
}, $processedHtml) ?? $processedHtml;

// 6a. Ganti Title & Meta Description (dukung urutan atribut apapun; limit=1 agar <svg><title> tidak ikut berubah)
if (!empty($finalTitle)) {
    if (preg_match('/<title[^>]*>.*?<\/title>/is', $processedHtml)) {
        $processedHtml = preg_replace('/<title[^>]*>.*?<\/title>/is', '<title>__FLASH_TITLE__</title>', $processedHtml, 1) ?? $processedHtml;
    } else {
        $processedHtml = preg_replace('/(<head\b[^>]*>)/i', "$1\n    <title>__FLASH_TITLE__</title>", $processedHtml, 1) ?? $processedHtml;
    }
    $processedHtml = preg_replace('/<meta\b(?=[^>]*\b(?:name|property)=["\'](?:title|og:title|twitter:title)["\'])[^>]*>/i', '', $processedHtml) ?? $processedHtml;
    $processedHtml = preg_replace('/(<title[^>]*>.*?<\/title>)/is', "$1\n    <meta name=\"title\" content=\"__FLASH_TITLE__\">", $processedHtml, 1) ?? $processedHtml;
}

if (!empty($finalDesc)) {
    $processedHtml = preg_replace('/<meta\b(?=[^>]*\bname=["\']description["\'])[^>]*>/i', '<meta name="description" content="__FLASH_DESC__">', $processedHtml, 1, $descReplaced) ?? $processedHtml;
    if (empty($descReplaced)) {
        $processedHtml = preg_replace('/(<head\b[^>]*>)/i', "$1\n    <meta name=\"description\" content=\"__FLASH_DESC__\">", $processedHtml) ?? $processedHtml;
    }
}

// 6b. Ganti Canonical & AMP Link (dukung urutan atribut apapun!)
$processedHtml = preg_replace('/<link\b(?=[^>]*\brel=["\']canonical["\'])[^>]*>/i', '<link rel="canonical" href="__FLASH_CANONICAL__">', $processedHtml, -1, $canCount) ?? $processedHtml;
if (empty($canCount)) {
    $processedHtml = preg_replace('/(<head\b[^>]*>)/i', "$1\n    <link rel=\"canonical\" href=\"__FLASH_CANONICAL__\">", $processedHtml) ?? $processedHtml;
}
$processedHtml = preg_replace('/<link\b(?=[^>]*\brel=["\']alternate["\'])[^>]*>/i', '<link rel="alternate" href="__FLASH_CANONICAL__">', $processedHtml) ?? $processedHtml;

if (!empty($finalAmpClean)) {
    $processedHtml = preg_replace('/<link\b(?=[^>]*\brel=["\']amphtml["\'])[^>]*>/i', '<link rel="amphtml" href="__FLASH_AMP__">', $processedHtml, -1, $ampCount) ?? $processedHtml;
    if (empty($ampCount) && !$isAmp) {
        $processedHtml = preg_replace('/(<link\b(?=[^>]*\brel=["\']canonical["\'])[^>]*>)/i', "$1\n    <link rel=\"amphtml\" href=\"__FLASH_AMP__\">", $processedHtml) ?? $processedHtml;
    }
} else {
    $processedHtml = preg_replace('/<link\b(?=[^>]*\brel=["\']amphtml["\'])[^>]*>\s*/i', '', $processedHtml) ?? $processedHtml;
}

// 6c. Ganti SELURUH Gambar & Media (Favicon/Icon, Logo, Banner, GIF, Video) menggunakan token aman
if (!empty($finalFavicon)) {
    $processedHtml = preg_replace('/<link\b(?=[^>]*\brel=["\'](?:shortcut\s+icon|icon|apple-touch-icon|apple-touch-icon-precomposed)["\'])[^>]*\/?>/i', '', $processedHtml) ?? $processedHtml;
    if (!empty($extractedFavicon)) {
        $processedHtml = str_replace($extractedFavicon, '__FLASH_FAVICON__', $processedHtml);
    }
    $processedHtml = preg_replace('/(<head\b[^>]*>)/i', "$1\n  <link rel=\"icon\" type=\"image/x-icon\" href=\"__FLASH_FAVICON__\">", $processedHtml) ?? $processedHtml;
}

if (!empty($extractedGif) && !empty($extractedLogo) && $extractedGif === $extractedLogo) {
    if (!empty($finalLogo)) {
        $processedHtml = str_replace($extractedLogo, '__FLASH_LOGO__', $processedHtml);
    }
} else {
    if (!empty($extractedLogo) && !empty($finalLogo)) {
        $processedHtml = str_replace($extractedLogo, '__FLASH_LOGO__', $processedHtml);
    }
    if (!empty($extractedGif) && !empty($finalGif)) {
        $processedHtml = str_replace($extractedGif, '__FLASH_GIF__', $processedHtml);
    }
}

if (!empty($extractedBanner) && !empty($finalBanner) && $extractedBanner !== $extractedLogo && $extractedBanner !== $extractedFavicon) {
    $processedHtml = str_replace($extractedBanner, '__FLASH_BANNER__', $processedHtml);
}

if (!empty($extractedVideo) && !empty($finalBanner)) {
    $processedHtml = str_replace($extractedVideo, '__FLASH_BANNER__', $processedHtml);
}

// 6d. Ganti SELURUH Tombol & Link Login / Register / Alternatif / Form
$processedHtml = preg_replace_callback('/<button\b([^>]*)onclick=["\'][^"\']*(?:window\.)?location(?:\.href)?\s*=\s*([\'"])(.*?)\2[^"\']*["\']([^>]*)>(.*?)<\/button>/is', function($m) {
    $preAttrs  = $m[1];
    $targetUrl = trim($m[3]);
    $postAttrs = $m[4];
    $body      = $m[5];
    $text      = trim(strip_tags($body)) . ' ' . $body;

    $isLogin = (bool) preg_match('/login|masuk|sign\s*in|auth/i', $text)
            || (bool) preg_match('/login|masuk|signin|auth/i', $targetUrl);

    $destToken = $isLogin ? '__FLASH_LOGIN__' : '__FLASH_REGISTER__';
    return '<button' . $preAttrs . 'onclick="window.location.href=\'' . $destToken . '\'"' . $postAttrs . '>' . $body . '</button>';
}, $processedHtml) ?? $processedHtml;

$processedHtml = preg_replace_callback('/<a\b([^>]*)href=["\']([^"\']*)["\']([^>]*)>(.*?)<\/a>/is', function($m) {
    $pre  = $m[1];
    $href = trim($m[2]);
    $post = $m[3];
    $body = $m[4];
    $text = trim(strip_tags($body)) . ' ' . $body;

    if (preg_match('/\[.*?\]\((https?:\/\/[^\)]+)\)/i', $href, $mHref)) {
        $href = $mHref[1];
    }

    if ($href === '#' || substr($href, 0, 1) === '#' || stripos($href, 'javascript:') === 0) {
        return $m[0];
    }

    $isLogin = (bool) preg_match('/login|masuk|sign\s*in|member\s*area|\bauth\b/i', $text)
            || (bool) preg_match('/login|masuk|signin|auth/i', $href)
            || (bool) preg_match('/class=["\'][^"\']*\b(?:login|btn-login|sign-in)\b/i', $m[0]);

    if ($isLogin) {
        return '<a' . $pre . 'href="__FLASH_LOGIN__" ' . $post . '>' . $body . '</a>';
    } else {
        return '<a' . $pre . 'href="__FLASH_REGISTER__" ' . $post . '>' . $body . '</a>';
    }
}, $processedHtml) ?? $processedHtml;

$processedHtml = preg_replace_callback('/<form\b([^>]*)action=(["\'])([^"\']*)\2([^>]*)>/is', function($m) {
    return '<form' . $m[1] . 'action=' . $m[2] . '__FLASH_REGISTER__' . $m[2] . $m[4] . '>';
}, $processedHtml) ?? $processedHtml;

if (!empty($extractedLoginUrl) && $extractedLoginUrl !== $rawTargetCanonical && strlen($extractedLoginUrl) > 8) {
    $processedHtml = str_replace($extractedLoginUrl, '__FLASH_LOGIN__', $processedHtml);
}
if (!empty($extractedRegUrl) && $extractedRegUrl !== $rawTargetCanonical && strlen($extractedRegUrl) > 8) {
    $processedHtml = str_replace($extractedRegUrl, '__FLASH_REGISTER__', $processedHtml);
}

// 6e. Ganti SELURUH kemunculan AMP URL & Canonical URL target asli (hapus sub-path lama /prv/limit)
if (!empty($rawTargetAmp) && strlen($rawTargetAmp) > 8) {
    $targetAmpNoSlash = rtrim($rawTargetAmp, '/');
    $processedHtml = str_replace($rawTargetAmp, '__FLASH_AMP__', $processedHtml);
    if ($targetAmpNoSlash !== $rawTargetAmp) {
        $processedHtml = str_replace($targetAmpNoSlash, '__FLASH_AMP__', $processedHtml);
    }
}
if (!empty($rawTargetCanonical) && strlen($rawTargetCanonical) > 8) {
    $targetCanNoSlash = rtrim($rawTargetCanonical, '/');
    $processedHtml = preg_replace_callback('/' . preg_quote($targetCanNoSlash, '/') . '(\/[^\s"\'<>]*)?/i', function($m) {
        $path = $m[1] ?? '';
        if (!empty($path) && preg_match('/\.(?:png|jpg|jpeg|gif|webp|svg|css|js|woff2?|ttf|ico|mp4|webm)(\?.*)?$/i', $path)) {
            return $m[0];
        }
        return '__FLASH_CANONICAL__';
    }, $processedHtml) ?? $processedHtml;
}

// -----------------------------------------------------------------------------
// 7. Sinkronisasi Jujur Ulasan Pengguna & Detail/FAQ + Penggantian SEMUA Nama Brand
// -----------------------------------------------------------------------------
$finalFaqsRaw    = $hasCustomFaqs    ? $customFaqs    : $extractedFaqs;
$finalReviewsRaw = $hasCustomReviews ? $customReviews : $extractedReviews;

$faqStructured = [];
if (is_array($finalFaqsRaw)) {
    foreach ($finalFaqsRaw as $fItem) {
        $q = trim((string)($fItem['question'] ?? ($fItem['q'] ?? '')));
        $a = trim((string)($fItem['answer'] ?? ($fItem['a'] ?? '')));
        if ($q === '' && $a === '') continue;
        foreach ($searchBrands as $sb) {
            if (strlen($sb) >= 3) {
                $q = smart_swap_brand_text($q, $sb, $finalName);
                $a = smart_swap_brand_text($a, $sb, $finalName);
            }
        }
        $faqStructured[] = [
            'question' => $q,
            'answer'   => $a
        ];
    }
}

$reviewsStructured = [];
if (is_array($finalReviewsRaw)) {
    foreach ($finalReviewsRaw as $rItem) {
        $rn = trim((string)($rItem['name'] ?? ''));
        $rl = trim((string)($rItem['location'] ?? 'Indonesia'));
        $rt = trim((string)($rItem['text'] ?? ''));
        $rr = max(1, min(5, intval($rItem['rating'] ?? 5)));
        if ($rn === '' && $rt === '') continue;
        foreach ($searchBrands as $sb) {
            if (strlen($sb) >= 3) {
                $rn = smart_swap_brand_text($rn, $sb, $finalName);
                $rl = smart_swap_brand_text($rl, $sb, $finalName);
                $rt = smart_swap_brand_text($rt, $sb, $finalName);
            }
        }
        $reviewsStructured[] = [
            'name'     => $rn ?: 'Pengguna',
            'location' => $rl ?: 'Indonesia',
            'rating'   => $rr,
            'text'     => $rt
        ];
    }
}

function safe_replace_brand_in_html($html, $searchList, $replaceWith, $oldTargetHost = '', $newCanonicalUrl = '') {
    $parts = preg_split('/(<[^>]+>)/s', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    $targetAttrs = 'placeholder|title|aria-label|alt|value|data-[a-zA-Z0-9_\-]+|option-label|option-tooltip-value|data-msg-[a-zA-Z0-9_\-]+|content';
    $inStyleOrSvg = false;

    for ($i = 0; $i < count($parts); $i++) {
        $p = $parts[$i];
        if (substr($p, 0, 1) === '<' && substr($p, -1) === '>') {
            if (preg_match('/^<style\b/i', $p)) $inStyleOrSvg = true;
            elseif (preg_match('/^<\/style>/i', $p)) $inStyleOrSvg = false;

            // HTML comments
            if (substr($p, 0, 4) === '<!--') {
                foreach ($searchList as $sw) {
                    if (strlen($sw) >= 3) {
                        $parts[$i] = smart_swap_brand_text($parts[$i], $sw, $replaceWith);
                    }
                }
                continue;
            }

            // Atribut tag visual, SEO meta & data-* (lewati meta viewport/robots dan aset URL murni)
            if (!preg_match('/^<meta\b[^>]*(?:viewport|robots)/i', $p)) {
                foreach ($searchList as $sw) {
                    if (strlen($sw) >= 3) {
                        $parts[$i] = preg_replace_callback('/(' . $targetAttrs . ')=([\'"])(.*?)\2/is', function($m) use ($sw, $replaceWith) {
                            $attr  = $m[1];
                            $quote = $m[2];
                            $val   = $m[3];
                            if (preg_match('/\.(?:png|jpg|jpeg|gif|webp|svg|css|js|woff2?)(\?.*)?$/i', $val) || strpos($val, '__FLASH_') !== false) {
                                return $m[0];
                            }
                            return $attr . '=' . $quote . smart_swap_brand_text($val, $sw, $replaceWith) . $quote;
                        }, $parts[$i]) ?? $parts[$i];
                    }
                }
            }

            // Ganti link navigasi domain lama -> domain baru tanpa membawa sub-path (/prv/limit dsb)
            if (!empty($oldTargetHost) && strlen($oldTargetHost) >= 4) {
                $newHost = !empty($newCanonicalUrl) ? parse_url($newCanonicalUrl, PHP_URL_HOST) : $replaceWith;
                if (!preg_match('/^<(?:img|amp-img|amp-anim|link\b[^>]*stylesheet|script\b[^>]*src)/i', $p)) {
                    $parts[$i] = preg_replace_callback('/(https?:\/\/(?:www\.)?' . preg_quote($oldTargetHost, '/') . ')([^\s"\'<>]*)/i', function($m) use ($newHost, $newCanonicalUrl) {
                        if (preg_match('/\.(?:png|jpg|jpeg|gif|webp|svg|css|js|woff2?|ttf|ico|mp4|webm)(\?.*)?$/i', $m[0])) {
                            return $m[0];
                        }
                        return !empty($newCanonicalUrl) ? rtrim($newCanonicalUrl, '/') . '/' : 'https://' . $newHost . '/';
                    }, $parts[$i]) ?? $parts[$i];
                }
            }
        } else {
            if ($inStyleOrSvg) continue; // Jangan ubah nama CSS class/variabel di dalam <style>
            foreach ($searchList as $sw) {
                if (strlen($sw) >= 3) {
                    $parts[$i] = smart_swap_brand_text($parts[$i], $sw, $replaceWith);
                }
            }
            if (!empty($oldTargetHost) && strlen($oldTargetHost) >= 4) {
                $newHostOnly = !empty($newCanonicalUrl) ? (parse_url($newCanonicalUrl, PHP_URL_HOST) ?: $replaceWith) : $replaceWith;
                $parts[$i] = str_ireplace($oldTargetHost, $newHostOnly, $parts[$i]);
            }
        }
    }
    return implode('', $parts);
}

$processedHtml = safe_replace_brand_in_html($processedHtml, $searchBrands, $finalName, $targetHostDomain, $finalCanClean);

// 7c. Resolusi seluruh token internal (__FLASH_*__) menjadi nilai murni
$tokenReplacements = [
    '__FLASH_TITLE__'             => htmlspecialchars($finalTitle ?: $finalName, ENT_NOQUOTES, 'UTF-8'),
    '__FLASH_DESC__'              => htmlspecialchars($finalDesc, ENT_QUOTES, 'UTF-8'),
    '__FLASH_CANONICAL_NOSLASH__' => rtrim($finalCanClean, '/'),
    '__FLASH_CANONICAL__'         => $finalCanClean,
    '__FLASH_AMP__'               => $finalAmpClean,
    '__FLASH_LOGIN__'             => $finalLogin,
    '__FLASH_REGISTER__'          => $finalReg,
    '__FLASH_FAVICON__'           => $finalFavicon,
    '__FLASH_LOGO__'              => $finalLogo,
    '__FLASH_GIF__'               => $finalGif ?: $finalBanner,
    '__FLASH_BANNER__'            => $finalBanner,
];
$processedHtml = strtr($processedHtml, $tokenReplacements);

// De-duplikasi akhir bila ada nama berulang (contoh Mega118118 -> Mega118)
if (preg_match('/^([a-zA-Z]+)(\d+)$/', $finalName, $mFN)) {
    $preFn = preg_quote($mFN[1], '/');
    $numFn = preg_quote($mFN[2], '/');
    $processedHtml = preg_replace('/(' . $preFn . $numFn . ')' . $numFn . '+/i', '$1', $processedHtml) ?? $processedHtml;
}
$fnQuoted = preg_quote($finalName, '/');
$processedHtml = preg_replace('/(' . $fnQuoted . ')(?:\s*' . $fnQuoted . ')+/i', '$1', $processedHtml) ?? $processedHtml;

// -----------------------------------------------------------------------------
// 8. Purify & Sinkronisasi Google Standards (100% bebas {{ ... }})
// -----------------------------------------------------------------------------
$cleanProjectSpec = [
    'brand_name'        => $finalName,
    'name'              => $finalName,
    'title'             => $finalTitle ?: ($finalName . ' - Situs Resmi'),
    'meta_description'  => $finalDesc,
    'canonical_url'     => $finalCanClean,
    'amp_url'           => $finalAmpClean,
    'login_url'         => $finalLogin,
    'register_url'      => $finalReg,
    'logo_url'          => $finalLogo,
    'banner_url'        => $finalBanner,
    'favicon_url'       => $finalFavicon,
    'gif_url'           => $finalGif,
    'faq_json'          => $faqStructured,
    'reviews_json'      => $reviewsStructured,
    'force_sync_blocks' => true
];

$processedHtml = sync_and_clean_project_html($processedHtml, $cleanProjectSpec);
$processedHtml = purify_html_for_google($processedHtml, $isAmp, $cleanProjectSpec);

// -----------------------------------------------------------------------------
// 9. Simpan / Update Project & Opsional Template
// -----------------------------------------------------------------------------
$dataToSave = [
    'name'             => $finalName,
    'brand_name'       => $finalName,
    'type'             => $finalType,
    'canonical_url'    => $finalCanClean,
    'amp_url'          => $finalAmpClean,
    'login_url'        => $finalLogin,
    'register_url'     => $finalReg,
    'banner_url'       => $finalBanner,
    'banner_title'     => $finalName . ' Official Promo',
    'logo_url'         => $finalLogo,
    'logo_title'       => 'Logo ' . $finalName,
    'favicon_url'      => $finalFavicon,
    'gif_url'          => $finalGif,
    'title'            => $finalTitle ?: ($finalName . ' - Situs Resmi'),
    'meta_description' => $finalDesc,
    'article_content'  => $processedHtml,
    'faq_json'         => json_encode($faqStructured, JSON_UNESCAPED_UNICODE),
    'reviews_json'     => json_encode($reviewsStructured, JSON_UNESCAPED_UNICODE)
];

if ($projId > 0) {
    $sql = "UPDATE projects SET name=?, brand_name=?, type=?, canonical_url=?, amp_url=?, login_url=?, register_url=?, banner_url=?, banner_title=?, logo_url=?, logo_title=?, favicon_url=?, gif_url=?, title=?, meta_description=?, article_content=?, faq_json=?, reviews_json=?, updated_at=CURRENT_TIMESTAMP WHERE id=?" . ($user['role'] !== 'admin' ? " AND user_id=?" : "");
    $params = array_values($dataToSave);
    $params[] = $projId;
    if ($user['role'] !== 'admin') $params[] = $user['id'];
    $pdo->prepare($sql)->execute($params);
    $activeProjId = $projId;
} else {
    $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $finalName)) . '-' . rand(100, 999);
    $ins = $pdo->prepare("INSERT INTO projects (user_id, name, brand_name, slug, type, canonical_url, amp_url, login_url, register_url, banner_url, banner_title, logo_url, logo_title, favicon_url, gif_url, title, meta_description, article_content, faq_json, reviews_json, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
    $ins->execute([
        $user['id'],
        $finalName,
        $finalName,
        $slug,
        $finalType,
        $finalCanClean,
        $finalAmpClean,
        $finalLogin,
        $finalReg,
        $finalBanner,
        $finalName . ' Official Promo',
        $finalLogo,
        'Logo ' . $finalName,
        $finalFavicon,
        $finalGif,
        $finalTitle ?: ($finalName . ' - Situs Resmi'),
        $finalDesc,
        $processedHtml,
        json_encode($faqStructured, JSON_UNESCAPED_UNICODE),
        json_encode($reviewsStructured, JSON_UNESCAPED_UNICODE)
    ]);
    $activeProjId = $pdo->lastInsertId();
}

// Catat riwayat ke clone_logs untuk pelacakan dan audit Administrator
try {
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $clientIp = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }
    $stmtLog = $pdo->prepare("INSERT INTO clone_logs (user_id, project_id, target_url, brand_name, page_format, source_mode, reviews_count, faqs_count, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
    $stmtLog->execute([
        $user['id'],
        $activeProjId,
        $targetUrl,
        $finalName,
        $finalType,
        $sourceMode,
        count($reviewsStructured),
        count($faqStructured),
        $clientIp
    ]);
} catch (Exception $e) {
    // Abaikan error logging agar respons kloning tetap sukses
}

$createdTemplateId = null;
if ($asTemplate || !empty($data['save_as_template'])) {
    try {
        $tplName = trim($data['template_name'] ?? ('Template ' . $finalName . ' (' . strtoupper($finalType) . ')'));
        $tplDesc = 'Template otomatis hasil kloning dari ' . ($targetHostDomain ?: $targetUrl) . ' (' . strtoupper($finalType) . ')';
        $tplFile = md5(uniqid('tpl_clone_', true)) . '.html';
        $tplPath = __DIR__ . '/../cdn/templates/' . $tplFile;

        if (file_put_contents($tplPath, $processedHtml) !== false) {
            $stmtTplIns = $pdo->prepare("INSERT INTO templates (name, type, description, file_path, html_content, created_at) VALUES (?, ?, ?, ?, '', CURRENT_TIMESTAMP)");
            $stmtTplIns->execute([$tplName, $finalType, $tplDesc, $tplFile]);
            $createdTemplateId = $pdo->lastInsertId();
            if ($activeProjId > 0 && $createdTemplateId) {
                $pdo->prepare("UPDATE projects SET template_id = ? WHERE id = ?")->execute([$createdTemplateId, $activeProjId]);
            }
        }
    } catch (Exception $e) {
    }
}

echo json_encode([
    'success' => true,
    'message' => 'Berhasil mendeteksi & mengkloning ' . strtoupper($finalType) . ', mengganti ' . count($searchBrands) . ' variasi brand lama ke "' . $finalName . '", serta memperbarui link & media secara bersih' . ($createdTemplateId ? ' (tersimpan sebagai template!)' : '!'),
    'project_id'     => $activeProjId,
    'template_id'    => $createdTemplateId,
    'detection_logs' => $detectionLogs,
    'data' => [
        'name'        => $finalName,
        'type'        => $finalType,
        'title'       => $finalTitle ?: ($finalName . ' - Situs Resmi'),
        'metaDesc'    => $finalDesc,
        'canonical'   => $finalCanClean,
        'ampUrl'      => $finalAmpClean,
        'loginUrl'    => $finalLogin,
        'registerUrl' => $finalReg,
        'logoUrl'     => $finalLogo,
        'bannerUrl'   => $finalBanner,
        'faviconUrl'  => $finalFavicon,
        'gifUrl'      => $finalGif,
        'article'     => $processedHtml,
        'faqs'        => $faqStructured,
        'reviews'     => $reviewsStructured
    ]
]);
