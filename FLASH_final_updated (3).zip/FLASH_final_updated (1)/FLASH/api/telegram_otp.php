<?php
// api/telegram_otp.php - Telegram OTP Verification Handler for FLASH Platform
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';

// Ambil konfigurasi bot Telegram dari settings database
$stmt = $pdo->prepare("SELECT value FROM settings WHERE key = ?");
$stmt->execute(['telegram_bot_token']);
$botToken = $stmt->fetchColumn() ?: '';

$stmt->execute(['telegram_bot_username']);
$botUsername = $stmt->fetchColumn() ?: 'FlashOfficialBot';

$stmt->execute(['telegram_otp_enabled']);
$otpEnabled = ($stmt->fetchColumn() === '1');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// 1. GENERATE DEEP-LINK TOKEN UNTUK PENDAFTARAN
if ($action === 'generate_token') {
    $email = trim($_POST['email'] ?? $_GET['email'] ?? '');
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Alamat email wajib diisi dan valid.']);
        exit;
    }

    // Buat token sync unik dan OTP 6 digit
    $tokenSync = bin2hex(random_bytes(12));
    $otpCode = (string)random_int(100000, 999999);
    $expiresAt = date('Y-m-d H:i:s', time() + 900); // 15 menit

    // Hapus OTP lama untuk email ini yang belum terverifikasi
    $stmtDel = $pdo->prepare("DELETE FROM telegram_otps WHERE email = ? AND is_verified = 0");
    $stmtDel->execute([$email]);

    // Simpan ke database
    $stmtInsert = $pdo->prepare("INSERT INTO telegram_otps (email, otp_code, token_sync, is_verified, expires_at) VALUES (?, ?, ?, 0, ?)");
    $stmtInsert->execute([$email, $otpCode, $tokenSync, $expiresAt]);

    $deepLink = "https://t.me/{$botUsername}?start=otp_{$tokenSync}";

    echo json_encode([
        'success' => true,
        'token_sync' => $tokenSync,
        'bot_username' => $botUsername,
        'deep_link' => $deepLink,
        'expires_in' => 900,
        'dev_code' => empty($botToken) ? $otpCode : null,
        'message' => 'Token deep-link berhasil dibuat. Silakan buka bot Telegram dan tekan START.'
    ]);
    exit;
}

// 2. VERIFIKASI KODE OTP
if ($action === 'verify_otp') {
    $tokenSync = trim($_POST['token_sync'] ?? '');
    $otpInput = trim($_POST['otp_code'] ?? '');

    if (empty($tokenSync) || empty($otpInput)) {
        echo json_encode(['success' => false, 'message' => 'Token sync dan kode OTP wajib diisi.']);
        exit;
    }

    $stmtCheck = $pdo->prepare("SELECT * FROM telegram_otps WHERE token_sync = ? ORDER BY id DESC LIMIT 1");
    $stmtCheck->execute([$tokenSync]);
    $otpRow = $stmtCheck->fetch();

    if (!$otpRow) {
        echo json_encode(['success' => false, 'message' => 'Sesi verifikasi tidak ditemukan atau sudah kadaluarsa.']);
        exit;
    }

    if (strtotime($otpRow['expires_at']) < time()) {
        echo json_encode(['success' => false, 'message' => 'Kode OTP telah kadaluarsa. Silakan buat kode baru.']);
        exit;
    }

    if ($otpRow['otp_code'] !== $otpInput) {
        echo json_encode(['success' => false, 'message' => 'Kode OTP salah. Periksa kembali pesan di Telegram Anda.']);
        exit;
    }

    // Tandai sebagai terverifikasi
    $stmtUpd = $pdo->prepare("UPDATE telegram_otps SET is_verified = 1 WHERE id = ?");
    $stmtUpd->execute([$otpRow['id']]);

    echo json_encode([
        'success' => true,
        'message' => 'Verifikasi OTP Telegram berhasil!',
        'email' => $otpRow['email']
    ]);
    exit;
}

// 3. WEBHOOK DARI TELEGRAM (Ketika user menekan tombol START dengan deep-link ?start=otp_<token>)
if ($action === 'webhook') {
    $rawInput = file_get_contents('php://input');
    $update = json_decode($rawInput, true);

    if (isset($update['message'])) {
        $chatId = $update['message']['chat']['id'] ?? null;
        $text = trim($update['message']['text'] ?? '');
        $senderName = $update['message']['from']['first_name'] ?? 'Pengguna';

        // Deteksi pesan /start otp_<token>
        if (preg_match('/^\/start\s+otp_([a-f0-9]+)$/i', $text, $matches)) {
            $tokenSync = $matches[1];

            $stmtFind = $pdo->prepare("SELECT * FROM telegram_otps WHERE token_sync = ? AND is_verified = 0 ORDER BY id DESC LIMIT 1");
            $stmtFind->execute([$tokenSync]);
            $otpData = $stmtFind->fetch();

            if ($otpData) {
                // Update chat id di database
                $stmtChat = $pdo->prepare("UPDATE telegram_otps SET telegram_chat_id = ? WHERE id = ?");
                $stmtChat->execute([(string)$chatId, $otpData['id']]);

                // Kirim pesan balasan Telegram berisi kode OTP
                $replyMsg = "⚡ <b>FLASH Platform - Kode Verifikasi OTP</b>\n\n"
                          . "Halo <b>" . htmlspecialchars($senderName) . "</b>,\n"
                          . "Gunakan kode verifikasi berikut untuk menyelesaikan pendaftaran Anda:\n\n"
                          . "🔐 <b><code>" . $otpData['otp_code'] . "</code></b>\n\n"
                          . "⏳ <i>Kode ini berlaku selama 15 menit. Jangan bagikan kepada siapa pun.</i>";

                if (!empty($botToken)) {
                    $tgUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
                    $tgData = [
                        'chat_id' => $chatId,
                        'text' => $replyMsg,
                        'parse_mode' => 'HTML'
                    ];
                    $ch = curl_init($tgUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $tgData);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
                    curl_exec($ch);
                    curl_close($ch);
                }
            } else {
                if (!empty($botToken)) {
                    $replyMsg = "⚠️ Tautan verifikasi ini tidak valid atau sudah kadaluarsa. Silakan lakukan pendaftaran ulang di website FLASH.";
                    $tgUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
                    $tgData = ['chat_id' => $chatId, 'text' => $replyMsg];
                    $ch = curl_init($tgUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $tgData);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
                    curl_exec($ch);
                    curl_close($ch);
                }
            }
        }
    }

    echo json_encode(['status' => 'ok']);
    exit;
}

// 4. CEK STATUS VERIFIKASI SECARA POLLING (OPSIONAL)
if ($action === 'check_status') {
    $tokenSync = trim($_GET['token_sync'] ?? '');
    if (empty($tokenSync)) {
        echo json_encode(['success' => false, 'verified' => false]);
        exit;
    }

    $stmtCheck = $pdo->prepare("SELECT is_verified, telegram_chat_id FROM telegram_otps WHERE token_sync = ? LIMIT 1");
    $stmtCheck->execute([$tokenSync]);
    $res = $stmtCheck->fetch();

    echo json_encode([
        'success' => true,
        'verified' => (bool)($res['is_verified'] ?? false),
        'chat_connected' => !empty($res['telegram_chat_id'])
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Action tidak dikenal.']);
