<?php
// api/vip_keyword_research.php - Real-Time Google Suggest + Gemini AI Keyword Engine
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/content_generator.php';
require_once __DIR__ . '/../config/database.php';

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Anda harus login untuk menggunakan fitur ini.']);
    exit;
}

$user = current_user();
$quota = get_user_quota_info($user);

// Proteksi VIP
if (!$quota['is_vip']) {
    echo json_encode([
        'success' => false,
        'is_vip_required' => true,
        'message' => 'Fitur Riset Kata Kunci Google Real-Time khusus untuk Paket VIP Ultra-Rank (Rp 4.000.000/bln) atau Administrator.'
    ]);
    exit;
}

$seedKeyword = trim($_POST['keyword'] ?? $_GET['keyword'] ?? '');
if (empty($seedKeyword)) {
    echo json_encode(['success' => false, 'message' => 'Masukkan kata kunci dasar (seed keyword) terlebih dahulu.']);
    exit;
}

// 1. Scraping Real-Time Google Suggest (Data Nyata yang Diketik Pengguna Google)
$encodedQuery = urlencode($seedKeyword);
$googleSuggestUrl = "https://suggestqueries.google.com/complete/search?client=firefox&hl=id&q=" . $encodedQuery;

$ch = curl_init($googleSuggestUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
$rawSuggest = curl_exec($ch);
curl_close($ch);

$realKeywords = [];
if (!empty($rawSuggest)) {
    $decodedSuggest = json_decode($rawSuggest, true);
    if (isset($decodedSuggest[1]) && is_array($decodedSuggest[1])) {
        $realKeywords = array_slice($decodedSuggest[1], 0, 15);
    }
}

// Jika Google Suggest kosong (misal kata kunci sangat unik), buat turunan default
if (empty($realKeywords)) {
    $realKeywords = [
        $seedKeyword . " resmi",
        $seedKeyword . " login",
        $seedKeyword . " daftar",
        $seedKeyword . " link alternatif",
        $seedKeyword . " terpercaya",
        $seedKeyword . " rtp live",
        $seedKeyword . " apk download"
    ];
}

// 2. Olah & Klasifikasikan Menggunakan AI Gemini (Search Intent & LSI Clustering)
$keywordListString = implode(', ', $realKeywords);
$prompt = "Sebagai Ahli SEO Google 2026 tingkat lanjut, analisislah daftar kata kunci pencarian real-time berikut untuk seed: '{$seedKeyword}'.\n"
        . "Daftar kata kunci pencarian Google: {$keywordListString}\n\n"
        . "Berikan respon HANYA dalam format JSON valid (tanpa markdown backtick ```json) dengan struktur persis seperti ini:\n"
        . "{\n"
        . "  \"transactional\": [\"kata kunci transaksi/daftar\", ...],\n"
        . "  \"informational\": [\"kata kunci informasi/panduan\", ...],\n"
        . "  \"recommended_titles\": [\n"
        . "    \"Judul SEO 1 ramah CTR tinggi\",\n"
        . "    \"Judul SEO 2 dengan LSI keyword\"\n"
        . "  ],\n"
        . "  \"meta_description\": \"Deskripsi meta 155 karakter yang kaya keyword dan memicu klik pengguna di Google SERP.\",\n"
        . "  \"recommended_headings\": [\"H1 Judul\", \"H2 Subjudul 1\", \"H2 Subjudul 2\"]\n"
        . "}";

$stmtAi = $pdo->prepare("SELECT value FROM settings WHERE key = ?");
// Prioritaskan API Key khusus Cloaking/SEO
$stmtAi->execute(['ai_api_key_cloaking']);
$aiApiKey = $stmtAi->fetchColumn() ?: '';
if (empty($aiApiKey)) {
    $stmtAi->execute(['ai_api_key']);
    $aiApiKey = $stmtAi->fetchColumn() ?: '';
}

$stmtAi->execute(['ai_model']);
$aiModel = $stmtAi->fetchColumn() ?: 'gemini-3-flash-preview';

$aiAnalysis = null;

if (!empty($aiApiKey)) {
    $apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/{$aiModel}:generateContent?key={$aiApiKey}";
    $postPayload = json_encode([
        'contents' => [
            ['parts' => [['text' => $prompt]]]
        ],
        'generationConfig' => [
            'temperature' => 0.4,
            'responseMimeType' => 'application/json'
        ]
    ]);

    $chAi = curl_init($apiUrl);
    curl_setopt($chAi, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chAi, CURLOPT_POST, true);
    curl_setopt($chAi, CURLOPT_POSTFIELDS, $postPayload);
    curl_setopt($chAi, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($chAi, CURLOPT_TIMEOUT, 12);
    curl_setopt($chAi, CURLOPT_SSL_VERIFYPEER, false);
    $aiRes = curl_exec($chAi);
    curl_close($chAi);

    if (!empty($aiRes)) {
        $aiDecoded = json_decode($aiRes, true);
        $aiText = $aiDecoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
        if (!empty($aiText)) {
            $cleanedJson = preg_replace('/^```(?:json)?\s*/i', '', trim($aiText));
            $cleanedJson = preg_replace('/\s*```$/', '', $cleanedJson);
            $aiAnalysis = json_decode($cleanedJson, true);
        }
    }
}

// Fallback jika AI offline atau API Key belum diset
if (!is_array($aiAnalysis)) {
    $aiAnalysis = [
        'transactional' => array_values(array_filter($realKeywords, function($k) {
            return preg_match('/daftar|login|resmi|link|apk/i', $k);
        })),
        'informational' => array_values(array_filter($realKeywords, function($k) {
            return !preg_match('/daftar|login|resmi|link|apk/i', $k);
        })),
        'recommended_titles' => [
            ucwords($seedKeyword) . " Resmi: Portal Terpercaya & Link Alternatif Terbaru",
            "Daftar " . ucwords($seedKeyword) . " Online - Akses Cepat & Panduan Lengkap"
        ],
        'meta_description' => "Kunjungi situs resmi " . ucwords($seedKeyword) . ". Temukan tautan login, cara pendaftaran instan, promo eksklusif, serta panduan terpercaya hari ini.",
        'recommended_headings' => [
            "Selamat Datang di Portal Resmi " . ucwords($seedKeyword),
            "Keunggulan & Fitur Utama " . ucwords($seedKeyword),
            "Panduan Pendaftaran & Pertanyaan Umum (FAQ)"
        ]
    ];
}

echo json_encode([
    'success' => true,
    'seed_keyword' => $seedKeyword,
    'google_suggest_count' => count($realKeywords),
    'real_google_keywords' => $realKeywords,
    'ai_analysis' => $aiAnalysis,
    'generated_at' => date('Y-m-d H:i:s')
]);
