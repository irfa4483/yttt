<?php
// api/preview_render.php
require_once __DIR__ . '/../includes/auth.php';
require_login();

header("Content-Type: text/html; charset=UTF-8");

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo "Invalid data";
    exit;
}

$title       = e($input['title'] ?? 'api66 Membandingkan Slot, Casino, dan Permainan Judi');
$desc        = e($input['meta_description'] ?? 'Kenali perbedaan slot online, live casino, dan permainan judi.');
$canonical   = e($input['canonical_url'] ?? 'https://escortdep.online/');
$ampUrl      = e($input['amp_url'] ?? 'https://api66-efd.pages.dev/');
$bannerUrl   = e($input['banner_url'] ?? 'https://d.top4top.io/p_3851b1m3q1.jpg');
$logoUrl     = e($input['logo_url'] ?? 'https://g.top4top.io/p_3851skfnb1.jpg');

$templateFile = __DIR__ . '/../template-lp-dan-amp/index.php';
if (!file_exists($templateFile)) {
    $templateFile = __DIR__ . '/../template-lp-dan-amp/index.html';
}

if (!file_exists($templateFile)) {
    echo "Template tidak ditemukan!";
    exit;
}

$html = file_get_contents($templateFile);

// 1. Replace Title & Meta Description
$html = preg_replace('/<title>(.*?)<\/title>/is', '<title>' . $title . '</title>', $html);
$html = preg_replace('/<meta name="description" content="(.*?)">/is', '<meta name="description" content="' . $desc . '">', $html);
$html = preg_replace('/<meta property="og:title" content="(.*?)">/is', '<meta property="og:title" content="' . $title . '">', $html);
$html = preg_replace('/<meta property="og:description" content="(.*?)">/is', '<meta property="og:description" content="' . $desc . '">', $html);

// 2. Replace Canonical & AMP URLs everywhere
$html = str_replace('https://escortdep.online/', $canonical, $html);
$html = str_replace('https://api66-efd.pages.dev/', $ampUrl, $html);

// 3. Replace Image Banner & Logo URLs everywhere
$html = str_replace('https://d.top4top.io/p_3851b1m3q1.jpg', $bannerUrl, $html);
$html = str_replace('https://g.top4top.io/p_3851skfnb1.jpg', $logoUrl, $html);

// 4. Remove popup overlay
$html = preg_replace('/<div class="popup-overlay"(.*?)<\/div>/is', '', $html);

// 4.5. Inject FAQs
$faqsData = $input['faqs'] ?? [];
if (!empty($faqsData)) {
    $faqsHtml = '<div class="faq-section" style="width:100%; margin-top:20px; text-align:left;">'
              . '<h3 style="color:#fff; font-size:16px; font-weight:bold; margin-bottom:12px; border-bottom:1px solid #333; padding-bottom:8px;">Pertanyaan Sering Diajukan (FAQ)</h3>';
    foreach ($faqsData as $f) {
        $q = e($f['question'] ?? 'Pertanyaan');
        $a = e($f['answer'] ?? 'Jawaban');
        $faqsHtml .= '<details style="background:rgba(255,255,255,0.05); margin-bottom:8px; padding:12px; border-radius:12px; border:1px solid rgba(255,255,255,0.1); cursor:pointer;">'
                   . '<summary style="font-weight:bold; color:#fff; font-size:13px;">' . $q . '</summary>'
                   . '<p style="margin-top:8px; color:#ccc; font-size:12px; line-height:1.5;">' . $a . '</p>'
                   . '</details>';
    }
    $faqsHtml .= '</div>';
    if (strpos($html, '</section>') !== false) {
        $html = str_replace('</section>', $faqsHtml . '</section>', $html);
    }
}

// 5. Inject Reviews
$reviewsData = $input['reviews'] ?? [];
if (!empty($reviewsData)) {
    $reviewsHtml = '<div class="testi-section" style="width:100%; margin-top:20px; text-align:left;">'
                 . '<h3 style="color:#fff; font-size:16px; font-weight:bold; margin-bottom:12px; border-bottom:1px solid #333; padding-bottom:8px;">Ulasan & Rating Pengguna</h3>'
                 . '<div style="display:grid; grid-template-columns:1fr; gap:12px;">';
    foreach ($reviewsData as $r) {
        $rName = e($r['name'] ?? 'Pengguna');
        $rLoc  = e($r['location'] ?? 'Indonesia');
        $rText = e($r['text'] ?? '');
        $rRate = intval($r['rating'] ?? 5);
        $initial = strtoupper(substr($rName, 0, 1));
        $stars = str_repeat('⭐', $rRate);

        $reviewsHtml .= '<div style="background:rgba(255,255,255,0.05); padding:14px; border-radius:14px; border:1px solid rgba(255,255,255,0.1);">'
                     . '<div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">'
                     . '<div style="width:32px; height:32px; border-radius:50%; background:#d4af37; color:#000; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px;">' . $initial . '</div>'
                     . '<div><strong style="color:#fff; font-size:13px; display:block;">' . $rName . '</strong><span style="font-size:10px; color:#aaa;">' . $rLoc . '</span></div>'
                     . '</div>'
                     . '<div style="font-size:11px; margin-bottom:6px;">' . $stars . '</div>'
                     . '<p style="font-size:12px; color:#eee; line-height:1.4; margin:0;">' . $rText . '</p>'
                     . '</div>';
    }
    $reviewsHtml .= '</div></div>';
    if (strpos($html, '</section>') !== false) {
        $html = str_replace('</section>', $reviewsHtml . '</section>', $html);
    }
}

// 6. Inject Article Content
$articleContent = $input['article_content'] ?? '';
if (!empty($articleContent)) {
    $customArticleHtml = '<div class="article-custom-content" style="width:100%; margin-top:20px; padding:16px; background:rgba(0,0,0,0.4); border-radius:16px; border:1px solid rgba(255,255,255,0.1); color:#e0e0e0; font-size:13px; line-height:1.6; text-align:left;">' 
                       . $articleContent 
                       . '</div>';
    if (strpos($html, '</section>') !== false) {
        $html = str_replace('</section>', $customArticleHtml . '</section>', $html);
    }
}

echo $html;
