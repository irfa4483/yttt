<?php
// FLASH/meta.php - Dynamic Meta & Tunnel Variables Synchronizer
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/tunnel_helper.php';

$settings = get_tunnel_settings($pdo);

// Mother URL
$murl = rtrim($settings['tunnel_murl'], '/');
// Favicon URL
$favurl = $settings['tunnel_favurl'];
// Logo ujung kiri atas
$mainlogo = $settings['tunnel_mainlogo'];
// Image besar page / Banner
$maincontent = $settings['tunnel_maincontent'];
$banner = $maincontent;
// Meta tag & target
$title = $settings['tunnel_title'];
$desc = $settings['tunnel_desc'];
$ampurl = rtrim($settings['tunnel_ampurl'], '/');
$tag = $settings['tunnel_tag'];
$login_url = $settings['tunnel_login_url'];
$register_url = $settings['tunnel_register_url'];

if (isset($_GET[$settings['tunnel_param'] ?? 'gacor'])) {
    $paramVal = $_GET[$settings['tunnel_param'] ?? 'gacor'];
    $BRAND = match_tunnel_keyword($paramVal, ($settings['tunnel_strict_keywords'] ?? '1') === '1');
    if ($BRAND) {
        $BRANDS = $BRAND;
    } else {
        feedback404();
        exit();
    }
}
