<?php
// config/database.php

$dbPath = __DIR__ . '/../database.sqlite';

try {
    $pdo = new PDO("sqlite:" . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("PRAGMA busy_timeout = 5000");

    // Inisialisasi tabel users
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Inisialisasi tabel news / berita
    $pdo->exec("CREATE TABLE IF NOT EXISTS news (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Pengumuman',
        author_name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Inisialisasi tabel settings
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )");

    // Inisialisasi tabel templates
    $pdo->exec("CREATE TABLE IF NOT EXISTS templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        html_content TEXT,
        file_path TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Inisialisasi tabel projects dengan kolom reviews_json dan template_id
    $pdo->exec("CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        type TEXT NOT NULL DEFAULT 'amp',
        canonical_url TEXT,
        amp_url TEXT,
        banner_url TEXT,
        logo_url TEXT,
        title TEXT,
        meta_description TEXT,
        article_content TEXT,
        faq_json TEXT,
        reviews_json TEXT,
        status TEXT NOT NULL DEFAULT 'draft',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Cek dan tambahkan kolom reviews_json, template_id, favicon_url, banner_title, logo_title, gif_url, login_url, register_url, brand_name jika belum ada (Migration Safe)
    $cols = $pdo->query("PRAGMA table_info(projects)")->fetchAll();
    $existingColNames = array_column($cols, 'name');
    
    $autoColumns = [
        'reviews_json' => 'TEXT',
        'template_id'  => 'INTEGER DEFAULT 1',
        'favicon_url'  => "TEXT DEFAULT ''",
        'banner_title' => "TEXT DEFAULT ''",
        'logo_title'   => "TEXT DEFAULT ''",
        'gif_url'      => "TEXT DEFAULT ''",
        'login_url'    => "TEXT DEFAULT ''",
        'register_url' => "TEXT DEFAULT ''",
        'brand_name'   => "TEXT DEFAULT ''"
    ];

    foreach ($autoColumns as $col => $def) {
        if (!in_array($col, $existingColNames)) {
            $pdo->exec("ALTER TABLE projects ADD COLUMN {$col} {$def}");
        }
    }

    // Pastikan tabel users memiliki trial_expires_at
    $userCols = array_column($pdo->query("PRAGMA table_info(users)")->fetchAll(), 'name');
    if (!in_array('trial_expires_at', $userCols)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN trial_expires_at DATETIME");
    }

    // Inisialisasi tabel clone_logs untuk pencatatan dan monitoring riwayat kloning
    $pdo->exec("CREATE TABLE IF NOT EXISTS clone_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        project_id INTEGER DEFAULT 0,
        target_url TEXT NOT NULL,
        brand_name TEXT NOT NULL,
        page_format TEXT DEFAULT 'lp',
        source_mode TEXT DEFAULT 'auto',
        reviews_count INTEGER DEFAULT 0,
        faqs_count INTEGER DEFAULT 0,
        ip_address TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Inisialisasi tabel telegram_otps untuk verifikasi pendaftaran Telegram
    $pdo->exec("CREATE TABLE IF NOT EXISTS telegram_otps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL,
        otp_code TEXT NOT NULL,
        telegram_chat_id TEXT DEFAULT '',
        token_sync TEXT NOT NULL,
        is_verified INTEGER DEFAULT 0,
        expires_at DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Inisialisasi tabel payments untuk pembayaran QR / Bukti Transfer
    $pdo->exec("CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        invoice_id TEXT UNIQUE NOT NULL,
        plan_name TEXT NOT NULL,
        amount INTEGER NOT NULL,
        unique_code INTEGER DEFAULT 0,
        total_amount INTEGER NOT NULL,
        payment_method TEXT DEFAULT 'qris',
        proof_image TEXT DEFAULT '',
        telegram_username TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'pending',
        notes TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Cek dan tambahkan kolom file_path & type ke tabel templates jika belum ada
    $colsTpl = $pdo->query("PRAGMA table_info(templates)")->fetchAll();
    $hasFilePath = false;
    $hasType = false;
    foreach ($colsTpl as $col) {
        if ($col['name'] === 'file_path') $hasFilePath = true;
        if ($col['name'] === 'type') $hasType = true;
    }
    if (!$hasFilePath) {
        $pdo->exec("ALTER TABLE templates ADD COLUMN file_path TEXT");
    }
    if (!$hasType) {
        $pdo->exec("ALTER TABLE templates ADD COLUMN type TEXT DEFAULT 'amp'");
        // Auto-klasifikasi template yang sudah ada (AMP vs LP)
        $existingTpls = $pdo->query("SELECT id, name, file_path FROM templates")->fetchAll();
        foreach ($existingTpls as $tplRow) {
            $f = __DIR__ . '/../cdn/templates/' . ($tplRow['file_path'] ?? '');
            $headContent = file_exists($f) ? substr(file_get_contents($f), 0, 800) : '';
            $isAmp = (stripos($headContent, '<html amp') !== false || stripos($headContent, '<html ⚡') !== false || stripos($headContent, 'amp-boilerplate') !== false || stripos($tplRow['name'], 'amp') !== false);
            $tplType = $isAmp ? 'amp' : 'lp';
            $pdo->prepare("UPDATE templates SET type = ? WHERE id = ?")->execute([$tplType, $tplRow['id']]);
        }
    }

    // Seed data template jika kosong
    $stmtTpl = $pdo->query("SELECT COUNT(*) as count FROM templates");
    if ($stmtTpl->fetch()['count'] == 0) {
        $seedTpl = $pdo->prepare("INSERT INTO templates (name, description, html_content, file_path) VALUES (?, ?, '', ?)");
        
        $phpTpl = __DIR__ . '/../template-lp-dan-amp/index.php';
        $htmlTpl = __DIR__ . '/../template-lp-dan-amp/index.html';
        
        $contentPhp = file_exists($phpTpl) ? file_get_contents($phpTpl) : '<h1>PHP Template Missing</h1>';
        $contentHtml = file_exists($htmlTpl) ? file_get_contents($htmlTpl) : '<h1>HTML Template Missing</h1>';
        
        $cdnDir = __DIR__ . '/../cdn/templates/';
        if (!is_dir($cdnDir)) {
            mkdir($cdnDir, 0755, true);
        }
        
        $hash1 = md5(uniqid('tpl_master', true)) . '.html';
        $hash2 = md5(uniqid('tpl_simple', true)) . '.html';
        
        file_put_contents($cdnDir . $hash1, $contentPhp);
        file_put_contents($cdnDir . $hash2, $contentHtml);
        
        $seedTpl->execute(['Template Master', 'Template bawaan dengan struktur lengkap AMP & LP', $hash1]);
        $seedTpl->execute(['Template Simple', 'Template HTML struktur ringan', $hash2]);
    }

    // Seed data user jika database baru
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    if ($stmt->fetch()['count'] == 0) {
        $adminPass = password_hash('admin123', PASSWORD_BCRYPT);
        $userPass  = password_hash('user123', PASSWORD_BCRYPT);

        $seed = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $seed->execute(['Administrator System', 'admin@example.com', $adminPass, 'admin']);
        $seed->execute(['Pengguna Biasa', 'user@example.com', $userPass, 'user']);
    }

    // Seed data berita jika kosong
    $stmtNews = $pdo->query("SELECT COUNT(*) as count FROM news");
    if ($stmtNews->fetch()['count'] == 0) {
        $seedNews = $pdo->prepare("INSERT INTO news (title, content, category, author_name) VALUES (?, ?, ?, ?)");
        $seedNews->execute([
            'Peluncuran SaaS Builder LP & AMP dengan AI Generator',
            'Platform SaaS Builder resmi diluncurkan! Buat Landing Page & AMP Page dengan Live Preview real-time, pengubah link canonical, dan AI Generator.',
            'Fitur Baru',
            'Administrator System'
        ]);
    }

    // Seed default settings jika kosong
    $defaultSettings = [
        'ai_provider' => 'gemini',
        'ai_api_key' => '',
        'ai_api_key_builder' => '',
        'ai_api_key_cloaking' => '',
        'ai_model' => 'gemini-1.5-flash',
        'site_domain' => 'http://localhost:8000',
        'telegram_bot_token' => '',
        'telegram_bot_username' => 'FlashOfficialBot',
        'telegram_otp_enabled' => '0',
        'qris_image_path' => '',
        'bank_name' => 'BCA',
        'bank_account_number' => '8735091234',
        'bank_account_name' => 'FLASH OFFICIAL'
    ];
    $stmtSetCheck = $pdo->prepare("SELECT COUNT(*) FROM settings WHERE key = ?");
    $stmtSetInsert = $pdo->prepare("INSERT INTO settings (key, value) VALUES (?, ?)");
    foreach ($defaultSettings as $k => $v) {
        $stmtSetCheck->execute([$k]);
        if ($stmtSetCheck->fetchColumn() == 0) {
            $stmtSetInsert->execute([$k, $v]);
        }
    }

} catch (PDOException $e) {
    die("Koneksi Database Gagal: " . $e->getMessage());
}

return $pdo;
