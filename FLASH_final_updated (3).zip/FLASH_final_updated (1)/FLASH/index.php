<?php
// FLASH/index.php - Official Landing Page for FLASH Platform & Dynamic SEO Tunnel
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/tunnel_helper.php';

// Cek apakah request ditujukan untuk Dynamic Tunnel atau Index Override aktif
if (should_handle_tunnel_request()) {
    handle_tunnel_request();
    exit;
}

// Jika pengguna sudah login, langsung alihkan ke Dashboard Member
if (is_logged_in()) {
    header('Location: /user/dashboard.php');
    exit;
}

$pageTitle = 'FLASH - Platform Kloning & Builder Landing Page & Google AMP Otomatis';
require_once __DIR__ . '/includes/header.php';
?>

<div class="min-h-screen bg-slate-950 text-slate-100 selection:bg-brand-500 selection:text-white relative overflow-hidden font-sans"
     x-data="{ 
        activeFaq: null,
        simStep: 3,
        simBrand: 'FLASH_MAXWIN',
        simTargetUrl: 'https://promo-resmi-target.com/event-jackpot'
     }">

    <!-- Ambient Glowing Background Accents -->
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[550px] bg-gradient-to-b from-brand-600/25 via-indigo-600/15 to-transparent blur-3xl pointer-events-none -z-10"></div>
    <div class="absolute top-1/4 -left-48 w-96 h-96 bg-brand-600/15 rounded-full blur-3xl pointer-events-none -z-10"></div>
    <div class="absolute top-1/2 -right-48 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none -z-10"></div>
    <div class="absolute bottom-40 left-1/3 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none -z-10"></div>

    <!-- 1. Floating Glass Navbar -->
    <nav class="border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-xl sticky top-0 z-50 px-4 sm:px-8 py-3.5 transition-all">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <!-- Brand Logo -->
            <a href="/" class="flex items-center gap-3 group">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-brand-500/30 group-hover:scale-105 transition-transform">
                    <i class="fa-solid fa-bolt-lightning text-xl text-amber-300"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <span class="font-black text-xl tracking-tight text-white group-hover:text-brand-300 transition-colors">
                            FLASH
                        </span>
                        <span class="text-[10px] px-2 py-0.5 rounded-full bg-brand-500/20 border border-brand-500/40 text-brand-300 font-extrabold uppercase tracking-wide">
                            v2.5 AI
                        </span>
                    </div>
                    <span class="text-[10px] text-slate-400 block leading-none font-medium">LP & Google AMP Engine</span>
                </div>
            </a>

            <!-- Navigation Links (Desktop) -->
            <div class="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-300">
                <a href="#fitur" class="hover:text-white transition-colors">Fitur Unggulan</a>
                <a href="#simulator" class="hover:text-white transition-colors">Live Simulator</a>
                <a href="#perbandingan" class="hover:text-white transition-colors">Perbandingan</a>
                <a href="#testimoni" class="hover:text-white transition-colors">Ulasan Pengguna</a>
                <a href="#harga" class="hover:text-brand-300 transition-colors font-bold text-amber-300">Paket & Harga</a>
                <a href="#faq" class="hover:text-white transition-colors">FAQ</a>
                <a href="/sitemap.xml" target="_blank" class="hover:text-brand-400 flex items-center gap-1">
                    <i class="fa-solid fa-sitemap text-[10px]"></i> Sitemap
                </a>
            </div>

            <!-- Action Buttons -->
            <div class="flex items-center gap-3">
                <a href="/auth/login.php" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/80 border border-transparent hover:border-slate-700 transition-all flex items-center gap-2">
                    <i class="fa-solid fa-right-to-bracket text-brand-400"></i>
                    <span>Masuk</span>
                </a>
                <a href="/auth/register.php" class="px-4 sm:px-5 py-2.5 rounded-xl bg-gradient-to-r from-brand-600 via-indigo-600 to-amber-500 hover:opacity-95 text-white font-bold text-xs shadow-lg shadow-brand-500/30 transition-all flex items-center gap-2">
                    <i class="fa-solid fa-gift text-amber-300"></i>
                    <span>Coba Trial 1 Hari (24 Jam)</span>
                </a>
            </div>
        </div>
    </nav>

    <!-- 2. Hero Section -->
    <header class="max-w-6xl mx-auto px-4 sm:px-6 pt-14 sm:pt-20 pb-16 text-center space-y-7">
        <!-- Top Badge Alert -->
        <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-brand-500/40 text-brand-300 text-xs font-semibold shadow-inner backdrop-blur-md">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <i class="fa-solid fa-wand-magic-sparkles text-amber-400"></i>
            <span>Deep Crawler Anti-Cloaking & AI Gemini Engine • SEO Google 2026 Ready</span>
        </div>

        <!-- Main Headline -->
        <h1 class="text-4xl sm:text-6xl lg:text-7xl font-black text-white tracking-tight leading-[1.12] max-w-5xl mx-auto">
            Kloning & Bangun <br class="hidden sm:inline">
            <span class="bg-gradient-to-r from-brand-400 via-indigo-300 to-amber-300 bg-clip-text text-transparent">
                Landing Page & Google AMP
            </span>
            <br>Tanpa Batas dalam 1-Klik
        </h1>

        <!-- Subtitle -->
        <p class="text-slate-400 text-base sm:text-xl max-w-3xl mx-auto leading-relaxed">
            Sedot URL website target secara instan. Multi-hop crawler mampu menembus LP yang disembunyikan atau di-redirect, sementara AI mendeteksi otomatis seluruh banner, logo, GIF animasi jackpot, ulasan bintang 5, serta FAQ Schema.org resmi tanpa sisa kode duplikat.
        </p>

        <!-- CTA Buttons -->
        <div class="flex flex-col sm:flex-row items-center justify-center gap-4 pt-3">
            <a href="/auth/register.php" class="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-brand-600 via-indigo-600 to-amber-500 hover:scale-[1.02] text-white font-extrabold text-sm shadow-xl shadow-brand-500/35 transition-all flex items-center justify-center gap-3">
                <i class="fa-solid fa-rocket text-amber-300 text-base"></i>
                <span>Daftar & Mulai Trial Gratis 1 Hari (24 Jam)</span>
            </a>
            <a href="/auth/login.php" class="w-full sm:w-auto px-6 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-200 text-sm font-semibold transition-all flex items-center justify-center gap-2">
                <i class="fa-solid fa-circle-play text-brand-400"></i>
                <span>Sudah Punya Akun? Masuk</span>
            </a>
        </div>

        <!-- Trust Checkpoints -->
        <div class="pt-4 flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs text-slate-400 font-medium">
            <span class="flex items-center gap-1.5 text-emerald-400">
                <i class="fa-solid fa-circle-check"></i> 100% Google Core Web Vitals
            </span>
            <span class="flex items-center gap-1.5 text-amber-400">
                <i class="fa-solid fa-bolt"></i> Standar Google AMP Validator
            </span>
            <span class="flex items-center gap-1.5 text-brand-300">
                <i class="fa-solid fa-star"></i> Schema Review & FAQPage JSON-LD
            </span>
            <span class="flex items-center gap-1.5 text-slate-300">
                <i class="fa-solid fa-shield-halved"></i> Multi-Hop Anti-Cloaking
            </span>
        </div>
    </header>

    <!-- 3. Interactive Mockup / Clone Simulator -->
    <section id="simulator" class="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div class="glass-card rounded-3xl border border-slate-800 bg-slate-900/70 shadow-2xl p-4 sm:p-8 space-y-6">
            <!-- Mockup Window Header -->
            <div class="flex items-center justify-between border-b border-slate-800/80 pb-4">
                <div class="flex items-center gap-2">
                    <span class="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span>
                    <span class="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
                    <span class="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
                    <span class="ml-2 text-xs font-mono text-slate-400 font-semibold">FLASH Interactive Clone & Detection Simulator</span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold">
                        <i class="fa-solid fa-circle text-[8px] animate-pulse mr-1"></i> Live Engine
                    </span>
                </div>
            </div>

            <!-- Simulation Input Bar -->
            <div class="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
                <div class="md:col-span-6 relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 font-mono text-xs">
                        <i class="fa-solid fa-link"></i>
                    </span>
                    <input type="text" x-model="simTargetUrl" 
                           class="w-full pl-9 pr-4 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-200 text-xs font-mono focus:outline-none focus:border-brand-500"
                           placeholder="https://target-domain.com/landing-page">
                </div>
                <div class="md:col-span-3 relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 font-mono text-xs">
                        <i class="fa-solid fa-tag"></i>
                    </span>
                    <input type="text" x-model="simBrand" 
                           class="w-full pl-9 pr-4 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-slate-200 text-xs font-bold focus:outline-none focus:border-brand-500"
                           placeholder="Nama Brand Anda">
                </div>
                <div class="md:col-span-3">
                    <a href="/auth/register.php" class="w-full py-3 px-4 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-brand-500/25 transition-all">
                        <i class="fa-solid fa-bolt-lightning text-amber-300"></i>
                        <span>Kloning Sekarang</span>
                    </a>
                </div>
            </div>

            <!-- Simulated Detection Dashboard -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <!-- Box 1: Elemen Halaman Terdeteksi -->
                <div class="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-3">
                    <div class="flex items-center justify-between">
                        <span class="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                            <i class="fa-solid fa-magnifying-glass-chart text-brand-400"></i> Status Deteksi
                        </span>
                        <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">100% Selesai</span>
                    </div>
                    <ul class="space-y-2 text-xs text-slate-400">
                        <li class="flex items-center justify-between text-slate-200">
                            <span>Format Halaman:</span>
                            <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold font-mono">Google AMP ⚡</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>Banner Promo (1200x628):</span>
                            <span class="text-emerald-400 font-semibold">✓ Terdeteksi</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>GIF Animasi Jackpot:</span>
                            <span class="text-emerald-400 font-semibold">✓ Terpetakan</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>Logo & Favicon Asli:</span>
                            <span class="text-emerald-400 font-semibold">✓ Terambil</span>
                        </li>
                    </ul>
                </div>

                <!-- Box 2: Ulasan Pengguna & FAQ Schema -->
                <div class="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-3">
                    <div class="flex items-center justify-between">
                        <span class="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                            <i class="fa-solid fa-comments text-emerald-400"></i> Ulasan & FAQ
                        </span>
                        <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">Schema.org</span>
                    </div>
                    <ul class="space-y-2 text-xs text-slate-400">
                        <li class="flex items-center justify-between text-slate-200">
                            <span>Rating Bintang Pengguna:</span>
                            <span class="text-amber-400 font-bold">⭐ 4.98 / 5.0 (98 Ulasan)</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>Ulasan Pengguna Asli:</span>
                            <span class="text-emerald-400 font-semibold">✓ 5 Ulasan Terstruktur</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>FAQ Accordion:</span>
                            <span class="text-emerald-400 font-semibold">✓ 4 Pertanyaan & Jawaban</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>JSON-LD Schema Markup:</span>
                            <span class="text-emerald-400 font-semibold">✓ AggregateRating Valid</span>
                        </li>
                    </ul>
                </div>

                <!-- Box 3: Brand Swapping & Output -->
                <div class="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-3">
                    <div class="flex items-center justify-between">
                        <span class="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                            <i class="fa-solid fa-arrow-right-arrow-left text-indigo-400"></i> Penggantian Brand
                        </span>
                        <span class="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-bold">Clean Code</span>
                    </div>
                    <ul class="space-y-2 text-xs text-slate-400">
                        <li class="flex items-center justify-between text-slate-200">
                            <span>Brand Baru:</span>
                            <span class="text-amber-300 font-bold font-mono" x-text="simBrand"></span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>Pembersihan Brand Lama:</span>
                            <span class="text-emerald-400 font-semibold">✓ 100% Bersih</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>Tombol Login & Daftar:</span>
                            <span class="text-emerald-400 font-semibold">✓ Terarah ke Link Anda</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span>Siap Deploy:</span>
                            <span class="text-brand-300 font-semibold font-mono">ZIP Export / Live URL</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. Stat Counter Bar -->
    <section class="border-y border-slate-800/80 bg-slate-900/40 py-10 px-4 sm:px-6">
        <div class="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div class="space-y-1">
                <span class="text-3xl sm:text-4xl font-black text-white tracking-tight">15,400+</span>
                <span class="text-xs text-slate-400 block font-medium uppercase tracking-wider">Landing Page & AMP Dibuat</span>
            </div>
            <div class="space-y-1">
                <span class="text-3xl sm:text-4xl font-black text-amber-400 tracking-tight">&lt; 0.8 Detik</span>
                <span class="text-xs text-slate-400 block font-medium uppercase tracking-wider">Waktu Muat (PageSpeed 99+)</span>
            </div>
            <div class="space-y-1">
                <span class="text-3xl sm:text-4xl font-black text-emerald-400 tracking-tight">100%</span>
                <span class="text-xs text-slate-400 block font-medium uppercase tracking-wider">Lulus Uji Google AMP</span>
            </div>
            <div class="space-y-1">
                <span class="text-3xl sm:text-4xl font-black text-indigo-400 tracking-tight">99.9%</span>
                <span class="text-xs text-slate-400 block font-medium uppercase tracking-wider">Tingkat Indeks Search Engine</span>
            </div>
        </div>
    </section>

    <!-- 5. Feature Grid Section -->
    <section id="fitur" class="max-w-7xl mx-auto px-4 sm:px-6 py-20 space-y-12">
        <div class="text-center space-y-3 max-w-3xl mx-auto">
            <span class="text-xs font-extrabold text-brand-400 uppercase tracking-widest px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20">
                Teknologi Generasi Baru
            </span>
            <h2 class="text-3xl sm:text-5xl font-black text-white tracking-tight">
                Dirancang Khusus Menjawab Tantangan Update Google 2026
            </h2>
            <p class="text-slate-400 text-sm sm:text-base leading-relaxed">
                Kami membangun arsitektur kloning yang cerdas: mendeteksi apa yang ada, jujur bila tidak ada, dan mengonversinya secara otomatis ke format landing page tercepat.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Feature 1 -->
            <div class="glass-card p-7 rounded-3xl border border-slate-800 hover:border-brand-500/40 transition-all space-y-4 group">
                <div class="w-12 h-12 rounded-2xl bg-brand-500/15 border border-brand-500/30 text-brand-400 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                    <i class="fa-solid fa-network-wired"></i>
                </div>
                <h3 class="text-lg font-bold text-white">Multi-Hop Crawler Anti-Cloaking</h3>
                <p class="text-slate-400 text-xs leading-relaxed">
                    Menelusuri redirect bertingkat, meta-refresh, dan skema cloaking target. Jika landing page disembunyikan di balik domain perantara atau URL di-restart, sistem tetap dapat mengambil halaman aslinya secara utuh.
                </p>
            </div>

            <!-- Feature 2 -->
            <div class="glass-card p-7 rounded-3xl border border-slate-800 hover:border-emerald-500/40 transition-all space-y-4 group">
                <div class="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                    <i class="fa-solid fa-bolt"></i>
                </div>
                <h3 class="text-lg font-bold text-white">Google AMP Validator 100% Resmi</h3>
                <p class="text-slate-400 text-xs leading-relaxed">
                    Membersihkan script ilegal, inline styles terlarang, dan merestrukturisasi gambar ke tag resmi <code>&lt;amp-img&gt;</code> serta video <code>&lt;amp-video&gt;</code> agar lulus uji AMP Test Google tanpa kompromi.
                </p>
            </div>

            <!-- Feature 3 -->
            <div class="glass-card p-7 rounded-3xl border border-slate-800 hover:border-amber-500/40 transition-all space-y-4 group">
                <div class="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                    <i class="fa-solid fa-comments"></i>
                </div>
                <h3 class="text-lg font-bold text-white">Deteksi Ulasan & FAQ Anti-Halusinasi</h3>
                <p class="text-slate-400 text-xs leading-relaxed">
                    AI Gemini secara akurat mengekstrak rating bintang, nama pengulas, testimoni nyata, dan FAQ. Jika target tidak memiliki ulasan atau FAQ, sistem dengan jujur memberitahukan "Tidak ada", menjaga orisinalitas situs Anda.
                </p>
            </div>

            <!-- Feature 4 -->
            <div class="glass-card p-7 rounded-3xl border border-slate-800 hover:border-indigo-500/40 transition-all space-y-4 group">
                <div class="w-12 h-12 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                    <i class="fa-solid fa-shuffle"></i>
                </div>
                <h3 class="text-lg font-bold text-white">Penggantian Brand Menyeluruh</h3>
                <p class="text-slate-400 text-xs leading-relaxed">
                    Mengganti seluruh variasi nama brand target (huruf besar, huruf kecil, camelCase) di judul SEO, meta description, konten artikel, ulasan, hingga atribut alt gambar tanpa meninggalkan jejak brand lama.
                </p>
            </div>

            <!-- Feature 5 -->
            <div class="glass-card p-7 rounded-3xl border border-slate-800 hover:border-purple-500/40 transition-all space-y-4 group">
                <div class="w-12 h-12 rounded-2xl bg-purple-500/15 border border-purple-500/30 text-purple-400 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                    <i class="fa-solid fa-file-zipper"></i>
                </div>
                <h3 class="text-lg font-bold text-white">1-Klik ZIP Clean Export</h3>
                <p class="text-slate-400 text-xs leading-relaxed">
                    Unduh paket arsip mandiri (HTML, aset lokal, Schema JSON-LD) yang bersih tanpa tag template template sisa <code>{{ ... }}</code>. Siap diupload langsung ke cPanel, Apache, Nginx, ataupun Cloudflare Pages.
                </p>
            </div>

            <!-- Feature 6 -->
            <div class="glass-card p-7 rounded-3xl border border-slate-800 hover:border-cyan-500/40 transition-all space-y-4 group">
                <div class="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                    <i class="fa-solid fa-chart-line"></i>
                </div>
                <h3 class="text-lg font-bold text-white">Dynamic SEO Tunnel & XML Sitemap</h3>
                <p class="text-slate-400 text-xs leading-relaxed">
                    Dilengkapi dengan generator sitemap dinamis ribuan keyword serta dynamic tunnel SEO yang memudahkan bot Google dan search engine utama merayapi halaman Anda dengan cepat.
                </p>
            </div>
        </div>
    </section>

    <!-- 6. Comparison Section: FLASH vs Builder Biasa -->
    <section id="perbandingan" class="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div class="glass-card rounded-3xl border border-slate-800 p-6 sm:p-10 space-y-8">
            <div class="text-center space-y-2">
                <span class="text-xs font-bold text-amber-400 uppercase tracking-widest">Keunggulan Mutlak</span>
                <h2 class="text-2xl sm:text-4xl font-black text-white">Kenapa Memilih FLASH Platform?</h2>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs sm:text-sm">
                    <thead>
                        <tr class="border-b border-slate-800 text-slate-400 uppercase text-[11px] tracking-wider">
                            <th class="py-4 px-4 font-bold">Fitur & Kemampuan</th>
                            <th class="py-4 px-4 text-brand-300 font-extrabold bg-brand-500/10 rounded-t-xl">FLASH Platform (v2.5)</th>
                            <th class="py-4 px-4 text-slate-500 font-semibold">Builder / Kloning Biasa</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 text-slate-300">
                        <tr>
                            <td class="py-4 px-4 font-medium">Kecepatan Kloning dari URL</td>
                            <td class="py-4 px-4 text-emerald-400 font-bold bg-brand-500/5">Instan &lt; 3 Detik (Full Element)</td>
                            <td class="py-4 px-4 text-slate-500">Manual memakan waktu berjam-jam</td>
                        </tr>
                        <tr>
                            <td class="py-4 px-4 font-medium">Validitas Google AMP</td>
                            <td class="py-4 px-4 text-emerald-400 font-bold bg-brand-500/5">100% Valid & Lulus Uji AMP Test</td>
                            <td class="py-4 px-4 text-rose-400 font-semibold">Sering gagal validasi script ilegal</td>
                        </tr>
                        <tr>
                            <td class="py-4 px-4 font-medium">Menembus LP Cloaking / Disembunyikan</td>
                            <td class="py-4 px-4 text-emerald-400 font-bold bg-brand-500/5">Bisa (Multi-Hop Deep Resolver)</td>
                            <td class="py-4 px-4 text-rose-400 font-semibold">Gagal / Error 403 Forbidden</td>
                        </tr>
                        <tr>
                            <td class="py-4 px-4 font-medium">Deteksi Ulasan & FAQ Otomatis</td>
                            <td class="py-4 px-4 text-emerald-400 font-bold bg-brand-500/5">AI Gemini + Schema JSON-LD</td>
                            <td class="py-4 px-4 text-slate-500">Tidak ada (Harus ketik satu per satu)</td>
                        </tr>
                        <tr>
                            <td class="py-4 px-4 font-medium">Penyaringan Anti-Duplikat Konten</td>
                            <td class="py-4 px-4 text-emerald-400 font-bold bg-brand-500/5">Brand, Meta & Schema diganti total</td>
                            <td class="py-4 px-4 text-rose-400 font-semibold">Rentan penalty plagiat Google</td>
                        </tr>
                        <tr>
                            <td class="py-4 px-4 font-medium">Admin Monitoring & Konversi Template</td>
                            <td class="py-4 px-4 text-emerald-400 font-bold bg-brand-500/5">1-Klik Jadikan Template Sistem</td>
                            <td class="py-4 px-4 text-slate-500">Tidak tersedia</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <!-- 7. Testimonials & User Reviews -->
    <section id="testimoni" class="max-w-6xl mx-auto px-4 sm:px-6 py-16 space-y-10">
        <div class="text-center space-y-2">
            <span class="text-xs font-bold text-brand-400 uppercase tracking-widest">Apa Kata Mereka</span>
            <h2 class="text-3xl sm:text-4xl font-black text-white">Ulasan Pengguna Nyata</h2>
            <p class="text-slate-400 text-xs sm:text-sm">Dipercaya oleh ribuan webmaster dan praktisi SEO di seluruh Indonesia.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Review 1 -->
            <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                <div class="flex items-center gap-1 text-amber-400 text-sm">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                </div>
                <p class="text-xs text-slate-300 leading-relaxed italic">
                    "Fitur kloning multi-hop-nya gila! Saya coba kloning domain target yang di-redirect ke beberapa link, sistem FLASH tetap bisa ambil LP aslinya dan langsung ganti brand ke situs saya dalam 5 detik."
                </p>
                <div class="flex items-center gap-3 pt-2 border-t border-slate-800">
                    <div class="w-9 h-9 rounded-full bg-brand-500/20 text-brand-300 font-bold flex items-center justify-center text-xs">
                        RF
                    </div>
                    <div>
                        <span class="text-xs font-bold text-white block">Rian Firmansyah</span>
                        <span class="text-[10px] text-slate-400">SEO Specialist & Webmaster</span>
                    </div>
                </div>
            </div>

            <!-- Review 2 -->
            <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                <div class="flex items-center gap-1 text-amber-400 text-sm">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                </div>
                <p class="text-xs text-slate-300 leading-relaxed italic">
                    "Yang paling saya suka deteksi ulasan dan FAQ-nya. Begitu dikloning, langsung muncul Schema AggregateRating di Google Search Console tanpa error satupun. Google AMP-nya juga 100% valid."
                </p>
                <div class="flex items-center gap-3 pt-2 border-t border-slate-800">
                    <div class="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-300 font-bold flex items-center justify-center text-xs">
                        BA
                    </div>
                    <div>
                        <span class="text-xs font-bold text-white block">Budi Anggara</span>
                        <span class="text-[10px] text-slate-400">Digital Marketing Agency Lead</span>
                    </div>
                </div>
            </div>

            <!-- Review 3 -->
            <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4">
                <div class="flex items-center gap-1 text-amber-400 text-sm">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                </div>
                <p class="text-xs text-slate-300 leading-relaxed italic">
                    "Panel adminnya sangat rapi. Kami bisa memantau siapa saja tim yang melakukan kloning URL dan hasil kloning yang bagus bisa langsung kami jadikan template sistem untuk dipakai bersama."
                </p>
                <div class="flex items-center gap-3 pt-2 border-t border-slate-800">
                    <div class="w-9 h-9 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-xs">
                        DW
                    </div>
                    <div>
                        <span class="text-xs font-bold text-white block">Deni Wijaya</span>
                        <span class="text-[10px] text-slate-400">Senior Affiliate Manager</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 8. Pricing & Subscription Plans (Paket Langganan & Biaya) -->
    <section id="harga" class="max-w-7xl mx-auto px-4 sm:px-6 py-20 space-y-12">
        <div class="text-center space-y-3 max-w-3xl mx-auto">
            <span class="text-xs font-extrabold text-amber-400 uppercase tracking-widest px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20">
                Pilihan Paket Fleksibel & Terjangkau
            </span>
            <h2 class="text-3xl sm:text-5xl font-black text-white tracking-tight">
                Investasi Terbaik untuk Dominasi <span class="bg-gradient-to-r from-brand-400 to-amber-300 bg-clip-text text-transparent">Peringkat Google</span>
            </h2>
            <p class="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Pilih paket kuota bulanan yang sesuai kebutuhan Anda. Mulai dari uji coba gratis 7 hari (1 minggu) hingga paket pro berkapasitas besar tanpa biaya tersembunyi.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
            
            <!-- PLAN 1: FREE TRIAL 1 HARI (24 JAM) GRATIS -->
            <div class="glass-card rounded-3xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between hover:border-slate-700 transition-all hover:shadow-xl relative group">
                <div class="space-y-5">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            Uji Coba 24 Jam
                        </span>
                        <h3 class="text-xl font-black text-white">Free Trial</h3>
                        <p class="text-slate-400 text-xs mt-1">Coba seluruh fitur builder & AMP 100% gratis selama 24 jam.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 0</span>
                            <span class="text-xs text-slate-400 font-semibold">/ 1 Hari</span>
                        </div>
                        <span class="text-[11px] text-emerald-400 font-medium">Aktif otomatis saat daftar akun</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-300">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>Kuota <b>3 Project</b> Landing Page & AMP</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>10x AI Generator & Kloning URL</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>Validasi Google AMP 100%</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>Live Preview Multi-Device</span>
                        </li>
                        <li class="flex items-center gap-2.5 text-slate-500">
                            <i class="fa-solid fa-xmark text-[11px]"></i>
                            <span>Clean ZIP Export Dinonaktifkan</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all group-hover:bg-slate-700">
                        <span>Mulai Trial 1 Hari Gratis</span>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            </div>

            <!-- PLAN 2: TRIAL 7 HARI (RP 150.000) -->
            <div class="glass-card rounded-3xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between hover:border-brand-500/50 transition-all hover:shadow-xl relative group">
                <div class="space-y-5">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-brand-400 bg-brand-500/10 border border-brand-500/20 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            Trial Mingguan (1 Minggu)
                        </span>
                        <h3 class="text-xl font-black text-white">Paket 7 Hari</h3>
                        <p class="text-slate-400 text-xs mt-1">Uji coba penuh selama 1 minggu lengkap dengan fitur unduh ZIP bersih.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 150.000</span>
                            <span class="text-xs text-slate-400 font-semibold">/ 7 Hari</span>
                        </div>
                        <span class="text-[11px] text-emerald-400 font-bold">Akses Penuh 1 Minggu</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-300">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-brand-400 text-[11px]"></i>
                            <span>Kuota <b>30 Project</b> LP & Google AMP</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-brand-400 text-[11px]"></i>
                            <span>60x AI Kloning Deep Crawler</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-brand-400 text-[11px]"></i>
                            <span>1-Click Clean ZIP Export Bersih</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-brand-400 text-[11px]"></i>
                            <span>Auto-Deploy via Remote Shell</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3 px-4 rounded-xl bg-brand-600/20 hover:bg-brand-600/30 border border-brand-500/40 text-brand-300 font-bold text-xs flex items-center justify-center gap-2 transition-all">
                        <span>Pilih Paket 7 Hari</span>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            </div>

            <!-- PLAN 2B: PAKET LITE (2 MINGGU - RP 350.000) -->
            <div class="glass-card rounded-3xl border border-sky-500/30 bg-slate-900/60 p-6 flex flex-col justify-between hover:border-sky-500/60 transition-all hover:shadow-xl relative group">
                <div class="space-y-5">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            2 Minggu Penuh
                        </span>
                        <h3 class="text-xl font-black text-white">Paket Lite</h3>
                        <p class="text-slate-400 text-xs mt-1">Paket hemat 2 minggu untuk percepatan pembuatan landing page & optimasi SEO.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 350.000</span>
                            <span class="text-xs text-slate-400 font-semibold">/ 2 Minggu</span>
                        </div>
                        <span class="text-[11px] text-sky-400 font-bold">14 Hari Masa Aktif</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-300">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-sky-400 text-[11px]"></i>
                            <span>Kuota <b>75 Project</b> LP & AMP</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-sky-400 text-[11px]"></i>
                            <span>150x AI Kloning Deep Crawler</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-sky-400 text-[11px]"></i>
                            <span>Auto-Deploy via Shell Receiver</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-sky-400 text-[11px]"></i>
                            <span>Auto Sitemap & Robots.txt Googlebot</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3 px-4 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-sky-300 font-bold text-xs flex items-center justify-center gap-2 transition-all">
                        <span>Pilih Paket Lite</span>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            </div>

            <!-- PLAN 2C: PAKET ELITE (1 BULAN - RP 550.000) -->
            <div class="glass-card rounded-3xl border border-emerald-500/30 bg-slate-900/60 p-6 flex flex-col justify-between hover:border-emerald-500/60 transition-all hover:shadow-xl relative group">
                <div class="space-y-5">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            Bulanan Hemat
                        </span>
                        <h3 class="text-xl font-black text-white">Paket Elite</h3>
                        <p class="text-slate-400 text-xs mt-1">Solusi bulanan lengkap bagi digital agency & SEO optimizer.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 550.000</span>
                            <span class="text-xs text-slate-400 font-semibold">/ bulan</span>
                        </div>
                        <span class="text-[11px] text-emerald-400 font-bold">30 Hari Masa Aktif</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-300">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>Kuota <b>150 Project</b> LP & AMP</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>300x AI Kloning Deep Crawler</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>AI Article & Review Generator</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-emerald-400 text-[11px]"></i>
                            <span>Full Remote Deploy Shell</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3 px-4 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-2 transition-all">
                        <span>Pilih Paket Elite</span>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            </div>

            <!-- PLAN 2D: PAKET PREMIUM (1 BULAN - RP 1.000.000) -->
            <div class="glass-card rounded-3xl border border-indigo-500/30 bg-slate-900/60 p-6 flex flex-col justify-between hover:border-indigo-500/60 transition-all hover:shadow-xl relative group">
                <div class="space-y-5">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            Pro Marketer
                        </span>
                        <h3 class="text-xl font-black text-white">Paket Premium</h3>
                        <p class="text-slate-400 text-xs mt-1">Kapasitas tinggi dengan pinger search engine untuk kecepatan indeks maksimal.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 1.000.000</span>
                            <span class="text-xs text-slate-400 font-semibold">/ bulan</span>
                        </div>
                        <span class="text-[11px] text-indigo-400 font-bold">30 Hari Masa Aktif</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-300">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-indigo-400 text-[11px]"></i>
                            <span>Kuota <b>300 Project</b> LP & AMP</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-indigo-400 text-[11px]"></i>
                            <span>600x AI Kloning Deep Crawler</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-indigo-400 text-[11px]"></i>
                            <span>Fast Index Pinger Google & Bing</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-indigo-400 text-[11px]"></i>
                            <span>5-Star Schema.org Rich Snippet</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3 px-4 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 font-bold text-xs flex items-center justify-center gap-2 transition-all">
                        <span>Pilih Paket Premium</span>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            </div>

            <!-- PLAN 2E: PAKET DIAMOND (1 BULAN - RP 2.000.000) -->
            <div class="glass-card rounded-3xl border border-cyan-500/30 bg-slate-900/60 p-6 flex flex-col justify-between hover:border-cyan-500/60 transition-all hover:shadow-xl relative group">
                <div class="space-y-5">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            💎 Diamond Scale
                        </span>
                        <h3 class="text-xl font-black text-white">Paket Diamond</h3>
                        <p class="text-slate-400 text-xs mt-1">Skala besar untuk jaringan multi-brand & dominasi kata kunci massal.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 2.000.000</span>
                            <span class="text-xs text-slate-400 font-semibold">/ bulan</span>
                        </div>
                        <span class="text-[11px] text-cyan-400 font-bold">30 Hari Masa Aktif</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-300">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-cyan-400 text-[11px]"></i>
                            <span>Kuota <b>600 Project</b> LP & AMP</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-cyan-400 text-[11px]"></i>
                            <span>1200x AI Kloning Deep Crawler</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-cyan-400 text-[11px]"></i>
                            <span>Multi-Domain Network Manager</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-cyan-400 text-[11px]"></i>
                            <span>VIP Keyword Research Suite</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3 px-4 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-bold text-xs flex items-center justify-center gap-2 transition-all">
                        <span>Pilih Paket Diamond</span>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            </div>

            <!-- PLAN 3: PRO VIP (POPULER - RP 4.000.000 / BULAN) -->
            <div class="glass-card rounded-3xl border-2 border-brand-500 bg-gradient-to-b from-brand-950/40 via-slate-900/80 to-slate-900 p-6 flex flex-col justify-between shadow-2xl shadow-brand-500/20 relative group scale-[1.03]">
                <!-- Top Ribbon -->
                <div class="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500 to-brand-500 text-slate-950 text-[10px] font-black uppercase tracking-wider shadow-lg flex items-center gap-1.5 whitespace-nowrap">
                    <i class="fa-solid fa-crown text-xs"></i> Paket Sultan / VIP Eksklusif
                </div>

                <div class="space-y-5 pt-2">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            Akses Penuh Tanpa Batas
                        </span>
                        <h3 class="text-xl font-black text-white flex items-center gap-2">
                            <span>VIP Ultra-Rank</span>
                            <i class="fa-solid fa-crown text-amber-400 text-sm"></i>
                        </h3>
                        <p class="text-slate-400 text-xs mt-1">Infrastruktur lengkap & amunisi SEO maksimal untuk mendominasi peringkat Google.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 4.000.000</span>
                            <span class="text-xs text-slate-400 font-semibold">/ bulan</span>
                        </div>
                        <span class="text-[11px] text-emerald-400 font-bold">Semua Fitur VIP Aktif Tanpa Limit</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-200">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-amber-400 text-[11px]"></i>
                            <span><b>Unlimited Project</b> LP & Google AMP Resmi</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-amber-400 text-[11px]"></i>
                            <span><b>Unlimited</b> Deep Crawler AI Kloning</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-amber-400 text-[11px]"></i>
                            <span>Dynamic SEO Tunnel (Etsy, Squarespace & Meta)</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-amber-400 text-[11px]"></i>
                            <span>Auto Ping Sitemap Google Indexing Otomatis</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-amber-400 text-[11px]"></i>
                            <span>Template FLASH Ultra-Rank Master (LP + AMP)</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-amber-400 text-[11px]"></i>
                            <span>Bot Telegram OTP & Notifikasi Lead Real-Time</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-amber-400 text-[11px]"></i>
                            <span>Dedicated Fast Server & Dukungan Prioritas 24/7</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-brand-600 via-indigo-600 to-amber-500 hover:opacity-95 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-brand-500/30 transition-all">
                        <span>Berlangganan VIP Sekarang</span>
                        <i class="fa-solid fa-bolt-lightning text-amber-300 text-xs"></i>
                    </a>
                </div>
            </div>

            <!-- PLAN 4: VPRO (VIP PRO SULTAN - RP 6.000.000 / BULAN) -->
            <div class="glass-card rounded-3xl border-2 border-purple-500/80 bg-gradient-to-b from-purple-950/40 via-slate-900/90 to-slate-900 p-6 flex flex-col justify-between hover:border-purple-400 transition-all shadow-2xl shadow-purple-500/20 relative group scale-[1.03]">
                <!-- Top Ribbon -->
                <div class="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white text-[10px] font-black uppercase tracking-wider shadow-lg flex items-center gap-1.5 whitespace-nowrap">
                    <i class="fa-solid fa-gem text-xs text-amber-300"></i> Kasta Tertinggi Marketer
                </div>

                <div class="space-y-5 pt-2">
                    <div>
                        <span class="text-[11px] font-bold uppercase tracking-wider text-purple-300 bg-purple-500/20 border border-purple-500/30 px-2.5 py-0.5 rounded-full inline-block mb-3">
                            Tingkat Ultimate
                        </span>
                        <h3 class="text-xl font-black text-white flex items-center gap-2">
                            <span>VPro (VIP Pro)</span>
                            <i class="fa-solid fa-gem text-purple-400 text-sm"></i>
                        </h3>
                        <p class="text-slate-400 text-xs mt-1">Dikhususkan untuk sindikat SEO, pemilik brand besar, dan jaringan PBN kelas atas.</p>
                    </div>

                    <div class="border-y border-slate-800/80 py-4">
                        <div class="flex items-baseline gap-1">
                            <span class="text-3xl font-black text-white">Rp 6.000.000</span>
                            <span class="text-xs text-slate-400 font-semibold">/ bulan</span>
                        </div>
                        <span class="text-[11px] text-purple-300 font-bold">Akses Sultan Segala Fitur & API Server</span>
                    </div>

                    <ul class="space-y-3 text-xs text-slate-200">
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-purple-400 text-[11px]"></i>
                            <span><b>Segala Fitur VIP Ultra-Rank</b> Termasuk</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-purple-400 text-[11px]"></i>
                            <span><b>Anti-Cloaking Bypass</b> (Googlebot User-Agent)</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-purple-400 text-[11px]"></i>
                            <span>Multi-Domain Tunnel Network Tanpa Batas</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-purple-400 text-[11px]"></i>
                            <span>Dedicated Private IP Proxy Scraper</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-purple-400 text-[11px]"></i>
                            <span>Private Telegram Bot Webhook & Lead Auto-Alert</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-purple-400 text-[11px]"></i>
                            <span>White-Label 100% Bebas Jejak/Watermark</span>
                        </li>
                        <li class="flex items-center gap-2.5">
                            <i class="fa-solid fa-check text-purple-400 text-[11px]"></i>
                            <span>Dedicated Account Engineer 24 Jam</span>
                        </li>
                    </ul>
                </div>

                <div class="pt-6">
                    <a href="/auth/register.php" class="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:opacity-95 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-500/30 transition-all">
                        <span>Berlangganan VPro Sekarang</span>
                        <i class="fa-solid fa-gem text-amber-300 text-xs"></i>
                    </a>
                </div>
            </div>

        </div>

        <!-- Guarantee & FAQ Callout -->
        <div class="glass-card rounded-2xl border border-slate-800/80 p-5 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-300">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center flex-shrink-0 text-lg">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                    <span class="font-bold text-white block">Garansi Bebas Risiko & Setup Mudah</span>
                    <span class="text-slate-400 text-[11px]">Coba gratis selama 7 hari tanpa kartu kredit. Aktif instan setelah pendaftaran.</span>
                </div>
            </div>
            <a href="/auth/register.php" class="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold whitespace-nowrap transition-all border border-slate-700">
                Coba Gratis Sekarang
            </a>
        </div>
    </section>

    <!-- 9. Interactive FAQ Accordion -->
    <section id="faq" class="max-w-4xl mx-auto px-4 sm:px-6 py-16 space-y-8">
        <div class="text-center space-y-2">
            <span class="text-xs font-bold text-indigo-400 uppercase tracking-widest">Pertanyaan Umum</span>
            <h2 class="text-3xl font-black text-white">Frequently Asked Questions</h2>
            <p class="text-slate-400 text-xs sm:text-sm">Jawaban lengkap seputar cara kerja, legalitas, dan keamanan sistem FLASH.</p>
        </div>

        <div class="space-y-3">
            <!-- FAQ 1 -->
            <div class="glass-card rounded-2xl border border-slate-800 overflow-hidden">
                <button @click="activeFaq = (activeFaq === 1 ? null : 1)" 
                        class="w-full p-5 text-left text-sm font-bold text-white flex items-center justify-between transition-colors hover:text-brand-300">
                    <span class="flex items-center gap-3">
                        <i class="fa-solid fa-circle-question text-brand-400"></i>
                        <span>Apakah hasil kloning Google AMP benar-benar lulus uji Google AMP Validator?</span>
                    </span>
                    <i class="fa-solid fa-chevron-down text-xs transition-transform duration-200" :class="activeFaq === 1 ? 'rotate-180' : ''"></i>
                </button>
                <div x-show="activeFaq === 1" x-collapse class="px-5 pb-5 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                    Ya, 100% valid. Sistem kami memiliki engine purifikasi HTML khusus yang membersihkan semua tag ilegal, menyaring CSS inline terlarang, menyisipkan amp-boilerplate resmi, serta mengonversi semua gambar ke <code>&lt;amp-img&gt;</code> dengan rasio dimensi yang presisi. Anda bisa langsung mengujinya di Google AMP Validator Tool.
                </div>
            </div>

            <!-- FAQ 2 -->
            <div class="glass-card rounded-2xl border border-slate-800 overflow-hidden">
                <button @click="activeFaq = (activeFaq === 2 ? null : 2)" 
                        class="w-full p-5 text-left text-sm font-bold text-white flex items-center justify-between transition-colors hover:text-brand-300">
                    <span class="flex items-center gap-3">
                        <i class="fa-solid fa-circle-question text-brand-400"></i>
                        <span>Bagaimana jika URL target menyembunyikan LP atau menggunakan redirect cloaking?</span>
                    </span>
                    <i class="fa-solid fa-chevron-down text-xs transition-transform duration-200" :class="activeFaq === 2 ? 'rotate-180' : ''"></i>
                </button>
                <div x-show="activeFaq === 2" x-collapse class="px-5 pb-5 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                    FLASH dilengkapi modul <em>Multi-Hop Deep Resolver</em>. Sistem secara otomatis menelusuri rantai redirect HTTP 301/302, meta refresh, maupun canonical target sampai ke halaman landing page tujuan akhir yang sebenarnya.
                </div>
            </div>

            <!-- FAQ 3 -->
            <div class="glass-card rounded-2xl border border-slate-800 overflow-hidden">
                <button @click="activeFaq = (activeFaq === 3 ? null : 3)" 
                        class="w-full p-5 text-left text-sm font-bold text-white flex items-center justify-between transition-colors hover:text-brand-300">
                    <span class="flex items-center gap-3">
                        <i class="fa-solid fa-circle-question text-brand-400"></i>
                        <span>Apakah ulasan pengguna dan FAQ dapat diedit secara manual?</span>
                    </span>
                    <i class="fa-solid fa-chevron-down text-xs transition-transform duration-200" :class="activeFaq === 3 ? 'rotate-180' : ''"></i>
                </button>
                <div x-show="activeFaq === 3" x-collapse class="px-5 pb-5 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                    Sangat bisa. Di Visual Builder, Anda dapat menambah, menghapus, atau mengedit narasi ulasan bintang 5 dan pertanyaan FAQ secara bebas. Jika target awal tidak memiliki ulasan atau FAQ, Anda bisa menambahkannya dengan 1-klik untuk mendongkrak peringkat SEO.
                </div>
            </div>

            <!-- FAQ 4 -->
            <div class="glass-card rounded-2xl border border-slate-800 overflow-hidden">
                <button @click="activeFaq = (activeFaq === 4 ? null : 4)" 
                        class="w-full p-5 text-left text-sm font-bold text-white flex items-center justify-between transition-colors hover:text-brand-300">
                    <span class="flex items-center gap-3">
                        <i class="fa-solid fa-circle-question text-brand-400"></i>
                        <span>Bagaimana cara menggunakan hasil halaman di hosting sendiri?</span>
                    </span>
                    <i class="fa-solid fa-chevron-down text-xs transition-transform duration-200" :class="activeFaq === 4 ? 'rotate-180' : ''"></i>
                </button>
                <div x-show="activeFaq === 4" x-collapse class="px-5 pb-5 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                    Tersedia tombol <strong>Ekspor ZIP</strong> di dashboard. Anda akan mendapatkan file <code>index.html</code> mandiri beserta seluruh aset gambar dan Schema JSON-LD yang siap diekstrak langsung ke public_html di hosting atau server apapun tanpa perlu database tambahan.
                </div>
            </div>
        </div>
    </section>

    <!-- 9. Final CTA Banner -->
    <section class="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div class="relative overflow-hidden rounded-3xl p-8 sm:p-14 bg-gradient-to-r from-brand-900/60 via-indigo-900/40 to-slate-900 border border-brand-500/30 text-center space-y-6 shadow-2xl">
            <div class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase">
                <i class="fa-solid fa-fire text-amber-400"></i> Akses Instan Langsung Aktif
            </div>
            <h2 class="text-3xl sm:text-5xl font-black text-white tracking-tight max-w-2xl mx-auto">
                Mulai Kloning Landing Page & Google AMP Sekarang Juga
            </h2>
            <p class="text-slate-300 text-sm sm:text-base max-w-xl mx-auto">
                Daftar hari ini dan nikmati uji coba gratis 24 jam dengan seluruh fitur kloning AI, Google AMP, dan Dynamic SEO Tunnel tanpa biaya.
            </p>
            <div class="pt-2">
                <a href="/auth/register.php" class="inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-brand-600 via-indigo-600 to-amber-500 hover:scale-105 text-white font-black text-sm shadow-2xl shadow-brand-500/40 transition-all">
                    <i class="fa-solid fa-bolt-lightning text-amber-300 text-base"></i>
                    <span>Daftar Akun Gratis Sekarang</span>
                </a>
            </div>
        </div>
    </section>

    <!-- 10. Modern SEO Footer -->
    <footer class="border-t border-slate-900 bg-slate-950/95 py-12 px-4 sm:px-8 text-xs text-slate-400">
        <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div class="space-y-3 md:col-span-1">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white">
                        <i class="fa-solid fa-bolt-lightning text-amber-300"></i>
                    </div>
                    <span class="font-black text-base text-white">FLASH PLATFORM</span>
                </div>
                <p class="text-[11px] text-slate-500 leading-relaxed">
                    Sistem otomasi kloning Landing Page & Google AMP berbasis AI Gemini dengan arsitektur multi-hop crawler dan pemurnian Schema.org resmi.
                </p>
            </div>

            <div class="space-y-2">
                <span class="text-xs font-bold text-white uppercase tracking-wider block">Navigasi Utama</span>
                <ul class="space-y-1.5 text-slate-400 text-xs">
                    <li><a href="/" class="hover:text-white transition-colors">Halaman Depan</a></li>
                    <li><a href="#fitur" class="hover:text-white transition-colors">Fitur Unggulan</a></li>
                    <li><a href="#simulator" class="hover:text-white transition-colors">Live Simulator</a></li>
                    <li><a href="#faq" class="hover:text-white transition-colors">Pertanyaan Umum (FAQ)</a></li>
                </ul>
            </div>

            <div class="space-y-2">
                <span class="text-xs font-bold text-white uppercase tracking-wider block">Akses Akun</span>
                <ul class="space-y-1.5 text-slate-400 text-xs">
                    <li><a href="/auth/login.php" class="hover:text-white transition-colors">Masuk ke Akun</a></li>
                    <li><a href="/auth/register.php" class="hover:text-white transition-colors">Daftar Trial 1 Hari (24 Jam)</a></li>
                    <li><a href="/user/dashboard.php" class="hover:text-white transition-colors">Member Dashboard</a></li>
                    <li><a href="/admin/dashboard.php" class="hover:text-white transition-colors">Admin Control Center</a></li>
                </ul>
            </div>

            <div class="space-y-2">
                <span class="text-xs font-bold text-white uppercase tracking-wider block">SEO & Protokol Web</span>
                <ul class="space-y-1.5 text-slate-400 text-xs font-mono">
                    <li>
                        <a href="/robots.txt" target="_blank" class="hover:text-amber-400 flex items-center gap-1.5">
                            <i class="fa-solid fa-robot text-slate-500"></i> /robots.txt
                        </a>
                    </li>
                    <li>
                        <a href="/sitemap.xml" target="_blank" class="hover:text-amber-400 flex items-center gap-1.5">
                            <i class="fa-solid fa-sitemap text-slate-500"></i> /sitemap.xml
                        </a>
                    </li>
                    <li>
                        <a href="/sitemap.php" target="_blank" class="hover:text-amber-400 flex items-center gap-1.5">
                            <i class="fa-solid fa-file-code text-slate-500"></i> /sitemap.php (Streamer)
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="max-w-7xl mx-auto pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <p>&copy; <?= date('Y') ?> FLASH System. Seluruh hak cipta dilindungi. Kompatibel dengan Google Core Web Vitals & Standar AMP 2026.</p>
            <div class="flex items-center gap-4">
                <span>Versi 2.5 (Stable)</span>
                <span>•</span>
                <span class="text-emerald-400">Sistem Online & Siap Digunakan</span>
            </div>
        </div>
    </footer>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
