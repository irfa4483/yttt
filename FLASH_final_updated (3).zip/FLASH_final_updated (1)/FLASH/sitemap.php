<?php
// FLASH/sitemap.php - Direct XML Sitemap Streamer & Dynamic Generator
require_once __DIR__ . '/includes/tunnel_helper.php';

$mode = $_GET['mode'] ?? $_GET['type'] ?? '';

// Jika diminta mode platform / projects publik
if ($mode === 'projects' || $mode === 'platform') {
    header("Content-Type: application/xml; charset=UTF-8");
    header("X-Robots-Tag: noindex, follow");

    $host = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost:8080');
    
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    
    // URL Statis Platform
    echo "  <url>\n    <loc>" . htmlspecialchars($host . '/', ENT_XML1) . "</loc>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n";
    echo "  <url>\n    <loc>" . htmlspecialchars($host . '/auth/login.php', ENT_XML1) . "</loc>\n    <changefreq>monthly</changefreq>\n    <priority>0.8</priority>\n  </url>\n";
    echo "  <url>\n    <loc>" . htmlspecialchars($host . '/auth/register.php', ENT_XML1) . "</loc>\n    <changefreq>monthly</changefreq>\n    <priority>0.8</priority>\n  </url>\n";

    // Project yang dipublikasikan (Live)
    try {
        $stmtP = $pdo->query("SELECT slug, updated_at FROM projects WHERE status = 'published' ORDER BY id DESC LIMIT 500");
        while ($p = $stmtP->fetch()) {
            $projUrl = $host . '/p.php?s=' . urlencode($p['slug']);
            $lastmod = date('Y-m-d', strtotime($p['updated_at'] ?? 'now'));
            echo "  <url>\n    <loc>" . htmlspecialchars($projUrl, ENT_XML1) . "</loc>\n    <lastmod>{$lastmod}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>0.9</priority>\n  </url>\n";
        }
    } catch (Exception $e) {}

    echo '</urlset>';
    exit;
}

$settings = get_tunnel_settings($pdo);
$filename = basename($settings['sitemap_filename'] ?? 'sitemap.xml');
$sitemapPath = __DIR__ . '/' . $filename;

if (file_exists($sitemapPath)) {
    header("Content-Type: application/xml; charset=UTF-8");
    header("X-Robots-Tag: noindex, follow");
    readfile($sitemapPath);
    exit;
} else {
    // Coba fallback ke sitemap.xml biasa jika ada
    if (file_exists(__DIR__ . '/sitemap.xml')) {
        header("Content-Type: application/xml; charset=UTF-8");
        header("X-Robots-Tag: noindex, follow");
        readfile(__DIR__ . '/sitemap.xml');
        exit;
    }
    
    // Jika belum ada file XML fisik, generate langsung sitemap platform
    header("Content-Type: application/xml; charset=UTF-8");
    $host = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost:8080');
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    echo "  <url><loc>" . htmlspecialchars($host . '/', ENT_XML1) . "</loc><changefreq>daily</changefreq><priority>1.0</priority></url>\n";
    echo '</urlset>';
    exit;
}
