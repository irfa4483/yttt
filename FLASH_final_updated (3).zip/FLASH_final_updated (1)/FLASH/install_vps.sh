#!/usr/bin/env bash
# ==============================================================================
# FLASH PLATFORM - Master VPS Installation & Auto-Deployment Script
# ==============================================================================
# Mendukung:
# - Ubuntu 20.04 / 22.04 / 24.04 LTS
# - Debian 11 / 12
# - AlmaLinux / Rocky Linux / CentOS 8 / 9
# - Integrasi Otomatis AAPanel (Opsi 2)
# ==============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

clear
echo -e "${CYAN}${BOLD}"
echo "========================================================================"
echo "          ⚡ FLASH PLATFORM - MASTER VPS INSTALLATION WIZARD ⚡         "
echo "========================================================================"
echo -e "${NC}"

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Skrip ini membutuhkan hak akses root. Jalankan dengan: sudo bash install_vps.sh${NC}"
    exit 1
fi

echo -e "Direktori Kerja: ${BOLD}$SCRIPT_DIR${NC}"
echo ""

# Menu Pilihan Mode Instalasi
echo -e "${BOLD}Pilih metode instalasi pada VPS Anda:${NC}"
echo -e "  ${CYAN}1)${NC} Standalone VPS Setup (Otomatis Nginx + PHP 8.2 + Auto-SSL Let's Encrypt)"
echo -e "  ${CYAN}2)${NC} Pasang / Perbarui SSL Domain Saja (Tinggal Masukkan Domain -> Langsung SSL HTTPS)"
echo -e "  ${CYAN}3)${NC} Konfigurasi AAPanel (Jika Anda sudah menginstal AAPanel di VPS)"
echo -e "  ${CYAN}4)${NC} Jalankan Diagnostik & Pemeriksaan Error Sistem Saja (check_system.sh)"
echo -e "  ${CYAN}5)${NC} Keluar"
echo ""
read -r -p "Masukkan pilihan Anda [1-5]: " INSTALL_MODE

case $INSTALL_MODE in
    2)
        echo -e "\n${GREEN}Menjalankan Wizard Auto-SSL Otomatis...${NC}"
        bash "$SCRIPT_DIR/setup_ssl.sh"
        exit 0
        ;;
    3)
        echo -e "\n${GREEN}Menjalankan Setup AAPanel...${NC}"
        bash "$SCRIPT_DIR/setup_aapanel.sh"
        exit 0
        ;;
    4)
        echo -e "\n${GREEN}Menjalankan Pemeriksaan Sistem...${NC}"
        bash "$SCRIPT_DIR/check_system.sh"
        exit 0
        ;;
    5)
        echo -e "Instalasi dibatalkan."
        exit 0
        ;;
    1|*)
        echo -e "\n${GREEN}Memulai Instalasi Standalone VPS...${NC}"
        ;;
esac

# ------------------------------------------------------------------------------
# STEP 1: DETEKSI SISTEM & UPDATE PACKAGES
# ------------------------------------------------------------------------------
echo -e "\n${CYAN}>>> [1/5] Memperbarui repositori paket Linux...${NC}"
if [ -f /etc/debian_version ]; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y software-properties-common curl wget unzip git ufw
elif [ -f /etc/redhat-release ]; then
    dnf install -y epel-release
    dnf update -y
    dnf install -y curl wget unzip git firewalld
fi

# ------------------------------------------------------------------------------
# STEP 2: INSTALL NGINX, PHP 8.2 & EKSTENSI
# ------------------------------------------------------------------------------
echo -e "\n${CYAN}>>> [2/5] Menginstal Nginx, PHP 8.2 dan Modul Wajib...${NC}"
if [ -f /etc/debian_version ]; then
    # Tambahkan repository Ondrej PHP jika Ubuntu/Debian
    if ! grep -q "ondrej/php" /etc/apt/sources.list /etc/apt/sources.list.d/* 2>/dev/null; then
        add-apt-repository -y ppa:ondrej/php 2>/dev/null || true
        apt-get update -y
    fi
    apt-get install -y nginx php8.2-fpm php8.2-cli php8.2-sqlite3 php8.2-curl php8.2-zip \
                       php8.2-mbstring php8.2-xml php8.2-gd php8.2-fileinfo php8.2-bcmath php8.2-intl \
                       sqlite3 curl zip unzip certbot python3-certbot-nginx
    PHP_FPM_SOCK="/run/php/php8.2-fpm.sock"
    WEB_USER="www-data"
elif [ -f /etc/redhat-release ]; then
    dnf install -y dnf-utils http://rpms.remirepo.net/enterprise/remi-release-$(rpm -E %rhel).rpm
    dnf module reset php -y
    dnf module enable php:remi-8.2 -y
    dnf install -y nginx php-fpm php-cli php-pdo php-sqlite3 php-curl php-zip php-mbstring php-xml php-gd php-bcmath php-intl sqlite curl zip unzip certbot python3-certbot-nginx
    PHP_FPM_SOCK="/run/php-fpm/www.sock"
    WEB_USER="nginx"
fi

# Pastikan PHP-FPM dan Nginx aktif
systemctl enable nginx
systemctl start nginx
systemctl enable php8.2-fpm 2>/dev/null || systemctl enable php-fpm 2>/dev/null
systemctl start php8.2-fpm 2>/dev/null || systemctl start php-fpm 2>/dev/null

# ------------------------------------------------------------------------------
# STEP 3: PENGATURAN DOMAIN & VHOST NGINX
# ------------------------------------------------------------------------------
echo -e "\n${CYAN}>>> [3/5] Pengaturan Domain & Virtual Host Nginx...${NC}"
read -r -p "Domain Anda mana? Masukkan nama domain (contoh: promo-resmi.com): " TARGET_DOMAIN
TARGET_DOMAIN=$(echo "$TARGET_DOMAIN" | tr -d ' ' | tr '[:upper:]' '[:lower:]')

if [ -z "$TARGET_DOMAIN" ]; then
    TARGET_DOMAIN="localhost"
fi

WEB_ROOT="$SCRIPT_DIR"
VHOST_CONF="/etc/nginx/sites-available/$TARGET_DOMAIN.conf"
if [ ! -d "/etc/nginx/sites-available" ]; then
    VHOST_CONF="/etc/nginx/conf.d/$TARGET_DOMAIN.conf"
fi

cat << EOF > "$VHOST_CONF"
server {
    listen 80;
    listen [::]:80;
    server_name $TARGET_DOMAIN www.$TARGET_DOMAIN;
    root $WEB_ROOT;

    index index.php index.html;
    charset utf-8;

    # 1. Routing Bersih Short-URL Landing Page: /s/slug -> /p.php?s=slug
    location ~* ^/s/([a-zA-Z0-9_\-]+)/?$ {
        rewrite ^/s/([a-zA-Z0-9_\-]+)/?$ /p.php?s=\$1 last;
    }

    # 2. Routing Statis & Fallback Index
    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    # 3. Direct execution file php
    location /p {
        try_files \$uri \$uri.php /p.php?\$query_string;
    }

    client_max_body_size 64M;

    # 4. PHP-FPM Handler
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:$PHP_FPM_SOCK;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 4 256k;
        fastcgi_busy_buffers_size 256k;
    }

    # 5. KEAMANAN TINGKAT TINGGI: Blokir Download Berkas Database & Kode Sensitif
    location ~* \.(sqlite|sqlite3|db|env|log|sh|sql|bak|git)$ {
        deny all;
        return 404;
    }

    location ~* ^/(config|tunnel_templates|scratch)/ {
        deny all;
        return 404;
    }

    location = /robots.txt {
        allow all;
        log_not_found off;
        access_log off;
    }

    location = /sitemap.xml {
        allow all;
        log_not_found off;
        access_log off;
    }
}
EOF

# Aktifkan site jika di Debian/Ubuntu
if [ -d "/etc/nginx/sites-enabled" ]; then
    ln -sf "$VHOST_CONF" "/etc/nginx/sites-enabled/$TARGET_DOMAIN.conf"
fi

# Uji dan reload Nginx
nginx -t && systemctl reload nginx

# ------------------------------------------------------------------------------
# STEP 4: PERMISSIONS & SQLITE LOCKING
# ------------------------------------------------------------------------------
echo -e "\n${CYAN}>>> [4/5] Mengatur Hak Akses & Izin Berkas SQLite...${NC}"
mkdir -p "$SCRIPT_DIR/cdn/templates" "$SCRIPT_DIR/uploads" "$SCRIPT_DIR/exports"
chown -R $WEB_USER:$WEB_USER "$SCRIPT_DIR"
chmod -R 775 "$SCRIPT_DIR/cdn" "$SCRIPT_DIR/uploads" "$SCRIPT_DIR/exports"
chmod 775 "$SCRIPT_DIR"
if [ -f "$SCRIPT_DIR/database.sqlite" ]; then
    chmod 664 "$SCRIPT_DIR/database.sqlite"
fi

# ------------------------------------------------------------------------------
# STEP 5: SSL CERTIFICATE & DIAGNOSTIK OTOMATIS
# ------------------------------------------------------------------------------
echo -e "\n${CYAN}>>> [5/5] Menerbitkan Sertifikat SSL Let's Encrypt Otomatis...${NC}"
if [ "$TARGET_DOMAIN" != "localhost" ]; then
    echo -e "  Memasang sertifikat SSL (HTTPS) otomatis untuk domain: ${BOLD}$TARGET_DOMAIN${NC}..."
    if [ -f "$SCRIPT_DIR/setup_ssl.sh" ]; then
        chmod +x "$SCRIPT_DIR/setup_ssl.sh"
        bash "$SCRIPT_DIR/setup_ssl.sh" "$TARGET_DOMAIN"
    else
        certbot --nginx -d "$TARGET_DOMAIN" -d "www.$TARGET_DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email --redirect --keep-until-expiring 2>/dev/null || \
        certbot --nginx -d "$TARGET_DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email --redirect --keep-until-expiring 2>/dev/null || true
    fi
fi

# Jalankan pemeriksaan akhir
if [ -f "$SCRIPT_DIR/check_system.sh" ]; then
    chmod +x "$SCRIPT_DIR/check_system.sh"
    bash "$SCRIPT_DIR/check_system.sh"
fi

PROTOCOL="http"
if [ "$TARGET_DOMAIN" != "localhost" ]; then
    PROTOCOL="https"
fi

echo -e "\n${GREEN}${BOLD}========================================================================${NC}"
echo -e "${GREEN}${BOLD}    ✓ INSTALASI & DEPLOYMENT FLASH DI VPS SELESAI!                     ${NC}"
echo -e "${GREEN}${BOLD}========================================================================${NC}"
echo -e "Akses Platform Anda di Browser:"
echo -e "  - Beranda Utama    : ${BOLD}$PROTOCOL://$TARGET_DOMAIN${NC}"
echo -e "  - Diagnostik Server: ${BOLD}$PROTOCOL://$TARGET_DOMAIN/check.php${NC}"
echo -e "  - Login Admin      : ${BOLD}$PROTOCOL://$TARGET_DOMAIN/auth/login.php${NC}"
echo -e "    * Email Default  : ${BOLD}admin@example.com${NC}"
echo -e "    * Password       : ${BOLD}admin123${NC}"
echo -e "${CYAN}========================================================================${NC}"
