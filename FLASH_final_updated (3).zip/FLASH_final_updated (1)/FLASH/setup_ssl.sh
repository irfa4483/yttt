#!/usr/bin/env bash
# ==============================================================================
# FLASH PLATFORM - Instant Automated SSL (Let's Encrypt / Certbot) Setup
# ==============================================================================
# Penggunaan:
#   sudo bash setup_ssl.sh
#   ATAU:
#   sudo bash setup_ssl.sh namadomain.com
# ==============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

clear
echo -e "${CYAN}${BOLD}"
echo "========================================================================"
echo "          🔒 FLASH PLATFORM - INSTANT AUTO-SSL WIZARD (HTTPS) 🔒        "
echo "========================================================================"
echo -e "${NC}"

# 1. Validasi Hak Akses Root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Skrip ini membutuhkan hak akses root. Jalankan dengan: sudo bash setup_ssl.sh${NC}"
    exit 1
fi

# 2. Tangkap Domain dari Argumen atau Prompt Input
TARGET_DOMAIN="$1"
if [ -z "$TARGET_DOMAIN" ]; then
    echo -e "${BOLD}Cukup masukkan nama domain Anda, skrip akan menerbitkan & memasang SSL HTTPS secara otomatis.${NC}"
    read -r -p "Domain Anda mana? Masukkan nama domain (contoh: domain-anda.com): " TARGET_DOMAIN
fi

# Bersihkan karakter & format domain
TARGET_DOMAIN=$(echo "$TARGET_DOMAIN" | tr -d ' ' | tr '[:upper:]' '[:lower:]' | sed 's~http[s]*://~~g' | sed 's~/.*~~g')

if [ -z "$TARGET_DOMAIN" ] || [ "$TARGET_DOMAIN" = "localhost" ]; then
    echo -e "${RED}[ERROR] Nama domain tidak valid! Pastikan Anda memasukkan domain publik (bukan localhost).${NC}"
    exit 1
fi

echo -e "\n${CYAN}>>> [1/4] Memeriksa & Menginstal Paket Certbot Nginx...${NC}"

# 3. Pastikan Nginx, Certbot & Plugin Nginx terinstal
if ! command -v certbot &>/dev/null || ! nginx -v &>/dev/null; then
    echo -e "  Menginstal dependensi Nginx & Certbot..."
    if [ -f /etc/debian_version ]; then
        export DEBIAN_FRONTEND=noninteractive
        apt-get update -y
        apt-get install -y certbot python3-certbot-nginx nginx curl
    elif [ -f /etc/redhat-release ]; then
        dnf install -y epel-release
        dnf install -y certbot python3-certbot-nginx nginx curl
    fi
else
    echo -e "  [${GREEN}OK${NC}] Nginx dan Certbot sudah terpasang."
fi

# 4. Deteksi Socket PHP-FPM
PHP_FPM_SOCK=""
for sock in /run/php/php8.2-fpm.sock /run/php/php8.3-fpm.sock /run/php/php8.1-fpm.sock /run/php-fpm/www.sock /tmp/php-cgi-82.sock /tmp/php-cgi-81.sock /run/php/php-fpm.sock; do
    if [ -S "$sock" ]; then
        PHP_FPM_SOCK="$sock"
        break
    fi
done

# 5. Konfigurasi Virtual Host Nginx jika belum ada
echo -e "\n${CYAN}>>> [2/4] Menyiapkan Virtual Host Nginx untuk $TARGET_DOMAIN...${NC}"

VHOST_CONF=""
if [ -d "/etc/nginx/sites-available" ]; then
    VHOST_CONF="/etc/nginx/sites-available/$TARGET_DOMAIN.conf"
    LINK_CONF="/etc/nginx/sites-enabled/$TARGET_DOMAIN.conf"
elif [ -d "/www/server/panel/vhost/nginx" ]; then
    VHOST_CONF="/www/server/panel/vhost/nginx/$TARGET_DOMAIN.conf"
    LINK_CONF=""
else
    mkdir -p /etc/nginx/conf.d
    VHOST_CONF="/etc/nginx/conf.d/$TARGET_DOMAIN.conf"
    LINK_CONF=""
fi

if [ ! -f "$VHOST_CONF" ]; then
    echo -e "  Membuat konfigurasi vhost Nginx baru di: ${BOLD}$VHOST_CONF${NC}"
    cat << EOF > "$VHOST_CONF"
server {
    listen 80;
    listen [::]:80;
    server_name $TARGET_DOMAIN www.$TARGET_DOMAIN;
    root $SCRIPT_DIR;

    index index.php index.html;
    charset utf-8;

    # Routing Bersih Short-URL Landing Page
    location ~* ^/s/([a-zA-Z0-9_\-]+)/?$ {
        rewrite ^/s/([a-zA-Z0-9_\-]+)/?$ /p.php?s=\$1 last;
    }

    # Routing Statis & Fallback Index
    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    # Direct execution file php
    location /p {
        try_files \$uri \$uri.php /p.php?\$query_string;
    }

    client_max_body_size 64M;

    # PHP Handler jika socket ditemukan
EOF

    if [ -n "$PHP_FPM_SOCK" ]; then
        cat << EOF >> "$VHOST_CONF"
    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:$PHP_FPM_SOCK;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_read_timeout 300;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 4 256k;
        fastcgi_busy_buffers_size 256k;
    }
EOF
    fi

    cat << 'EOF' >> "$VHOST_CONF"
    # Keamanan: Blokir akses berkas database & konfigurasi
    location ~* \.(sqlite|sqlite3|db|env|log|sh|sql|bak|git)$ {
        deny all;
        return 404;
    }

    location ~* ^/(config|tunnel_templates|scratch)/ {
        deny all;
        return 404;
    }

    location = /robots.txt {
        allow all;
        log_not_found off;
        access_log off;
    }

    location = /sitemap.xml {
        allow all;
        log_not_found off;
        access_log off;
    }
}
EOF

    if [ -n "$LINK_CONF" ] && [ -d "/etc/nginx/sites-enabled" ]; then
        ln -sf "$VHOST_CONF" "$LINK_CONF"
    fi
else
    echo -e "  [${GREEN}OK${NC}] File virtual host Nginx sudah ada di: ${BOLD}$VHOST_CONF${NC}"
fi

# Pastikan Nginx syntax OK sebelum minta sertifikat
nginx -t >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo -e "${YELLOW}[WARN] Syntax Nginx ada catatan, mencoba me-reload...${NC}"
fi
systemctl reload nginx 2>/dev/null || nginx -s reload 2>/dev/null || true

# 6. Menerbitkan Sertifikat SSL Let's Encrypt Otomatis
echo -e "\n${CYAN}>>> [3/4] Menerbitkan Sertifikat SSL Let's Encrypt Otomatis...${NC}"
echo -e "  Menghubungi server Let's Encrypt CA untuk domain: ${BOLD}$TARGET_DOMAIN${NC}..."

# Coba terbitkan untuk domain dan www.domain
SSL_SUCCESS=0
certbot --nginx -d "$TARGET_DOMAIN" -d "www.$TARGET_DOMAIN" \
        --non-interactive --agree-tos --register-unsafely-without-email \
        --redirect --keep-until-expiring >/tmp/certbot_flash.log 2>&1

if [ $? -eq 0 ]; then
    SSL_SUCCESS=1
else
    # Jika gagal (misal www belum diarahkan ke DNS), fallback hanya ke root domain
    echo -e "  [${YELLOW}INFO${NC}] Mencoba penerbitan SSL untuk root domain ${BOLD}$TARGET_DOMAIN${NC} (single)..."
    certbot --nginx -d "$TARGET_DOMAIN" \
            --non-interactive --agree-tos --register-unsafely-without-email \
            --redirect --keep-until-expiring >>/tmp/certbot_flash.log 2>&1
    if [ $? -eq 0 ]; then
        SSL_SUCCESS=1
    fi
fi

# 7. Hasil & Verifikasi Akhir
echo -e "\n${CYAN}>>> [4/4] Memeriksa Status Akhir SSL & Web Server...${NC}"
nginx -t >/dev/null 2>&1 && (systemctl reload nginx 2>/dev/null || nginx -s reload 2>/dev/null || true)

# Setup cron auto renewal jika belum ada
if ! crontab -l 2>/dev/null | grep -q "certbot renew"; then
    (crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet --post-hook 'systemctl reload nginx || nginx -s reload'") | crontab - 2>/dev/null || true
    echo -e "  [${GREEN}OK${NC}] Jadwal auto-renewal SSL aktif setiap hari pukul 03:00 WIB."
fi

if [ $SSL_SUCCESS -eq 1 ]; then
    echo -e "\n${GREEN}${BOLD}========================================================================${NC}"
    echo -e "${GREEN}${BOLD}    ✓ SERTIFIKAT SSL (HTTPS) BERHASIL DITERBITKAN & AKTIF!             ${NC}"
    echo -e "${GREEN}${BOLD}========================================================================${NC}"
    echo -e "Domain Anda kini telah dilindungi enkripsi SSL kelas bank:"
    echo -e "  🔒 URL Website Resmi : ${BOLD}https://$TARGET_DOMAIN${NC}"
    echo -e "  🔒 Diagnostik Server : ${BOLD}https://$TARGET_DOMAIN/check.php${NC}"
    echo -e "  🔒 Login Dashboard   : ${BOLD}https://$TARGET_DOMAIN/auth/login.php${NC}"
    echo -e "  ✓ Port 80 (HTTP) otomatis dialihkan ke Port 443 (HTTPS) secara permanen (301 Redirect)."
    echo -e "${CYAN}========================================================================${NC}"
else
    echo -e "\n${YELLOW}${BOLD}========================================================================${NC}"
    echo -e "${YELLOW}${BOLD}    ! CATATAN PENERBITAN SSL                                            ${NC}"
    echo -e "${YELLOW}${BOLD}========================================================================${NC}"
    echo -e "Certbot belum berhasil memvalidasi domain. Kemungkinan penyebab:"
    echo -e "1. ${BOLD}DNS A Record${NC} domain ${CYAN}$TARGET_DOMAIN${NC} belum diarahkan ke IP VPS ini."
    echo -e "2. DNS baru saja diubah dan masih dalam masa propagasi (biasanya butuh 5-15 menit)."
    echo -e "3. Port 80 / 443 terblokir oleh firewall hosting (buka port 80 & 443 di panel VPS Anda)."
    echo -e ""
    echo -e "Log detail certbot dapat dilihat di: ${BOLD}/tmp/certbot_flash.log${NC}"
    echo -e "Jika DNS sudah aktif, jalankan ulang kapan saja dengan:"
    echo -e "  ${BOLD}sudo bash setup_ssl.sh $TARGET_DOMAIN${NC}"
    echo -e "${CYAN}========================================================================${NC}"
fi
