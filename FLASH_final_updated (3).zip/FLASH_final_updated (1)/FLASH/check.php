<?php
// FLASH/check.php - System Environment, Permissions & Health Inspector
header('Content-Type: text/html; charset=UTF-8');

$requirements = [
    'php_version' => [
        'name' => 'Versi PHP (Minimal 7.4, Rekomendasi 8.1 - 8.4)',
        'pass' => version_compare(PHP_VERSION, '7.4.0', '>='),
        'current' => PHP_VERSION,
        'recommendation' => 'Gunakan PHP 8.1, 8.2, 8.3, atau 8.4.'
    ],
    'pdo_sqlite' => [
        'name' => 'Ekstensi PHP: PDO SQLite (pdo_sqlite)',
        'pass' => extension_loaded('pdo_sqlite'),
        'current' => extension_loaded('pdo_sqlite') ? 'Aktif' : 'Tidak Ditemukan',
        'recommendation' => 'Install paket php-sqlite3 atau aktifkan extension pdo_sqlite di panel.'
    ],
    'sqlite3' => [
        'name' => 'Ekstensi PHP: SQLite3 Driver',
        'pass' => extension_loaded('sqlite3') || extension_loaded('pdo_sqlite'),
        'current' => extension_loaded('sqlite3') ? 'Aktif' : 'Fallback via PDO',
        'recommendation' => 'Pastikan ekstensi SQLite3 aktif.'
    ],
    'curl' => [
        'name' => 'Ekstensi PHP: cURL (Untuk Clone URL Target & API)',
        'pass' => extension_loaded('curl'),
        'current' => extension_loaded('curl') ? 'Aktif' : 'Tidak Ditemukan',
        'recommendation' => 'Wajib untuk mendeteksi & mengkloning URL. Install php-curl.'
    ],
    'zip' => [
        'name' => 'Ekstensi PHP: ZipArchive (Untuk Export ZIP Clean Package)',
        'pass' => class_exists('ZipArchive'),
        'current' => class_exists('ZipArchive') ? 'Aktif' : 'Tidak Ditemukan',
        'recommendation' => 'Install php-zip agar fitur ekspor ZIP landing page berfungsi.'
    ],
    'openssl' => [
        'name' => 'Ekstensi PHP: OpenSSL (Koneksi Aman HTTPS & Enkripsi)',
        'pass' => extension_loaded('openssl'),
        'current' => extension_loaded('openssl') ? 'Aktif' : 'Tidak Ditemukan',
        'recommendation' => 'Aktifkan php-openssl.'
    ],
    'mbstring' => [
        'name' => 'Ekstensi PHP: Multibyte String (mbstring)',
        'pass' => extension_loaded('mbstring'),
        'current' => extension_loaded('mbstring') ? 'Aktif' : 'Tidak Ditemukan',
        'recommendation' => 'Wajib untuk manipulasi teks brand UTF-8. Install php-mbstring.'
    ],
    'fileinfo' => [
        'name' => 'Ekstensi PHP: Fileinfo (Deteksi MIME-Type Media & Gambar)',
        'pass' => extension_loaded('fileinfo'),
        'current' => extension_loaded('fileinfo') ? 'Aktif' : 'Tidak Ditemukan',
        'recommendation' => 'Aktifkan ekstensi php-fileinfo.'
    ],
    'gd' => [
        'name' => 'Ekstensi PHP: GD Graphics Library (Resize & Watermark Gambar)',
        'pass' => extension_loaded('gd'),
        'current' => extension_loaded('gd') ? 'Aktif' : 'Tidak Ditemukan (Opsional)',
        'recommendation' => 'Disarankan untuk manipulasi aset gambar. Install php-gd.'
    ]
];

// Periksa Izin Folder & Database
$baseDir = __DIR__;
$dbFile = $baseDir . '/database.sqlite';
$cdnDir = $baseDir . '/cdn/templates';
$uploadDir = $baseDir . '/uploads';
$exportDir = $baseDir . '/exports';

// Pastikan folder ada
if (!is_dir($cdnDir)) @mkdir($cdnDir, 0775, true);
if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);
if (!is_dir($exportDir)) @mkdir($exportDir, 0775, true);

$permissions = [
    'db_dir' => [
        'name' => 'Izin Tulis Direktori Root (Untuk SQLite Journal Lock)',
        'path' => $baseDir,
        'pass' => is_writable($baseDir),
        'current' => is_writable($baseDir) ? 'Bisa Ditulis (Writable)' : 'Read-Only (Harus chmod 775)',
        'recommendation' => 'Jalankan: chmod 775 ' . $baseDir . ' && chown -R www:www ' . $baseDir
    ],
    'db_file' => [
        'name' => 'Izin Tulis File Database (database.sqlite)',
        'path' => $dbFile,
        'pass' => file_exists($dbFile) ? is_writable($dbFile) : is_writable($baseDir),
        'current' => file_exists($dbFile) ? (is_writable($dbFile) ? 'Bisa Ditulis (Writable)' : 'Terkunci (Read-Only)') : 'Belum Dibuat (Otomatis dibuat saat run)',
        'recommendation' => 'Jalankan: chmod 664 ' . $dbFile . ' && chown www:www ' . $dbFile
    ],
    'cdn_templates' => [
        'name' => 'Izin Tulis Folder Template (cdn/templates/)',
        'path' => $cdnDir,
        'pass' => is_writable($cdnDir),
        'current' => is_writable($cdnDir) ? 'Bisa Ditulis (Writable)' : 'Read-Only',
        'recommendation' => 'Jalankan: chmod 775 ' . $cdnDir . ' && chown -R www:www ' . $cdnDir
    ],
    'exports_dir' => [
        'name' => 'Izin Tulis Folder Export ZIP (exports/)',
        'path' => $exportDir,
        'pass' => is_writable($exportDir),
        'current' => is_writable($exportDir) ? 'Bisa Ditulis (Writable)' : 'Read-Only',
        'recommendation' => 'Jalankan: chmod 775 ' . $exportDir . ' && chown -R www:www ' . $exportDir
    ]
];

// Uji Koneksi Database Nyata
$dbTestPass = false;
$dbErrorMsg = '';
try {
    $testPdo = new PDO("sqlite:" . $dbFile);
    $testPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $testPdo->query("SELECT 1");
    $dbTestPass = true;
} catch (Exception $e) {
    $dbErrorMsg = $e->getMessage();
}

// Uji Koneksi Internet Outgoing cURL
$curlTestPass = false;
$curlLatency = 0;
if (extension_loaded('curl')) {
    $startTime = microtime(true);
    $ch = curl_init('https://www.google.com');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res !== false && $httpCode > 0) {
        $curlTestPass = true;
        $curlLatency = round((microtime(true) - $startTime) * 1000);
    }
}

// Hitung skor kelayakan sistem
$totalChecks = count($requirements) + count($permissions) + 2;
$passedChecks = 0;
foreach ($requirements as $r) if ($r['pass']) $passedChecks++;
foreach ($permissions as $p) if ($p['pass']) $passedChecks++;
if ($dbTestPass) $passedChecks++;
if ($curlTestPass) $passedChecks++;

$isSystemHealthy = ($passedChecks >= ($totalChecks - 1)); // toleransi GD opsional
?>
<!DOCTYPE html>
<html lang="id" class="h-full bg-slate-950 text-slate-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemeriksaan Sistem VPS & AAPanel - FLASH Platform</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .glass-card {
            background: rgba(15, 23, 42, 0.75);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
    </style>
</head>
<body class="min-h-full p-4 sm:p-8 bg-slate-950 text-slate-100 font-sans">
    <div class="max-w-4xl mx-auto space-y-6">
        
        <!-- Header -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div class="flex items-center gap-3.5">
                <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25">
                    <i class="fa-solid fa-stethoscope text-2xl text-amber-300"></i>
                </div>
                <div>
                    <h1 class="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                        Pemeriksaan Lingkungan Server & VPS
                    </h1>
                    <p class="text-xs text-slate-400">Diagnostik mandiri modul PHP, izin folder SQLite, cURL, dan konfigurasi AAPanel</p>
                </div>
            </div>
            <div>
                <a href="/" class="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 transition-all">
                    <i class="fa-solid fa-house text-amber-400"></i> Kembali ke Beranda
                </a>
            </div>
        </div>

        <!-- Status Summary Card -->
        <div class="glass-card p-6 rounded-3xl border <?= $isSystemHealthy ? 'border-emerald-500/40 bg-emerald-500/5' : 'border-rose-500/40 bg-rose-500/5' ?> shadow-xl">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                    <div class="w-12 h-12 rounded-2xl <?= $isSystemHealthy ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300' ?> flex items-center justify-center text-2xl flex-shrink-0">
                        <i class="fa-solid <?= $isSystemHealthy ? 'fa-circle-check' : 'fa-triangle-exclamation' ?>"></i>
                    </div>
                    <div>
                        <h2 class="text-lg font-bold text-white">
                            <?= $isSystemHealthy ? 'Sistem Siap Digunakan Secara Maksimal' : 'Ditemukan Masalah Konfigurasi Pada Server' ?>
                        </h2>
                        <p class="text-xs text-slate-400 mt-0.5">
                            <?= $passedChecks ?> dari <?= $totalChecks ?> komponen lulus uji kelayakan.
                        </p>
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <span class="px-3.5 py-1.5 rounded-full text-xs font-extrabold uppercase <?= $isSystemHealthy ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30' ?>">
                        <?= $isSystemHealthy ? '100% OPERASIONAL' : 'BUTUH PENYESUAIAN' ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- 1. Persyaratan Ekstensi PHP -->
        <div class="glass-card rounded-3xl border border-slate-800 overflow-hidden shadow-xl">
            <div class="px-6 py-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
                <h3 class="text-sm font-bold text-white flex items-center gap-2">
                    <i class="fa-brands fa-php text-indigo-400 text-lg"></i> Status Ekstensi PHP & Versi
                </h3>
                <span class="text-xs text-slate-400 font-mono">PHP <?= PHP_VERSION ?> (<?= PHP_SAPI ?>)</span>
            </div>
            <div class="divide-y divide-slate-800/60 text-xs">
                <?php foreach ($requirements as $key => $item): ?>
                    <div class="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-900/30 transition-colors">
                        <div class="space-y-0.5">
                            <span class="font-bold text-slate-200 block"><?= $item['name'] ?></span>
                            <?php if (!$item['pass']): ?>
                                <span class="text-[11px] text-amber-400 block font-mono"><i class="fa-solid fa-arrow-right text-[9px]"></i> <?= $item['recommendation'] ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="flex items-center gap-3">
                            <span class="font-mono text-slate-400 text-[11px]"><?= $item['current'] ?></span>
                            <?php if ($item['pass']): ?>
                                <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                                    <i class="fa-solid fa-check mr-1"></i> PASS
                                </span>
                            <?php else: ?>
                                <span class="px-2.5 py-0.5 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[10px] font-bold">
                                    <i class="fa-solid fa-xmark mr-1"></i> GAGAL
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 2. Izin Folder & File Database SQLite -->
        <div class="glass-card rounded-3xl border border-slate-800 overflow-hidden shadow-xl">
            <div class="px-6 py-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
                <h3 class="text-sm font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-folder-tree text-amber-400"></i> Izin File & Direktori (Permissions)
                </h3>
                <span class="text-xs text-slate-400 font-mono">User Web Server: <?= (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) ? (posix_getpwuid(posix_geteuid())['name'] ?? 'www') : 'Web Daemon' ?></span>
            </div>
            <div class="divide-y divide-slate-800/60 text-xs">
                <?php foreach ($permissions as $key => $p): ?>
                    <div class="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-900/30 transition-colors">
                        <div class="space-y-0.5">
                            <span class="font-bold text-slate-200 block"><?= $p['name'] ?></span>
                            <span class="text-[10px] text-slate-500 font-mono block"><?= $p['path'] ?></span>
                            <?php if (!$p['pass']): ?>
                                <span class="text-[11px] text-amber-400 block font-mono"><i class="fa-solid fa-terminal text-[9px]"></i> <?= $p['recommendation'] ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="flex items-center gap-3">
                            <span class="font-mono text-slate-400 text-[11px]"><?= $p['current'] ?></span>
                            <?php if ($p['pass']): ?>
                                <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                                    <i class="fa-solid fa-check mr-1"></i> PASS
                                </span>
                            <?php else: ?>
                                <span class="px-2.5 py-0.5 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[10px] font-bold">
                                    <i class="fa-solid fa-xmark mr-1"></i> PERLU PERBAIKAN
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 3. Tes Konektivitas Database & Jaringan Outgoing -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div class="glass-card p-5 rounded-3xl border border-slate-800 space-y-3">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-database text-brand-400"></i> Tes Koneksi SQLite Langsung
                    </span>
                    <?php if ($dbTestPass): ?>
                        <span class="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold">BERHASIL</span>
                    <?php else: ?>
                        <span class="px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-300 text-[10px] font-bold">ERROR</span>
                    <?php endif; ?>
                </div>
                <p class="text-xs text-slate-400">
                    <?= $dbTestPass ? 'Kueri PDO SQLite berhasil dijalankan tanpa kendala timeout atau file lock.' : ('Gagal menghubungkan SQLite: ' . htmlspecialchars($dbErrorMsg)) ?>
                </p>
            </div>

            <div class="glass-card p-5 rounded-3xl border border-slate-800 space-y-3">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-globe text-emerald-400"></i> Tes Outgoing cURL (Crawler)
                    </span>
                    <?php if ($curlTestPass): ?>
                        <span class="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold"><?= $curlLatency ?> ms</span>
                    <?php else: ?>
                        <span class="px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-300 text-[10px] font-bold">GAGAL KONEKSI</span>
                    <?php endif; ?>
                </div>
                <p class="text-xs text-slate-400">
                    <?= $curlTestPass ? 'Server dapat melakukan scraping URL target & menghubungi Google Gemini API secara lancar.' : 'Server memblokir koneksi cURL keluar (periksa firewall atau DNS VPS).' ?>
                </p>
            </div>
        </div>

        <!-- Panduan Singkat AAPanel -->
        <div class="glass-card p-6 rounded-3xl border border-indigo-500/30 bg-indigo-500/5 space-y-3">
            <h4 class="text-sm font-bold text-indigo-300 flex items-center gap-2">
                <i class="fa-solid fa-lightbulb text-amber-400"></i> Perintah 1-Klik di Terminal VPS (Untuk Perbaikan Izin AAPanel)
            </h4>
            <p class="text-xs text-slate-300 leading-relaxed">
                Jika ada izin folder yang merah, jalankan perintah ini di Terminal VPS / SSH:
            </p>
            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs text-amber-300 overflow-x-auto select-all">
                chown -R www:www <?= $baseDir ?> && chmod -R 775 <?= $baseDir ?>/cdn <?= $baseDir ?>/uploads <?= $baseDir ?>/exports && chmod 664 <?= $baseDir ?>/database.sqlite
            </div>
        </div>

    </div>
</body>
</html>
