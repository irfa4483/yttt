<?php
// includes/auth.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pdo = require __DIR__ . '/../config/database.php';

/**
 * Hasilkan Token CSRF untuk keamanan form
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verifikasi Token CSRF
 */
function verify_csrf_token($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Sanitasi string untuk output HTML aman (Mencegah XSS)
 */
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Cek apakah pengguna sudah login
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Ambil data user yang sedang login dari database
 */
function current_user() {
    global $pdo;
    if (!is_logged_in()) {
        return null;
    }

    static $cachedUser = null;
    if ($cachedUser !== null) {
        return $cachedUser;
    }

    $stmt = $pdo->prepare("SELECT id, name, email, role, created_at, trial_expires_at FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $cachedUser = $stmt->fetch();
    return $cachedUser;
}

/**
 * Cek apakah masa trial user masih aktif (7 hari / 1 minggu gratis)
 * Admin selalu aktif selamanya.
 */
function is_trial_active($user = null) {
    if (!$user) {
        $user = current_user();
    }
    if (!$user) return false;
    if ($user['role'] === 'admin') return true;

    if (empty($user['trial_expires_at'])) {
        return false;
    }

    $expires = strtotime($user['trial_expires_at']);
    return ($expires > time());
}

/**
 * Mendapatkan sisa waktu trial (dalam hari, jam, atau menit)
 */
function get_trial_time_remaining($user = null) {
    if (!$user) {
        $user = current_user();
    }
    if (!$user || $user['role'] === 'admin') return 'Unlimited (Admin)';
    if (empty($user['trial_expires_at'])) return 'Expired';

    $diff = strtotime($user['trial_expires_at']) - time();
    if ($diff <= 0) return 'Expired';

    $days = floor($diff / 86400);
    $hours = floor(($diff % 86400) / 3600);
    $minutes = floor(($diff % 3600) / 60);

    if ($days > 0) {
        return "{$days} hari {$hours} jam";
    }
    if ($hours > 0) {
        return "{$hours} jam {$minutes} menit";
    }
    return "{$minutes} menit";
}

/**
 * Cek dan hitung kuota kloning user berdasarkan Paket / Role
 */
function get_user_quota_info($user = null) {
    global $pdo;
    if (!$user) {
        $user = current_user();
    }
    if (!$user) return null;

    $role = $user['role'] ?? 'user';
    $isVipOrAdmin = ($role === 'admin' || $role === 'vip' || $role === 'vpro');

    // Hitung pemakaian kloning 30 hari terakhir
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM clone_logs WHERE user_id = ? AND created_at >= datetime('now', '-30 days')");
    $stmt->execute([$user['id']]);
    $usedClones = (int)$stmt->fetchColumn();

    // Hitung jumlah project pengguna
    $stmtProj = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE user_id = ?");
    $stmtProj->execute([$user['id']]);
    $totalProjects = (int)$stmtProj->fetchColumn();

    if ($isVipOrAdmin) {
        $planTitle = 'VIP Ultra-Rank';
        if ($role === 'admin') $planTitle = 'Administrator';
        if ($role === 'vpro') $planTitle = 'VPro Sultan';

        return [
            'is_vip' => true,
            'role' => $role,
            'plan_name' => $planTitle,
            'max_clones' => -1,
            'used_clones' => $usedClones,
            'remaining_clones' => 'Unlimited',
            'can_clone' => true,
            'max_projects' => -1,
            'total_projects' => $totalProjects
        ];
    }

    // Role Trial 7 Hari (Berbayar Rp 150.000)
    if ($role === 'trial7') {
        $maxClones = 60;
        $maxProjects = 30;
        $remaining = max(0, $maxClones - $usedClones);
        return [
            'is_vip' => false,
            'role' => $role,
            'plan_name' => 'Paket 7 Hari (Rp 150.000)',
            'max_clones' => $maxClones,
            'used_clones' => $usedClones,
            'remaining_clones' => $remaining,
            'can_clone' => ($remaining > 0),
            'max_projects' => $maxProjects,
            'total_projects' => $totalProjects
        ];
    }

    // Role Lite 2 Minggu (Berbayar Rp 350.000)
    if ($role === 'lite') {
        $maxClones = 150;
        $maxProjects = 75;
        $remaining = max(0, $maxClones - $usedClones);
        return [
            'is_vip' => false,
            'role' => $role,
            'plan_name' => 'Paket Lite 2 Minggu (Rp 350.000)',
            'max_clones' => $maxClones,
            'used_clones' => $usedClones,
            'remaining_clones' => $remaining,
            'can_clone' => ($remaining > 0),
            'max_projects' => $maxProjects,
            'total_projects' => $totalProjects
        ];
    }

    // Role Elite (Berbayar Rp 550.000)
    if ($role === 'elite') {
        $maxClones = 300;
        $maxProjects = 150;
        $remaining = max(0, $maxClones - $usedClones);
        return [
            'is_vip' => false,
            'role' => $role,
            'plan_name' => 'Paket Elite (Rp 550.000)',
            'max_clones' => $maxClones,
            'used_clones' => $usedClones,
            'remaining_clones' => $remaining,
            'can_clone' => ($remaining > 0),
            'max_projects' => $maxProjects,
            'total_projects' => $totalProjects
        ];
    }

    // Role Premium (Berbayar Rp 1.000.000)
    if ($role === 'premium') {
        $maxClones = 600;
        $maxProjects = 300;
        $remaining = max(0, $maxClones - $usedClones);
        return [
            'is_vip' => false,
            'role' => $role,
            'plan_name' => 'Paket Premium (Rp 1.000.000)',
            'max_clones' => $maxClones,
            'used_clones' => $usedClones,
            'remaining_clones' => $remaining,
            'can_clone' => ($remaining > 0),
            'max_projects' => $maxProjects,
            'total_projects' => $totalProjects
        ];
    }

    // Role Diamond (Berbayar Rp 2.000.000)
    if ($role === 'diamond') {
        $maxClones = 1200;
        $maxProjects = 600;
        $remaining = max(0, $maxClones - $usedClones);
        return [
            'is_vip' => false,
            'role' => $role,
            'plan_name' => 'Paket Diamond (Rp 2.000.000)',
            'max_clones' => $maxClones,
            'used_clones' => $usedClones,
            'remaining_clones' => $remaining,
            'can_clone' => ($remaining > 0),
            'max_projects' => $maxProjects,
            'total_projects' => $totalProjects
        ];
    }

    $isTrial = is_trial_active($user);
    $maxClones = $isTrial ? 10 : 0;
    $maxProjects = $isTrial ? 3 : 0;
    $remaining = max(0, $maxClones - $usedClones);

    return [
        'is_vip' => false,
        'role' => $role,
        'plan_name' => ($isTrial ? 'Free Trial (1 Hari Gratis)' : 'Masa Trial Habis'),
        'max_clones' => $maxClones,
        'used_clones' => $usedClones,
        'remaining_clones' => $remaining,
        'can_clone' => ($isTrial && $remaining > 0),
        'max_projects' => $maxProjects,
        'total_projects' => $totalProjects
    ];
}

/**
 * Wajibkan login untuk mengakses halaman
 */
function require_login() {
    if (!is_logged_in()) {
        set_flash('error', 'Silakan login terlebih dahulu untuk mengakses halaman ini.');
        header('Location: /auth/login.php');
        exit;
    }
}

/**
 * Wajibkan role tertentu (misal: 'admin')
 */
function require_role($requiredRole) {
    require_login();
    $user = current_user();

    if (!$user || $user['role'] !== $requiredRole) {
        set_flash('error', 'Anda tidak memiliki hak akses (Role) untuk membuka halaman tersebut.');
        if ($user && $user['role'] === 'admin') {
            header('Location: /admin/dashboard.php');
        } else {
            header('Location: /user/dashboard.php');
        }
        exit;
    }
}

/**
 * Helper khusus memvalidasi role administrator
 */
function require_admin() {
    require_role('admin');
}

/**
 * Set pesan kilat Toast Notification
 * @param string $type ('success', 'error', 'warning', 'info')
 * @param string $message
 */
function set_flash($type, $message) {
    $_SESSION['toasts'][] = [
        'id' => uniqid(),
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Ambil pesan kilat spesifik berdasarkan type
 */
function get_flash($key) {
    if (!isset($_SESSION['toasts']) || !is_array($_SESSION['toasts'])) {
        return null;
    }
    foreach ($_SESSION['toasts'] as $index => $toast) {
        if ($toast['type'] === $key) {
            $msg = $toast['message'];
            unset($_SESSION['toasts'][$index]);
            $_SESSION['toasts'] = array_values($_SESSION['toasts']);
            return $msg;
        }
    }
    return null;
}

/**
 * Ambil seluruh daftar toast lalu hapus dari session
 */
function get_flashes() {
    $toasts = $_SESSION['toasts'] ?? [];
    unset($_SESSION['toasts']);
    return $toasts;
}

