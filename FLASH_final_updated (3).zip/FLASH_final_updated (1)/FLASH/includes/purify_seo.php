<?php
// FLASH/includes/purify_seo.php
// Pure PHP (100% No AI) HTML Sanitizer, Google Standards & SEO Optimizer
// - Cleans toxic 3rd party scripts, old analytics IDs, hidden copyright
// - Enhances Robots meta tag for maximum Google crawlability and snippet display
// - Injects/Updates Valid Schema.org Structured Data (WebSite, FAQPage, Organization)
// - Fixes copyright footers to match the current Brand
// - Ensures AMP compliance (disallows forbidden attributes / scripts)

function purify_html_for_google($html, $isAmp, $projectData = []) {
    if (empty(trim($html))) return $html;

    @ini_set('pcre.backtrack_limit', '10000000');
    @ini_set('pcre.recursion_limit', '10000000');

    $rawBrand    = $projectData['brand_name'] ?? ($projectData['name'] ?? 'Brand');
    // Sanitasi teks dari kemungkinan template leak atau sintaks aneh
    $cleanText = function($str) {
        $str = preg_replace('/\{\{\s*[a-zA-Z0-9_]+\s*(?:\|\s*default\(([\'"])(.*?)\1\))?\s*\}\}/s', '$2', $str);
        $str = preg_replace('/(?:\'|\")\)\s*\}\}/', '', $str);
        $str = preg_replace('/(?:\'|\")\s*\}\}/', '', $str);
        $str = preg_replace('/\{\{\s*[a-zA-Z0-9_]+\s*\}\}/', '', $str);
        return trim($str);
    };

    $brandName   = $cleanText($rawBrand) ?: 'Brand';
    $title       = $cleanText($projectData['title'] ?? $brandName) ?: $brandName;
    $description = $cleanText($projectData['meta_description'] ?? ($brandName . ' - Situs Resmi dan Terpercaya.')) ?: ($brandName . ' - Situs Resmi dan Terpercaya.');
    
    // Hapus duplikasi brand akibat regex recursive (contoh Mega118118 -> Mega118)
    if (preg_match('/^([a-zA-Z]+)(\d+)$/', $brandName, $mB)) {
        $prefix = preg_quote($mB[1], '/');
        $digits = preg_quote($mB[2], '/');
        $brandName = preg_replace('/(' . $prefix . $digits . ')' . $digits . '+/i', '$1', $brandName);
        $title = preg_replace('/(' . $prefix . $digits . ')' . $digits . '+/i', '$1', $title);
        $description = preg_replace('/(' . $prefix . $digits . ')' . $digits . '+/i', '$1', $description);
    }
    // De-duplikasi umum jika teks brand berulang (Mega118 Mega118 -> Mega118)
    $bQuoted = preg_quote($brandName, '/');
    $brandName   = preg_replace('/(' . $bQuoted . ')(?:\s*' . $bQuoted . ')+/i', '$1', $brandName);
    $title       = preg_replace('/(' . $bQuoted . ')(?:\s*' . $bQuoted . ')+/i', '$1', $title);
    $description = preg_replace('/(' . $bQuoted . ')(?:\s*' . $bQuoted . ')+/i', '$1', $description);

    $canonical   = $projectData['canonical_url'] ?? '';
    $ampUrl      = $projectData['amp_url'] ?? '';
    $logoUrl     = $projectData['logo_url'] ?? '';
    $bannerUrl   = $projectData['banner_url'] ?? '';
    $currentYear = date('Y');

    // 1. Remove dangerous tracking, telemetry & verification tags from target site
    // Hapus meta google-site-verification milik situs target lama agar tidak bentrok dengan Search Console milik user
    $html = preg_replace('/<meta\b[^>]*name=["\']google-site-verification["\'][^>]*\/?>\s*/i', '', $html) ?? $html;

    // Hapus script tracking pihak ketiga (GA, GTM, FB Pixel, Histats, Clarity, Yandex, Hotjar, CF insights, NewRelic NREUM, Cloudflare Challenge)
    // JANGAN hapus runtime framework, slider, atau script popup internal website agar semua fungsi & gambar tetap jalan utuh
    $html = preg_replace_callback('/<script\b([^>]*)>(.*?)<\/script>/is', function($m) {
        $attrs   = $m[1];
        $content = $m[2];
        if (preg_match('/(?:google-analytics|googletagmanager|pixel\.facebook|Magefan_FacebookPixel|histats|clarity\.ms|yandex|hotjar|cloudflareinsights|nr-data\.net)/i', $attrs)) {
            return '';
        }
        if (preg_match('/(?:gtag\(|fbq\(|_gaq\.push|GoogleAnalyticsObject|window\.NREUM|bam\.nr-data\.net|__cf\$cv\$params|cdn-cgi\/challenge-platform|wpgtm\.trackPromotion)/i', $content)) {
            return '';
        }
        return $m[0];
    }, $html) ?? $html;

    $html = preg_replace('/<noscript\b[^>]*>.*?(?:googletagmanager|facebook\.com\/tr).*?<\/noscript>/is', '', $html) ?? $html;

    // 2. AMP Rules Enforcement (if AMP)
    if ($isAmp) {
        // In AMP, inline on* event handlers (onclick, onload, etc.) are strictly forbidden
        $html = preg_replace('/\s+on[a-zA-Z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);
        // Clean any standard script tags that are NOT AMP components
        $html = preg_replace_callback('/<script\b([^>]*)>(.*?)<\/script>/is', function($m) {
            $attrs = $m[1];
            if (preg_match('/src=["\'][^"\']*cdn\.ampproject\.org/i', $attrs) || preg_match('/type=["\']application\/(?:ld\+)?json["\']/i', $attrs)) {
                return $m[0]; // Retain AMP scripts and Schema JSON-LD
            }
            return ''; // Discard unauthorized scripts in AMP
        }, $html);
    }

    // 3. Google SEO Robots Tag Optimization
    // Ensures Google indexes with full snippets, image preview, and video preview
    $robotsMeta = '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">';
    if (preg_match('/<meta[^>]*name=["\']robots["\'][^>]*>/i', $html)) {
        $html = preg_replace('/<meta[^>]*name=["\']robots["\'][^>]*>/i', $robotsMeta, $html, 1);
    } else {
        $html = preg_replace('/(<head\b[^>]*>)/i', "$1\n    " . $robotsMeta, $html, 1);
    }

    // 4. OpenGraph & Twitter Card SEO Tags (Update existing or insert fresh)
    $ogMeta = [];
    if (preg_match('/<meta[^>]*property=["\']og:title["\'][^>]*>/i', $html)) {
        $html = preg_replace('/<meta[^>]*property=["\']og:title["\'][^>]*>/i', '<meta property="og:title" content="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '">', $html);
    } else {
        $ogMeta[] = '<meta property="og:title" content="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '">';
    }
    if (preg_match('/<meta[^>]*property=["\']og:description["\'][^>]*>/i', $html)) {
        $html = preg_replace('/<meta[^>]*property=["\']og:description["\'][^>]*>/i', '<meta property="og:description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '">', $html);
    } else {
        $ogMeta[] = '<meta property="og:description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '">';
    }
    if (!empty($canonical)) {
        if (preg_match('/<meta[^>]*property=["\']og:url["\'][^>]*>/i', $html)) {
            $html = preg_replace('/<meta[^>]*property=["\']og:url["\'][^>]*>/i', '<meta property="og:url" content="' . htmlspecialchars($canonical, ENT_QUOTES, 'UTF-8') . '">', $html);
        } else {
            $ogMeta[] = '<meta property="og:url" content="' . htmlspecialchars($canonical, ENT_QUOTES, 'UTF-8') . '">';
        }
    }
    if (!empty($bannerUrl)) {
        if (preg_match('/<meta[^>]*property=["\']og:image["\'][^>]*>/i', $html)) {
            $html = preg_replace('/<meta[^>]*property=["\']og:image["\'][^>]*>/i', '<meta property="og:image" content="' . htmlspecialchars($bannerUrl, ENT_QUOTES, 'UTF-8') . '">', $html);
        } else {
            $ogMeta[] = '<meta property="og:image" content="' . htmlspecialchars($bannerUrl, ENT_QUOTES, 'UTF-8') . '">';
        }
        $html = preg_replace('/<meta[^>]*property=["\']og:image:secure_url["\'][^>]*>/i', '<meta property="og:image:secure_url" content="' . htmlspecialchars($bannerUrl, ENT_QUOTES, 'UTF-8') . '">', $html);
        $html = preg_replace('/<meta[^>]*name=["\']twitter:image["\'][^>]*>/i', '<meta name="twitter:image" content="' . htmlspecialchars($bannerUrl, ENT_QUOTES, 'UTF-8') . '">', $html);
    }
    if (!empty($canonical)) {
        $html = preg_replace('/<meta[^>]*property=["\']og:(?:canonical|author)["\'][^>]*>/i', '', $html);
        // Bersihkan duplikasi <link rel="alternate"> yang berulang
        $altSeen = false;
        $html = preg_replace_callback('/<link\b[^>]*\brel=["\']alternate["\'][^>]*>\s*/i', function($m) use (&$altSeen, $canonical) {
            if ($altSeen) return '';
            $altSeen = true;
            return '<link rel="alternate" hreflang="id" href="' . htmlspecialchars($canonical, ENT_QUOTES, 'UTF-8') . "\">\n";
        }, $html);
    }
    if (!empty($ogMeta)) {
        $html = preg_replace('/(<head\b[^>]*>)/i', "$1\n    " . implode("\n    ", $ogMeta), $html, 1);
    }

    // 5. Anti-Copyright & DMCA Protection: Neutralize Old Brand Copyright Footers
    // Replace "Copyright © 20xx OldBrand" or "Hak Cipta Terpelihara" with current Brand
    $cleanCopyrightText = "&copy; {$currentYear} {$brandName}. All rights reserved.";
    $copyrightPatterns = [
        '/(?:&copy;|©|copyright|\(c\))\s*(?:20\d{2}(?:\s*-\s*20\d{2})?)?\s*[^<.\n\r]{1,120}(?:all\s*rights\s*reserved|hak\s*cipta\s*terpelihara)?\.?/i'
    ];
    // Replace in footers / body
    $html = preg_replace_callback($copyrightPatterns[0], function($m) use ($cleanCopyrightText) {
        return $cleanCopyrightText;
    }, $html) ?? $html;

    // 6. Google Rich Snippets: Clean up old Schema.org or inject fresh valid JSON-LD
    // Remove old conflicting JSON-LD if present to avoid scraping flags
    $html = preg_replace('/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>.*?<\/script>/is', '', $html) ?? $html;

    $canBase = rtrim($canonical ?: 'https://domain.com', '/');

    // Build rich, validated Schema.org graph
    $schemaGraph = [
        "@context" => "https://schema.org",
        "@graph" => [
            [
                "@type" => "WebSite",
                "@id" => $canBase . "/#website",
                "url" => ($canonical ?: 'https://domain.com'),
                "name" => $brandName,
                "description" => $description,
                "publisher" => [
                    "@type" => "Organization",
                    "name" => $brandName,
                    "logo" => [
                        "@type" => "ImageObject",
                        "url" => $logoUrl ?: ($bannerUrl ?: 'https://placehold.co/200x60')
                    ]
                ]
            ],
            [
                "@type" => "WebPage",
                "@id" => $canBase . "/#webpage",
                "url" => ($canonical ?: 'https://domain.com'),
                "name" => $title,
                "isPartOf" => [
                    "@id" => $canBase . "/#website"
                ],
                "description" => $description,
                "inLanguage" => "id-ID"
            ]
        ]
    ];

    // Add FAQPage Schema if FAQs exist
    $faqsData = [];
    if (!empty($projectData['faq_json'])) {
        $faqsData = is_array($projectData['faq_json']) ? $projectData['faq_json'] : json_decode($projectData['faq_json'], true);
    }
    if (!empty($faqsData) && is_array($faqsData)) {
        $faqEntities = [];
        foreach ($faqsData as $f) {
            if (!empty($f['question']) && !empty($f['answer'])) {
                $faqEntities[] = [
                    "@type" => "Question",
                    "name" => $f['question'],
                    "acceptedAnswer" => [
                        "@type" => "Answer",
                        "text" => $f['answer']
                    ]
                ];
            }
        }
        if (!empty($faqEntities)) {
            $schemaGraph["@graph"][] = [
                "@type" => "FAQPage",
                "@id" => $canBase . "/#faq",
                "mainEntity" => $faqEntities
            ];
        }
    }

    // Add Reviews Schema if Reviews exist
    $reviewsData = [];
    if (!empty($projectData['reviews_json'])) {
        $reviewsData = is_array($projectData['reviews_json']) ? $projectData['reviews_json'] : json_decode($projectData['reviews_json'], true);
    }
    if (!empty($reviewsData) && is_array($reviewsData)) {
        $reviewEntities = [];
        foreach ($reviewsData as $rv) {
            $rName = trim($rv['name'] ?? '');
            $rText = trim($rv['text'] ?? '');
            $rLoc  = trim($rv['location'] ?? 'Indonesia');
            $rRate = max(1, min(5, intval($rv['rating'] ?? 5)));
            if ($rName !== '' && $rText !== '') {
                $reviewObj = [
                    "@type" => "Review",
                    "author" => [
                        "@type" => "Person",
                        "name" => $rName
                    ],
                    "reviewBody" => $rText,
                    "reviewRating" => [
                        "@type" => "Rating",
                        "ratingValue" => (string)$rRate,
                        "bestRating" => "5",
                        "worstRating" => "1"
                    ]
                ];
                if ($rLoc !== '') {
                    $reviewObj["author"]["homeLocation"] = [
                        "@type" => "Place",
                        "name" => $rLoc
                    ];
                }
                $reviewEntities[] = $reviewObj;
            }
        }
        if (!empty($reviewEntities)) {
            $schemaGraph["@graph"][0]["review"] = $reviewEntities;
        }
    }

    $schemaJson = json_encode($schemaGraph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $schemaTag = "\n<script type=\"application/ld+json\">\n" . $schemaJson . "\n</script>\n";

    // Inject Schema.org right before </head>
    if (stripos($html, '</head>') !== false) {
        $html = str_ireplace('</head>', $schemaTag . '</head>', $html);
    } elseif (stripos($html, '<body') !== false) {
        $html = preg_replace('/(<body\b[^>]*>)/i', $schemaTag . "$1", $html);
    } else {
        $html = "<!DOCTYPE html>\n<html>\n<head>\n" . $schemaTag . "</head>\n<body>\n" . $html . "\n</body>\n</html>";
    }

    return $html;
}

/**
 * Split ekspresi template pada level kurung & tanda kutip teratas (aman untuk nested default() & ~)
 */
function flash_split_top_level($str, $delimiter) {
    $parts = [];
    $buf = '';
    $depth = 0;
    $inQuote = null;
    $len = strlen($str);
    for ($i = 0; $i < $len; $i++) {
        $ch = $str[$i];
        if ($inQuote !== null) {
            $buf .= $ch;
            if ($ch === $inQuote && ($i === 0 || $str[$i - 1] !== '\\')) {
                $inQuote = null;
            }
            continue;
        }
        if ($ch === '\'' || $ch === '"') {
            $inQuote = $ch;
            $buf .= $ch;
        } elseif ($ch === '(') {
            $depth++;
            $buf .= $ch;
        } elseif ($ch === ')') {
            if ($depth > 0) $depth--;
            $buf .= $ch;
        } elseif ($ch === $delimiter && $depth === 0) {
            $parts[] = $buf;
            $buf = '';
        } else {
            $buf .= $ch;
        }
    }
    $parts[] = $buf;
    return $parts;
}

/**
 * Evaluasi ekspresi template {{ field | default(...) ~ '...' }} secara rekursif hingga bersih 100%
 */
function flash_eval_template_expr($expr, $fieldMap, $depth = 0) {
    if ($depth > 10) return '';
    $expr = trim($expr);
    if ($expr === '') return '';

    // 1. Evaluasi operator penyambungan string (~) di level teratas
    $concatParts = flash_split_top_level($expr, '~');
    if (count($concatParts) > 1) {
        $out = '';
        foreach ($concatParts as $cp) {
            $out .= flash_eval_template_expr($cp, $fieldMap, $depth + 1);
        }
        return $out;
    }

    // 2. Cek apakah keseluruhan dibungkus tanda kurung (...)
    if ($expr[0] === '(' && substr($expr, -1) === ')') {
        $inner = substr($expr, 1, -1);
        // Pastikan tanda kurung awal memang berpasangan dengan akhir
        $d = 0; $q = null; $matched = true; $ilen = strlen($inner);
        for ($i = 0; $i < $ilen; $i++) {
            $c = $inner[$i];
            if ($q !== null) {
                if ($c === $q && ($i === 0 || $inner[$i - 1] !== '\\')) $q = null;
                continue;
            }
            if ($c === '\'' || $c === '"') $q = $c;
            elseif ($c === '(') $d++;
            elseif ($c === ')') {
                $d--;
                if ($d < 0) { $matched = false; break; }
            }
        }
        if ($matched && $d === 0) {
            return flash_eval_template_expr($inner, $fieldMap, $depth + 1);
        }
    }

    // 3. Evaluasi literal string ('...' atau "...")
    $firstCh = $expr[0];
    $lastCh  = substr($expr, -1);
    if (($firstCh === '\'' || $firstCh === '"') && $lastCh === $firstCh && strlen($expr) >= 2) {
        return stripcslashes(substr($expr, 1, -1));
    }

    // 4. Evaluasi filter pipe (| default(...))
    $pipeParts = flash_split_top_level($expr, '|');
    $baseExpr  = trim($pipeParts[0]);
    $val = '';

    if (preg_match('/^[a-zA-Z_][a-zA-Z0-9_:]*$/', $baseExpr)) {
        if (isset($fieldMap[$baseExpr]) && trim((string)$fieldMap[$baseExpr]) !== '') {
            return (string)$fieldMap[$baseExpr];
        }
    } else {
        $val = flash_eval_template_expr($baseExpr, $fieldMap, $depth + 1);
        if ($val !== '') return $val;
    }

    for ($p = 1; $p < count($pipeParts); $p++) {
        $filter = trim($pipeParts[$p]);
        if (preg_match('/^default\s*\((.*)\)$/s', $filter, $mDef)) {
            $candidate = flash_eval_template_expr($mDef[1], $fieldMap, $depth + 1);
            if ($candidate !== '') return $candidate;
        }
    }

    if (is_numeric($baseExpr)) return $baseExpr;
    return $val;
}

/**
 * Ekstraksi Jujur & Akurat Ulasan Pengguna (Reviews/Testimonials) dan Detail-detail (<details> / FAQ) dari HTML.
 * Hanya mengekstrak item yang benar-benar ada di HTML/JSON-LD (tidak pernah mengarang data palsu).
 */
function extract_reviews_and_faqs_from_html($html, $brandHint = '') {
    $reviews = [];
    $faqs    = [];
    if (empty(trim((string)$html))) {
        return ['reviews' => [], 'faqs' => []];
    }

    $evalMap = [];
    if (!empty($brandHint)) {
        $evalMap = [
            'brand_name'         => $brandHint,
            'name'               => $brandHint,
            'brand_name_short'   => $brandHint,
            'brand_name_alt'     => strtolower($brandHint),
            'brand_name_keyword' => strtolower($brandHint)
        ];
    }

    $cleanTxt = function($s) use ($evalMap) {
        if (!is_string($s) || $s === '') return '';
        for ($p = 0; $p < 4; $p++) {
            $cnt = 0;
            $res = preg_replace_callback('/\{\{\s*(?!block:)([a-zA-Z_][a-zA-Z0-9_:]*[^\}\{\r\n]{0,600})\}\}/', function($m) use ($evalMap) {
                return flash_eval_template_expr($m[1], $evalMap);
            }, $s, -1, $cnt);
            if ($res !== null) $s = $res;
            if ($cnt === 0) break;
        }
        $s = preg_replace('/\{\{.*?\}\}/s', '', $s) ?? $s;
        $s = strip_tags($s);
        $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $s = preg_replace('/\s+/u', ' ', $s) ?? $s;
        $s = trim($s);
        $s = trim($s, "\"'“”‘’");
        return trim($s);
    };

    $seenFaqKeys = [];
    $addFaq = function($q, $a) use (&$faqs, &$seenFaqKeys, $cleanTxt) {
        $qClean = $cleanTxt($q);
        $aClean = $cleanTxt($a);
        $qClean = preg_replace('/[\+\-−✕×]\s*$/u', '', $qClean) ?? $qClean;
        $qClean = trim($qClean);
        if (strlen($qClean) < 4 || strlen($aClean) < 4) return;
        if (preg_match('/^(?:menu|navigasi|navigation|filter|kategori|sort|privacy\s+settings|cookie|language|currency)$/i', $qClean)) return;
        $key = strtolower($qClean);
        if (isset($seenFaqKeys[$key])) return;
        $seenFaqKeys[$key] = true;
        $faqs[] = [
            'question' => $qClean,
            'answer'   => $aClean
        ];
    };

    $seenRevKeys = [];
    $addReview = function($name, $loc, $rating, $text) use (&$reviews, &$seenRevKeys, $cleanTxt) {
        $nClean = $cleanTxt($name);
        $lClean = $cleanTxt($loc);
        $tClean = $cleanTxt($text);
        if (strlen($nClean) < 2 || strlen($tClean) < 6) return;
        // Jika format nama "Jokowi, Solo", pisahkan kota ke location bila location kosong atau berisi tanggal
        if (strpos($nClean, ',') !== false) {
            $nParts = array_map('trim', explode(',', $nClean, 2));
            if (!empty($nParts[0]) && !empty($nParts[1])) {
                $nClean = $nParts[0];
                if ($lClean === '' || preg_match('/^\d{4}-\d{2}-\d{2}$/', $lClean)) {
                    $lClean = $nParts[1];
                }
            }
        }
        if ($lClean === '') $lClean = 'Indonesia';
        $rInt = intval(round(floatval($rating)));
        if ($rInt < 1 || $rInt > 5) $rInt = 5;
        $key = strtolower($nClean . '|' . substr($tClean, 0, 40));
        if (isset($seenRevKeys[$key])) return;
        $seenRevKeys[$key] = true;
        $reviews[] = [
            'name'     => $nClean,
            'location' => $lClean,
            'rating'   => (string)$rInt,
            'text'     => $tClean
        ];
    };

    // --- 1. EKSTRAKSI DETAIL / FAQ DARI DOM HTML ---
    // 1a. Elemen <details><summary>...</summary>...</details>
    if (preg_match_all('/<details\b[^>]*>\s*<summary\b[^>]*>([\s\S]*?)<\/summary>([\s\S]*?)<\/details>/i', $html, $mDetails, PREG_SET_ORDER)) {
        foreach ($mDetails as $md) {
            $addFaq($md[1], $md[2]);
        }
    }

    // 1b. Elemen .cok-faq-item (<button class="cok-faq-q">...</button><div class="cok-faq-a">...</div>)
    if (preg_match_all('/<div\b[^>]*class=["\'][^"\']*\bcok-faq-item\b[^"\']*["\'][^>]*>\s*<button\b[^>]*class=["\'][^"\']*\bcok-faq-q\b[^"\']*["\'][^>]*>([\s\S]*?)<\/button>\s*<div\b[^>]*class=["\'][^"\']*\bcok-faq-a\b[^"\']*["\'][^>]*>([\s\S]*?)<\/div>\s*<\/div>/i', $html, $mCokFaq, PREG_SET_ORDER)) {
        foreach ($mCokFaq as $mc) {
            $addFaq($mc[1], $mc[2]);
        }
    }

    // 1c. Elemen .faq-item dengan .faq-question dan .faq-answer
    if (preg_match_all('/<div\b[^>]*class=["\'][^"\']*\bfaq-item\b[^"\']*["\'][^>]*>[\s\S]*?<[^>]*class=["\'][^"\']*\bfaq-question\b[^"\']*["\'][^>]*>([\s\S]*?)<\/(?:button|div|h[1-6]|a)>[\s\S]*?<div\b[^>]*class=["\'][^"\']*\bfaq-answer\b[^"\']*["\'][^>]*>([\s\S]*?)<\/div>\s*<\/div>/i', $html, $mFaqQA, PREG_SET_ORDER)) {
        foreach ($mFaqQA as $mf) {
            $qRaw = preg_replace('/<span\b[^>]*class=["\'][^"\']*\bicon\b[^"\']*["\'][^>]*>[\s\S]*?<\/span>/i', '', $mf[1]) ?? $mf[1];
            $addFaq($qRaw, $mf[2]);
        }
    }

    // --- 2. EKSTRAKSI ULASAN PENGGUNA (REVIEWS / TESTIMONIALS) DARI DOM HTML ---
    // 2a. Pattern .testimonial-card (.testimonial-text + .profile-info h4/span)
    if (preg_match_all('/<div\b[^>]*class=["\'][^"\']*\btestimonial-card\b[^"\']*["\'][^>]*>([\s\S]*?)(?=<div\b[^>]*class=["\'][^"\']*\btestimonial-card\b|<\/section>|<style\b|<footer\b|$)/i', $html, $mTestiCards)) {
        foreach ($mTestiCards[1] as $tcChunk) {
            $tTxt = '';
            $tName = '';
            $tLoc = '';
            $tRate = 5;
            if (preg_match('/<p\b[^>]*class=["\'][^"\']*\btestimonial-text\b[^"\']*["\'][^>]*>([\s\S]*?)<\/p>/i', $tcChunk, $mTT)) {
                $tTxt = $mTT[1];
            }
            if (preg_match('/<div\b[^>]*class=["\'][^"\']*\bprofile-info\b[^"\']*["\'][^>]*>[\s\S]*?<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>(?:\s*<span[^>]*>([\s\S]*?)<\/span>)?/i', $tcChunk, $mPI)) {
                $tName = $mPI[1];
                $rawSpan = $mPI[2] ?? '';
                if (preg_match_all('/★|⭐/u', $rawSpan, $mSt)) {
                    $tRate = count($mSt[0]);
                }
                $tLoc = preg_replace('/<small\b[^>]*>[\s\S]*?<\/small>/i', '', $rawSpan) ?? $rawSpan;
                $tLoc = str_replace(['★', '☆', '⭐'], '', $tLoc);
            }
            if ($tName !== '' && $tTxt !== '') {
                $addReview($tName, $tLoc, $tRate, $tTxt);
            }
        }
    }

    // 2b. Pattern <article class="testi-card"> (Microdata schema.org)
    if (preg_match_all('/<article\b[^>]*class=["\'][^"\']*\btesti-card\b[^"\']*["\'][^>]*>([\s\S]*?)<\/article>/i', $html, $mArtCards)) {
        foreach ($mArtCards[1] as $acChunk) {
            $aName = '';
            $aLoc  = '';
            $aTxt  = '';
            $aRate = 5;
            if (preg_match('/<h[1-6][^>]*class=["\'][^"\']*\bname\b[^"\']*["\'][^>]*>([\s\S]*?)<\/h[1-6]>/i', $acChunk, $mAN)) {
                $aName = $mAN[1];
            } elseif (preg_match('/<span\b[^>]*itemprop=["\']name["\'][^>]*>([\s\S]*?)<\/span>/i', $acChunk, $mAN2)) {
                $aName = $mAN2[1];
            }
            if (preg_match('/<p\b[^>]*class=["\'][^"\']*\bmeta\b[^"\']*["\'][^>]*>([\s\S]*?)<\/p>/i', $acChunk, $mAL)) {
                $aLoc = $mAL[1];
            }
            if (preg_match('/<p\b[^>]*class=["\'][^"\']*\bquote\b[^"\']*["\'][^>]*>([\s\S]*?)<\/p>/i', $acChunk, $mAT)) {
                $aTxt = $mAT[1];
            } elseif (preg_match('/<[^>]*itemprop=["\']reviewBody["\'][^>]*>([\s\S]*?)<\/[^>]+>/i', $acChunk, $mAT2)) {
                $aTxt = $mAT2[1];
            }
            if (preg_match('/<meta\b[^>]*itemprop=["\']ratingValue["\'][^>]*content=["\']([^"\']+)["\']/i', $acChunk, $mAR)) {
                $aRate = floatval($mAR[1]);
            }
            if ($aName !== '' && $aTxt !== '') {
                $addReview($aName, $aLoc, $aRate, $aTxt);
            }
        }
    }

    // 2c. Pattern .review-card (.review-name, .review-stars, .review-text, .review-date)
    if (preg_match_all('/<div\b[^>]*class=["\'][^"\']*\breview-card\b[^"\']*["\'][^>]*>([\s\S]*?)(?=<div\b[^>]*class=["\'][^"\']*\breview-card\b|<\/div>\s*(?:<!--|<h[1-6]|<div\b[^>]*style|<footer|<script|<section)|$)/i', $html, $mRevCards)) {
        foreach ($mRevCards[1] as $rcChunk) {
            $rName = '';
            $rLoc  = '';
            $rTxt  = '';
            $rRate = 5;
            if (preg_match('/<[^>]*class=["\'][^"\']*\breview-name\b[^"\']*["\'][^>]*>([\s\S]*?)<\/[^>]+>/i', $rcChunk, $mRN)) {
                $rName = $mRN[1];
            }
            if (preg_match('/<[^>]*class=["\'][^"\']*\breview-stars\b[^"\']*["\'][^>]*>([\s\S]*?)<\/[^>]+>/i', $rcChunk, $mRS)) {
                $starsEvaluated = $cleanTxt($mRS[1]);
                if (preg_match_all('/★|⭐/u', $starsEvaluated, $mStarCnt)) {
                    $rRate = count($mStarCnt[0]);
                }
            }
            if (preg_match('/<[^>]*class=["\'][^"\']*\breview-text\b[^"\']*["\'][^>]*>([\s\S]*?)<\/[^>]+>/i', $rcChunk, $mRT)) {
                $rTxt = $mRT[1];
            }
            if (preg_match('/<[^>]*class=["\'][^"\']*\breview-(?:date|loc|location|city|meta)\b[^"\']*["\'][^>]*>([\s\S]*?)<\/[^>]+>/i', $rcChunk, $mRD)) {
                $rLoc = $mRD[1];
            }
            if ($rName !== '' && $rTxt !== '') {
                $addReview($rName, $rLoc, $rRate, $rTxt);
            }
        }
    }

    // 2d. Pattern .testi-section (Dynamic Block)
    if (empty($reviews) && preg_match('/<div\b[^>]*class=["\'][^"\']*\btesti-section\b[^"\']*["\'][^>]*>([\s\S]*?)<\/div>\s*<\/div>/i', $html, $mTestiSec)) {
        if (preg_match_all('/<strong[^>]*>([\s\S]*?)<\/strong>\s*<span[^>]*>([\s\S]*?)<\/span>\s*<\/div>\s*<\/div>\s*<div[^>]*>([\s\S]*?)<\/div>\s*<p[^>]*>([\s\S]*?)<\/p>/i', $mTestiSec[0], $mDynItems, PREG_SET_ORDER)) {
            foreach ($mDynItems as $di) {
                $rate = 5;
                if (preg_match_all('/⭐|★/u', $di[3], $mSt)) {
                    $rate = count($mSt[0]);
                }
                $addReview($di[1], $di[2], $rate, $di[4]);
            }
        }
    }

    // 2e. Pattern .review-per (.by-per .author & .say-con)
    if (empty($reviews) && preg_match_all('/<div\b[^>]*class=["\'][^"\']*\breview-per\b[^"\']*["\'][^>]*>([\s\S]*?)(?=<div\b[^>]*class=["\'][^"\']*\breview-per\b|<div\b[^>]*class=["\'][^"\']*\bpagination-box\b|<\/section>|$)/i', $html, $mRevPer)) {
        foreach ($mRevPer[1] as $rpChunk) {
            $rpName = '';
            $rpTxt  = '';
            if (preg_match('/<[^>]*class=["\'][^"\']*\bauthor\b[^"\']*["\'][^>]*>([\s\S]*?)<\/[^>]+>/i', $rpChunk, $mAu)) {
                $rpName = $mAu[1];
            }
            if (preg_match('/<[^>]*class=["\'][^"\']*\bsay-con\b[^"\']*["\'][^>]*>([\s\S]*?)<\/[^>]+>/i', $rpChunk, $mSc)) {
                $rpTxt = $mSc[1];
            }
            if ($rpName !== '' && $rpTxt !== '') {
                $addReview($rpName, 'Indonesia', 5, $rpTxt);
            }
        }
    }

    // --- 3. EKSTRAKSI DARI JSON-LD SCHEMA.ORG (FAQPage & Review) BILA BELUM TERCAKUP DI DOM ---
    if ((empty($faqs) || empty($reviews)) && preg_match_all('/<script\b[^>]*type=["\']application\/ld\+json["\'][^>]*>([\s\S]*?)<\/script>/i', $html, $mLdScripts)) {
        foreach ($mLdScripts[1] as $ldRaw) {
            // Bersihkan tag PHP / template di dalam JSON-LD bila ada sebelum decode
            $ldCleaned = preg_replace('/<\?php.*?\?>/is', '', $ldRaw) ?? $ldRaw;
            $ldCleaned = preg_replace_callback('/\{\{\s*(?!block:)([a-zA-Z_][a-zA-Z0-9_:]*[^\}\{\r\n]{0,500})\}\}/', function($m) use ($evalMap) {
                return flash_eval_template_expr($m[1], $evalMap);
            }, $ldCleaned) ?? $ldCleaned;
            $ldDec = json_decode(trim($ldCleaned), true);
            if (!is_array($ldDec)) continue;

            $stack = [$ldDec];
            while ($stack) {
                $node = array_shift($stack);
                if (!is_array($node)) continue;

                $nodeType = $node['@type'] ?? '';
                if ($nodeType === 'FAQPage' && empty($faqs) && !empty($node['mainEntity']) && is_array($node['mainEntity'])) {
                    foreach ($node['mainEntity'] as $me) {
                        $q = $me['name'] ?? ($me['question'] ?? '');
                        $a = $me['acceptedAnswer']['text'] ?? ($me['answer'] ?? '');
                        if (!empty($q) && !empty($a)) {
                            $addFaq($q, $a);
                        }
                    }
                }
                if ($nodeType === 'Review') {
                    $rAuthor = is_array($node['author'] ?? null) ? ($node['author']['name'] ?? '') : ($node['author'] ?? '');
                    $rLoc    = is_array($node['author']['homeLocation'] ?? null) ? ($node['author']['homeLocation']['name'] ?? '') : ($node['datePublished'] ?? 'Indonesia');
                    $rBody   = $node['reviewBody'] ?? ($node['description'] ?? '');
                    $rRate   = $node['reviewRating']['ratingValue'] ?? 5;
                    if (!empty($rAuthor) && !empty($rBody)) {
                        $addReview($rAuthor, $rLoc, $rRate, $rBody);
                    }
                }
                if (!empty($node['review']) && is_array($node['review'])) {
                    $revList = isset($node['review'][0]) ? $node['review'] : [$node['review']];
                    foreach ($revList as $rvItem) {
                        if (!is_array($rvItem)) continue;
                        $rAuthor = is_array($rvItem['author'] ?? null) ? ($rvItem['author']['name'] ?? '') : ($rvItem['author'] ?? '');
                        $rLoc    = is_array($rvItem['author']['homeLocation'] ?? null) ? ($rvItem['author']['homeLocation']['name'] ?? '') : ($rvItem['datePublished'] ?? 'Indonesia');
                        $rBody   = $rvItem['reviewBody'] ?? ($rvItem['description'] ?? '');
                        $rRate   = $rvItem['reviewRating']['ratingValue'] ?? 5;
                        if (!empty($rAuthor) && !empty($rBody)) {
                            $addReview($rAuthor, $rLoc, $rRate, $rBody);
                        }
                    }
                }

                foreach ($node as $k => $v) {
                    if ($k !== 'review' && $k !== 'mainEntity' && is_array($v)) {
                        $stack[] = $v;
                    }
                }
            }
        }
    }

    return [
        'reviews' => array_values($reviews),
        'faqs'    => array_values($faqs)
    ];
}

/**
 * Render HTML Block untuk Daftar FAQ (<details>)
 */
function build_flash_faqs_block_html($faqsData) {
    if (empty($faqsData) || !is_array($faqsData)) return '';
    $validFaqs = [];
    foreach ($faqsData as $f) {
        $q = trim($f['question'] ?? ($f['q'] ?? ''));
        $a = trim($f['answer'] ?? ($f['a'] ?? ''));
        if ($q !== '' && $a !== '') {
            $validFaqs[] = ['question' => $q, 'answer' => $a];
        }
    }
    if (empty($validFaqs)) return '';

    $out = '<div class="faq-section" data-flash-faqs="1" style="width:100%; max-width:1100px; margin:20px auto; text-align:left;">'
         . '<h3 style="color:#fff; font-size:16px; font-weight:bold; margin-bottom:12px; border-bottom:1px solid #333; padding-bottom:8px;">Pertanyaan Sering Diajukan (FAQ)</h3>';
    foreach ($validFaqs as $vf) {
        $q = htmlspecialchars($vf['question'], ENT_QUOTES, 'UTF-8');
        $a = htmlspecialchars($vf['answer'], ENT_QUOTES, 'UTF-8');
        $out .= '<details style="background:rgba(255,255,255,0.05); margin-bottom:8px; padding:12px; border-radius:12px; border:1px solid rgba(255,255,255,0.1); cursor:pointer;">'
              . '<summary style="font-weight:bold; color:#fff; font-size:13px;">' . $q . '</summary>'
              . '<p style="margin-top:8px; color:#ccc; font-size:12px; line-height:1.5;">' . $a . '</p>'
              . '</details>';
    }
    $out .= '</div>';
    return $out;
}

/**
 * Render HTML Block untuk Ulasan Pengguna (Reviews)
 */
function build_flash_reviews_block_html($reviewsData) {
    if (empty($reviewsData) || !is_array($reviewsData)) return '';
    $validRevs = [];
    foreach ($reviewsData as $r) {
        $n = trim($r['name'] ?? '');
        $t = trim($r['text'] ?? '');
        if ($n !== '' && $t !== '') {
            $validRevs[] = [
                'name'     => $n,
                'location' => trim($r['location'] ?? 'Indonesia') ?: 'Indonesia',
                'rating'   => max(1, min(5, intval($r['rating'] ?? 5))),
                'text'     => $t
            ];
        }
    }
    if (empty($validRevs)) return '';

    $out = '<div class="testi-section" data-flash-reviews="1" style="width:100%; max-width:1100px; margin:20px auto; text-align:left;">'
         . '<h3 style="color:#fff; font-size:16px; font-weight:bold; margin-bottom:12px; border-bottom:1px solid #333; padding-bottom:8px;">Ulasan & Rating Pengguna</h3>'
         . '<div style="display:grid; grid-template-columns:1fr; gap:12px;">';
    foreach ($validRevs as $vr) {
        $rName = htmlspecialchars($vr['name'], ENT_QUOTES, 'UTF-8');
        $rLoc  = htmlspecialchars($vr['location'], ENT_QUOTES, 'UTF-8');
        $rText = htmlspecialchars($vr['text'], ENT_QUOTES, 'UTF-8');
        $initial = htmlspecialchars(strtoupper(substr($vr['name'], 0, 1)), ENT_QUOTES, 'UTF-8');
        $stars = str_repeat('⭐', $vr['rating']);

        $out .= '<div style="background:rgba(255,255,255,0.05); padding:14px; border-radius:14px; border:1px solid rgba(255,255,255,0.1);">'
              . '<div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">'
              . '<div style="width:32px; height:32px; border-radius:50%; background:#d4af37; color:#000; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px;">' . $initial . '</div>'
              . '<div><strong style="color:#fff; font-size:13px; display:block;">' . $rName . '</strong><span style="font-size:10px; color:#aaa;">' . $rLoc . '</span></div>'
              . '</div>'
              . '<div style="font-size:11px; margin-bottom:6px;">' . $stars . '</div>'
              . '<p style="font-size:12px; color:#eee; line-height:1.4; margin:0;">' . $rText . '</p>'
              . '</div>';
    }
    $out .= '</div></div>';
    return $out;
}

/**
 * Sinkronisasi penuh Ulasan Pengguna (Reviews) & Detail-detail (<details> / FAQ) langsung ke elemen DOM HTML
 */
function sync_html_reviews_and_faqs($html, $reviewsData, $faqsData, $forceSyncEmpty = false) {
    if (empty(trim((string)$html))) return $html;

    // Normalisasi array FAQs
    $cleanFaqs = [];
    if (is_array($faqsData)) {
        foreach ($faqsData as $f) {
            if (!is_array($f)) continue;
            $q = trim((string)($f['question'] ?? ($f['q'] ?? '')));
            $a = trim((string)($f['answer'] ?? ($f['a'] ?? '')));
            if ($q !== '' && $a !== '') {
                $cleanFaqs[] = ['question' => $q, 'answer' => $a];
            }
        }
    }

    // Normalisasi array Reviews
    $cleanReviews = [];
    if (is_array($reviewsData)) {
        foreach ($reviewsData as $r) {
            if (!is_array($r)) continue;
            $n = trim((string)($r['name'] ?? ''));
            $t = trim((string)($r['text'] ?? ''), " \t\n\r\0\x0B\"'“”");
            $l = trim((string)($r['location'] ?? 'Indonesia')) ?: 'Indonesia';
            $rt = max(1, min(5, intval(round(floatval($r['rating'] ?? 5)))));
            if ($n !== '' && $t !== '') {
                $cleanReviews[] = [
                    'name'     => $n,
                    'location' => $l,
                    'rating'   => $rt,
                    'text'     => $t
                ];
            }
        }
    }

    // =========================================================================
    // A. SINKRONISASI DETAIL-DETAIL (<details>) & FAQ DI HTML
    // =========================================================================
    $faqReplacedInDom = false;

    // 1. Jika ada elemen <details><summary>...</summary>...</details> di HTML
    if (preg_match('/<details\b([^>]*)>\s*<summary\b([^>]*)>([\s\S]*?)<\/summary>([\s\S]*?)<\/details>/i', $html, $mFirstDet)) {
        if (!empty($cleanFaqs)) {
            $detAttr = $mFirstDet[1];
            $sumAttr = $mFirstDet[2];
            $bodySample = trim($mFirstDet[4]);
            $ansOpen = '<div class="content" style="padding:8px 0;line-height:1.6;">';
            $ansClose = '</div>';
            if (preg_match('/^(<div\b[^>]*>)[\s\S]*(<\/div>)$/i', $bodySample, $mWrapDiv)) {
                $ansOpen = $mWrapDiv[1];
                $ansClose = $mWrapDiv[2];
            } elseif (preg_match('/^(<p\b[^>]*>)[\s\S]*(<\/p>)$/i', $bodySample, $mWrapP)) {
                $ansOpen = $mWrapP[1];
                $ansClose = $mWrapP[2];
            }

            $newDetailsList = [];
            foreach ($cleanFaqs as $cf) {
                $qEsc = htmlspecialchars($cf['question'], ENT_QUOTES, 'UTF-8');
                $aEsc = htmlspecialchars($cf['answer'], ENT_QUOTES, 'UTF-8');
                $newDetailsList[] = '<details' . $detAttr . ">\n<summary" . $sumAttr . '>' . $qEsc . "</summary>\n" . $ansOpen . $aEsc . $ansClose . "\n</details>";
            }
            $allDetailsHtml = implode("\n", $newDetailsList);

            $detIdx = 0;
            $html = preg_replace_callback('/<details\b[^>]*>\s*<summary\b[^>]*>[\s\S]*?<\/summary>[\s\S]*?<\/details>/i', function() use (&$detIdx, $allDetailsHtml) {
                $detIdx++;
                return ($detIdx === 1) ? $allDetailsHtml : '';
            }, $html) ?? $html;
            $faqReplacedInDom = true;
        } elseif ($forceSyncEmpty) {
            $html = preg_replace('/<div\b[^>]*class=["\'][^"\']*\bfaq-(?:container|section)\b[^"\']*["\'][^>]*>\s*(?:<h[1-6][^>]*>[\s\S]*?<\/h[1-6]>\s*)?(?:<details\b[^>]*>[\s\S]*?<\/details>\s*)+<\/div>/i', '', $html) ?? $html;
            $html = preg_replace('/<details\b[^>]*>\s*<summary\b[^>]*>[\s\S]*?<\/summary>[\s\S]*?<\/details>\s*/i', '', $html) ?? $html;
            $faqReplacedInDom = true;
        }
    }

    // 2. Jika ada elemen .cok-faq (.cok-faq-item)
    if (preg_match('/<div\b[^>]*class=["\'][^"\']*\bcok-faq\b[^"\']*["\'][^>]*>(?:\s*<div\b[^>]*class=["\'][^"\']*\bcok-faq-item\b[^"\']*["\'][^>]*>\s*<button\b[^>]*>[\s\S]*?<\/button>\s*<div\b[^>]*>[\s\S]*?<\/div>\s*<\/div>)+\s*<\/div>/i', $html)) {
        if (!empty($cleanFaqs)) {
            $cokItems = [];
            foreach ($cleanFaqs as $cf) {
                $qEsc = htmlspecialchars($cf['question'], ENT_QUOTES, 'UTF-8');
                $aEsc = htmlspecialchars($cf['answer'], ENT_QUOTES, 'UTF-8');
                $cokItems[] = "  <div class=\"cok-faq-item\">\n    <button class=\"cok-faq-q\">{$qEsc}</button>\n    <div class=\"cok-faq-a\">{$aEsc}</div>\n  </div>";
            }
            $newCokHtml = "<div class=\"cok-faq\">\n" . implode("\n\n", $cokItems) . "\n</div>";
            $html = preg_replace('/<div\b[^>]*class=["\'][^"\']*\bcok-faq\b[^"\']*["\'][^>]*>(?:\s*<div\b[^>]*class=["\'][^"\']*\bcok-faq-item\b[^"\']*["\'][^>]*>\s*<button\b[^>]*>[\s\S]*?<\/button>\s*<div\b[^>]*>[\s\S]*?<\/div>\s*<\/div>)+\s*<\/div>/i', $newCokHtml, $html, 1) ?? $html;
            $faqReplacedInDom = true;
        } elseif ($forceSyncEmpty) {
            $html = preg_replace('/<h2\b[^>]*class=["\'][^"\']*\bcok-faq-title\b[^"\']*["\'][^>]*>[^<]*Pertanyaan[^<]*<\/h2>\s*/i', '', $html) ?? $html;
            $html = preg_replace('/<div\b[^>]*class=["\'][^"\']*\bcok-faq\b[^"\']*["\'][^>]*>(?:\s*<div\b[^>]*class=["\'][^"\']*\bcok-faq-item\b[^"\']*["\'][^>]*>\s*<button\b[^>]*>[\s\S]*?<\/button>\s*<div\b[^>]*>[\s\S]*?<\/div>\s*<\/div>)+\s*<\/div>/i', '', $html) ?? $html;
            $faqReplacedInDom = true;
        }
    }

    // 3. Jika ada {{ block:faqs }}
    if (strpos($html, '{{ block:faqs }}') !== false) {
        $faqsBlockHtml = $faqReplacedInDom ? '' : build_flash_faqs_block_html($cleanFaqs);
        $html = str_replace('{{ block:faqs }}', $faqsBlockHtml, $html);
        $faqReplacedInDom = true;
    }

    // 4. Jika user menambahkan FAQ/Detail baru pada halaman yang sebelumnya tidak punya kontainer FAQ sama sekali
    if (!$faqReplacedInDom && !empty($cleanFaqs)) {
        $faqsBlockHtml = build_flash_faqs_block_html($cleanFaqs);
        if (stripos($html, '</body>') !== false) {
            $html = preg_replace('/(<\/body>)/i', "\n" . $faqsBlockHtml . "\n$1", $html, 1) ?? $html;
        } else {
            $html .= "\n" . $faqsBlockHtml;
        }
    }

    // =========================================================================
    // B. SINKRONISASI ULASAN PENGGUNA (REVIEWS / TESTIMONIALS) DI HTML
    // =========================================================================
    $revReplacedInDom = false;

    // 1. Pattern <section class="testimonial-section"> (.testimonial-grid > .testimonial-card)
    if (preg_match('/<section\b[^>]*class=["\'][^"\']*\btestimonial-section\b[^"\']*["\'][^>]*>([\s\S]*?)<\/section>/i', $html, $mTestiSecFull)) {
        if (!empty($cleanReviews)) {
            $existingImgs = [];
            if (preg_match_all('/<img\b[^>]*class=["\'][^"\']*\bprofile-img\b[^"\']*["\'][^>]*>/i', $mTestiSecFull[1], $mProfImgs)) {
                $existingImgs = $mProfImgs[0];
            }
            $cardsOut = [];
            foreach ($cleanReviews as $idx => $cr) {
                $rName = htmlspecialchars($cr['name'], ENT_QUOTES, 'UTF-8');
                $rLoc  = htmlspecialchars($cr['location'], ENT_QUOTES, 'UTF-8');
                $rText = htmlspecialchars($cr['text'], ENT_QUOTES, 'UTF-8');
                $starsStr = str_repeat('★', $cr['rating']) . str_repeat('☆', 5 - $cr['rating']);
                $initChar = htmlspecialchars(strtoupper(substr($cr['name'], 0, 1)), ENT_QUOTES, 'UTF-8');
                $imgHtml  = $existingImgs[$idx] ?? ($existingImgs[0] ?? '<div class="profile-img" style="display:flex;align-items:center;justify-content:center;background:#002d84;color:#fff;font-weight:700;font-size:1.2rem;">' . $initChar . '</div>');
                $activeCls = ($idx === 1) ? ' active' : '';
                $cardsOut[] = "<div class=\"testimonial-card{$activeCls}\">\n"
                            . "<div class=\"quote-icon\">\n<i class=\"fas fa-quote-left\"></i>\n</div>\n"
                            . "<p class=\"testimonial-text\">\n\"{$rText}\"\n</p>\n"
                            . "<div class=\"profile-area\">\n{$imgHtml}\n<div class=\"profile-info\">\n"
                            . "<h4>{$rName}</h4>\n"
                            . "<span>{$rLoc} <small style=\"color:#f59e0b;margin-left:4px;\">{$starsStr}</small></span>\n"
                            . "</div>\n</div>\n</div>";
            }
            $newSecHtml = preg_replace_callback('/(<div\b[^>]*class=["\'][^"\']*\btestimonial-grid\b[^"\']*["\'][^>]*>)[\s\S]*$/i', function($mGrid) use ($cardsOut) {
                return $mGrid[1] . "\n" . implode("\n", $cardsOut) . "\n</div>\n</div>\n</section>";
            }, $mTestiSecFull[0], 1);
            if (!empty($newSecHtml)) {
                $html = str_replace($mTestiSecFull[0], $newSecHtml, $html);
                $revReplacedInDom = true;
            }
        } elseif ($forceSyncEmpty) {
            $html = str_replace($mTestiSecFull[0], '', $html);
            $revReplacedInDom = true;
        }
    }

    // 2. Pattern .testi-grid (<article class="testi-card">)
    if (preg_match('/<div\b[^>]*class=["\'][^"\']*\btesti-grid\b[^"\']*["\'][^>]*>\s*(?:<!--[\s\S]*?-->\s*)*<article\b[^>]*class=["\'][^"\']*\btesti-card\b[\s\S]*?<\/article>\s*<\/div>/i', $html, $mArtGridFull)) {
        if (!empty($cleanReviews)) {
            $artCards = [];
            $todayStr = date('Y-m-d');
            foreach ($cleanReviews as $cr) {
                $rName = htmlspecialchars($cr['name'], ENT_QUOTES, 'UTF-8');
                $rLoc  = htmlspecialchars($cr['location'], ENT_QUOTES, 'UTF-8');
                $rText = htmlspecialchars($cr['text'], ENT_QUOTES, 'UTF-8');
                $rRate = (string)$cr['rating'];
                $initChar = htmlspecialchars(strtoupper(substr($cr['name'], 0, 1)), ENT_QUOTES, 'UTF-8');
                $artCards[] = "          <article class=\"testi-card\">\n"
                            . "            <div class=\"testi-head\">\n"
                            . "              <div class=\"avatar\">{$initChar}</div>\n"
                            . "              <div>\n"
                            . "                <div itemprop=\"author\" itemscope itemtype=\"https://schema.org/Person\">\n"
                            . "                  <h3 class=\"name\"><span itemprop=\"name\">{$rName}</span></h3>\n"
                            . "                  <p class=\"meta\">\n"
                            . "                    <span itemprop=\"homeLocation\" itemscope itemtype=\"https://schema.org/Place\">\n"
                            . "                      <span itemprop=\"name\">{$rLoc}</span>\n"
                            . "                    </span>\n"
                            . "                  </p>\n"
                            . "                </div>\n"
                            . "              </div>\n"
                            . "            </div>\n"
                            . "            <meta itemprop=\"datePublished\" content=\"{$todayStr}\">\n"
                            . "            <p class=\"quote\" itemprop=\"reviewBody\">{$rText}</p>\n"
                            . "            <div itemprop=\"reviewRating\" itemscope itemtype=\"https://schema.org/Rating\">\n"
                            . "              <meta itemprop=\"ratingValue\" content=\"{$rRate}\">\n"
                            . "              <meta itemprop=\"bestRating\" content=\"5\">\n"
                            . "              <meta itemprop=\"worstRating\" content=\"1\">\n"
                            . "            </div>\n"
                            . "          </article>";
            }
            $newArtGrid = "<div class=\"testi-grid\">\n" . implode("\n\n", $artCards) . "\n</div>";
            $html = str_replace($mArtGridFull[0], $newArtGrid, $html);
            $revReplacedInDom = true;
        } elseif ($forceSyncEmpty) {
            $html = preg_replace('/<h2\b[^>]*class=["\'][^"\']*\bcok-faq-title\b[^"\']*["\'][^>]*>[^<]*Pendapat[^<]*<\/h2>\s*/i', '', $html) ?? $html;
            $html = str_replace($mArtGridFull[0], '', $html);
            $revReplacedInDom = true;
        }
    }

    // 3. Pattern .reviews-grid (<div class="review-card">)
    if (preg_match('/<div\b[^>]*class=["\'][^"\']*\breviews-grid\b[^"\']*["\'][^>]*>(?:\s*<div\b[^>]*class=["\'][^"\']*\breview-card\b[^"\']*["\'][^>]*>(?:\s*<div\b[^>]*>[\s\S]*?<\/div>|(?:\s*<(?:p|span|h[1-6]|small)\b[^>]*>[\s\S]*?<\/(?:p|span|h[1-6]|small)>))+\s*<\/div>)+\s*<\/div>/i', $html, $mRevGridFull)) {
        if (!empty($cleanReviews)) {
            $revCards = [];
            foreach ($cleanReviews as $cr) {
                $rName = htmlspecialchars($cr['name'], ENT_QUOTES, 'UTF-8');
                $rLoc  = htmlspecialchars($cr['location'], ENT_QUOTES, 'UTF-8');
                $rText = htmlspecialchars($cr['text'], ENT_QUOTES, 'UTF-8');
                $starsStr = str_repeat('★', $cr['rating']) . str_repeat('☆', 5 - $cr['rating']);
                $displayHeaderName = (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $cr['location']) && stripos($cr['name'], $cr['location']) === false)
                    ? ($rName . ', ' . $rLoc)
                    : $rName;
                $displayDate = preg_match('/^\d{4}-\d{2}-\d{2}$/', $cr['location']) ? $rLoc : date('Y-m-d');
                $revCards[] = "            <div class=\"review-card\">\n"
                            . "                <div class=\"review-header\">\n"
                            . "                    <span class=\"review-name\">{$displayHeaderName}</span>\n"
                            . "                    <span class=\"review-stars\">{$starsStr}</span>\n"
                            . "                </div>\n"
                            . "                <p class=\"review-text\">\"{$rText}\"</p>\n"
                            . "                <span class=\"review-date\">{$displayDate}</span>\n"
                            . "            </div>";
            }
            $newRevGrid = "<div class=\"reviews-grid\">\n" . implode("\n", $revCards) . "\n        </div>";
            $html = str_replace($mRevGridFull[0], $newRevGrid, $html);
            $revReplacedInDom = true;
        } elseif ($forceSyncEmpty) {
            $html = preg_replace('/<h2[^>]*>[^<]*REVIEW\s+TERATAS[^<]*<\/h2>\s*/i', '', $html) ?? $html;
            $html = str_replace($mRevGridFull[0], '', $html);
            $revReplacedInDom = true;
        }
    }

    // 4. Pattern .testi-section (Dynamic Block)
    if (preg_match('/<div\b[^>]*class=["\'][^"\']*\btesti-section\b[^"\']*["\'][^>]*>[\s\S]*?<\/div>\s*<\/div>/i', $html, $mDynTesti)) {
        if (!$revReplacedInDom && !empty($cleanReviews)) {
            $html = str_replace($mDynTesti[0], build_flash_reviews_block_html($cleanReviews), $html);
            $revReplacedInDom = true;
        } elseif ($forceSyncEmpty && empty($cleanReviews)) {
            $html = str_replace($mDynTesti[0], '', $html);
            $revReplacedInDom = true;
        }
    }

    // 5. Jika ada {{ block:reviews }}
    if (strpos($html, '{{ block:reviews }}') !== false) {
        $revsBlockHtml = $revReplacedInDom ? '' : build_flash_reviews_block_html($cleanReviews);
        $html = str_replace('{{ block:reviews }}', $revsBlockHtml, $html);
        $revReplacedInDom = true;
    }

    // 6. Jika user menambahkan Ulasan baru pada halaman yang sebelumnya tidak punya kontainer ulasan sama sekali
    if (!$revReplacedInDom && !empty($cleanReviews)) {
        $revsBlockHtml = build_flash_reviews_block_html($cleanReviews);
        if (stripos($html, '</body>') !== false) {
            $html = preg_replace('/(<\/body>)/i', "\n" . $revsBlockHtml . "\n$1", $html, 1) ?? $html;
        } else {
            $html .= "\n" . $revsBlockHtml;
        }
    }

    return $html;
}

/**
 * Sinkronisasi seluruh field project (Title, Deskripsi, Canonical, AMP, Login, Register, Banner, Logo, Favicon, GIF, Brand)
 * ke dalam HTML secara langsung dan membersihkan 100% kode template {{ ... }} agar HTML bersih tanpa kode aneh.
 */
function sync_and_clean_project_html($html, $newProject = [], $oldProject = []) {
    if (empty(trim($html))) return $html;

    $brand = !empty($newProject['brand_name']) ? trim($newProject['brand_name']) : trim($newProject['name'] ?? 'BRAND');
    $canUrl = trim($newProject['canonical_url'] ?? '');
    $ampUrl = trim($newProject['amp_url'] ?? '');
    $loginUrl = !empty($newProject['login_url']) ? trim($newProject['login_url']) : $canUrl;
    $regUrl   = !empty($newProject['register_url']) ? trim($newProject['register_url']) : $canUrl;
    $bannerUrl = trim($newProject['banner_url'] ?? '');
    $logoUrl   = trim($newProject['logo_url'] ?? '');
    $favUrl    = !empty($newProject['favicon_url']) ? trim($newProject['favicon_url']) : $logoUrl;
    $gifUrl    = !empty($newProject['gif_url']) ? trim($newProject['gif_url']) : $bannerUrl;
    $title     = trim($newProject['title'] ?? '');
    $metaDesc  = trim($newProject['meta_description'] ?? '');

    $faqsList = [];
    if (isset($newProject['faq_json'])) {
        $faqsList = is_array($newProject['faq_json']) ? $newProject['faq_json'] : (json_decode((string)$newProject['faq_json'], true) ?: []);
    }
    $reviewsList = [];
    if (isset($newProject['reviews_json'])) {
        $reviewsList = is_array($newProject['reviews_json']) ? $newProject['reviews_json'] : (json_decode((string)$newProject['reviews_json'], true) ?: []);
    }

    $fieldMap = [
        'brand_name'          => $brand,
        'name'                => $newProject['name'] ?? $brand,
        'brand_name_short'    => $brand,
        'brand_name_alt'      => strtolower($brand),
        'brand_name_keyword'  => strtolower($brand),
        'domain_url'          => $canUrl ?: '#',
        'copyright_year'      => date('Y'),
        'og_site_name'        => $brand,
        'publisher'           => $brand,
        'meta_keywords'       => $brand,
        'title'               => $title,
        'og_title'            => $title,
        'twitter_title'       => $title,
        'meta_description'    => $metaDesc,
        'og_description'      => $metaDesc,
        'twitter_description' => $metaDesc,
        'canonical_url'       => $canUrl,
        'og_url'              => $canUrl,
        'twitter_url'         => $canUrl,
        'preconnect_url'      => $canUrl,
        'alternate_url'       => $canUrl,
        'amp_url'             => $ampUrl,
        'login_url'           => $loginUrl,
        'register_url'        => $regUrl,
        'livechat_url'        => $regUrl,
        'logo_url'            => $logoUrl,
        'twitter_image'       => $bannerUrl ?: $logoUrl,
        'banner_url'          => $bannerUrl,
        'og_image'            => $bannerUrl,
        'favicon_url'         => $favUrl,
        'icon_url'            => $favUrl,
        'gif_url'             => $gifUrl,
        'jackpot_gif'         => $gifUrl,
        'banner_gif_url'      => $gifUrl,
        'banner_title'        => $newProject['banner_title'] ?? ($title ?: $brand),
        'logo_title'          => $newProject['logo_title'] ?? $brand,
        'image_title'         => $newProject['banner_title'] ?? ($title ?: $brand),
        'img_title'           => $newProject['banner_title'] ?? ($title ?: $brand),
    ];

    if (!empty($reviewsList) && is_array($reviewsList)) {
        foreach ($reviewsList as $rIdx => $rvItem) {
            $slotNum = $rIdx + 1;
            if ($slotNum > 10) break;
            $rn = trim((string)($rvItem['name'] ?? ''));
            $rl = trim((string)($rvItem['location'] ?? ''));
            $rr = max(1, min(5, intval($rvItem['rating'] ?? 5)));
            $fieldMap["review{$slotNum}_name"]  = ($rl !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $rl)) ? ($rn . ', ' . $rl) : $rn;
            $fieldMap["review{$slotNum}_stars"] = str_repeat('★', $rr) . str_repeat('☆', 5 - $rr);
            $fieldMap["review{$slotNum}_date"]  = preg_match('/^\d{4}-\d{2}-\d{2}$/', $rl) ? $rl : date('Y-m-d');
        }
    }

    // 1. Evaluasi tag {{ field | default(...) ~ ... }} dengan evaluator rekursif aman dari terdalam ke terluar
    for ($pass = 0; $pass < 10; $pass++) {
        $count = 0;
        $res = preg_replace_callback('/\{\{\s*(?!block:)([a-zA-Z_][a-zA-Z0-9_:]*[^\}\{\r\n]{0,700})\}\}/', function($m) use ($fieldMap) {
            return flash_eval_template_expr($m[1], $fieldMap);
        }, $html, -1, $count);
        if ($res !== null) $html = $res;
        if ($count === 0) break;
    }

    // Fallback untuk tag multiline pendek atau tag template yang kurungnya tidak tertutup sempurna
    for ($pass = 0; $pass < 4; $pass++) {
        $res = preg_replace_callback('/\{\{\s*(?!block:)([a-zA-Z_][a-zA-Z0-9_:]*(?:\s*\|\s*[^\}\{]{1,500})?)\}\}/s', function($m) use ($fieldMap) {
            return flash_eval_template_expr($m[1], $fieldMap);
        }, $html);
        if ($res !== null) $html = $res;
    }

    // Bersihkan sisa fragmen sintaks template bocor / rusak (misal unclosed "{{ title | default('" atau "') }}")
    $html = preg_replace('/\{\{\s*(?:title|brand_name|meta_description|twitter_description|og_description|canonical_url)\s*\|\s*default\(\s*[\'"]/i', '', $html) ?? $html;
    $html = preg_replace('/(?:\'|\")\)\s*\}\}/', '', $html) ?? $html;
    $html = preg_replace('/(?:\'|\")\s*\}\}/', '', $html) ?? $html;
    $html = preg_replace('/\{\{\s*(?!block:)[a-zA-Z0-9_]+\s*\}\}/', '', $html) ?? $html;

    // 2. Jika ada perubahan nilai dari $oldProject ke $newProject, ganti semua kemunculan nilai lama di seluruh HTML
    if (!empty($oldProject) && is_array($oldProject)) {
        // Ganti URL aset & navigasi yang berubah
        $urlKeys = ['favicon_url', 'logo_url', 'gif_url', 'banner_url', 'login_url', 'register_url', 'amp_url'];
        foreach ($urlKeys as $uk) {
            $oldVal = trim($oldProject[$uk] ?? '');
            $newVal = trim($fieldMap[$uk] ?? '');
            if (!empty($oldVal) && !empty($newVal) && $oldVal !== $newVal && strlen($oldVal) > 6) {
                $html = str_replace($oldVal, $newVal, $html);
            }
        }
        // Untuk canonical_url, ganti tanpa merusak path file gambar/css yang kebetulan satu domain
        $oldCan = trim($oldProject['canonical_url'] ?? '');
        if (!empty($oldCan) && !empty($canUrl) && $oldCan !== $canUrl && strlen($oldCan) > 8) {
            $oldCanNoSlash = rtrim($oldCan, '/');
            $newCanNoSlash = rtrim($canUrl, '/');
            $html = preg_replace_callback('/' . preg_quote($oldCanNoSlash, '/') . '(\/[^\s"\'<>]*)?/i', function($m) use ($newCanNoSlash) {
                $path = $m[1] ?? '';
                if (!empty($path) && preg_match('/\.(?:png|jpg|jpeg|gif|webp|svg|css|js|woff2?|ttf|ico|mp4|webm)(\?.*)?$/i', $path)) {
                    return $m[0];
                }
                return $newCanNoSlash . '/';
            }, $html) ?? $html;
        }
        // Jika nama brand diubah di builder (termasuk variasi spasi/strip), ganti hanya di teks terlihat, komentar & atribut non-URL agar src gambar/css aman
        $oldNames = array_unique(array_filter([
            trim($oldProject['name'] ?? ''),
            trim($oldProject['brand_name'] ?? '')
        ], function($v) use ($brand) {
            return strlen($v) >= 3 && strcasecmp($v, $brand) !== 0 && !in_array(strtolower($v), ['project baru', 'brand', 'tes']);
        }));
        if (!empty($oldNames) && !empty($brand)) {
            $parts = preg_split('/(<[^>]+>)/s', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
            $safeAttrRx = '/(alt|title|placeholder|aria-label|content|value|data-[a-zA-Z0-9_\-]+)=([\'"])(.*?)\2/is';
            $inStyle = false;
            for ($pi = 0; $pi < count($parts); $pi++) {
                $seg = $parts[$pi];
                if (substr($seg, 0, 1) === '<' && substr($seg, -1) === '>') {
                    if (preg_match('/^<style\b/i', $seg)) $inStyle = true;
                    elseif (preg_match('/^<\/style>/i', $seg)) $inStyle = false;
                    if (substr($seg, 0, 4) === '<!--') {
                        foreach ($oldNames as $on) {
                            $parts[$pi] = preg_replace('/\b' . preg_quote($on, '/') . '\b/iu', $brand, $parts[$pi]) ?? $parts[$pi];
                        }
                    } elseif (!preg_match('/^<meta\b[^>]*(?:viewport|robots)/i', $seg)) {
                        $parts[$pi] = preg_replace_callback($safeAttrRx, function($m) use ($oldNames, $brand) {
                            if (preg_match('/\.(?:png|jpg|jpeg|gif|webp|svg|css|js|woff2?)(\?.*)?$/i', $m[3])) {
                                return $m[0];
                            }
                            $v = $m[3];
                            foreach ($oldNames as $on) {
                                $v = preg_replace('/\b' . preg_quote($on, '/') . '\b/iu', $brand, $v) ?? $v;
                            }
                            return $m[1] . '=' . $m[2] . $v . $m[2];
                        }, $seg) ?? $seg;
                    }
                } else {
                    if ($inStyle) continue;
                    foreach ($oldNames as $on) {
                        $parts[$pi] = preg_replace('/\b' . preg_quote($on, '/') . '\b/iu', $brand, $parts[$pi]) ?? $parts[$pi];
                    }
                }
            }
            $html = implode('', $parts);
            foreach ($faqsList as &$fItem) {
                foreach (['question', 'answer', 'q', 'a'] as $fk) {
                    if (!empty($fItem[$fk])) {
                        foreach ($oldNames as $on) {
                            $fItem[$fk] = preg_replace('/\b' . preg_quote($on, '/') . '\b/iu', $brand, $fItem[$fk]) ?? $fItem[$fk];
                        }
                    }
                }
            }
            unset($fItem);
            foreach ($reviewsList as &$rItem) {
                foreach (['name', 'location', 'text'] as $rk) {
                    if (!empty($rItem[$rk])) {
                        foreach ($oldNames as $on) {
                            $rItem[$rk] = preg_replace('/\b' . preg_quote($on, '/') . '\b/iu', $brand, $rItem[$rk]) ?? $rItem[$rk];
                        }
                    }
                }
            }
            unset($rItem);
        }
    }

    // 3. Paksa tag-tag utama HTML (<title>, <meta description>, <link canonical>, <link amphtml>, <link icon>, tombol login/daftar) selalu sesuai nilai terbaru
    if (!empty($title)) {
        $safeTitle = htmlspecialchars($title, ENT_NOQUOTES, 'UTF-8');
        $html = preg_replace_callback('/<title[^>]*>.*?<\/title>/is', function() use ($safeTitle) {
            return '<title>' . $safeTitle . '</title>';
        }, $html, 1) ?? $html;
    }
    if (!empty($metaDesc)) {
        $safeDesc = htmlspecialchars($metaDesc, ENT_QUOTES, 'UTF-8');
        if (preg_match('/<meta[^>]*name=["\']description["\'][^>]*>/i', $html)) {
            $html = preg_replace_callback('/<meta[^>]*name=["\']description["\'][^>]*>/i', function() use ($safeDesc) {
                return '<meta name="description" content="' . $safeDesc . '">';
            }, $html) ?? $html;
        }
    }
    if (!empty($canUrl)) {
        $safeCan = htmlspecialchars($canUrl, ENT_QUOTES, 'UTF-8');
        $html = preg_replace_callback('/<link\b[^>]*\brel=["\']canonical["\'][^>]*>/i', function() use ($safeCan) {
            return '<link rel="canonical" href="' . $safeCan . '">';
        }, $html) ?? $html;
        $html = preg_replace_callback('/<link\b[^>]*\brel=["\']alternate["\'][^>]*>/i', function() use ($safeCan) {
            return '<link rel="alternate" href="' . $safeCan . '">';
        }, $html) ?? $html;
    }
    if (!empty($ampUrl)) {
        $safeAmp = htmlspecialchars($ampUrl, ENT_QUOTES, 'UTF-8');
        $html = preg_replace_callback('/<link\b[^>]*\brel=["\']amphtml["\'][^>]*>/i', function() use ($safeAmp) {
            return '<link rel="amphtml" href="' . $safeAmp . '">';
        }, $html) ?? $html;
    }
    if (!empty($favUrl)) {
        $safeFav = htmlspecialchars($favUrl, ENT_QUOTES, 'UTF-8');
        $html = preg_replace_callback('/<link\b[^>]*\brel=["\'](?:shortcut\s+)?icon["\'][^>]*>/i', function() use ($safeFav) {
            return '<link rel="icon" type="image/x-icon" href="' . $safeFav . '">';
        }, $html) ?? $html;
    }

    // 4. Update SELURUH tombol <button onclick="...">, <form action="...">, & <a href="..."> agar tidak ada link sisa (/prv/limit, /cart, dll)
    $fallbackActionUrl = !empty($regUrl) ? $regUrl : (!empty($loginUrl) ? $loginUrl : $canUrl);
    if (!empty($loginUrl) || !empty($regUrl) || !empty($canUrl)) {
        $html = preg_replace_callback('/<button\b([^>]*)onclick=["\'][^"\']*(?:window\.)?location(?:\.href)?\s*=\s*([\'"])(.*?)\2[^"\']*["\']([^>]*)>(.*?)<\/button>/is', function($m) use ($loginUrl, $regUrl, $fallbackActionUrl) {
            $preAttrs  = $m[1];
            $targetUrl = trim($m[3]);
            $postAttrs = $m[4];
            $body      = $m[5];
            $text      = trim(strip_tags($body));
            $isLogin   = (bool) preg_match('/login|masuk|sign\s*in|auth/i', $text) || (bool) preg_match('/login|masuk|signin|auth/i', $targetUrl);
            $dest      = $isLogin ? ($loginUrl ?: $fallbackActionUrl) : ($regUrl ?: $fallbackActionUrl);
            return '<button' . $preAttrs . 'onclick="window.location.href=\'' . $dest . '\'"' . $postAttrs . '>' . $body . '</button>';
        }, $html) ?? $html;

        $html = preg_replace_callback('/<form\b([^>]*)action=["\']([^"\']*)["\']([^>]*)>/is', function($m) use ($fallbackActionUrl) {
            if (empty($fallbackActionUrl)) return $m[0];
            return '<form' . $m[1] . 'action="' . htmlspecialchars($fallbackActionUrl, ENT_QUOTES, 'UTF-8') . '"' . $m[3] . '>';
        }, $html) ?? $html;

        $html = preg_replace_callback('/<a\b([^>]*)href=["\']([^"\']*)["\']([^>]*)>(.*?)<\/a>/is', function($m) use ($loginUrl, $regUrl, $fallbackActionUrl) {
            $pre  = $m[1];
            $href = trim($m[2]);
            $post = $m[3];
            $body = $m[4];
            $text = trim(strip_tags($body));
            if ($href === '#' || substr($href, 0, 1) === '#' || substr($href, 0, 11) === 'javascript:') return $m[0];

            $isLogin = (bool) preg_match('/login|masuk|sign\s*in|member\s*area|auth/i', $text)
                    || (bool) preg_match('/login|masuk|signin|auth/i', $href)
                    || (bool) preg_match('/class=["\'][^"\']*\b(?:login|btn-login|sign-in)\b/i', $m[0]);

            $dest = $isLogin ? ($loginUrl ?: $fallbackActionUrl) : ($regUrl ?: $fallbackActionUrl);
            if (!empty($dest)) {
                return '<a' . $pre . 'href="' . $dest . '"' . $post . '>' . $body . '</a>';
            }
            return $m[0];
        }, $html) ?? $html;
    }

    // 5. Sinkronisasi Ulasan Pengguna (Reviews) & Detail-detail (<details> / FAQ) ke dalam DOM HTML
    $hasExplicitBlocks = (isset($newProject['reviews_json']) && $newProject['reviews_json'] !== '')
                      || (isset($newProject['faq_json']) && $newProject['faq_json'] !== '');
    $forceSyncBlocks = !empty($oldProject) || !empty($newProject['force_sync_blocks']) || $hasExplicitBlocks;
    if ($forceSyncBlocks || !empty($reviewsList) || !empty($faqsList)) {
        $html = sync_html_reviews_and_faqs($html, $reviewsList, $faqsList, $forceSyncBlocks);
    }

    return $html;
}
