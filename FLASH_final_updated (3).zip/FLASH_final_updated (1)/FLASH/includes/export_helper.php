<?php
// includes/export_helper.php - Modular ZIP Installer Generator for LP, AMP & Tunnel with 24-Hour Auto-Cleanup
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/purify_seo.php';
require_once __DIR__ . '/tunnel_helper.php';

/**
 * Otomatis menghapus berkas ekspor ZIP di penyimpanan yang sudah berumur lebih dari 24 jam
 */
function cleanup_expired_exports($maxAgeSeconds = 86400) {
    $exportDir = __DIR__ . '/../exports';
    if (!is_dir($exportDir)) {
        @mkdir($exportDir, 0755, true);
        return 0;
    }

    $deleted = 0;
    $now = time();
    $files = scandir($exportDir);
    foreach ($files as $f) {
        if ($f === '.' || $f === '..' || $f === '.htaccess' || $f === 'index.html') continue;
        $filePath = $exportDir . '/' . $f;
        if (is_file($filePath)) {
            $mtime = filemtime($filePath);
            if (($now - $mtime) >= $maxAgeSeconds) {
                @unlink($filePath);
                $deleted++;
            }
        }
    }
    return $deleted;
}

/**
 * Generator Standalone .htaccess untuk Hosting / VPS
 */
function get_standalone_htaccess($isPhp = false) {
    if ($isPhp) {
        return <<<'HTACCESS'
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /

    # Sajikan file & folder fisik langsung jika ada
    RewriteCond %{REQUEST_FILENAME} -f [OR]
    RewriteCond %{REQUEST_FILENAME} -d
    RewriteRule ^ - [L]

    # Sitemap XML streamer
    RewriteRule ^sitemap\.xml$ sitemap.xml [L]

    # Direct PHP routing
    RewriteRule ^$ index.php [L,QSA]
</IfModule>

<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json
</IfModule>
HTACCESS;
    }

    return <<<'HTACCESS'
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    DirectoryIndex index.html index.php
    RewriteCond %{REQUEST_FILENAME} -f [OR]
    RewriteCond %{REQUEST_FILENAME} -d
    RewriteRule ^ - [L]
</IfModule>

<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json
</IfModule>
HTACCESS;
}

/**
 * 1. PAKET STANDALONE LANDING PAGE (LP) ZIP
 */
function create_lp_export_zip($pdo, $projectId, $userId) {
    cleanup_expired_exports(86400);

    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        return ['success' => false, 'message' => 'Project Landing Page tidak ditemukan.'];
    }

    // Ambil atau render HTML
    $html = '';
    if (!empty(trim($project['article_content'] ?? ''))) {
        $html = $project['article_content'];
    } else {
        $tid = intval($project['template_id'] ?? 1);
        $stmtTpl = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
        $stmtTpl->execute([$tid]);
        $tplFile = $stmtTpl->fetchColumn();
        if ($tplFile && file_exists(__DIR__ . '/../cdn/templates/' . $tplFile)) {
            $html = file_get_contents(__DIR__ . '/../cdn/templates/' . $tplFile);
        }
    }

    if (empty($html)) {
        return ['success' => false, 'message' => 'Konten template Landing Page kosong.'];
    }

    // Replace template tags
    $targetUrl = !empty($project['canonical_url']) ? $project['canonical_url'] : '#';
    $loginUrl = !empty($project['login_url']) ? $project['login_url'] : $targetUrl;
    $regUrl   = !empty($project['register_url']) ? $project['register_url'] : $targetUrl;
    $brand    = !empty($project['brand_name']) ? $project['brand_name'] : $project['name'];

    // 1. Sinkronisasi seluruh field dan bersihkan 100% tag template {{ ... }} dari level terdalam
    $html = sync_and_clean_project_html($html, $project);

    $replaceTags = [
        '{{ brand_name }}'      => $brand,
        '{{ name }}'            => $project['name'],
        '{{ title }}'           => $project['title'] ?: ($brand . ' - Official Landing Page'),
        '{{ meta_description }}'=> $project['meta_description'] ?: '',
        '{{ canonical_url }}'   => $project['canonical_url'] ?: '',
        '{{ amp_url }}'         => $project['amp_url'] ?: '',
        '{{ login_url }}'       => $loginUrl,
        '{{ register_url }}'    => $regUrl,
        '{{ logo_url }}'        => $project['logo_url'] ?: '',
        '{{ banner_url }}'      => $project['banner_url'] ?: '',
        '{{ favicon_url }}'     => $project['favicon_url'] ?: '',
        '{{ gif_url }}'         => $project['gif_url'] ?: ($project['banner_url'] ?: ''),
        '{{ block:faqs }}'      => '',
        '{{ block:reviews }}'   => '',
        '{{ block:article }}'   => ''
    ];
    $html = strtr($html, $replaceTags);

    // Bersihkan sisa syntax template leak jika ada
    $html = preg_replace('/(?:\'|\")\)\s*\}\}/', '', $html) ?? $html;
    $html = preg_replace('/(?:\'|\")\s*\}\}/', '', $html) ?? $html;
    $html = preg_replace('/\{\{\s*[a-zA-Z0-9_:]+\s*\}\}/', '', $html) ?? $html;

    // Ganti CTA links statis (hanya pada tag <a> agar <link rel="stylesheet/icon"> tidak ikut berubah)
    $html = preg_replace_callback('/<a\b[^>]*\bhref=(["\'])([^"\']*)\1[^>]*>/i', function($m) use ($loginUrl, $regUrl) {
        if (preg_match('/login|masuk|signin|auth/i', $m[2])) {
            return str_replace($m[1] . $m[2] . $m[1], '"' . $loginUrl . '"', $m[0]);
        }
        if (preg_match('/daftar|register|signup/i', $m[2])) {
            return str_replace($m[1] . $m[2] . $m[1], '"' . $regUrl . '"', $m[0]);
        }
        return $m[0];
    }, $html) ?? $html;

    // Purify standar Google SEO
    $html = purify_html_for_google($html, false, $project);
    // Pastikan 100% bebas kode template {{ ... }}
    $html = preg_replace('/\{\{\s*[a-zA-Z0-9_:]+\s*(?:\|[^\r\n\}]{0,600}?)?\}\}/', '', $html) ?? $html;
    $html = preg_replace('/(?:\'|\")\s*\)\s*\}\}/', '', $html) ?? $html;

    // Buat sitemap.xml & robots.txt otomatis sesuai canonical & amp url
    $mainDomain = !empty($project['canonical_url']) ? rtrim($project['canonical_url'], '/') : 'https://domain-anda.com';
    $ampDomain  = !empty($project['amp_url']) ? rtrim($project['amp_url'], '/') : ($mainDomain . '/amp');
    $todayDate  = date('Y-m-d');

    // 1. Standalone sitemap.xml standar Google
    $sitemapXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $sitemapXml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"\n";
    $sitemapXml .= "        xmlns:xhtml=\"http://www.w3.org/1999/xhtml\">\n";
    $sitemapXml .= "  <url>\n";
    $sitemapXml .= "    <loc>" . htmlspecialchars($mainDomain, ENT_XML1, 'UTF-8') . "/</loc>\n";
    $sitemapXml .= "    <lastmod>{$todayDate}</lastmod>\n";
    $sitemapXml .= "    <changefreq>daily</changefreq>\n";
    $sitemapXml .= "    <priority>1.0</priority>\n";
    if (!empty($project['amp_url'])) {
        $sitemapXml .= "    <xhtml:link rel=\"amphtml\" href=\"" . htmlspecialchars($ampDomain, ENT_XML1, 'UTF-8') . "\" />\n";
    }
    $sitemapXml .= "  </url>\n";
    if (!empty($project['amp_url'])) {
        $sitemapXml .= "  <url>\n";
        $sitemapXml .= "    <loc>" . htmlspecialchars($ampDomain, ENT_XML1, 'UTF-8') . "</loc>\n";
        $sitemapXml .= "    <lastmod>{$todayDate}</lastmod>\n";
        $sitemapXml .= "    <changefreq>daily</changefreq>\n";
        $sitemapXml .= "    <priority>0.9</priority>\n";
        $sitemapXml .= "  </url>\n";
    }
    $sitemapXml .= "</urlset>";

    // 2. Standalone robots.txt standar Google
    $robotsTxt = "User-agent: *\n";
    $robotsTxt .= "Allow: /\n\n";
    $robotsTxt .= "Sitemap: {$mainDomain}/sitemap.xml\n";

    // Buat ZIP
    $slugClean = preg_replace('/[^a-zA-Z0-9_\-]/', '', $project['slug'] ?: 'lp');
    $zipFilename = 'lp_' . $slugClean . '_' . date('Ymd_His') . '.zip';
    $zipPath = __DIR__ . '/../exports/' . $zipFilename;

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        return ['success' => false, 'message' => 'Gagal membuat file ZIP di server.'];
    }

    $zip->addFromString('index.html', $html);
    $zip->addFromString('sitemap.xml', $sitemapXml);
    $zip->addFromString('robots.txt', $robotsTxt);
    $zip->addFromString('.htaccess', get_standalone_htaccess(false));

    $zip->close();

    return [
        'success'   => true,
        'type'      => 'lp',
        'filename'  => $zipFilename,
        'filepath'  => $zipPath,
        'filesize'  => round(filesize($zipPath) / 1024, 2) . ' KB',
        'download_url' => '/api/download_export.php?file=' . urlencode($zipFilename)
    ];
}

/**
 * 2. PAKET STANDALONE GOOGLE AMP ZIP
 */
function create_amp_export_zip($pdo, $projectId, $userId) {
    cleanup_expired_exports(86400);

    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        return ['success' => false, 'message' => 'Project AMP tidak ditemukan.'];
    }

    $html = '';
    if (!empty(trim($project['article_content'] ?? ''))) {
        $html = $project['article_content'];
    } else {
        $tid = intval($project['template_id'] ?? 1);
        $stmtTpl = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
        $stmtTpl->execute([$tid]);
        $tplFile = $stmtTpl->fetchColumn();
        if ($tplFile && file_exists(__DIR__ . '/../cdn/templates/' . $tplFile)) {
            $html = file_get_contents(__DIR__ . '/../cdn/templates/' . $tplFile);
        }
    }

    if (empty($html)) {
        return ['success' => false, 'message' => 'Konten template AMP kosong.'];
    }

    $targetUrl = !empty($project['amp_url']) ? $project['amp_url'] : (!empty($project['canonical_url']) ? $project['canonical_url'] : '#');
    $loginUrl = !empty($project['login_url']) ? $project['login_url'] : $targetUrl;
    $regUrl   = !empty($project['register_url']) ? $project['register_url'] : $targetUrl;
    $brand    = !empty($project['brand_name']) ? $project['brand_name'] : $project['name'];

    // 1. Sinkronisasi seluruh field dan bersihkan 100% tag template {{ ... }} dari level terdalam
    $html = sync_and_clean_project_html($html, $project);

    $replaceTags = [
        '{{ brand_name }}'      => $brand,
        '{{ name }}'            => $project['name'],
        '{{ title }}'           => $project['title'] ?: ($brand . ' - Official Google AMP Page'),
        '{{ meta_description }}'=> $project['meta_description'] ?: '',
        '{{ canonical_url }}'   => $project['canonical_url'] ?: '',
        '{{ amp_url }}'         => $project['amp_url'] ?: '',
        '{{ login_url }}'       => $loginUrl,
        '{{ register_url }}'    => $regUrl,
        '{{ logo_url }}'        => $project['logo_url'] ?: '',
        '{{ banner_url }}'      => $project['banner_url'] ?: '',
        '{{ favicon_url }}'     => $project['favicon_url'] ?: '',
        '{{ gif_url }}'         => $project['gif_url'] ?: ($project['banner_url'] ?: ''),
        '{{ block:faqs }}'      => '',
        '{{ block:reviews }}'   => '',
        '{{ block:article }}'   => ''
    ];
    $html = strtr($html, $replaceTags);

    // Bersihkan sisa syntax template leak jika ada
    $html = preg_replace('/(?:\'|\")\)\s*\}\}/', '', $html) ?? $html;
    $html = preg_replace('/(?:\'|\")\s*\}\}/', '', $html) ?? $html;
    $html = preg_replace('/\{\{\s*[a-zA-Z0-9_:]+\s*\}\}/', '', $html) ?? $html;

    $html = preg_replace_callback('/<a\b[^>]*\bhref=(["\'])([^"\']*)\1[^>]*>/i', function($m) use ($loginUrl, $regUrl) {
        if (preg_match('/login|masuk|signin|auth/i', $m[2])) {
            return str_replace($m[1] . $m[2] . $m[1], '"' . $loginUrl . '"', $m[0]);
        }
        if (preg_match('/daftar|register|signup/i', $m[2])) {
            return str_replace($m[1] . $m[2] . $m[1], '"' . $regUrl . '"', $m[0]);
        }
        return $m[0];
    }, $html) ?? $html;

    // Purify standar Google AMP Core
    $html = purify_html_for_google($html, true, $project);
    // Pastikan 100% bebas kode template {{ ... }}
    $html = preg_replace('/\{\{\s*[a-zA-Z0-9_:]+\s*(?:\|[^\r\n\}]{0,600}?)?\}\}/', '', $html) ?? $html;
    $html = preg_replace('/(?:\'|\")\s*\)\s*\}\}/', '', $html) ?? $html;

    // Buat sitemap.xml & robots.txt otomatis untuk AMP
    $mainDomain = !empty($project['canonical_url']) ? rtrim($project['canonical_url'], '/') : 'https://domain-anda.com';
    $ampDomain  = !empty($project['amp_url']) ? rtrim($project['amp_url'], '/') : $mainDomain;
    $todayDate  = date('Y-m-d');

    // 1. Standalone sitemap.xml standar Google AMP
    $sitemapXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $sitemapXml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"\n";
    $sitemapXml .= "        xmlns:xhtml=\"http://www.w3.org/1999/xhtml\">\n";
    $sitemapXml .= "  <url>\n";
    $sitemapXml .= "    <loc>" . htmlspecialchars($ampDomain, ENT_XML1, 'UTF-8') . "/</loc>\n";
    $sitemapXml .= "    <lastmod>{$todayDate}</lastmod>\n";
    $sitemapXml .= "    <changefreq>daily</changefreq>\n";
    $sitemapXml .= "    <priority>1.0</priority>\n";
    if (!empty($project['canonical_url'])) {
        $sitemapXml .= "    <xhtml:link rel=\"canonical\" href=\"" . htmlspecialchars($mainDomain, ENT_XML1, 'UTF-8') . "/\" />\n";
    }
    $sitemapXml .= "  </url>\n";
    $sitemapXml .= "</urlset>";

    // 2. Standalone robots.txt standar Google
    $robotsTxt = "User-agent: *\n";
    $robotsTxt .= "Allow: /\n\n";
    $robotsTxt .= "Sitemap: {$ampDomain}/sitemap.xml\n";

    $slugClean = preg_replace('/[^a-zA-Z0-9_\-]/', '', $project['slug'] ?: 'amp');
    $zipFilename = 'amp_' . $slugClean . '_' . date('Ymd_His') . '.zip';
    $zipPath = __DIR__ . '/../exports/' . $zipFilename;

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        return ['success' => false, 'message' => 'Gagal membuat file ZIP di server.'];
    }

    $zip->addFromString('index.html', $html);
    $zip->addFromString('sitemap.xml', $sitemapXml);
    $zip->addFromString('robots.txt', $robotsTxt);
    $zip->addFromString('.htaccess', get_standalone_htaccess(false));

    $zip->close();

    return [
        'success'   => true,
        'type'      => 'amp',
        'filename'  => $zipFilename,
        'filepath'  => $zipPath,
        'filesize'  => round(filesize($zipPath) / 1024, 2) . ' KB',
        'download_url' => '/api/download_export.php?file=' . urlencode($zipFilename)
    ];
}

/**
 * 3. PAKET STANDALONE AUTO TUNNEL (SEO DOORWAY GATEWAY) ZIP
 */
function create_tunnel_export_zip($pdo) {
    cleanup_expired_exports(86400);

    $settings = get_tunnel_settings($pdo);

    $murl = rtrim($settings['tunnel_murl'], '/');
    $ampurl = rtrim($settings['tunnel_ampurl'], '/');
    $paramName = $settings['tunnel_param'] ?: 'gacor';
    $loginUrl = $settings['tunnel_login_url'] ?: ($ampurl . '/?' . $paramName . '=login');
    $regUrl = $settings['tunnel_register_url'] ?: ($ampurl . '/?' . $paramName . '=register');
    $title = $settings['tunnel_title'];
    $desc = $settings['tunnel_desc'];
    $favurl = $settings['tunnel_favurl'];
    $mainlogo = $settings['tunnel_mainlogo'];
    $maincontent = $settings['tunnel_maincontent'];
    $tag = $settings['tunnel_tag'];
    $defaultBrand = $settings['tunnel_default_brand'] ?: 'PENIDABET';
    $strict = ($settings['tunnel_strict_keywords'] ?? '1') === '1' ? '1' : '0';

    // Ambil Template LP yang dipilih untuk Tunnel
    $tplMode = $settings['tunnel_template_mode'] ?? 'project';
    $templatePhpCode = '';

    if ($tplMode === 'squarespace' && file_exists(__DIR__ . '/../tunnel_templates/squarespace.php')) {
        $templatePhpCode = file_get_contents(__DIR__ . '/../tunnel_templates/squarespace.php');
    } elseif ($tplMode === 'etsy' && file_exists(__DIR__ . '/../tunnel_templates/etsy.php')) {
        $templatePhpCode = file_get_contents(__DIR__ . '/../tunnel_templates/etsy.php');
    } else {
        // Ambil project LP yang dipilih dari database
        $projId = intval($settings['tunnel_project_id'] ?? 0);
        $project = null;
        if ($projId > 0) {
            $stmtP = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
            $stmtP->execute([$projId]);
            $project = $stmtP->fetch(PDO::FETCH_ASSOC);
        }
        if (!$project) {
            $stmtP = $pdo->query("SELECT * FROM projects ORDER BY id DESC LIMIT 1");
            $project = $stmtP->fetch(PDO::FETCH_ASSOC);
        }

        if ($project && !empty(trim($project['article_content'] ?? ''))) {
            $rawHtml = $project['article_content'];
        } elseif ($project) {
            $tid = intval($project['template_id'] ?? 1);
            $stmtTpl = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
            $stmtTpl->execute([$tid]);
            $tplFile = $stmtTpl->fetchColumn();
            if ($tplFile && file_exists(__DIR__ . '/../cdn/templates/' . $tplFile)) {
                $rawHtml = file_get_contents(__DIR__ . '/../cdn/templates/' . $tplFile);
            } else {
                $rawHtml = file_get_contents(__DIR__ . '/../tunnel_templates/squarespace.php');
            }
        } else {
            $rawHtml = file_get_contents(__DIR__ . '/../tunnel_templates/squarespace.php');
        }

        // Siapkan dynamic renderer template.php untuk standalone
        $templatePhpCode = <<<'PHP'
<?php
// Standalone Template Renderer
$replaceTags = [
    '{{ brand_name }}'      => $BRAND,
    '{{ name }}'            => $BRAND,
    '{{ title }}'           => $BRAND . ' : ' . $title,
    '{{ meta_description }}'=> $BRAND . ' ' . $desc,
    '{{ canonical_url }}'   => $canonicalUrl,
    '{{ amp_url }}'         => $ampFullUrl,
    '{{ login_url }}'       => $login_url,
    '{{ register_url }}'    => $register_url,
    '{{ logo_url }}'        => !empty($mainlogo) ? $mainlogo : '',
    '{{ banner_url }}'      => !empty($maincontent) ? $maincontent : '',
    '{{ favicon_url }}'     => !empty($favurl) ? $favurl : '',
    '{{ gif_url }}'         => !empty($maincontent) ? $maincontent : '',
    '{{ block:faqs }}'      => '',
    '{{ block:reviews }}'   => '',
    '{{ block:article }}'   => ''
];
$rendered = strtr($rawHtmlTemplate, $replaceTags);

if (preg_match('/<title\b[^>]*>(.*?)<\/title>/is', $rendered)) {
    $rendered = preg_replace('/<title\b[^>]*>(.*?)<\/title>/is', '<title>' . htmlspecialchars($BRAND . ' : ' . $title) . '</title>', $rendered);
}
if (preg_match('/<meta\b[^>]*\bname=["\']description["\'][^>]*>/i', $rendered)) {
    $rendered = preg_replace('/<meta\b[^>]*\bname=["\']description["\'][^>]*>/i', '<meta name="description" content="' . htmlspecialchars($BRAND . ' ' . $desc) . '">', $rendered);
}
if (preg_match('/<link\b[^>]*\brel=["\']canonical["\'][^>]*>/i', $rendered)) {
    $rendered = preg_replace('/<link\b[^>]*\brel=["\']canonical["\'][^>]*>/i', '<link rel="canonical" href="' . $canonicalUrl . '">', $rendered);
}
if (preg_match('/<link\b[^>]*\brel=["\']amphtml["\'][^>]*>/i', $rendered)) {
    $rendered = preg_replace('/<link\b[^>]*\brel=["\']amphtml["\'][^>]*>/i', '<link rel="amphtml" href="' . $ampFullUrl . '">', $rendered);
}

$rendered = preg_replace('/href=["\'][^"\']*login[^"\']*["\']/i', 'href="' . $login_url . '"', $rendered);
$rendered = preg_replace('/href=["\'][^"\']*(?:daftar|register)[^"\']*["\']/i', 'href="' . $register_url . '"', $rendered);

// Injeksi Schema.org WebSite & Product Standar Google
$schemaOrg = '<script type="application/ld+json">{"@context":"https://schema.org","@type":"WebSite","name":"' . addslashes($BRAND) . '","url":"' . addslashes($canonicalUrl) . '"}</script>';
if (stripos($rendered, '</head>') !== false) {
    $rendered = str_ireplace('</head>', $schemaOrg . "\n</head>", $rendered);
}

echo $rendered;
PHP;
        $templatePhpCode = "<?php\n\$rawHtmlTemplate = " . var_export($rawHtml, true) . ";\n?>\n" . $templatePhpCode;
    }

    // 1. Standalone meta.php
    $metaPhpContent = "<?php\n"
        . "// Standalone Meta & Configuration File\n"
        . "\$murl = " . var_export($murl, true) . ";\n"
        . "\$ampurl = " . var_export($ampurl, true) . ";\n"
        . "\$paramName = " . var_export($paramName, true) . ";\n"
        . "\$login_url = " . var_export($loginUrl, true) . ";\n"
        . "\$register_url = " . var_export($regUrl, true) . ";\n"
        . "\$title = " . var_export($title, true) . ";\n"
        . "\$desc = " . var_export($desc, true) . ";\n"
        . "\$tag = " . var_export($tag, true) . ";\n"
        . "\$favurl = " . var_export($favurl, true) . ";\n"
        . "\$mainlogo = " . var_export($mainlogo, true) . ";\n"
        . "\$maincontent = " . var_export($maincontent, true) . ";\n"
        . "\$banner = \$maincontent;\n"
        . "\$defaultBrand = " . var_export($defaultBrand, true) . ";\n"
        . "\$strictKeywords = " . ($strict === '1' ? 'true' : 'false') . ";\n";

    // 2. Standalone index.php (Gateway Tunnel)
    $indexPhpContent = <<<'PHP'
<?php
// Standalone Dynamic SEO Tunnel & Landing Page Gateway
header("Content-Type: text/html; charset=UTF-8");
require_once __DIR__ . '/meta.php';

function feedback404() {
    http_response_code(404);
    header("HTTP/1.0 404 Not Found");
    echo '<!DOCTYPE html><html><head><title>404 Not Found</title></head><body style="font-family:sans-serif;text-align:center;padding:50px;"><h1>404 Not Found</h1><p>Halaman atau kata kunci yang dicari tidak ditemukan.</p></body></html>';
    exit;
}

$rawParam = $_GET[$paramName] ?? '';
$BRAND = null;

if (!empty($rawParam)) {
    $target = strtolower(trim((string)$rawParam));
    $targetClean = preg_replace('/\s+/', ' ', str_replace(['-', '+', '_'], ' ', $target));
    $kwFile = __DIR__ . '/daftar.txt';
    if (file_exists($kwFile)) {
        $fh = fopen($kwFile, 'r');
        if ($fh) {
            while (($line = fgets($fh)) !== false) {
                $kw = strtolower(trim($line));
                if ($kw === $target || $kw === $targetClean) {
                    $BRAND = strtoupper($kw);
                    break;
                }
            }
            fclose($fh);
        }
    }
    if (!$BRAND && $strictKeywords) {
        feedback404();
    } elseif (!$BRAND) {
        $BRAND = strtoupper($targetClean);
    }
} else {
    $BRAND = strtoupper($defaultBrand ?: 'BRAND');
}

$BRANDS = $BRAND;
$canonicalUrl = rtrim($murl, '/') . '/?' . $paramName . '=' . urlencode(strtolower($BRAND));
$ampFullUrl = rtrim($ampurl, '/') . '/?' . $paramName . '=' . urlencode(strtolower($BRAND));

require __DIR__ . '/template.php';
PHP;

    // 3. Pastikan sitemap.xml valid 100% Google Standard
    $activeSitemap = $settings['sitemap_filename'] ?? 'sitemap.xml';
    $sitemapSourcePath = __DIR__ . '/../' . basename($activeSitemap);
    if (!file_exists($sitemapSourcePath)) {
        $sitemapSourcePath = __DIR__ . '/../sitemap.xml';
    }

    $sitemapContent = '';
    if (file_exists($sitemapSourcePath)) {
        $sitemapContent = file_get_contents($sitemapSourcePath);
        // Pastikan XML declaration ada
        if (strpos($sitemapContent, '<?xml') === false) {
            $sitemapContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" . $sitemapContent;
        }
    } else {
        // Fallback generate cepat jika file hilang
        generate_sitemap_xml($murl, $paramName, 'daily', '0.9', false);
        $sitemapContent = file_get_contents(__DIR__ . '/../sitemap.xml');
    }

    // 4. Salin daftar.txt
    $daftarPath = __DIR__ . '/../daftar.txt';
    $daftarContent = file_exists($daftarPath) ? file_get_contents($daftarPath) : "situs bola bisa cashout\nsitus bola bet 5000\n";

    // 5. Buat ZIP Installer
    $zipFilename = 'tunnel_installer_' . date('Ymd_His') . '.zip';
    $zipPath = __DIR__ . '/../exports/' . $zipFilename;

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        return ['success' => false, 'message' => 'Gagal membuat file ZIP Tunnel di server.'];
    }

    $zip->addFromString('index.php', $indexPhpContent);
    $zip->addFromString('meta.php', $metaPhpContent);
    $zip->addFromString('template.php', $templatePhpCode);
    $zip->addFromString('sitemap.xml', $sitemapContent);
    $zip->addFromString('daftar.txt', $daftarContent);
    $zip->addFromString('.htaccess', get_standalone_htaccess(true));
    $zip->addFromString('README.txt', "PAKET STANDALONE AUTO TUNNEL (SEO DOORWAY GATEWAY)\nTanggal Dibuat: " . date('Y-m-d H:i:s') . "\n\nBERKAS DALAM PAKET:\n- index.php    : Gerbang utama tunnel & landing page otomatis.\n- meta.php     : Konfigurasi target, URL daftar/login, title, desc, dll.\n- template.php : Desain visual Landing Page yang dipilih dari template.\n- sitemap.xml  : Sitemap XML valid standar Google (19.100 kata kunci).\n- daftar.txt   : Basis data 19.100 kata kunci pencocokan tunnel.\n- .htaccess    : Konfigurasi routing server Apache/LiteSpeed/cPanel.\n\nPANDUAN PASANG:\n1. Ekstrak seluruh berkas ZIP ini ke direktori root website Anda (misal public_html atau /var/www/html).\n2. Buka domain Anda dengan parameter (contoh: https://domain.com/?{$paramName}=situs+bola+bisa+cashout).\n3. Submit file sitemap.xml ke Google Search Console.\n4. Tombol DAFTAR & LOGIN otomatis aktif dan mengarah ke link Anda.\n\n*Catatan: Berkas ZIP installer ini otomatis dihapus dari penyimpanan server setelah 24 jam.\n");

    $zip->close();

    $sizeMb = round(filesize($zipPath) / 1048576, 2);
    $sizeFmt = ($sizeMb >= 1) ? $sizeMb . ' MB' : round(filesize($zipPath) / 1024, 2) . ' KB';

    return [
        'success'      => true,
        'type'         => 'tunnel',
        'filename'     => $zipFilename,
        'filepath'     => $zipPath,
        'filesize'     => $sizeFmt,
        'download_url' => '/api/download_export.php?file=' . urlencode($zipFilename)
    ];
}
