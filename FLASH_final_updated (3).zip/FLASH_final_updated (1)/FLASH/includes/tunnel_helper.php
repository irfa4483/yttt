<?php
// includes/tunnel_helper.php - Core Engine for SEO Doorway / Tunnel & Sitemap Management
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/purify_seo.php';

if (!function_exists('feedback404')) {
    function feedback404() {
        http_response_code(404);
        header("HTTP/1.0 404 Not Found");
        echo '<!DOCTYPE html><html><head><title>404 Not Found</title></head><body style="font-family:sans-serif; text-align:center; padding:50px;"><h1>404 Not Found</h1><p>Halaman atau kata kunci yang dicari tidak ditemukan.</p></body></html>';
        exit;
    }
}

/**
 * Mengambil konfigurasi Tunnel dari tabel settings dengan nilai default yang aman
 */
function get_tunnel_settings($pdo) {
    $defaults = [
        'tunnel_enabled'        => '1',
        'tunnel_param'          => 'gacor',
        'tunnel_strict_keywords'=> '1',
        'tunnel_template_mode'  => 'project', // 'project', 'squarespace', 'etsy'
        'tunnel_project_id'     => '0',
        'tunnel_murl'           => '',
        'tunnel_ampurl'         => 'https://situstogelmalamini.pages.dev/ampsitustogel',
        'tunnel_title'          => 'Sarana Terbaik Situs Togel Malam Ini dengan Hadiah Terbesar',
        'tunnel_desc'           => 'hadir dengan sarana terbaik situs togel malam ini dengan hadiah terbesar se asia, bisa di akses dimana pun kalian berada !',
        'tunnel_tag'            => 'PENIDABET',
        'tunnel_favurl'         => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiYtiNrK0sv9p1x2xQ7ofa2ghbszPRwQHoE4RVT3nCu_VEg8cJbFqUR-XSY0SsL1vaPOTzx_O-DegHED6gO4VnsIvikVsRnagG-szP9roMF1xZTPcTigCH_GOn8VvvEQDRt9XJRlyWLi0Q7BqQ_3gqq5kYVM2TF77c9Y-GraLn37Xg5ubp2e-ADHwUNqJDU/s1875/Image_20251205201308_2_116.png',
        'tunnel_mainlogo'       => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEisnxAn12_9D6235cgEVzbyvs9TR5oKx37E-R971nzEtG1pdBeY6GOOXn2WmQvAXFygBikx2SY_U-5Qx_WgMuxP9_203E99oPvrR5CEHcjeQPsBtO88gkw43Pzr2Snq5XH8l6bbKNzaF7YgZ2NTR__DW_MhLIyTEurnFlR6920zNsS82QLUAKQ2UDjPhq9P/s1254/cab7c0f7-2184-4385-bc6c-727f79357ff2.png',
        'tunnel_maincontent'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEisnxAn12_9D6235cgEVzbyvs9TR5oKx37E-R971nzEtG1pdBeY6GOOXn2WmQvAXFygBikx2SY_U-5Qx_WgMuxP9_203E99oPvrR5CEHcjeQPsBtO88gkw43Pzr2Snq5XH8l6bbKNzaF7YgZ2NTR__DW_MhLIyTEurnFlR6920zNsS82QLUAKQ2UDjPhq9P/s1254/cab7c0f7-2184-4385-bc6c-727f79357ff2.png',
        'tunnel_login_url'      => 'https://situstogelmalamini.com/login',
        'tunnel_register_url'   => 'https://situstogelmalamini.com/register',
        'tunnel_default_brand'  => 'PENIDABET',
        'tunnel_index_override' => '0',
        'sitemap_filename'      => 'sitemap.xml'
    ];

    $stmt = $pdo->query("SELECT key, value FROM settings WHERE key LIKE 'tunnel_%' OR key = 'sitemap_filename'");
    $saved = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    $settings = array_merge($defaults, $saved);

    // Auto detect Mother URL jika kosong
    if (empty($settings['tunnel_murl'])) {
        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $settings['tunnel_murl'] = $protocol . '://' . $host;
    }

    return $settings;
}

/**
 * Menyimpan pengaturan Tunnel ke database
 */
function save_tunnel_settings($pdo, $data) {
    $allowedKeys = [
        'tunnel_enabled', 'tunnel_param', 'tunnel_strict_keywords', 'tunnel_template_mode',
        'tunnel_project_id', 'tunnel_murl', 'tunnel_ampurl', 'tunnel_title', 'tunnel_desc',
        'tunnel_tag', 'tunnel_favurl', 'tunnel_mainlogo', 'tunnel_maincontent',
        'tunnel_login_url', 'tunnel_register_url', 'tunnel_default_brand', 'tunnel_index_override',
        'sitemap_filename'
    ];

    $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM settings WHERE key = ?");
    $stmtUpdate = $pdo->prepare("UPDATE settings SET value = ? WHERE key = ?");
    $stmtInsert = $pdo->prepare("INSERT INTO settings (key, value) VALUES (?, ?)");

    foreach ($data as $k => $v) {
        if (!in_array($k, $allowedKeys)) continue;
        $val = trim((string)$v);
        $stmtCheck->execute([$k]);
        if ($stmtCheck->fetchColumn() > 0) {
            $stmtUpdate->execute([$val, $k]);
        } else {
            $stmtInsert->execute([$k, $val]);
        }
    }
}

/**
 * Mencari kecocokan kata kunci di daftar.txt
 */
function match_tunnel_keyword($target, $strict = true) {
    $target = strtolower(trim((string)$target));
    if ($target === '') return false;

    // Bersihkan karakter spasi ganda, dash, atau plus
    $targetClean = preg_replace('/\s+/', ' ', str_replace(['-', '+', '_'], ' ', $target));

    $filePath = __DIR__ . '/../daftar.txt';
    if (!file_exists($filePath)) {
        // Jika file tidak ada dan strict mode non-aktif, kembalikan target
        return !$strict ? strtoupper($targetClean) : false;
    }

    $handle = fopen($filePath, 'r');
    if (!$handle) {
        return !$strict ? strtoupper($targetClean) : false;
    }

    $foundBrand = false;
    while (($line = fgets($handle)) !== false) {
        $keyword = strtolower(trim($line));
        if ($keyword === '') continue;

        if ($keyword === $target || $keyword === $targetClean) {
            $foundBrand = strtoupper($keyword);
            break;
        }
    }
    fclose($handle);

    if ($foundBrand) {
        return $foundBrand;
    }

    return !$strict ? strtoupper($targetClean) : false;
}

/**
 * Mengambil statistik file sitemap XML aktif
 */
function get_sitemap_stats($filename = 'sitemap.xml') {
    if (empty($filename)) $filename = 'sitemap.xml';
    $filename = basename($filename);
    $path = __DIR__ . '/../' . $filename;
    if (!file_exists($path)) {
        return ['exists' => false, 'filename' => $filename, 'count' => 0, 'size' => 0, 'modified' => null, 'detected_domain' => ''];
    }

    $size = filesize($path);
    $modified = filemtime($path);

    // Hitung jumlah <loc> dan deteksi domain yang sedang digunakan
    $count = 0;
    $detectedDomain = '';
    $handle = fopen($path, 'r');
    if ($handle) {
        while (($buffer = fgets($handle, 4096)) !== false) {
            $count += substr_count($buffer, '<loc>');
            if (empty($detectedDomain) && preg_match('/<loc>(https?:\/\/[^\/?]+)/i', $buffer, $m)) {
                $detectedDomain = $m[1];
            }
        }
        fclose($handle);
    }

    return [
        'exists'          => true,
        'filename'        => $filename,
        'count'           => $count,
        'size'            => $size,
        'size_fmt'        => ($size > 1048576) ? round($size / 1048576, 2) . ' MB' : round($size / 1024, 2) . ' KB',
        'modified'        => date('d M Y H:i:s', $modified),
        'detected_domain' => $detectedDomain
    ];
}

/**
 * Mengubah nama berkas sitemap di server (Rename File)
 */
function rename_sitemap_file($pdo, $oldName, $newName) {
    $oldName = basename(trim((string)$oldName));
    $newName = basename(trim((string)$newName));

    if (empty($newName)) {
        return ['success' => false, 'message' => 'Nama berkas baru tidak boleh kosong.'];
    }

    if (!str_ends_with(strtolower($newName), '.xml')) {
        $newName .= '.xml';
    }

    // Bersihkan karakter aneh
    $newName = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $newName);

    $oldPath = __DIR__ . '/../' . $oldName;
    $newPath = __DIR__ . '/../' . $newName;

    if (!file_exists($oldPath)) {
        return ['success' => false, 'message' => "Berkas $oldName tidak ditemukan di server."];
    }

    if ($oldPath === $newPath) {
        return ['success' => true, 'filename' => $newName, 'message' => 'Nama berkas tidak berubah.'];
    }

    if (rename($oldPath, $newPath)) {
        save_tunnel_settings($pdo, ['sitemap_filename' => $newName]);
        return ['success' => true, 'filename' => $newName, 'message' => "Nama berkas sitemap berhasil diubah dari $oldName menjadi $newName!"];
    }

    return ['success' => false, 'message' => 'Gagal mengubah nama berkas. Periksa izin tulis (permissions) folder.'];
}

/**
 * Mengubah nama domain di dalam sitemap asli tanpa men-generate ulang (Stream Replace)
 */
function replace_sitemap_domain($filename, $newDomain, $oldDomain = null) {
    $filename = basename(trim((string)$filename ?: 'sitemap.xml'));
    $path = __DIR__ . '/../' . $filename;
    if (!file_exists($path)) {
        return ['success' => false, 'message' => "Berkas $filename tidak ditemukan di server."];
    }

    $newDomain = rtrim(trim((string)$newDomain), '/');
    if (empty($newDomain)) {
        return ['success' => false, 'message' => 'Domain baru tidak boleh kosong.'];
    }

    // Auto-detect domain lama jika kosong
    if (empty($oldDomain)) {
        $fp = fopen($path, 'r');
        if ($fp) {
            while (($line = fgets($fp)) !== false) {
                if (preg_match('/<loc>(https?:\/\/[^\/?]+)/i', $line, $m)) {
                    $oldDomain = $m[1];
                    break;
                }
            }
            fclose($fp);
        }
    }

    if (empty($oldDomain)) {
        return ['success' => false, 'message' => 'Gagal mendeteksi domain lama di dalam berkas sitemap.'];
    }

    $oldDomain = rtrim(trim($oldDomain), '/');
    if ($oldDomain === $newDomain) {
        return ['success' => true, 'count' => 0, 'message' => 'Nama domain di dalam sitemap sudah sesuai dengan domain tujuan.'];
    }

    // Stream Replace hemat memori
    $tempPath = $path . '.tmp';
    $in = fopen($path, 'r');
    $out = fopen($tempPath, 'w');
    if (!$in || !$out) {
        if ($in) fclose($in);
        if ($out) fclose($out);
        return ['success' => false, 'message' => 'Gagal membuka berkas sitemap untuk pembaruan nama domain.'];
    }

    $replacedCount = 0;
    while (($line = fgets($in)) !== false) {
        if (strpos($line, $oldDomain) !== false) {
            $line = str_replace($oldDomain, $newDomain, $line);
            $replacedCount++;
        }
        fwrite($out, $line);
    }
    fclose($in);
    fclose($out);

    unlink($path);
    rename($tempPath, $path);

    return [
        'success'   => true,
        'count'     => $replacedCount,
        'oldDomain' => $oldDomain,
        'newDomain' => $newDomain,
        'message'   => "Nama domain di dalam sitemap asli berhasil diperbarui dari $oldDomain menjadi $newDomain pada " . number_format($replacedCount) . " URL!"
    ];
}

/**
 * Mengambil statistik file daftar.txt
 */
function get_keywords_stats() {
    $path = __DIR__ . '/../daftar.txt';
    if (!file_exists($path)) {
        return ['exists' => false, 'count' => 0, 'size' => 0, 'sample' => []];
    }

    $size = filesize($path);
    $count = 0;
    $sample = [];

    $handle = fopen($path, 'r');
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $kw = trim($line);
            if ($kw === '') continue;
            $count++;
            if ($count <= 10) {
                $sample[] = $kw;
            }
        }
        fclose($handle);
    }

    return [
        'exists'   => true,
        'count'    => $count,
        'size'     => $size,
        'size_fmt' => ($size > 1048576) ? round($size / 1048576, 2) . ' MB' : round($size / 1024, 2) . ' KB',
        'sample'   => $sample
    ];
}

/**
 * Generate sitemap.xml otomatis dari daftar.txt
 */
function generate_sitemap_xml($domain, $param = 'gacor', $changefreq = 'daily', $priority = '0.9', $encodeSpaces = false) {
    $daftarPath = __DIR__ . '/../daftar.txt';
    $sitemapPath = __DIR__ . '/../sitemap.xml';

    if (!file_exists($daftarPath)) {
        return ['success' => false, 'message' => 'File daftar.txt tidak ditemukan. Silakan tambahkan kata kunci terlebih dahulu.'];
    }

    $in = fopen($daftarPath, 'r');
    if (!$in) {
        return ['success' => false, 'message' => 'Gagal membuka file daftar.txt untuk dibaca.'];
    }

    $out = fopen($sitemapPath, 'w');
    if (!$out) {
        fclose($in);
        return ['success' => false, 'message' => 'Gagal membuat file sitemap.xml. Periksa izin tulis (permissions) di folder root.'];
    }

    $domain = rtrim($domain, '/');
    fwrite($out, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fwrite($out, '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n");

    $count = 0;
    while (($line = fgets($in)) !== false) {
        $keyword = trim($line);
        if ($keyword === '') continue;

        $targetQuery = $encodeSpaces ? rawurlencode($keyword) : htmlspecialchars($keyword, ENT_XML1, 'UTF-8');
        $loc = $domain . '/?' . $param . '=' . $targetQuery;

        $xmlLine = '<url><loc>' . htmlspecialchars($loc, ENT_XML1, 'UTF-8') . '</loc><changefreq>' . $changefreq . '</changefreq><priority>' . $priority . '</priority></url>' . "\n";
        fwrite($out, $xmlLine);
        $count++;
    }

    fwrite($out, '</urlset>' . "\n");
    fclose($in);
    fclose($out);

    return ['success' => true, 'count' => $count, 'message' => "Berhasil men-generate sitemap.xml dengan $count URL kata kunci!"];
}

/**
 * Hapus sitemap.xml
 */
function delete_sitemap_xml() {
    $path = __DIR__ . '/../sitemap.xml';
    if (file_exists($path)) {
        if (@unlink($path)) {
            return ['success' => true, 'message' => 'File sitemap.xml berhasil dihapus.'];
        }
        return ['success' => false, 'message' => 'Gagal menghapus file sitemap.xml. Periksa permission file.'];
    }
    return ['success' => true, 'message' => 'File sitemap.xml memang belum ada.'];
}

/**
 * Simpan atau tambah kata kunci ke daftar.txt
 */
function save_keywords_list($content, $append = false) {
    $path = __DIR__ . '/../daftar.txt';
    $mode = $append ? 'a' : 'w';
    $fh = fopen($path, $mode);
    if (!$fh) {
        return ['success' => false, 'message' => 'Gagal membuka file daftar.txt untuk penulisan.'];
    }

    $lines = preg_split('/\r\n|\r|\n/', $content);
    $written = 0;
    foreach ($lines as $line) {
        $kw = trim($line);
        if ($kw !== '') {
            fwrite($fh, $kw . "\n");
            $written++;
        }
    }
    fclose($fh);

    return ['success' => true, 'count' => $written, 'message' => "Berhasil menyimpan $written kata kunci ke daftar.txt!"];
}

/**
 * Cek apakah request saat ini harus ditangani oleh tunnel
 */
function should_handle_tunnel_request() {
    global $pdo;
    $settings = get_tunnel_settings($pdo);

    if (($settings['tunnel_enabled'] ?? '1') !== '1') {
        return false;
    }

    $param = $settings['tunnel_param'] ?? 'gacor';

    // 1. Ada parameter tunnel khusus di URL (misal: ?gacor=situs bola bisa cashout)
    if (isset($_GET[$param]) && trim($_GET[$param]) !== '') {
        return true;
    }

    // 2. Mode Index Override aktif: pengunjung biasa di root / (bukan admin/member auth/api)
    $reqUri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($reqUri, PHP_URL_PATH) ?? '/';

    if (($settings['tunnel_index_override'] ?? '0') === '1') {
        if ($path === '/' || $path === '/index.php') {
            // Kecualikan jika sudah login atau mengakses auth
            if (!str_starts_with($path, '/auth') && !str_starts_with($path, '/user') && !str_starts_with($path, '/admin') && !str_starts_with($path, '/api')) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Eksekusi Rendering Tunnel
 */
function handle_tunnel_request() {
    global $pdo;
    $settings = get_tunnel_settings($pdo);

    $paramName = $settings['tunnel_param'] ?? 'gacor';
    $rawKeyword = $_GET[$paramName] ?? '';

    $strict = ($settings['tunnel_strict_keywords'] ?? '1') === '1';

    if (!empty($rawKeyword)) {
        $BRAND = match_tunnel_keyword($rawKeyword, $strict);
        if (!$BRAND) {
            feedback404();
            exit;
        }
    } else {
        // Mode index override tanpa parameter query
        $BRAND = strtoupper($settings['tunnel_default_brand'] ?? 'BRAND');
    }

    $BRANDS = $BRAND;

    // Persiapkan Variabel Global Tunnel
    $murl = rtrim($settings['tunnel_murl'], '/');
    $ampurl = rtrim($settings['tunnel_ampurl'], '/');
    $favurl = $settings['tunnel_favurl'];
    $mainlogo = $settings['tunnel_mainlogo'];
    $maincontent = $settings['tunnel_maincontent'];
    $banner = $maincontent;
    $title = $settings['tunnel_title'];
    $desc = $settings['tunnel_desc'];
    $tag = $settings['tunnel_tag'];
    $login_url = !empty($settings['tunnel_login_url']) ? $settings['tunnel_login_url'] : ($ampurl . '/?' . $paramName . '=' . urlencode(strtolower($BRAND)));
    $register_url = !empty($settings['tunnel_register_url']) ? $settings['tunnel_register_url'] : ($ampurl . '/?' . $paramName . '=' . urlencode(strtolower($BRAND)));

    $fullCurrentUrl = $murl . '/?' . $paramName . '=' . urlencode(strtolower($BRAND));
    $canonicalUrl = $fullCurrentUrl;
    $ampFullUrl = $ampurl . '/?' . $paramName . '=' . urlencode(strtolower($BRAND));

    $tplMode = $settings['tunnel_template_mode'] ?? 'project';

    // Opsi 1: Mengikuti Landing Page (LP) dari salah satu Project pengguna
    if ($tplMode === 'project') {
        $projId = intval($settings['tunnel_project_id'] ?? 0);
        $project = null;

        if ($projId > 0) {
            $stmtP = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
            $stmtP->execute([$projId]);
            $project = $stmtP->fetch(PDO::FETCH_ASSOC);
        }

        if (!$project) {
            // Ambil project terbaru
            $stmtP = $pdo->query("SELECT * FROM projects ORDER BY id DESC LIMIT 1");
            $project = $stmtP->fetch(PDO::FETCH_ASSOC);
        }

        if ($project) {
            // Override data project dengan variabel dinamis tunnel
            $project['name'] = $BRAND;
            $project['brand_name'] = $BRAND;
            $project['title'] = $BRAND . ' : ' . $title;
            $project['meta_description'] = $BRAND . ' ' . $desc;
            $project['canonical_url'] = $canonicalUrl;
            $project['amp_url'] = $ampFullUrl;
            $project['login_url'] = $login_url;
            $project['register_url'] = $register_url;
            if (!empty($favurl)) $project['favicon_url'] = $favurl;
            if (!empty($mainlogo)) $project['logo_url'] = $mainlogo;
            if (!empty($maincontent)) $project['banner_url'] = $maincontent;

            // Render HTML dari Project
            $html = '';
            if (!empty(trim($project['article_content'] ?? ''))) {
                $html = $project['article_content'];
            } else {
                $tid = intval($project['template_id'] ?? 1);
                $stmtTpl = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
                $stmtTpl->execute([$tid]);
                $tplFile = $stmtTpl->fetchColumn();
                if ($tplFile && file_exists(__DIR__ . '/../cdn/templates/' . $tplFile)) {
                    $html = file_get_contents(__DIR__ . '/../cdn/templates/' . $tplFile);
                }
            }

            if (empty($html)) {
                // Fallback jika project kosong
                $html = file_get_contents(__DIR__ . '/../tunnel_templates/squarespace.php');
            }

            // Ganti tag template
            $replaceTags = [
                '{{ brand_name }}'     => $BRAND,
                '{{ name }}'           => $BRAND,
                '{{ title }}'          => $project['title'],
                '{{ meta_description }}'=> $project['meta_description'],
                '{{ canonical_url }}'  => $canonicalUrl,
                '{{ amp_url }}'        => $ampFullUrl,
                '{{ login_url }}'      => $login_url,
                '{{ register_url }}'   => $register_url,
                '{{ logo_url }}'       => $project['logo_url'],
                '{{ banner_url }}'     => $project['banner_url'],
                '{{ favicon_url }}'    => $project['favicon_url'],
                '{{ gif_url }}'        => $project['banner_url'],
                '{{ block:faqs }}'     => '',
                '{{ block:reviews }}'  => '',
                '{{ block:article }}'  => ''
            ];
            $html = strtr($html, $replaceTags);

            // Ganti canonical, amphtml, title, description jika sudah ada tag lama di HTML project
            if (preg_match('/<title\b[^>]*>(.*?)<\/title>/is', $html)) {
                $html = preg_replace('/<title\b[^>]*>(.*?)<\/title>/is', '<title>' . htmlspecialchars($project['title']) . '</title>', $html);
            }
            if (preg_match('/<meta\b[^>]*\bname=["\']description["\'][^>]*>/i', $html)) {
                $html = preg_replace('/<meta\b[^>]*\bname=["\']description["\'][^>]*>/i', '<meta name="description" content="' . htmlspecialchars($project['meta_description']) . '">', $html);
            }
            if (preg_match('/<link\b[^>]*\brel=["\']canonical["\'][^>]*>/i', $html)) {
                $html = preg_replace('/<link\b[^>]*\brel=["\']canonical["\'][^>]*>/i', '<link rel="canonical" href="' . $canonicalUrl . '">', $html);
            }
            if (preg_match('/<link\b[^>]*\brel=["\']amphtml["\'][^>]*>/i', $html)) {
                $html = preg_replace('/<link\b[^>]*\brel=["\']amphtml["\'][^>]*>/i', '<link rel="amphtml" href="' . $ampFullUrl . '">', $html);
            }

            // Ganti semua link login/daftar statis yang mungkin masih ada
            $html = preg_replace('/href=["\'][^"\']*login[^"\']*["\']/i', 'href="' . $login_url . '"', $html);
            $html = preg_replace('/href=["\'][^"\']*(?:daftar|register)[^"\']*["\']/i', 'href="' . $register_url . '"', $html);

            // Purify untuk standar Google SEO Core
            $isAmp = (bool) preg_match('/<html\b[^>]*\b(amp|⚡)\b[^>]*>/i', $html) || (($project['type'] ?? '') === 'amp');
            $html = purify_html_for_google($html, $isAmp, $project);

            header("Content-Type: text/html; charset=UTF-8");
            echo $html;
            exit;
        }
    }

    // Persiapkan fake project data untuk purify template bawaan
    $fakeProject = [
        'name'             => $BRAND,
        'brand_name'       => $BRAND,
        'title'            => $BRAND . ' : ' . $title,
        'meta_description' => $BRAND . ' ' . $desc,
        'canonical_url'    => $canonicalUrl,
        'amp_url'          => $ampFullUrl,
        'login_url'        => $login_url,
        'register_url'     => $register_url,
        'banner_url'       => $banner,
        'logo_url'         => $mainlogo,
        'favicon_url'      => $favurl
    ];

    // Opsi 2: Template Bawaan Squarespace
    if ($tplMode === 'squarespace') {
        $tplPath = __DIR__ . '/../tunnel_templates/squarespace.php';
        if (file_exists($tplPath)) {
            ob_start();
            include $tplPath;
            $rawHtml = ob_get_clean();
            $isAmp = (bool) preg_match('/<html\b[^>]*\b(amp|⚡)\b[^>]*>/i', $rawHtml);
            $cleanHtml = purify_html_for_google($rawHtml, $isAmp, $fakeProject);
            header("Content-Type: text/html; charset=UTF-8");
            echo $cleanHtml;
            exit;
        }
    }

    // Opsi 3: Template Bawaan Etsy
    if ($tplMode === 'etsy') {
        $tplPath = __DIR__ . '/../tunnel_templates/etsy.php';
        if (file_exists($tplPath)) {
            ob_start();
            include $tplPath;
            $rawHtml = ob_get_clean();
            $isAmp = (bool) preg_match('/<html\b[^>]*\b(amp|⚡)\b[^>]*>/i', $rawHtml);
            $cleanHtml = purify_html_for_google($rawHtml, $isAmp, $fakeProject);
            header("Content-Type: text/html; charset=UTF-8");
            echo $cleanHtml;
            exit;
        }
    }

    // Default Fallback
    $tplPath = __DIR__ . '/../tunnel_templates/squarespace.php';
    ob_start();
    include $tplPath;
    $rawHtml = ob_get_clean();
    $cleanHtml = purify_html_for_google($rawHtml, false, $fakeProject);
    header("Content-Type: text/html; charset=UTF-8");
    echo $cleanHtml;
    exit;
}
