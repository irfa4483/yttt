<?php
// includes/header.php
require_once __DIR__ . '/auth.php';
$user = current_user();
$pageTitle = $pageTitle ?? 'Sistem Autentikasi PHP';
$initialToasts = get_flashes();
?>
<!DOCTYPE html>
<html lang="id" class="h-full bg-slate-950 text-slate-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - Modern Auth System</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            900: '#312e81',
                        }
                    }
                }
            }
        }
    </script>
    <!-- Alpine.js CDN -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .glass-card {
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="h-full flex flex-col antialiased bg-slate-950 text-slate-100" 
      x-data="globalApp(<?= htmlspecialchars(json_encode($initialToasts), ENT_QUOTES, 'UTF-8') ?>)">

    <!-- Floating Custom Toast Notification System -->
    <div class="fixed top-5 right-5 z-50 flex flex-col gap-3 w-full max-w-sm pointer-events-none" x-cloak>
        <template x-for="t in toasts" :key="t.id">
            <div x-show="t.visible"
                 x-transition:enter="transition ease-out duration-300 transform"
                 x-transition:enter-start="opacity-0 translate-x-8 scale-95"
                 x-transition:enter-end="opacity-100 translate-x-0 scale-100"
                 x-transition:leave="transition ease-in duration-200 transform"
                 x-transition:leave-start="opacity-100 translate-x-0 scale-100"
                 x-transition:leave-end="opacity-0 translate-x-8 scale-95"
                 class="pointer-events-auto p-4 rounded-2xl border shadow-2xl backdrop-blur-xl flex items-start gap-3.5 relative overflow-hidden"
                 :class="{
                    'bg-slate-900/90 border-emerald-500/30 text-emerald-300 shadow-emerald-950/40': t.type === 'success',
                    'bg-slate-900/90 border-rose-500/30 text-rose-300 shadow-rose-950/40': t.type === 'error',
                    'bg-slate-900/90 border-amber-500/30 text-amber-300 shadow-amber-950/40': t.type === 'warning',
                    'bg-slate-900/90 border-brand-500/30 text-indigo-300 shadow-indigo-950/40': t.type === 'info'
                 }">
                
                <!-- Toast Icon -->
                <div class="mt-0.5 text-lg flex-shrink-0">
                    <template x-if="t.type === 'success'"><i class="fa-solid fa-circle-check text-emerald-400"></i></template>
                    <template x-if="t.type === 'error'"><i class="fa-solid fa-circle-xmark text-rose-400"></i></template>
                    <template x-if="t.type === 'warning'"><i class="fa-solid fa-triangle-exclamation text-amber-400"></i></template>
                    <template x-if="t.type === 'info'"><i class="fa-solid fa-circle-info text-brand-400"></i></template>
                </div>

                <!-- Toast Content -->
                <div class="flex-1 pr-2">
                    <h4 class="text-xs font-bold uppercase tracking-wider mb-0.5" 
                        x-text="t.type === 'success' ? 'Sukses' : (t.type === 'error' ? 'Kesalahan' : (t.type === 'warning' ? 'Peringatan' : 'Informasi'))"></h4>
                    <p class="text-xs text-slate-200 leading-relaxed font-medium" x-text="t.message"></p>
                </div>

                <!-- Close Button -->
                <button @click="dismissToast(t.id)" class="text-slate-400 hover:text-white transition-colors p-1">
                    <i class="fa-solid fa-xmark text-xs"></i>
                </button>
            </div>
        </template>
    </div>

    <!-- Custom Animated Confirmation Modal (Replaces Browser Default confirm()) -->
    <div x-show="confirmModal.open" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md" 
         x-cloak>
        
        <div @click.away="confirmModal.open = false"
             class="glass-card w-full max-w-md p-6 rounded-3xl border border-slate-700 shadow-2xl space-y-5 text-center">
            
            <!-- Icon Header -->
            <div class="mx-auto w-14 h-14 rounded-2xl flex items-center justify-center text-2xl"
                 :class="{
                    'bg-rose-500/10 text-rose-400 border border-rose-500/20': confirmModal.variant === 'danger',
                    'bg-amber-500/10 text-amber-400 border border-amber-500/20': confirmModal.variant === 'warning',
                    'bg-brand-500/10 text-brand-400 border border-brand-500/20': confirmModal.variant === 'info'
                 }">
                <i class="fa-solid" :class="confirmModal.icon || 'fa-triangle-exclamation'"></i>
            </div>

            <!-- Title & Message -->
            <div class="space-y-2">
                <h3 class="text-lg font-bold text-white" x-text="confirmModal.title"></h3>
                <p class="text-xs text-slate-400 leading-relaxed" x-text="confirmModal.message"></p>
            </div>

            <!-- Action Buttons -->
            <div class="flex items-center justify-center gap-3 pt-2">
                <button type="button" @click="confirmModal.open = false" 
                        class="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-all">
                    Batal
                </button>
                <button type="button" @click="confirmModal.onConfirm()" 
                        class="px-5 py-2.5 rounded-xl font-semibold text-xs text-white shadow-lg transition-all"
                        :class="{
                            'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30': confirmModal.variant === 'danger',
                            'bg-amber-600 hover:bg-amber-500 shadow-amber-600/30': confirmModal.variant === 'warning',
                            'bg-brand-600 hover:bg-brand-500 shadow-brand-600/30': confirmModal.variant === 'info'
                        }"
                        x-text="confirmModal.confirmText || 'Ya, Lanjutkan'">
                </button>
            </div>
        </div>
    </div>

    <script>
        function globalApp(serverToasts) {
            return {
                toasts: serverToasts.map(t => ({ ...t, visible: true })),
                confirmModal: {
                    open: false,
                    title: '',
                    message: '',
                    variant: 'danger',
                    icon: 'fa-triangle-exclamation',
                    confirmText: 'Ya, Lanjutkan',
                    onConfirm: () => {}
                },
                init() {
                    // Auto dismiss server toasts
                    this.toasts.forEach(t => {
                        setTimeout(() => this.dismissToast(t.id), 4500);
                    });

                    // Expose helper modal global
                    window.showToast = (type, message) => {
                        const id = Date.now();
                        this.toasts.push({ id, type, message, visible: true });
                        setTimeout(() => this.dismissToast(id), 4500);
                    };

                    window.customConfirm = (opts) => {
                        this.confirmModal.title = opts.title || 'Konfirmasi Tindakan';
                        this.confirmModal.message = opts.message || 'Apakah Anda yakin ingin melanjutkan?';
                        this.confirmModal.variant = opts.variant || 'danger';
                        this.confirmModal.icon = opts.icon || 'fa-triangle-exclamation';
                        this.confirmModal.confirmText = opts.confirmText || 'Ya, Lanjutkan';
                        this.confirmModal.onConfirm = () => {
                            this.confirmModal.open = false;
                            if (typeof opts.onConfirm === 'function') opts.onConfirm();
                        };
                        this.confirmModal.open = true;
                    };
                },
                dismissToast(id) {
                    const toast = this.toasts.find(t => t.id === id);
                    if (toast) {
                        toast.visible = false;
                        setTimeout(() => {
                            this.toasts = this.toasts.filter(t => t.id !== id);
                        }, 300);
                    }
                }
            }
        }
    </script>
