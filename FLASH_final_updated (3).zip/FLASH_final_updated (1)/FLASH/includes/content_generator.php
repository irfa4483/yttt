<?php
// Function to generate fresh unique FAQs and SEO content based on brand and keywords (100% tanpa AI)
function generate_unique_faqs($brandName) {
    $pool = [
        [
            'q' => "Apa itu {$brandName} dan bagaimana cara aksesnya?",
            'a' => "{$brandName} adalah platform situs resmi terpercaya dengan dukungan teknologi modern, keamanan sistem tinggi, serta layanan akses 24 jam nonstop tanpa gangguan."
        ],
        [
            'q' => "Apakah pendaftaran akun di {$brandName} gratis?",
            'a' => "Ya, pendaftaran akun baru di {$brandName} 100% gratis, proses verifikasi data kilat kurang dari 2 menit dan langsung aktif untuk digunakan."
        ],
        [
            'q' => "Metode transaksi apa saja yang tersedia di {$brandName}?",
            'a' => "{$brandName} menyediakan opsi pembayaran lengkap mulai dari transfer bank lokal (BCA, Mandiri, BNI, BRI), e-wallet (QRIS, Dana, OVO, Gopay), hingga pulsa tanpa potongan."
        ],
        [
            'q' => "Bagaimana cara mendapatkan link alternatif resmi {$brandName}?",
            'a' => "Pengguna dapat mengakses halaman resmi {$brandName} atau menghubungi layanan Customer Service melalui Livechat & WhatsApp resmi yang siap membantu setiap hari."
        ],
        [
            'q' => "Berapa minimal transaksi deposit dan penarikan di {$brandName}?",
            'a' => "Minimal deposit di {$brandName} sangat terjangkau yaitu Rp 5.000, serta penarikan dana diproses otomatis dengan sistem terpercaya dan transparan."
        ],
        [
            'q' => "Apakah {$brandName} bisa diakses lancar melalui smartphone?",
            'a' => "Tentu saja, {$brandName} didesain responsif dan mendukung teknologi Google AMP sehingga sangat ringan, cepat, dan hemat kuota saat diakses di perangkat HP Android maupun iOS."
        ]
    ];
    
    // Shuffle and pick 3-4 unique FAQs
    shuffle($pool);
    return array_slice($pool, 0, 4);
}

// Function to generate fresh reviews
function generate_unique_reviews($brandName) {
    $reviewsPool = [
        [
            'name' => 'Budi Santoso',
            'location' => 'Jakarta',
            'rating' => '5',
            'text' => "Layanan {$brandName} sangat memuaskan! Proses transaksi super cepat dan akses halamannya sangat enteng di ponsel."
        ],
        [
            'name' => 'Reza Fahlevi',
            'location' => 'Surabaya',
            'rating' => '5',
            'text' => "Situs terpercaya yang pernah saya temukan. Sistem keamanan {$brandName} mantap dan Customer Service selalu ramah merespon."
        ],
        [
            'name' => 'Dewi Anggraini',
            'location' => 'Bandung',
            'rating' => '5',
            'text' => "Rekomendasi terbaik! Tampilan {$brandName} simpel tapi elegan, transparan dan tidak pernah ada kendala saat bermain."
        ],
        [
            'name' => 'Fajar Nugraha',
            'location' => 'Medan',
            'rating' => '5',
            'text' => "Daftar di {$brandName} mudah banget, verifikasi instan dan banyak promo menarik setiap minggunya."
        ]
    ];
    shuffle($reviewsPool);
    return $reviewsPool;
}
