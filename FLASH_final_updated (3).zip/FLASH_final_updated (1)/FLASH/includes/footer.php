<?php
// includes/footer.php
?>
    <footer class="mt-auto border-t border-slate-800 bg-slate-900/50 py-4 text-center text-xs text-slate-500">
        <div class="max-w-7xl mx-auto px-4">
            <p>&copy; <?= date('Y') ?> Modern PHP Auth System &bull; SQLite PDO & Tailwind CSS & Alpine.js</p>
        </div>
    </footer>
</body>
</html>
