<?php
// router.php - PHP built-in server router
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$filePath = __DIR__ . $path;

// Static files (css, js, images, fonts, etc.)
if ($path !== '/' && file_exists($filePath) && is_file($filePath)) {
    $ext = pathinfo($filePath, PATHINFO_EXTENSION);
    if ($ext !== 'php') {
        return false; // serve static by built-in server
    }
    require $filePath;
    return;
}

// Directory → coba index.php
if (is_dir($filePath)) {
    $idx = rtrim($filePath, '/') . '/index.php';
    if (file_exists($idx)) { require $idx; return; }
}

// Root
if ($path === '/' || $path === '') {
    require __DIR__ . '/index.php';
    return;
}

http_response_code(404);
echo "<h1>404</h1><p>$path not found</p>";
