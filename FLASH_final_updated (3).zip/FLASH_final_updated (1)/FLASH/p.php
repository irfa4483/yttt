<?php
// p.php - Published & Live Preview Page Renderer
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/purify_seo.php';

// Allow iframe embedding for preview
header("X-Frame-Options: SAMEORIGIN");
header("Content-Type: text/html; charset=UTF-8");

$slug = trim($_GET['s'] ?? '');
$id   = intval($_GET['id'] ?? 0);
$isPreview = isset($_GET['preview']) && $_GET['preview'] == '1';

$project = null;

if (!empty($slug)) {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE slug = ?");
    $stmt->execute([$slug]);
    $project = $stmt->fetch();
} 

if (!$project && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $project = $stmt->fetch();
}

// Jika project tidak ditemukan, return 404
if (!$project) {
    http_response_code(404);
    echo "<h1>404 Not Found</h1><p>Project tidak ditemukan.</p>";
    exit;
}

// Simpan salinan data project DB sebelum di-override POST untuk sinkronisasi dinamis perubahan URL/aset
$oldProject = $project;

// Override dengan data POST jika dikirim dari Live Preview Form Builder
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['name'])) $project['name'] = $_POST['name'];
    if (isset($_POST['brand_name'])) $project['brand_name'] = $_POST['brand_name'];
    if (isset($_POST['title'])) $project['title'] = $_POST['title'];
    if (isset($_POST['meta_description'])) $project['meta_description'] = $_POST['meta_description'];
    if (isset($_POST['canonical_url'])) $project['canonical_url'] = $_POST['canonical_url'];
    if (isset($_POST['amp_url'])) $project['amp_url'] = $_POST['amp_url'];
    if (isset($_POST['banner_url'])) $project['banner_url'] = $_POST['banner_url'];
    if (isset($_POST['logo_url'])) $project['logo_url'] = $_POST['logo_url'];
    if (isset($_POST['favicon_url'])) $project['favicon_url'] = $_POST['favicon_url'];
    if (isset($_POST['login_url'])) $project['login_url'] = $_POST['login_url'];
    if (isset($_POST['register_url'])) $project['register_url'] = $_POST['register_url'];
    if (isset($_POST['gif_url'])) $project['gif_url'] = $_POST['gif_url'];
    if (isset($_POST['jackpot_gif'])) $project['jackpot_gif'] = $_POST['jackpot_gif'];
    if (isset($_POST['banner_gif_url'])) $project['banner_gif_url'] = $_POST['banner_gif_url'];
    if (isset($_POST['banner_title'])) $project['banner_title'] = $_POST['banner_title'];
    if (isset($_POST['logo_title'])) $project['logo_title'] = $_POST['logo_title'];
    if (isset($_POST['article_content'])) $project['article_content'] = $_POST['article_content'];
    if (isset($_POST['faq_json'])) $project['faq_json'] = $_POST['faq_json'];
    if (isset($_POST['reviews_json'])) $project['reviews_json'] = $_POST['reviews_json'];
}

// Fallback cerdas untuk icon dan titel gambar
if (empty($project['favicon_url'])) {
    $project['favicon_url'] = !empty($project['logo_url']) ? $project['logo_url'] : '';
}
$project['icon_url'] = $project['favicon_url'];

if (empty($project['gif_url'])) {
    $project['gif_url'] = !empty($project['banner_url']) ? $project['banner_url'] : '';
}
if (empty($project['jackpot_gif'])) {
    $project['jackpot_gif'] = $project['gif_url'];
}
if (empty($project['banner_gif_url'])) {
    $project['banner_gif_url'] = $project['gif_url'];
}

$pageOrProjectTitle = !empty($project['title']) ? $project['title'] : ($project['name'] ?? 'Official Website');
if (empty($project['banner_title'])) {
    $project['banner_title'] = $pageOrProjectTitle;
}
if (empty($project['logo_title'])) {
    $project['logo_title'] = !empty($project['name']) ? $project['name'] : $pageOrProjectTitle;
}
$project['image_title'] = $project['banner_title'];
$project['img_title']   = $project['banner_title'];
if (empty($project['brand_name'])) {
    $project['brand_name'] = !empty($project['name']) ? $project['name'] : 'BRAND';
}
$project['brand_name_short'] = $project['brand_name'];
$project['brand_name_alt']   = strtolower($project['brand_name']);

$targetUrl = !empty($project['canonical_url']) ? $project['canonical_url'] : ($project['amp_url'] ?? '#');
if (empty($project['register_url'])) $project['register_url'] = $targetUrl;
if (empty($project['login_url']))    $project['login_url'] = $targetUrl;
if (empty($project['livechat_url'])) $project['livechat_url'] = $targetUrl;

// If builder has saved full HTML in article_content, use that.
if (!empty(trim($project['article_content'] ?? ''))) {
    $html = $project['article_content'];
} else {
    // Otherwise use template from file
    $tid = intval($project['template_id'] ?? 1);
    $stmtTpl = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
    $stmtTpl->execute([$tid]);
    $tplFile = $stmtTpl->fetchColumn();
    
    if (!$tplFile) {
        $stmtTpl->execute([1]);
        $tplFile = $stmtTpl->fetchColumn();
    }
    
    $html = '';
    if ($tplFile) {
        $fullPath = __DIR__ . '/cdn/templates/' . $tplFile;
        if (file_exists($fullPath)) {
            $html = file_get_contents($fullPath);
        }
    }
}


// 1. Sinkronisasi seluruh field terbaru dan bersihkan 100% tag template {{ ... }} dari level terdalam
$html = sync_and_clean_project_html($html, $project, $oldProject);

// Global replace any remaining explicit {{ field }} tags
$directTags = [
    '{{ brand_name }}'     => $project['brand_name'] ?? 'BRAND',
    '{{ name }}'           => $project['name'] ?? 'BRAND',
    '{{ title }}'          => $project['title'] ?? '',
    '{{ meta_description }}'=> $project['meta_description'] ?? '',
    '{{ canonical_url }}'  => $project['canonical_url'] ?? '',
    '{{ amp_url }}'        => $project['amp_url'] ?? '',
    '{{ login_url }}'      => $project['login_url'] ?? '',
    '{{ register_url }}'   => $project['register_url'] ?? '',
    '{{ logo_url }}'       => $project['logo_url'] ?? '',
    '{{ banner_url }}'     => $project['banner_url'] ?? '',
    '{{ favicon_url }}'    => $project['favicon_url'] ?? '',
    '{{ gif_url }}'        => $project['gif_url'] ?? ''
];
$html = strtr($html, $directTags);

// Sanitasi ekstra: bersihkan sisa potongan template syntax leak ('}} atau ') }}) jika ada
$html = preg_replace('/(?:\'|\")\)\s*\}\}/', '', $html);
$html = preg_replace('/(?:\'|\")\s*\}\}/', '', $html);
$html = preg_replace('/\{\{\s*(?!block:)[a-zA-Z0-9_]+\s*\}\}/', '', $html);

// Pembersihan tuntas untuk variasi spasi / sisa brand lama pada output HTML (contoh: Airbet88, Airbet 88, Airbet-88)
$activeBrand = trim($project['brand_name'] ?? ($project['name'] ?? ''));

// Hapus duplikasi brand akibat regex recursive (contoh Mega118118 -> Mega118)
if (!empty($activeBrand) && strlen($activeBrand) >= 3) {
    if (preg_match('/^([a-zA-Z]+)(\d+)$/', $activeBrand, $mBrandParts)) {
        $bPre = preg_quote($mBrandParts[1], '/');
        $bNum = preg_quote($mBrandParts[2], '/');
        $html = preg_replace('/(' . $bPre . $bNum . ')' . $bNum . '+/i', '$1', $html);
    }
    $bQuoted = preg_quote($activeBrand, '/');
    $html = preg_replace('/(' . $bQuoted . ')(?:' . $bQuoted . ')+/i', '$1', $html);
}

if (!empty($activeBrand) && !in_array(strtolower($activeBrand), ['brand', 'tes', 'project baru'])) {
    $searchOld = [];
    if (!empty($project['brand_old'])) $searchOld[] = $project['brand_old'];
    // Deteksi jika ada nama brand lama yang masih tersisa seperti AIRBET88
    $searchOld = array_merge($searchOld, ['AIRBET88', 'AIRBET 88', 'AIRBET-88', 'AIRBET']);
    $searchOld = array_unique(array_filter($searchOld));
    foreach ($searchOld as $so) {
        if (strcasecmp($so, $activeBrand) !== 0 && strlen($so) >= 3) {
            $html = preg_replace('/\b' . preg_quote($so, '/') . '\b/i', $activeBrand, $html);
        }
    }
}

// 2. Pertahankan elemen popup asli apa adanya tanpa menghapusnya
// (Popup dan seluruh gambar/aset tetap utuh 100%)

// 3. Inject Dynamic Blocks (FAQ, Reviews, Article)
// Prepare FAQ HTML
$faqsHtml = '';
$faqsData = json_decode($project['faq_json'] ?: '[]', true);
if (!empty($faqsData)) {
    $faqsHtml = '<div class="faq-section" style="width:100%; margin-top:20px; text-align:left;">'
              . '<h3 style="color:#fff; font-size:16px; font-weight:bold; margin-bottom:12px; border-bottom:1px solid #333; padding-bottom:8px;">Pertanyaan Sering Diajukan (FAQ)</h3>';
    foreach ($faqsData as $f) {
        $q = e($f['question'] ?? 'Pertanyaan');
        $a = e($f['answer'] ?? 'Jawaban');
        $faqsHtml .= '<details style="background:rgba(255,255,255,0.05); margin-bottom:8px; padding:12px; border-radius:12px; border:1px solid rgba(255,255,255,0.1); cursor:pointer;">'
                   . '<summary style="font-weight:bold; color:#fff; font-size:13px;">' . $q . '</summary>'
                   . '<p style="margin-top:8px; color:#ccc; font-size:12px; line-height:1.5;">' . $a . '</p>'
                   . '</details>';
    }
    $faqsHtml .= '</div>';
}

// Prepare Reviews HTML
$reviewsHtml = '';
$reviewsData = json_decode($project['reviews_json'] ?: '[]', true);
if (!empty($reviewsData)) {
    $reviewsHtml = '<div class="testi-section" style="width:100%; margin-top:20px; text-align:left;">'
                 . '<h3 style="color:#fff; font-size:16px; font-weight:bold; margin-bottom:12px; border-bottom:1px solid #333; padding-bottom:8px;">Ulasan & Rating Pengguna</h3>'
                 . '<div style="display:grid; grid-template-columns:1fr; gap:12px;">';
    foreach ($reviewsData as $r) {
        $rName = e($r['name'] ?? 'Pengguna');
        $rLoc  = e($r['location'] ?? 'Indonesia');
        $rText = e($r['text'] ?? '');
        $rRate = intval($r['rating'] ?? 5);
        $initial = strtoupper(substr($rName, 0, 1));
        
        $stars = str_repeat('⭐', $rRate);

        $reviewsHtml .= '<div style="background:rgba(255,255,255,0.05); padding:14px; border-radius:14px; border:1px solid rgba(255,255,255,0.1);">'
                     . '<div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">'
                     . '<div style="width:32px; height:32px; border-radius:50%; background:#d4af37; color:#000; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px;">' . $initial . '</div>'
                     . '<div><strong style="color:#fff; font-size:13px; display:block;">' . $rName . '</strong><span style="font-size:10px; color:#aaa;">' . $rLoc . '</span></div>'
                     . '</div>'
                     . '<div style="font-size:11px; margin-bottom:6px;">' . $stars . '</div>'
                     . '<p style="font-size:12px; color:#eee; line-height:1.4; margin:0;">' . $rText . '</p>'
                     . '</div>';
    }
    $reviewsHtml .= '</div></div>';
}

// Inject into HTML blocks
$html = str_replace('{{ block:faqs }}', $faqsHtml, $html);
$html = str_replace('{{ block:reviews }}', $reviewsHtml, $html);
// We also replace {{ block:article }} with nothing since article_content is the full template now.
$html = str_replace('{{ block:article }}', '', $html);

// 6. Purify HTML for Google Standards (Sanitize 3rd party scripts, optimize meta robots, clean copyright, and enrich Schema.org)
$isAmpPage = (bool) preg_match('/<html\b[^>]*\b(amp|⚡)\b[^>]*>/i', $html) || (($project['type'] ?? '') === 'amp');
$html = purify_html_for_google($html, $isAmpPage, $project);

// 7. Sanitasi tuntas bebas bocoran tag template {{ ... }}
$html = preg_replace('/\{\{\s*[a-zA-Z0-9_:]+\s*(?:\|[^\r\n\}]{0,600}?)?\}\}/', '', $html) ?? $html;
$html = preg_replace('/(?:\'|\")\s*\)\s*\}\}/', '', $html) ?? $html;

// Render final clean HTML
echo $html;
