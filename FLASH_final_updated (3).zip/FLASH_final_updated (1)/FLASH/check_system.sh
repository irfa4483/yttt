#!/usr/bin/env bash
# ==============================================================================
# FLASH PLATFORM - Comprehensive System, AAPanel, & VPS Diagnostic Tool
# ==============================================================================
# Usage:
#   chmod +x check_system.sh
#   ./check_system.sh
# ==============================================================================

# Colors for terminal output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

clear
echo -e "${CYAN}${BOLD}"
echo "========================================================================"
echo "          ⚡ FLASH PLATFORM - SYSTEM & VPS HEALTH CHECKER ⚡           "
echo "========================================================================"
echo -e "${NC}"
echo -e "Waktu Pengecekan : $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Direktori Kerja  : ${BOLD}$SCRIPT_DIR${NC}"
echo ""

TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
WARNINGS=0

report_pass() {
    local title="$1"
    local detail="$2"
    echo -e "  [${GREEN}✓ PASS${NC}] ${BOLD}${title}${NC} : ${detail}"
    ((TOTAL_TESTS++))
    ((PASSED_TESTS++))
}

report_fail() {
    local title="$1"
    local detail="$2"
    local fix="$3"
    echo -e "  [${RED}✗ FAIL${NC}] ${RED}${BOLD}${title}${NC} : ${detail}"
    if [ -n "$fix" ]; then
        echo -e "           ${YELLOW}↳ Saran Perbaikan: ${fix}${NC}"
    fi
    ((TOTAL_TESTS++))
    ((FAILED_TESTS++))
}

report_warn() {
    local title="$1"
    local detail="$2"
    local fix="$3"
    echo -e "  [${YELLOW}! WARN${NC}] ${YELLOW}${BOLD}${title}${NC} : ${detail}"
    if [ -n "$fix" ]; then
        echo -e "           ${YELLOW}↳ Catatan: ${fix}${NC}"
    fi
    ((TOTAL_TESTS++))
    ((WARNINGS++))
}

# ------------------------------------------------------------------------------
# 1. DETEKSI SISTEM OPERASI & SERVER
# ------------------------------------------------------------------------------
echo -e "${PURPLE}${BOLD}>>> [1/6] Pengecekan Sistem Operasi & Lingkungan Host${NC}"

if [ -f /etc/os-release ]; then
    . /etc/os-release
    report_pass "Sistem Operasi" "$PRETTY_NAME ($ID $VERSION_ID)"
else
    report_warn "Sistem Operasi" "Distro tidak teridentifikasi via /etc/os-release" ""
fi

# Cek AAPanel
if [ -d "/www/server/panel" ]; then
    report_pass "AAPANEL Detected" "Ditemukan instalasi AAPanel aktif di /www/server/panel"
else
    report_warn "AAPANEL" "AAPANel tidak terdeteksi (Mode Native VPS / Docker / Standalone)" ""
fi

# Cek Web Server
WEBSERVER=""
if pgrep nginx > /dev/null 2>&1; then
    WEBSERVER="Nginx ($(nginx -v 2>&1 | awk -F'/' '{print $2}'))"
    report_pass "Web Server" "Nginx aktif ($WEBSERVER)"
elif pgrep apache2 > /dev/null 2>&1 || pgrep httpd > /dev/null 2>&1; then
    WEBSERVER="Apache"
    report_pass "Web Server" "Apache Web Server aktif"
else
    report_warn "Web Server" "Nginx/Apache tidak terdeteksi berjalan pada port aktif." "Pastikan web server aktif."
fi
echo ""

# ------------------------------------------------------------------------------
# 2. DETEKSI PHP & EKSTENSI WAJIB
# ------------------------------------------------------------------------------
echo -e "${PURPLE}${BOLD}>>> [2/6] Pengecekan PHP & Ekstensi Wajib FLASH${NC}"

# Cari binary PHP (baik sistem native maupun AAPanel)
PHP_BIN=""
if command -v php > /dev/null 2>&1; then
    PHP_BIN="$(command -v php)"
elif [ -f "/www/server/php/82/bin/php" ]; then
    PHP_BIN="/www/server/php/82/bin/php"
elif [ -f "/www/server/php/81/bin/php" ]; then
    PHP_BIN="/www/server/php/81/bin/php"
elif [ -f "/www/server/php/83/bin/php" ]; then
    PHP_BIN="/www/server/php/83/bin/php"
elif [ -f "/www/server/php/84/bin/php" ]; then
    PHP_BIN="/www/server/php/84/bin/php"
fi

if [ -z "$PHP_BIN" ]; then
    report_fail "PHP Binary" "PHP CLI tidak ditemukan di sistem!" "Install PHP: apt install php atau install PHP via AAPanel App Store."
    PHP_VER="0"
else
    PHP_VER=$($PHP_BIN -r "echo PHP_VERSION;" 2>/dev/null)
    PHP_MAJOR=$($PHP_BIN -r "echo PHP_MAJOR_VERSION;" 2>/dev/null)
    PHP_MINOR=$($PHP_BIN -r "echo PHP_MINOR_VERSION;" 2>/dev/null)
    
    if [ "$PHP_MAJOR" -ge 8 ]; then
        report_pass "PHP Versi" "PHP $PHP_VER ($PHP_BIN) [Rekomendasi]"
    elif [ "$PHP_MAJOR" -eq 7 ] && [ "$PHP_MINOR" -ge 4 ]; then
        report_pass "PHP Versi" "PHP $PHP_VER ($PHP_BIN) [Didukung]"
    else
        report_fail "PHP Versi" "PHP $PHP_VER terlalu usang." "Upgrade ke minimal PHP 8.1 / 8.2."
    fi
fi

if [ -n "$PHP_BIN" ]; then
    # Daftar Ekstensi Wajib
    MISSING_PKGS=()
    check_ext() {
        local ext="$1"
        local desc="$2"
        local apt_pkg="$3"
        
        if $PHP_BIN -m 2>/dev/null | grep -i -E "^${ext}$" > /dev/null 2>&1; then
            report_pass "Ekstensi: $ext" "$desc"
        else
            report_fail "Ekstensi: $ext" "$desc tidak aktif!" "Jalankan: apt install $apt_pkg atau aktifkan di AAPanel > PHP > Extensions."
            MISSING_PKGS+=("$apt_pkg")
        fi
    }

    check_ext "pdo_sqlite" "Database Engine SQLite PDO" "php-sqlite3"
    check_ext "sqlite3" "SQLite3 Driver" "php-sqlite3"
    check_ext "curl" "Crawler URL, Scraping Target & AI API" "php-curl"
    check_ext "zip" "Kompresi Ekspor ZIP Bersih" "php-zip"
    check_ext "openssl" "Koneksi HTTPS & Enkripsi" "php-openssl"
    check_ext "mbstring" "Pemrosesan Teks Brand UTF-8" "php-mbstring"
    check_ext "fileinfo" "Deteksi Format MIME Media/Banner" "php-fileinfo"
    check_ext "gd" "Manipulasi Grafis & Thumbnail" "php-gd"
    check_ext "dom" "Parser Dokumen HTML / DOM" "php-xml"

    # AUTO-FIX: Pasang otomatis modul yang belum di-install
    if [ ${#MISSING_PKGS[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}${BOLD}[AUTO-INSTALL] Terdeteksi modul PHP yang belum terpasang: ${MISSING_PKGS[*]}${NC}"
        if [ "$EUID" -eq 0 ]; then
            echo -e "${CYAN}Menginstal modul yang belum terpasang secara otomatis...${NC}"
            if [ -f /etc/debian_version ]; then
                apt-get update -y && apt-get install -y "${MISSING_PKGS[@]}"
            elif [ -f /etc/redhat-release ]; then
                dnf install -y "${MISSING_PKGS[@]}"
            fi
            systemctl restart php*-fpm 2>/dev/null || true
            systemctl restart nginx 2>/dev/null || true
            echo -e "${GREEN}✓ Modul berhasil diinstal dan layanan web server telah di-restart!${NC}\n"
        else
            echo -e "${YELLOW}Jalankan perintah ini dengan akses root/sudo untuk menginstal otomatis:${NC}"
            echo -e "  ${BOLD}sudo apt-get install -y ${MISSING_PKGS[*]}${NC}\n"
        fi
    fi

    # Cek Setting php.ini yang esensial
    UPLOAD_MAX=$($PHP_BIN -r "echo ini_get('upload_max_filesize');")
    POST_MAX=$($PHP_BIN -r "echo ini_get('post_max_size');")
    MEM_LIMIT=$($PHP_BIN -r "echo ini_get('memory_limit');")
    MAX_TIME=$($PHP_BIN -r "echo ini_get('max_execution_time');")

    report_pass "php.ini Limits" "upload_max=$UPLOAD_MAX, post_max=$POST_MAX, memory=$MEM_LIMIT, max_execution_time=${MAX_TIME}s"
fi
echo ""

# ------------------------------------------------------------------------------
# 3. PENGECEKAN IZIN FOLDER & DATABASE SQLITE
# ------------------------------------------------------------------------------
echo -e "${PURPLE}${BOLD}>>> [3/6] Pengecekan Izin Berkas, Direktori & SQLite Lock${NC}"

# Pastikan folder target dibuat
mkdir -p "$SCRIPT_DIR/cdn/templates" "$SCRIPT_DIR/uploads" "$SCRIPT_DIR/exports" 2>/dev/null

# 1. Cek direktori utama
if [ -w "$SCRIPT_DIR" ]; then
    report_pass "Izin Root Project" "Direktori root bisa ditulis ($SCRIPT_DIR)"
else
    report_fail "Izin Root Project" "Direktori root tidak bisa ditulis oleh user saat ini!" "chown -R www:www $SCRIPT_DIR && chmod 775 $SCRIPT_DIR"
fi

# 2. Cek database.sqlite
DB_FILE="$SCRIPT_DIR/database.sqlite"
if [ -f "$DB_FILE" ]; then
    if [ -w "$DB_FILE" ]; then
        report_pass "Database SQLite" "File database.sqlite ditemukan dan Writable"
    else
        report_fail "Database SQLite" "File database.sqlite TIDAK bisa ditulis (Read-Only)!" "chmod 664 $DB_FILE && chown www:www $DB_FILE"
    fi
else
    report_warn "Database SQLite" "File database.sqlite belum ada (akan dibuat otomatis saat aplikasi dijalankan)" "Pastikan direktori root memiliki izin tulis."
fi

# 3. Cek folder cdn/templates
if [ -w "$SCRIPT_DIR/cdn/templates" ]; then
    report_pass "Folder Template" "cdn/templates Writable"
else
    report_fail "Folder Template" "cdn/templates tidak bisa ditulis!" "chmod -R 775 $SCRIPT_DIR/cdn && chown -R www:www $SCRIPT_DIR/cdn"
fi

# 4. Cek folder uploads
if [ -w "$SCRIPT_DIR/uploads" ]; then
    report_pass "Folder Uploads" "uploads Writable"
else
    report_fail "Folder Uploads" "uploads tidak bisa ditulis!" "chmod -R 775 $SCRIPT_DIR/uploads && chown -R www:www $SCRIPT_DIR/uploads"
fi

# 5. Cek folder exports
if [ -w "$SCRIPT_DIR/exports" ]; then
    report_pass "Folder Exports" "exports Writable"
else
    report_fail "Folder Exports" "exports tidak bisa ditulis!" "chmod -R 775 $SCRIPT_DIR/exports && chown -R www:www $SCRIPT_DIR/exports"
fi
echo ""

# ------------------------------------------------------------------------------
# 4. UJI INTEGRITAS DATABASE SQLITE NYATA
# ------------------------------------------------------------------------------
echo -e "${PURPLE}${BOLD}>>> [4/6] Uji Integritas SQLite Kueri & Timeout${NC}"

if [ -n "$PHP_BIN" ]; then
    SQL_TEST=$($PHP_BIN -r "
        try {
            require '$SCRIPT_DIR/config/database.php';
            \$check = \$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
            \$tplCount = \$pdo->query('SELECT COUNT(*) FROM templates')->fetchColumn();
            \$logCount = \$pdo->query('SELECT COUNT(*) FROM clone_logs')->fetchColumn();
            echo 'SUCCESS|Users:' . \$check . '|Templates:' . \$tplCount . '|CloneLogs:' . \$logCount;
        } catch (Exception \$e) {
            echo 'ERROR|' . \$e->getMessage();
        }
    " 2>/dev/null)

    if [[ "$SQL_TEST" =~ ^SUCCESS ]]; then
        DETAILS=$(echo "$SQL_TEST" | cut -d'|' -f2,3,4)
        report_pass "Koneksi SQLite" "Kueri SQL berhasil ($DETAILS)"
    else
        ERR_MSG=$(echo "$SQL_TEST" | cut -d'|' -f2)
        report_fail "Koneksi SQLite" "Gagal membaca database: $ERR_MSG" "Periksa izin file database.sqlite dan module pdo_sqlite."
    fi
else
    report_warn "Koneksi SQLite" "Lewati tes kueri karena PHP CLI belum terpasang." ""
fi
echo ""

# ------------------------------------------------------------------------------
# 5. UJI KONEKTIVITAS JARINGAN CRAWLER & AI GEMINI
# ------------------------------------------------------------------------------
echo -e "${PURPLE}${BOLD}>>> [5/6] Uji Jaringan Keluar (Crawler Kloning & AI API)${NC}"

# Tes outgoing cURL
if command -v curl > /dev/null 2>&1; then
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 https://www.google.com 2>/dev/null)
    if [ "$HTTP_CODE" -ge 200 ] && [ "$HTTP_CODE" -lt 400 ]; then
        report_pass "Outgoing HTTP" "Koneksi ke internet aktif (HTTP $HTTP_CODE)"
    else
        report_fail "Outgoing HTTP" "VPS memblokir koneksi keluar (HTTP $HTTP_CODE)" "Periksa firewall VPS (UFW/Iptables/Security Group)."
    fi

    # Tes Gemini API endpoint
    GEMINI_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 https://generativelanguage.googleapis.com 2>/dev/null)
    if [ "$GEMINI_CODE" -gt 0 ]; then
        report_pass "Gemini AI Endpoint" "Dapat terhubung ke generativelanguage.googleapis.com (HTTP $GEMINI_CODE)"
    else
        report_warn "Gemini AI Endpoint" "Tidak dapat mencapai endpoint Google Gemini" "Pastikan koneksi DNS VPS dapat me-resolve domain Google."
    fi
else
    report_warn "Outgoing HTTP" "cURL binary tidak terpasang di sistem Linux" "Jalankan: apt install curl"
fi
echo ""

# ------------------------------------------------------------------------------
# 6. UJI KEAMANAN WEB & ENDPOINT PLATFORM
# ------------------------------------------------------------------------------
echo -e "${PURPLE}${BOLD}>>> [6/6] Uji Keamanan Berkas Sensitif & Routing Web${NC}"

# Cek apakah database.sqlite dapat diakses langsung dari luar jika port 80/443 aktif
if command -v curl > /dev/null 2>&1; then
    # Cek via local request
    SEC_CODE=$(curl -s -o /dev/null -w "%{http_code}" -H "Host: localhost" http://127.0.0.1/database.sqlite 2>/dev/null)
    if [ "$SEC_CODE" == "404" ] || [ "$SEC_CODE" == "403" ]; then
        report_pass "Proteksi SQLite" "database.sqlite terlindungi dari download publik (HTTP $SEC_CODE)"
    elif [ "$SEC_CODE" == "200" ]; then
        report_fail "Proteksi SQLite" "BAHAYA: database.sqlite dapat didownload bebas via web!" "Tambahkan aturan 'location ~* \.sqlite$ { deny all; return 404; }' pada konfigurasi Nginx AAPanel."
    else
        report_pass "Proteksi SQLite" "Akses langsung ditutup atau web server lokal belum listening (HTTP $SEC_CODE)"
    fi
fi

# Cek robots.txt & sitemap.xml fisik
if [ -f "$SCRIPT_DIR/robots.txt" ]; then
    report_pass "File robots.txt" "Tersedia di root project"
else
    report_fail "File robots.txt" "Tidak ditemukan!" "Buat berkas robots.txt di root project."
fi

if [ -f "$SCRIPT_DIR/sitemap.xml" ] || [ -f "$SCRIPT_DIR/sitemap.php" ]; then
    report_pass "File sitemap" "Sitemap XML & Streamer PHP tersedia"
else
    report_fail "File sitemap" "sitemap.xml tidak ditemukan!" "Pastikan sitemap.xml atau sitemap.php tersedia."
fi
echo ""

# ------------------------------------------------------------------------------
# HASIL REKAPITULASI & KESIMPULAN
# ------------------------------------------------------------------------------
echo -e "${CYAN}${BOLD}========================================================================${NC}"
echo -e "${BOLD}                        HASIL AUDIT SISTEM FLASH                        ${NC}"
echo -e "${CYAN}${BOLD}========================================================================${NC}"
echo -e "Total Komponen Diperiksa : ${BOLD}$TOTAL_TESTS${NC}"
echo -e "Komponen Lulus (PASS)    : ${GREEN}${BOLD}$PASSED_TESTS${NC}"
echo -e "Komponen Gagal (FAIL)    : ${RED}${BOLD}$FAILED_TESTS${NC}"
echo -e "Peringatan (WARNING)     : ${YELLOW}${BOLD}$WARNINGS${NC}"
echo ""

if [ "$FAILED_TESTS" -eq 0 ]; then
    echo -e "${GREEN}${BOLD}🎉 STATUS: LULUS PENUH! Sistem VPS & AAPanel siap menjalankan FLASH.${NC}"
    echo -e "Silakan akses dashboard platform melalui web browser Anda."
else
    echo -e "${RED}${BOLD}⚠️ STATUS: DITEMUKAN $FAILED_TESTS MASALAH YANG PERLU DIPERBAIKI.${NC}"
    echo -e "${YELLOW}Perintah Cepat Perbaikan Izin AAPanel / VPS:${NC}"
    echo -e "  ${BOLD}chown -R www:www $SCRIPT_DIR${NC}"
    echo -e "  ${BOLD}chmod -R 775 $SCRIPT_DIR/cdn $SCRIPT_DIR/uploads $SCRIPT_DIR/exports${NC}"
    echo -e "  ${BOLD}chmod 664 $SCRIPT_DIR/database.sqlite${NC}"
    echo -e "  ${BOLD}chmod 775 $SCRIPT_DIR${NC}"
fi
echo -e "${CYAN}========================================================================${NC}"
exit $FAILED_TESTS
