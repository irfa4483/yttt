<?php
// admin/dashboard.php
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$currentUser = current_user();

// Handle Action Admin (Ubah Role / Hapus User / Tambah User / Tambah Berita / Hapus Berita)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        set_flash('error', 'Validasi keamanan CSRF gagal. Silakan muat ulang.');
        header('Location: /admin/dashboard.php');
        exit;
    }

    $action = $_POST['action'] ?? '';

    // Action 1: Toggle User Role
    if ($action === 'toggle_role') {
        $targetId = intval($_POST['user_id'] ?? 0);
        $newRole = $_POST['new_role'] ?? 'user';

        if ($targetId === $currentUser['id']) {
            set_flash('error', 'Anda tidak dapat mengubah role akun Anda sendiri.');
        } elseif (in_array($newRole, ['admin', 'user'])) {
            $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->execute([$newRole, $targetId]);
            set_flash('success', 'Role pengguna berhasil diperbarui menjadi ' . strtoupper($newRole) . '.');
        }
        header('Location: /admin/dashboard.php');
        exit;
    }

    // Action 2: Delete User
    if ($action === 'delete_user') {
        $targetId = intval($_POST['user_id'] ?? 0);

        if ($targetId === $currentUser['id']) {
            set_flash('error', 'Anda tidak dapat menghapus akun Anda sendiri.');
        } else {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$targetId]);
            set_flash('success', 'Pengguna berhasil dihapus dari database.');
        }
        header('Location: /admin/dashboard.php');
        exit;
    }

    // Action 3: Add User
    if ($action === 'add_user') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'user';

        if (!in_array($role, ['admin', 'user'])) {
            $role = 'user';
        }

        if (empty($name) || empty($email) || empty($password)) {
            set_flash('error', 'Semua kolom wajib diisi.');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            set_flash('error', 'Format alamat email tidak valid.');
        } elseif (strlen($password) < 6) {
            set_flash('error', 'Password minimal harus 6 karakter.');
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                set_flash('error', 'Email tersebut sudah terdaftar.');
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $email, $hash, $role]);
                set_flash('success', 'User baru (' . $name . ') berhasil ditambahkan.');
            }
        }
        header('Location: /admin/dashboard.php');
        exit;
    }

    // Action 4: Add News / Berita
    if ($action === 'add_news') {
        $title = trim($_POST['title'] ?? '');
        $category = trim($_POST['category'] ?? 'Pengumuman');
        $content = trim($_POST['content'] ?? '');

        if (!in_array($category, ['Pengumuman', 'Fitur Baru', 'Pemeliharaan'])) {
            $category = 'Pengumuman';
        }

        if (empty($title) || empty($content)) {
            set_flash('error', 'Judul dan isi berita wajib diisi.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO news (title, content, category, author_name) VALUES (?, ?, ?, ?)");
            $stmt->execute([$title, $content, $category, $currentUser['name']]);
            set_flash('success', 'Berita / Pengumuman baru berhasil diterbitkan.');
        }
        header('Location: /admin/dashboard.php');
        exit;
    }

    // Action 5: Delete News
    if ($action === 'delete_news') {
        $newsId = intval($_POST['news_id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM news WHERE id = ?");
        $stmt->execute([$newsId]);
        set_flash('success', 'Berita berhasil dihapus.');
        header('Location: /admin/dashboard.php');
        exit;
    }

    // Action 6: Add Template
    if ($action === 'add_template') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $html_content = trim($_POST['html_content'] ?? '');
        
        // Cek apakah ada file yang diupload
        if (isset($_FILES['template_file']) && $_FILES['template_file']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['template_file']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['php', 'phtml', 'php5', 'phar'])) {
                set_flash('error', 'Keamanan: Dilarang keras mengupload file PHP!');
                header('Location: /admin/dashboard.php');
                exit;
            }
            $uploadedHtml = file_get_contents($_FILES['template_file']['tmp_name']);
            if (!empty($uploadedHtml)) {
                $html_content = $uploadedHtml;
            }
        }

        if (empty($name) || empty($html_content)) {
            set_flash('error', 'Nama Template dan Kode HTML wajib diisi (atau upload file).');
        } else {
            $hashName = md5(uniqid('tpl_', true)) . '.html'; // Force extension .html
            $targetPath = __DIR__ . '/../cdn/templates/' . $hashName;
            
            if (file_put_contents($targetPath, $html_content) !== false) {
                $stmt = $pdo->prepare("INSERT INTO templates (name, description, file_path, html_content) VALUES (?, ?, ?, '')");
                $stmt->execute([$name, $description, $hashName]);
                set_flash('success', 'Template baru berhasil ditambahkan dan disimpan dengan aman.');
            } else {
                set_flash('error', 'Gagal menulis file template ke server.');
            }
        }
        header('Location: /admin/dashboard.php');
        exit;
    }
    
    // Action 7: Edit Template
    if ($action === 'edit_template') {
        $id = intval($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $html_content = trim($_POST['html_content'] ?? '');
        
        if (empty($name) || empty($html_content)) {
            set_flash('error', 'Nama Template dan Kode HTML wajib diisi.');
        } else {
            $stmt = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
            $stmt->execute([$id]);
            $filePath = $stmt->fetchColumn();
            
            if ($filePath) {
                $targetPath = __DIR__ . '/../cdn/templates/' . $filePath;
                file_put_contents($targetPath, $html_content);
                
                $stmtUpd = $pdo->prepare("UPDATE templates SET name = ?, description = ? WHERE id = ?");
                $stmtUpd->execute([$name, $description, $id]);
                set_flash('success', 'Template berhasil diupdate.');
            } else {
                set_flash('error', 'Template tidak ditemukan.');
            }
        }
        header('Location: /admin/dashboard.php');
        exit;
    }

    // Action 8: Delete Template
    if ($action === 'delete_template') {
        $targetId = intval($_POST['template_id'] ?? 0);
        // Cegah menghapus template default jika id = 1
        if ($targetId === 1) {
            set_flash('error', 'Template default sistem tidak dapat dihapus.');
        } else {
            // Cek apakah ada project yang pakai template ini
            $stmtCheck = $pdo->prepare("SELECT COUNT(*) as count FROM projects WHERE template_id = ?");
            $stmtCheck->execute([$targetId]);
            $count = $stmtCheck->fetch()['count'];
            
            if ($count > 0) {
                set_flash('error', "Gagal dihapus: Ada $count project yang masih menggunakan template ini.");
            } else {
                // Delete physical file first
                $stmt = $pdo->prepare("SELECT file_path FROM templates WHERE id = ?");
                $stmt->execute([$targetId]);
                $fpath = $stmt->fetchColumn();
                if ($fpath) {
                    $fullPath = __DIR__ . '/../cdn/templates/' . $fpath;
                    if (file_exists($fullPath)) unlink($fullPath);
                }
                
                $stmtDel = $pdo->prepare("DELETE FROM templates WHERE id = ?");
                $stmtDel->execute([$targetId]);
                set_flash('success', 'Template berhasil dihapus beserta filenya.');
            }
        }
        header('Location: /admin/dashboard.php');
        exit;
    }

    // Action 9: Konversi Kloning/Project Menjadi Template Sistem Otomatis
    if ($action === 'convert_to_template') {
        $projId = intval($_POST['project_id'] ?? 0);
        $stmtP = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
        $stmtP->execute([$projId]);
        $proj = $stmtP->fetch();

        if ($proj && !empty(trim($proj['article_content'] ?? ''))) {
            $tplName = trim($_POST['template_name'] ?? ('Template ' . $proj['name'] . ' (' . strtoupper($proj['type'] ?? 'AMP') . ')'));
            $tplType = in_array($proj['type'] ?? '', ['amp', 'lp']) ? $proj['type'] : 'amp';
            $tplDesc = 'Template sistem hasil konversi dari project kloning: ' . $proj['name'];
            $hashName = md5(uniqid('tpl_conv_', true)) . '.html';
            $targetPath = __DIR__ . '/../cdn/templates/' . $hashName;

            if (file_put_contents($targetPath, $proj['article_content']) !== false) {
                $stmtIns = $pdo->prepare("INSERT INTO templates (name, type, description, file_path, html_content, created_at) VALUES (?, ?, ?, ?, '', CURRENT_TIMESTAMP)");
                $stmtIns->execute([$tplName, $tplType, $tplDesc, $hashName]);
                $newTplId = $pdo->lastInsertId();
                
                // Hubungkan project ke template baru
                $pdo->prepare("UPDATE projects SET template_id = ? WHERE id = ?")->execute([$newTplId, $projId]);

                set_flash('success', 'Project "' . $proj['name'] . '" berhasil dikonversi dan disimpan menjadi Template Sistem baru!');
            } else {
                set_flash('error', 'Gagal menulis file template ke folder cdn/templates/.');
            }
        } else {
            set_flash('error', 'Konten HTML project kosong atau project tidak ditemukan.');
        }
        header('Location: /admin/dashboard.php?tab=projects');
        exit;
    }

    // Action 10: Hapus Project (Admin Mode)
    if ($action === 'delete_project_admin') {
        $projId = intval($_POST['project_id'] ?? 0);
        $stmtDel = $pdo->prepare("DELETE FROM projects WHERE id = ?");
        $stmtDel->execute([$projId]);
        set_flash('success', 'Project berhasil dihapus oleh Administrator.');
        $redirectTab = $_POST['redirect_tab'] ?? 'projects';
        header('Location: /admin/dashboard.php?tab=' . $redirectTab);
        exit;
    }

    // Action 11: Hapus Log Kloning Tertentu (Admin Mode)
    if ($action === 'delete_clone_log') {
        $logId = intval($_POST['log_id'] ?? 0);
        $stmtDelLog = $pdo->prepare("DELETE FROM clone_logs WHERE id = ?");
        $stmtDelLog->execute([$logId]);
        set_flash('success', 'Riwayat log kloning berhasil dihapus.');
        header('Location: /admin/dashboard.php?tab=clonelogs');
        exit;
    }

    // Action 12: Bersihkan Seluruh Riwayat Log Kloning (Admin Mode)
    if ($action === 'clear_all_clone_logs') {
        $pdo->exec("DELETE FROM clone_logs");
        set_flash('success', 'Seluruh riwayat log kloning berhasil dibersihkan.');
        header('Location: /admin/dashboard.php?tab=clonelogs');
        exit;
    }

    // Action 13: Ubah / Edit Detail Project Secara Lengkap (Admin Mode)
    if ($action === 'edit_project_admin') {
        $projId = intval($_POST['project_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $brandName = trim($_POST['brand_name'] ?? $name);
        $title = trim($_POST['title'] ?? '');
        $type = in_array($_POST['type'] ?? '', ['amp', 'lp']) ? $_POST['type'] : 'amp';
        $status = in_array($_POST['status'] ?? '', ['draft', 'published']) ? $_POST['status'] : 'draft';
        $canonicalUrl = trim($_POST['canonical_url'] ?? '');
        $ampUrl = trim($_POST['amp_url'] ?? '');
        $loginUrl = trim($_POST['login_url'] ?? '');
        $registerUrl = trim($_POST['register_url'] ?? '');
        $metaDesc = trim($_POST['meta_description'] ?? '');

        if ($projId > 0 && !empty($name)) {
            $stmtUpd = $pdo->prepare("UPDATE projects SET name = ?, brand_name = ?, title = ?, type = ?, status = ?, canonical_url = ?, amp_url = ?, login_url = ?, register_url = ?, meta_description = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmtUpd->execute([$name, $brandName, $title, $type, $status, $canonicalUrl, $ampUrl, $loginUrl, $registerUrl, $metaDesc, $projId]);
            set_flash('success', 'Detail project "' . $name . '" berhasil diperbarui oleh Administrator.');
        } else {
            set_flash('error', 'Nama project tidak boleh kosong.');
        }
        $redirectTab = $_POST['redirect_tab'] ?? 'projects';
        header('Location: /admin/dashboard.php?tab=' . $redirectTab);
        exit;
    }
}

// Ambil Statistik
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalAdmins = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
$totalMembers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$totalNews = $pdo->query("SELECT COUNT(*) FROM news")->fetchColumn();
$totalTemplates = $pdo->query("SELECT COUNT(*) FROM templates")->fetchColumn();
$totalProjects = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$totalCloneLogs = $pdo->query("SELECT COUNT(*) FROM clone_logs")->fetchColumn();

// Ambil Daftar Semua User
$stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY id DESC");
$allUsers = $stmt->fetchAll();

// Ambil Daftar Berita
$stmtNews = $pdo->query("SELECT id, title, content, category, author_name, created_at FROM news ORDER BY id DESC");
$allNews = $stmtNews->fetchAll();

// Ambil Daftar Semua Project Beserta Siapa Yang Mengkloning / Membuatnya
$stmtProjects = $pdo->query("
    SELECT projects.*, users.name as creator_name, users.email as creator_email, users.role as creator_role, templates.name as template_name
    FROM projects 
    LEFT JOIN users ON projects.user_id = users.id 
    LEFT JOIN templates ON projects.template_id = templates.id 
    ORDER BY projects.id DESC
");
$allProjects = $stmtProjects->fetchAll();

// Ambil Riwayat Log Kloning URL Pengguna Lengkap
$stmtCloneLogs = $pdo->query("
    SELECT clone_logs.*, 
           users.name as user_name, users.email as user_email, users.role as user_role,
           projects.name as project_current_name, projects.slug as project_slug,
           projects.type as project_current_type, projects.status as project_status,
           projects.article_content as project_content
    FROM clone_logs
    LEFT JOIN users ON clone_logs.user_id = users.id
    LEFT JOIN projects ON clone_logs.project_id = projects.id
    ORDER BY clone_logs.id DESC
");
$allCloneLogs = $stmtCloneLogs->fetchAll();

// Ambil Daftar Template
$stmtTpl = $pdo->query("SELECT * FROM templates ORDER BY created_at DESC");
$allTemplatesRaw = $stmtTpl->fetchAll();
$allTemplates = [];
foreach ($allTemplatesRaw as $tpl) {
    if (!empty($tpl['file_path'])) {
        $path = __DIR__ . '/../cdn/templates/' . $tpl['file_path'];
        $tpl['html_content'] = file_exists($path) ? file_get_contents($path) : '';
    }
    $allTemplates[] = $tpl;
}

$pageTitle = 'Dashboard Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" 
     x-data="{ 
        sidebarOpen: false, 
        modalUserOpen: false, 
        modalNewsOpen: false, 
        modalTemplateOpen: false, 
        modalEditTemplateOpen: false, 
        modalEditProjectOpen: false,
        editProj: {},
        editTpl: {}, 
        activeTab: new URLSearchParams(window.location.search).get('tab') || localStorage.getItem('adminActiveTab') || 'clonelogs' 
     }" 
     x-init="$watch('activeTab', val => {
         localStorage.setItem('adminActiveTab', val);
         window.history.replaceState(null, '', '?tab=' + val);
         if(val === 'templates') initCodeMirror();
     })">
    
    <!-- Admin Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <!-- Brand Logo -->
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/20">
                    <i class="fa-solid fa-bolt-lightning text-lg text-amber-300"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Admin FLASH</h2>
                    <span class="text-[11px] text-amber-400 font-semibold uppercase tracking-wider">Control Center</span>
                </div>
            </div>

            <!-- Navigation Links -->
            <nav class="space-y-1.5 pt-4">
                <button @click="activeTab = 'clonelogs'" 
                        :class="activeTab === 'clonelogs' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs transition-all text-left cursor-pointer">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-clock-rotate-left w-4 text-center text-amber-400"></i>
                        <span>Riwayat Kloning User</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold"><?= $totalCloneLogs ?></span>
                </button>

                <button @click="activeTab = 'projects'" 
                        :class="activeTab === 'projects' ? 'bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs transition-all text-left cursor-pointer">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-layer-group w-4 text-center text-brand-400"></i>
                        <span>Semua Project & Kloning</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-brand-500/20 text-brand-300 text-[10px] font-bold"><?= $totalProjects ?></span>
                </button>

                <button @click="activeTab = 'templates'; initCodeMirror()" 
                        :class="activeTab === 'templates' ? 'bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs transition-all text-left cursor-pointer">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-code w-4 text-center"></i>
                        <span>Manajemen Template</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= $totalTemplates ?></span>
                </button>

                <button @click="activeTab = 'users'" 
                        :class="activeTab === 'users' ? 'bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs transition-all text-left cursor-pointer">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-users-gear w-4 text-center"></i>
                        <span>Kelola User & Role</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= $totalUsers ?></span>
                </button>

                <button @click="activeTab = 'news'" 
                        :class="activeTab === 'news' ? 'bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-transparent'"
                        class="w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs transition-all text-left cursor-pointer">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-newspaper w-4 text-center"></i>
                        <span>Kelola Berita / News</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= $totalNews ?></span>
                </button>
                    <span class="px-2 py-0.5 rounded-full bg-brand-500/20 text-brand-300 text-[10px] font-bold"><?= $totalProjects ?></span>
                </button>

                <a href="/user/tunnel.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-network-wired w-4 text-center text-amber-400"></i>
                        <span>Tunnel & Sitemap Manager</span>
                    </div>
                    <span class="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">Auto</span>
                </a>

                <a href="/admin/ai_settings.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-wand-magic-sparkles w-4 text-center text-amber-400"></i>
                    <span>Pengaturan AI API</span>
                </a>
            </nav>

            <!-- Tombol Kembali ke Dashboard User -->
            <div class="pt-6 border-t border-slate-800/80">
                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">Navigasi Utama</span>
                <a href="/user/dashboard.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white text-xs font-semibold transition-all">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-arrow-left text-brand-400"></i>
                        <span>Dashboard User</span>
                    </div>
                    <i class="fa-solid fa-angle-right text-[10px]"></i>
                </a>
            </div>
        </div>

        <!-- Logout Button -->
        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <button type="button" 
                    @click="customConfirm({
                        title: 'Konfirmasi Keluar',
                        message: 'Apakah Anda yakin ingin keluar dari Admin Panel?',
                        variant: 'warning',
                        icon: 'fa-arrow-right-from-bracket',
                        confirmText: 'Ya, Keluar',
                        onConfirm: () => window.location.href = '/auth/logout.php'
                    })"
                    class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </button>
        </div>
    </aside>

    <!-- Main Admin Workspace -->
    <div class="flex-1 flex flex-col min-w-0">
        
        <!-- Top Navigation Bar -->
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-300 text-[10px] font-bold uppercase border border-amber-500/20">ADMINISTRATOR MODE</span>
                </div>
            </div>

            <div class="flex items-center gap-4">
                <a href="/user/dashboard.php" class="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-2 transition-all">
                    <i class="fa-solid fa-house text-brand-400"></i>
                    <span class="hidden sm:inline">Dashboard User</span>
                </a>

                <div class="flex items-center gap-3 bg-slate-800/60 border border-slate-700/50 py-1.5 px-3 rounded-full">
                    <div class="w-7 h-7 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-400 font-bold flex items-center justify-center text-xs">
                        <i class="fa-solid fa-user-gear"></i>
                    </div>
                    <span class="text-xs font-semibold text-slate-200"><?= e($currentUser['name']) ?></span>
                </div>
            </div>
        </header>

        <!-- Dynamic Content Area -->
        <main class="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto space-y-8">
            
            <!-- Stat Cards -->
            <div class="grid grid-cols-2 sm:grid-cols-6 gap-4">
                <div class="glass-card p-5 rounded-2xl border border-amber-500/30 bg-amber-500/5 flex items-center justify-between col-span-2 sm:col-span-1 shadow-lg shadow-amber-500/5">
                    <div>
                        <span class="text-[11px] text-amber-300 font-semibold uppercase tracking-wider block mb-1">Riwayat Kloning</span>
                        <span class="text-2xl font-black text-amber-400"><?= $totalCloneLogs ?></span>
                    </div>
                    <div class="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                    </div>
                </div>

                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div>
                        <span class="text-[11px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">Semua LP & AMP</span>
                        <span class="text-2xl font-bold text-emerald-400"><?= $totalProjects ?></span>
                    </div>
                    <div class="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-layer-group"></i>
                    </div>
                </div>

                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div>
                        <span class="text-[11px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">Templates</span>
                        <span class="text-2xl font-bold text-brand-400"><?= $totalTemplates ?></span>
                    </div>
                    <div class="w-10 h-10 rounded-xl bg-brand-500/10 text-brand-400 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-code"></i>
                    </div>
                </div>

                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div>
                        <span class="text-[11px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">Total Users</span>
                        <span class="text-2xl font-bold text-white"><?= $totalUsers ?></span>
                    </div>
                    <div class="w-10 h-10 rounded-xl bg-slate-800 text-slate-200 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-users"></i>
                    </div>
                </div>

                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div>
                        <span class="text-[11px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">Members Aktif</span>
                        <span class="text-2xl font-bold text-indigo-400"><?= $totalMembers ?></span>
                    </div>
                    <div class="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-user-group"></i>
                    </div>
                </div>

                <div class="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div>
                        <span class="text-[11px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">Berita Aktif</span>
                        <span class="text-2xl font-bold text-slate-200"><?= $totalNews ?></span>
                    </div>
                    <div class="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-newspaper"></i>
                    </div>
                </div>
            </div>

            <!-- TAB 0: RIWAYAT LOG KLONING PENGGUNA (Audit & Konversi Template) -->
            <div x-show="activeTab === 'clonelogs'" x-cloak class="space-y-6">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-clock-rotate-left text-amber-400"></i> Riwayat & Audit Kloning URL Pengguna
                        </h2>
                        <p class="text-xs text-slate-400 mt-1">
                            Lacak siapa saja pengguna yang mengkloning link website, URL target asli yang disedot, elemen terdeteksi, dan jadikan template publik secara instan.
                        </p>
                    </div>
                    <div class="flex items-center gap-3">
                        <?php if (!empty($allCloneLogs)): ?>
                            <form action="/admin/dashboard.php" method="POST" class="inline"
                                  @submit.prevent="customConfirm({
                                      title: 'Bersihkan Semua Log Kloning',
                                      message: 'Apakah Anda yakin ingin menghapus seluruh catatan riwayat kloning? Data project pengguna tetap aman dan tidak terhapus.',
                                      variant: 'danger',
                                      icon: 'fa-trash-can',
                                      confirmText: 'Ya, Bersihkan Semua',
                                      onConfirm: () => $el.submit()
                                  })">
                                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                <input type="hidden" name="action" value="clear_all_clone_logs">
                                <button type="submit" class="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-rose-500/20 border border-slate-700 hover:border-rose-500/40 text-rose-300 text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer">
                                    <i class="fa-solid fa-broom text-rose-400"></i> Bersihkan Log
                                </button>
                            </form>
                        <?php endif; ?>
                        <a href="/user/builder.php" class="px-4 py-2 rounded-xl bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white font-semibold text-xs shadow-lg shadow-brand-500/20 flex items-center gap-2 transition-all">
                            <i class="fa-solid fa-wand-magic-sparkles text-amber-300"></i> Test Clone di Builder
                        </a>
                    </div>
                </div>

                <!-- Table Log Kloning -->
                <div class="glass-card rounded-3xl border border-slate-800 overflow-hidden shadow-2xl">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm text-slate-300">
                            <thead class="bg-slate-900/90 text-xs font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-800">
                                <tr>
                                    <th class="py-4 px-5">ID & Waktu</th>
                                    <th class="py-4 px-5">Pengguna (User)</th>
                                    <th class="py-4 px-5">URL Target Asli</th>
                                    <th class="py-4 px-5">Hasil & Brand Baru</th>
                                    <th class="py-4 px-5">Elemen Terdeteksi</th>
                                    <th class="py-4 px-5 text-right">Aksi Cepat Admin</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-800/60">
                                <?php if (empty($allCloneLogs)): ?>
                                    <tr>
                                        <td colspan="6" class="py-12 text-center text-slate-500 text-sm">
                                            <div class="flex flex-col items-center justify-center gap-2">
                                                <i class="fa-solid fa-inbox text-2xl text-slate-600"></i>
                                                <span>Belum ada riwayat kloning URL dari pengguna. Setiap kloning yang dilakukan user akan otomatis tercatat di sini.</span>
                                            </div>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($allCloneLogs as $cLog): ?>
                                        <?php 
                                            $parsedTarget = parse_url($cLog['target_url'] ?? '');
                                            $targetHost = $parsedTarget['host'] ?? $cLog['target_url'];
                                        ?>
                                        <tr class="hover:bg-slate-900/40 transition-colors">
                                            <!-- ID & Waktu -->
                                            <td class="py-4 px-5 font-mono text-xs">
                                                <span class="text-amber-400 font-bold block">#<?= $cLog['id'] ?></span>
                                                <span class="text-slate-400 text-[11px] block"><?= date('d M Y, H:i', strtotime($cLog['created_at'])) ?></span>
                                                <span class="text-[10px] text-slate-500 block font-mono">IP: <?= e($cLog['ip_address'] ?: '127.0.0.1') ?></span>
                                            </td>

                                            <!-- Pengguna (User) -->
                                            <td class="py-4 px-5">
                                                <div class="flex items-center gap-3">
                                                    <div class="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 font-bold flex items-center justify-center text-xs text-brand-300 uppercase flex-shrink-0">
                                                        <?= strtoupper(substr($cLog['user_name'] ?? 'U', 0, 1)) ?>
                                                    </div>
                                                    <div class="min-w-0">
                                                        <div class="flex items-center gap-1.5 flex-wrap">
                                                            <span class="font-bold text-slate-100 text-xs truncate"><?= e($cLog['user_name'] ?? 'Anonim') ?></span>
                                                            <?php if (($cLog['user_role'] ?? '') === 'admin'): ?>
                                                                <span class="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold border border-amber-500/30">ADMIN</span>
                                                            <?php else: ?>
                                                                <span class="px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 text-[9px]">USER</span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <span class="text-[11px] text-slate-400 font-mono block truncate"><?= e($cLog['user_email'] ?? '-') ?></span>
                                                    </div>
                                                </div>
                                            </td>

                                            <!-- Target URL Asli -->
                                            <td class="py-4 px-5 max-w-xs">
                                                <div class="space-y-1">
                                                    <div class="flex items-center gap-1.5">
                                                        <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-mono border border-slate-700 truncate max-w-[200px]" title="<?= e($targetHost) ?>">
                                                            <i class="fa-solid fa-globe text-slate-400 mr-1"></i><?= e($targetHost) ?>
                                                        </span>
                                                        <span class="px-1.5 py-0.5 rounded bg-brand-500/10 text-brand-300 text-[9px] font-semibold uppercase">
                                                            <?= e($cLog['source_mode'] ?? 'auto') ?>
                                                        </span>
                                                    </div>
                                                    <a href="<?= e($cLog['target_url']) ?>" target="_blank" rel="noreferrer noopener" 
                                                       title="Buka Link Target Asli"
                                                       class="text-[11px] text-brand-400 hover:text-brand-300 hover:underline flex items-center gap-1 font-mono truncate max-w-[240px]">
                                                        <span class="truncate"><?= e($cLog['target_url']) ?></span>
                                                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px] flex-shrink-0"></i>
                                                    </a>
                                                </div>
                                            </td>

                                            <!-- Hasil & Brand Baru -->
                                            <td class="py-4 px-5">
                                                <div class="space-y-1">
                                                    <div class="flex items-center gap-2">
                                                        <span class="font-bold text-white text-xs"><?= e($cLog['brand_name']) ?></span>
                                                        <?php if (($cLog['page_format'] ?? 'lp') === 'amp'): ?>
                                                            <span class="px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[9px] font-bold">
                                                                <i class="fa-solid fa-bolt text-amber-400 mr-0.5"></i> AMP
                                                            </span>
                                                        <?php else: ?>
                                                            <span class="px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-300 text-[9px] font-bold">
                                                                <i class="fa-solid fa-globe text-blue-400 mr-0.5"></i> LP
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if (!empty($cLog['project_slug'])): ?>
                                                        <a href="/p.php?s=<?= e($cLog['project_slug']) ?>" target="_blank" class="text-[10px] text-emerald-400 hover:underline font-mono block">
                                                            /p.php?s=<?= e($cLog['project_slug']) ?>
                                                        </a>
                                                    <?php elseif ($cLog['project_id'] > 0): ?>
                                                        <span class="text-[10px] text-slate-500 font-mono">Project #<?= $cLog['project_id'] ?></span>
                                                    <?php else: ?>
                                                        <span class="text-[10px] text-slate-600 italic">Project sudah dihapus</span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>

                                            <!-- Elemen Terdeteksi -->
                                            <td class="py-4 px-5">
                                                <div class="flex flex-col gap-1">
                                                    <?php if ($cLog['reviews_count'] > 0): ?>
                                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-semibold w-fit">
                                                            <i class="fa-solid fa-star text-amber-400 text-[9px]"></i> <?= $cLog['reviews_count'] ?> Ulasan Terdeteksi
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-800 text-slate-500 text-[10px] w-fit">
                                                            <i class="fa-solid fa-minus text-[9px]"></i> Tanpa Ulasan
                                                        </span>
                                                    <?php endif; ?>

                                                    <?php if ($cLog['faqs_count'] > 0): ?>
                                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-[10px] font-semibold w-fit">
                                                            <i class="fa-solid fa-circle-question text-indigo-400 text-[9px]"></i> <?= $cLog['faqs_count'] ?> FAQ Terdeteksi
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-800 text-slate-500 text-[10px] w-fit">
                                                            <i class="fa-solid fa-minus text-[9px]"></i> Tanpa FAQ
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>

                                            <!-- Aksi Cepat Admin -->
                                            <td class="py-4 px-5 text-right">
                                                <div class="flex items-center justify-end gap-1.5">
                                                    <?php if ($cLog['project_id'] > 0 && !empty($cLog['project_current_name'])): ?>
                                                        <!-- Jadikan Template Sistem Otomatis -->
                                                        <form action="/admin/dashboard.php" method="POST" class="inline"
                                                              @submit.prevent="customConfirm({
                                                                  title: 'Jadikan Template Sistem',
                                                                  message: 'Konversi hasil kloning project &quot;<?= e(addslashes($cLog['project_current_name'])) ?>&quot; menjadi Template Sistem umum agar bisa langsung dipilih oleh semua pengguna lain di galeri template?',
                                                                  variant: 'success',
                                                                  icon: 'fa-wand-magic-sparkles',
                                                                  confirmText: 'Ya, Jadikan Template',
                                                                  onConfirm: () => $el.submit()
                                                              })">
                                                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                            <input type="hidden" name="action" value="convert_to_template">
                                                            <input type="hidden" name="project_id" value="<?= $cLog['project_id'] ?>">
                                                            <input type="hidden" name="template_name" value="Template <?= e($cLog['brand_name']) ?> (<?= strtoupper($cLog['page_format'] ?? 'AMP') ?>)">
                                                            <button type="submit" title="Jadikan Template Sistem Resmi" class="px-2.5 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer">
                                                                <i class="fa-solid fa-cube text-emerald-400"></i>
                                                                <span class="hidden md:inline">Jadikan Template</span>
                                                            </button>
                                                        </form>

                                                        <!-- Buka di Visual Builder -->
                                                        <a href="/user/builder.php?id=<?= $cLog['project_id'] ?>" title="Edit di Visual Builder" class="p-1.5 rounded-lg bg-slate-800 hover:bg-brand-600/30 border border-slate-700 hover:border-brand-500/50 text-brand-300 text-xs transition-all">
                                                            <i class="fa-solid fa-pen"></i>
                                                        </a>

                                                        <!-- Live Preview -->
                                                        <a href="/p.php?id=<?= $cLog['project_id'] ?>&preview=1" target="_blank" title="Lihat Pratinjau Live" class="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs transition-all">
                                                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                                        </a>
                                                    <?php endif; ?>

                                                    <!-- Hapus Log Ini -->
                                                    <form action="/admin/dashboard.php" method="POST" class="inline"
                                                          @submit.prevent="customConfirm({
                                                              title: 'Hapus Log Kloning',
                                                              message: 'Hapus catatan log kloning ini dari riwayat admin?',
                                                              variant: 'danger',
                                                              icon: 'fa-trash-can',
                                                              confirmText: 'Ya, Hapus Log',
                                                              onConfirm: () => $el.submit()
                                                          })">
                                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                        <input type="hidden" name="action" value="delete_clone_log">
                                                        <input type="hidden" name="log_id" value="<?= $cLog['id'] ?>">
                                                        <button type="submit" title="Hapus Log Riwayat Kloning" class="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-600/30 border border-slate-700 hover:border-rose-500/50 text-rose-400 text-xs transition-all cursor-pointer">
                                                            <i class="fa-solid fa-trash-can"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- TAB 1: USER MANAGEMENT -->
            <div x-show="activeTab === 'users'" class="space-y-6">
                <!-- User Table Header & Add Button -->
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-users-gear text-brand-400"></i> Kelola User & Hak Akses (Role)
                        </h2>
                        <p class="text-xs text-slate-400 mt-1">Ubah role pengguna atau hapus akun terdaftar</p>
                    </div>
                    <button @click="modalUserOpen = true" 
                            class="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-lg shadow-brand-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer">
                        <i class="fa-solid fa-user-plus"></i> Tambah User Baru
                    </button>
                </div>

                <!-- User Management Table -->
                <div class="glass-card rounded-3xl border border-slate-800 overflow-hidden shadow-2xl">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm text-slate-300">
                            <thead class="bg-slate-900/90 text-xs font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-800">
                                <tr>
                                    <th class="py-4 px-6">ID</th>
                                    <th class="py-4 px-6">Pengguna</th>
                                    <th class="py-4 px-6">Email</th>
                                    <th class="py-4 px-6">Role</th>
                                    <th class="py-4 px-6">Terdaftar</th>
                                    <th class="py-4 px-6 text-right">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-800/60">
                                <?php foreach ($allUsers as $u): ?>
                                    <tr class="hover:bg-slate-900/40 transition-colors">
                                        <td class="py-4 px-6 font-mono text-xs text-slate-500">#<?= $u['id'] ?></td>
                                        <td class="py-4 px-6">
                                            <div class="flex items-center gap-3">
                                                <div class="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 font-bold flex items-center justify-center text-sm text-brand-300 uppercase">
                                                    <?= strtoupper(substr($u['name'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <span class="font-semibold text-slate-100 block"><?= e($u['name']) ?></span>
                                                    <?php if ($u['id'] === $currentUser['id']): ?>
                                                        <span class="text-[10px] text-amber-400 font-semibold">(Anda)</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="py-4 px-6 text-slate-300 font-mono text-xs"><?= e($u['email']) ?></td>
                                        <td class="py-4 px-6">
                                            <?php if ($u['role'] === 'admin'): ?>
                                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
                                                    <i class="fa-solid fa-shield-halved text-[10px]"></i> ADMIN
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
                                                    <i class="fa-solid fa-user text-[10px]"></i> USER
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="py-4 px-6 text-xs text-slate-400">
                                            <?= date('d M Y, H:i', strtotime($u['created_at'])) ?>
                                        </td>
                                        <td class="py-4 px-6 text-right space-x-2">
                                            <?php if ($u['id'] !== $currentUser['id']): ?>
                                                <!-- Form Ubah Role -->
                                                <form action="/admin/dashboard.php" method="POST" class="inline"
                                                      @submit.prevent="customConfirm({
                                                          title: 'Ubah Role Pengguna',
                                                          message: 'Ubah role <?= e($u['name']) ?> dari <?= strtoupper($u['role']) ?> menjadi <?= $u['role'] === 'admin' ? 'USER' : 'ADMIN' ?>?',
                                                          variant: 'warning',
                                                          icon: 'fa-user-pen',
                                                          confirmText: 'Ya, Ubah Role',
                                                          onConfirm: () => $el.submit()
                                                      })">
                                                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                    <input type="hidden" name="action" value="toggle_role">
                                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                                    <input type="hidden" name="new_role" value="<?= $u['role'] === 'admin' ? 'user' : 'admin' ?>">
                                                    <button type="submit" class="p-2 rounded-lg bg-slate-800 hover:bg-indigo-600/30 border border-slate-700 hover:border-indigo-500/50 text-indigo-300 text-xs transition-all cursor-pointer">
                                                        <i class="fa-solid fa-user-pen"></i> Ubah Role
                                                    </button>
                                                </form>

                                                <!-- Form Hapus User -->
                                                <form action="/admin/dashboard.php" method="POST" class="inline"
                                                      @submit.prevent="customConfirm({
                                                          title: 'Hapus Pengguna',
                                                          message: 'Apakah Anda yakin ingin menghapus akun <?= e($u['name']) ?> secara permanen?',
                                                          variant: 'danger',
                                                          icon: 'fa-user-slash',
                                                          confirmText: 'Ya, Hapus Permanen',
                                                          onConfirm: () => $el.submit()
                                                      })">
                                                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                    <input type="hidden" name="action" value="delete_user">
                                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                                    <button type="submit" class="p-2 rounded-lg bg-slate-800 hover:bg-rose-600/30 border border-slate-700 hover:border-rose-500/50 text-rose-400 text-xs transition-all cursor-pointer">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-xs text-slate-600 italic">No Action</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- TAB 2: NEWS MANAGEMENT -->
            <div x-show="activeTab === 'news'" class="space-y-6" style="display: none;">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-newspaper text-brand-400"></i> Kelola Berita & Pengumuman
                        </h2>
                        <p class="text-xs text-slate-400 mt-1">Terbitkan pengumuman baru untuk seluruh pengguna</p>
                    </div>
                    <button @click="modalNewsOpen = true" 
                            class="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-lg shadow-brand-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer">
                        <i class="fa-solid fa-plus"></i> Terbitkan Berita Baru
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <?php if (empty($allNews)): ?>
                        <div class="col-span-2 p-8 text-center text-slate-500 text-sm glass-card rounded-2xl">Belum ada berita diterbitkan.</div>
                    <?php else: ?>
                        <?php foreach ($allNews as $n): ?>
                            <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4 relative flex flex-col justify-between">
                                <div class="space-y-2">
                                    <div class="flex items-center justify-between">
                                        <span class="px-2.5 py-0.5 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-300 text-[10px] font-semibold">
                                            <?= e($n['category']) ?>
                                        </span>
                                        <span class="text-xs text-slate-500"><?= date('d M Y, H:i', strtotime($n['created_at'])) ?></span>
                                    </div>
                                    <h3 class="text-base font-bold text-white"><?= e($n['title']) ?></h3>
                                    <p class="text-xs text-slate-400 leading-relaxed"><?= nl2br(e($n['content'])) ?></p>
                                </div>

                                <div class="pt-3 border-t border-slate-800/60 flex items-center justify-between">
                                    <span class="text-[11px] text-slate-500">Penulis: <?= e($n['author_name']) ?></span>

                                    <form action="/admin/dashboard.php" method="POST"
                                          @submit.prevent="customConfirm({
                                              title: 'Hapus Berita',
                                              message: 'Apakah Anda yakin ingin menghapus berita ini?',
                                              variant: 'danger',
                                              icon: 'fa-trash',
                                              confirmText: 'Hapus',
                                              onConfirm: () => $el.submit()
                                          })">
                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                        <input type="hidden" name="action" value="delete_news">
                                        <input type="hidden" name="news_id" value="<?= $n['id'] ?>">
                                        <button type="submit" class="text-xs text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1 cursor-pointer">
                                            <i class="fa-solid fa-trash-can"></i> Hapus
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- TAB 3: TEMPLATES -->
            <div x-show="activeTab === 'templates'" x-cloak>
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                    <div>
                        <h2 class="text-xl font-bold text-white">Manajemen Template</h2>
                        <p class="text-sm text-slate-400">Kelola template HTML untuk digunakan user di Builder</p>
                    </div>
                    <button @click="modalTemplateOpen = true; setTimeout(() => initCodeMirrorAdd(), 100)" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-brand-500/20 transition-all flex items-center gap-2">
                        <i class="fa-solid fa-code"></i> Tambah Template
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php if (empty($allTemplates)): ?>
                        <div class="col-span-full py-12 text-center glass-card rounded-3xl border border-slate-800">
                            <i class="fa-solid fa-code text-4xl text-slate-600 mb-4"></i>
                            <h3 class="text-lg font-bold text-slate-300">Belum Ada Template</h3>
                            <p class="text-slate-500 text-sm mt-1">Sistem belum memiliki template apapun.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($allTemplates as $tpl): ?>
                            <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4 relative flex flex-col justify-between">
                                <div class="space-y-2">
                                    <div class="flex items-center justify-between">
                                        <span class="px-2.5 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-[10px] font-semibold">
                                            ID: <?= $tpl['id'] ?> <?= $tpl['id'] == 1 ? '(Default)' : '' ?>
                                        </span>
                                        <span class="text-xs text-slate-500"><?= date('d M Y, H:i', strtotime($tpl['created_at'])) ?></span>
                                    </div>
                                    <h3 class="text-base font-bold text-white"><?= e($tpl['name']) ?></h3>
                                    <p class="text-xs text-slate-400 leading-relaxed"><?= e($tpl['description']) ?></p>
                                </div>

                                <div class="pt-4 border-t border-slate-800/60 flex items-center justify-between">
                                    <button @click="editTpl = <?= htmlspecialchars(json_encode($tpl), ENT_QUOTES, 'UTF-8') ?>; modalEditTemplateOpen = true; setTimeout(() => initCodeMirrorEdit(), 100)" class="text-xs text-brand-400 hover:text-brand-300 font-semibold flex items-center gap-1 cursor-pointer">
                                        <i class="fa-solid fa-pen"></i> Edit
                                    </button>
                                    
                                    <?php if ($tpl['id'] != 1): ?>
                                    <form action="/admin/dashboard.php" method="POST"
                                          @submit.prevent="customConfirm({
                                              title: 'Hapus Template',
                                              message: 'Apakah Anda yakin ingin menghapus template ini? Pastikan tidak ada project yang menggunakannya.',
                                              variant: 'danger',
                                              icon: 'fa-trash',
                                              confirmText: 'Hapus',
                                              onConfirm: () => $el.submit()
                                          })">
                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                        <input type="hidden" name="action" value="delete_template">
                                        <input type="hidden" name="template_id" value="<?= $tpl['id'] ?>">
                                        <button type="submit" class="text-xs text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1 cursor-pointer">
                                            <i class="fa-solid fa-trash-can"></i> Hapus
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- TAB 4: ALL PROJECTS & CLONING LOGS (Siapa yang Kloning & Jadikan Template Otomatis) -->
            <div x-show="activeTab === 'projects'" x-cloak class="space-y-6">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-layer-group text-brand-400"></i> Semua Project & Kloning Pengguna
                        </h2>
                        <p class="text-xs text-slate-400 mt-1">Pantau siapa saja pengguna yang melakukan kloning / membuat landing page dan jadikan sebagai Template Sistem dengan 1-klik</p>
                    </div>
                    <div class="flex items-center gap-3">
                        <a href="/user/builder.php" class="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-lg shadow-brand-500/20 flex items-center gap-2 transition-all">
                            <i class="fa-solid fa-wand-magic-sparkles"></i> Buka Visual Builder
                        </a>
                    </div>
                </div>

                <div class="glass-card rounded-3xl border border-slate-800 overflow-hidden shadow-2xl">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm text-slate-300">
                            <thead class="bg-slate-900/90 text-xs font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-800">
                                <tr>
                                    <th class="py-4 px-6">ID</th>
                                    <th class="py-4 px-6">Landing Page / Brand</th>
                                    <th class="py-4 px-6">Dibuat / Dikloning Oleh</th>
                                    <th class="py-4 px-6">Tipe & Status</th>
                                    <th class="py-4 px-6">Waktu Kloning</th>
                                    <th class="py-4 px-6 text-right">Otomatisasi Template & Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-800/60">
                                <?php if (empty($allProjects)): ?>
                                    <tr>
                                        <td colspan="6" class="py-12 text-center text-slate-500 text-sm">Belum ada project atau kloningan dari pengguna manapun.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($allProjects as $proj): ?>
                                        <tr class="hover:bg-slate-900/40 transition-colors">
                                            <td class="py-4 px-6 font-mono text-xs text-slate-500">#<?= $proj['id'] ?></td>
                                            <td class="py-4 px-6">
                                                <div class="flex items-center gap-3">
                                                    <div class="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-200 uppercase overflow-hidden">
                                                        <?php if (!empty($proj['logo_url'])): ?>
                                                            <img src="<?= e($proj['logo_url']) ?>" alt="Logo" class="w-full h-full object-contain p-1" onerror="this.remove()">
                                                        <?php else: ?>
                                                            <?= strtoupper(substr($proj['name'], 0, 2)) ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div>
                                                        <span class="font-bold text-white block text-sm"><?= e($proj['name']) ?></span>
                                                        <span class="text-[11px] text-slate-400 font-mono">/p.php?s=<?= e($proj['slug']) ?></span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="py-4 px-6">
                                                <div class="space-y-0.5">
                                                    <div class="flex items-center gap-2">
                                                        <span class="font-semibold text-slate-200"><?= e($proj['creator_name'] ?: 'Tidak Diketahui') ?></span>
                                                        <?php if (($proj['creator_role'] ?? '') === 'admin'): ?>
                                                            <span class="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold border border-amber-500/30">ADMIN</span>
                                                        <?php else: ?>
                                                            <span class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 text-[9px]">USER</span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <span class="text-xs text-slate-500 block"><?= e($proj['creator_email'] ?: '-') ?></span>
                                                </div>
                                            </td>
                                            <td class="py-4 px-6">
                                                <div class="flex items-center gap-2">
                                                    <?php if (($proj['type'] ?? 'amp') === 'amp'): ?>
                                                        <span class="px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-bold">
                                                            <i class="fa-solid fa-bolt text-amber-400 mr-1"></i> AMP
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-300 text-[10px] font-bold">
                                                            <i class="fa-solid fa-globe text-blue-400 mr-1"></i> LP
                                                        </span>
                                                    <?php endif; ?>

                                                    <?php if (($proj['status'] ?? 'draft') === 'published'): ?>
                                                        <span class="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 text-[10px] font-bold">Live</span>
                                                    <?php else: ?>
                                                        <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[10px]">Draft</span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td class="py-4 px-6 text-xs text-slate-400">
                                                <?= date('d M Y, H:i', strtotime($proj['created_at'])) ?>
                                            </td>
                                            <td class="py-4 px-6 text-right">
                                                <div class="flex items-center justify-end gap-2">
                                                    <!-- Tombol Otomatis Jadikan Template Sistem -->
                                                    <form action="/admin/dashboard.php" method="POST" class="inline"
                                                          @submit.prevent="customConfirm({
                                                              title: 'Jadikan Template Otomatis',
                                                              message: 'Konversi hasil kloning project <?= e(addslashes($proj['name'])) ?> ini menjadi Template Sistem resmi agar dapat digunakan oleh semua pengguna lain di masa mendatang?',
                                                              variant: 'success',
                                                              icon: 'fa-wand-magic-sparkles',
                                                              confirmText: 'Ya, Jadikan Template',
                                                              onConfirm: () => $el.submit()
                                                          })">
                                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                        <input type="hidden" name="action" value="convert_to_template">
                                                        <input type="hidden" name="project_id" value="<?= $proj['id'] ?>">
                                                        <input type="hidden" name="template_name" value="Template <?= e($proj['name']) ?> (<?= strtoupper($proj['type'] ?? 'AMP') ?>)">
                                                        <button type="submit" title="Jadikan Template Sistem Otomatis" class="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer">
                                                            <i class="fa-solid fa-cube text-emerald-400"></i>
                                                            <span>Jadikan Template</span>
                                                        </button>
                                                    </form>

                                                    <!-- Quick Edit Detail Project (Admin) -->
                                                    <button type="button" @click="editProj = <?= htmlspecialchars(json_encode($proj), ENT_QUOTES, 'UTF-8') ?>; modalEditProjectOpen = true;" title="Ubah Detail Project (Admin)" class="p-2 rounded-lg bg-slate-800 hover:bg-amber-600/30 border border-slate-700 hover:border-amber-500/50 text-amber-300 text-xs transition-all cursor-pointer">
                                                        <i class="fa-solid fa-sliders"></i>
                                                    </button>

                                                    <!-- Edit di Builder -->
                                                    <a href="/user/builder.php?id=<?= $proj['id'] ?>" title="Buka di Builder" class="p-2 rounded-lg bg-slate-800 hover:bg-indigo-600/30 border border-slate-700 hover:border-indigo-500/50 text-indigo-300 text-xs transition-all">
                                                        <i class="fa-solid fa-pen"></i>
                                                    </a>

                                                    <!-- Preview Langsung -->
                                                    <a href="/p.php?id=<?= $proj['id'] ?>&preview=1" target="_blank" title="Lihat Pratinjau Live" class="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs transition-all">
                                                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                                    </a>

                                                    <!-- Hapus Project (Admin) -->
                                                    <form action="/admin/dashboard.php" method="POST" class="inline"
                                                          @submit.prevent="customConfirm({
                                                              title: 'Hapus Project',
                                                              message: 'Hapus project <?= e(addslashes($proj['name'])) ?> secara permanen dari server?',
                                                              variant: 'danger',
                                                              icon: 'fa-trash-can',
                                                              confirmText: 'Hapus Permanen',
                                                              onConfirm: () => $el.submit()
                                                          })">
                                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                        <input type="hidden" name="action" value="delete_project_admin">
                                                        <input type="hidden" name="project_id" value="<?= $proj['id'] ?>">
                                                        <button type="submit" title="Hapus Project" class="p-2 rounded-lg bg-slate-800 hover:bg-rose-600/30 border border-slate-700 hover:border-rose-500/50 text-rose-400 text-xs transition-all cursor-pointer">
                                                            <i class="fa-solid fa-trash-can"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <!-- MODAL 1: Tambah User -->
    <div x-show="modalUserOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" 
         x-cloak>
        
        <div @click.away="modalUserOpen = false" 
             class="glass-card w-full max-w-lg p-6 rounded-3xl border border-slate-700 shadow-2xl space-y-6">
            
            <div class="flex items-center justify-between border-b border-slate-800 pb-4">
                <h3 class="text-lg font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-user-plus text-brand-400"></i> Tambah Pengguna Baru
                </h3>
                <button @click="modalUserOpen = false" class="text-slate-400 hover:text-white">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <form action="/admin/dashboard.php" method="POST" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_user">
                
                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Nama Lengkap</label>
                    <input type="text" name="name" required placeholder="Nama User Baru"
                           class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Email</label>
                    <input type="email" name="email" required placeholder="email@domain.com"
                           class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Password</label>
                    <input type="password" name="password" required placeholder="••••••••"
                           class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Role</label>
                    <select name="role" class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        <option value="user">User Biasa</option>
                        <option value="admin">Administrator</option>
                    </select>
                </div>

                <div class="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
                    <button type="button" @click="modalUserOpen = false" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700">
                        Batal
                    </button>
                    <button type="submit" class="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold shadow-lg shadow-brand-500/20">
                        Simpan User
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL 2: Tambah Berita / News -->
    <div x-show="modalNewsOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" 
         x-cloak>
        
        <div @click.away="modalNewsOpen = false" 
             class="glass-card w-full max-w-lg p-6 rounded-3xl border border-slate-700 shadow-2xl space-y-6">
            
            <div class="flex items-center justify-between border-b border-slate-800 pb-4">
                <h3 class="text-lg font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-newspaper text-brand-400"></i> Terbitkan Berita Baru
                </h3>
                <button @click="modalNewsOpen = false" class="text-slate-400 hover:text-white">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <form action="/admin/dashboard.php" method="POST" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_news">
                
                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Judul Berita / Pengumuman</label>
                    <input type="text" name="title" required placeholder="Judul Pengumuman"
                           class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Kategori</label>
                    <select name="category" class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        <option value="Pengumuman">Pengumuman</option>
                        <option value="Fitur Baru">Fitur Baru</option>
                        <option value="Pemeliharaan">Pemeliharaan Server</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Isi Berita / Pesan</label>
                    <textarea name="content" rows="4" required placeholder="Tuliskan isi pengumuman lengkap..."
                              class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500"></textarea>
                </div>

                <div class="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
                    <button type="button" @click="modalNewsOpen = false" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700">
                        Batal
                    </button>
                    <button type="submit" class="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold shadow-lg shadow-brand-500/20">
                        Terbitkan Berita
                    </button>
                </div>
            </form>
        </div>
    </div>
    <!-- MODAL 3: Tambah Template -->
    <div x-show="modalTemplateOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" 
         x-cloak>
        
        <div @click.away="modalTemplateOpen = false" 
             class="glass-card w-full max-w-4xl max-h-[90vh] flex flex-col rounded-3xl border border-slate-700 shadow-2xl overflow-hidden">
            
            <div class="flex items-center justify-between border-b border-slate-800 p-6 pb-4">
                <h3 class="text-lg font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-code text-brand-400"></i> Tambah Template Baru
                </h3>
                <button @click="modalTemplateOpen = false" class="text-slate-400 hover:text-white">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <form action="/admin/dashboard.php" method="POST" enctype="multipart/form-data" class="flex flex-col flex-1 overflow-hidden">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_template">
                
                <div class="flex-1 overflow-y-auto p-6 space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Nama Template <span class="text-rose-500">*</span></label>
                            <input type="text" name="name" required placeholder="Contoh: Template Dewa Slot"
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Deskripsi Singkat</label>
                            <input type="text" name="description" placeholder="Deskripsi opsional..."
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        </div>
                    </div>

                    <div class="flex items-center gap-4 my-2">
                        <div class="flex-1 h-px bg-slate-800"></div>
                        <span class="text-xs text-slate-500 font-semibold uppercase tracking-wider">Input HTML (Pilih Salah Satu)</span>
                        <div class="flex-1 h-px bg-slate-800"></div>
                    </div>

                    <div class="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-4 text-xs text-indigo-300">
                        <div class="font-bold text-indigo-200 mb-2 flex items-center gap-2">
                            <i class="fa-solid fa-circle-info"></i> Dokumentasi Variabel Dinamis (Dynamic Tags)
                        </div>
                        <p class="mb-2 text-indigo-300/80 leading-relaxed">Gunakan tag ini di dalam HTML Anda agar nilainya otomatis di-generate oleh sistem dari Builder:</p>
                        <ul class="list-disc pl-4 space-y-1 text-indigo-300/90 font-mono text-[10px]">
                            <li>{{ title | default('Teks Default') }} &mdash; <span class="font-sans text-xs">Untuk Judul SEO / H1</span></li>
                            <li>{{ meta_description | default('...') }} &mdash; <span class="font-sans text-xs">Untuk Tag Meta Description</span></li>
                            <li>{{ canonical_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk Tag rel="canonical"</span></li>
                            <li>{{ amp_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk Tag rel="amphtml"</span></li>
                            <li>{{ logo_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk atribut src logo (img)</span></li>
                            <li>{{ banner_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk atribut src banner utama (img)</span></li>
                            <li>{{ block:faqs }} &mdash; <span class="font-sans text-xs">Merender otomatis daftar Accordion FAQ</span></li>
                            <li>{{ block:reviews }} &mdash; <span class="font-sans text-xs">Merender otomatis Grid Testimonial & Rating</span></li>
                        </ul>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Upload File (.html, .php)</label>
                        <input type="file" name="template_file" accept=".html,.php,.txt"
                               class="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-300 text-sm focus:outline-none focus:border-brand-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-brand-500/10 file:text-brand-300 hover:file:bg-brand-500/20">
                        <p class="text-[10px] text-slate-500 mt-1">Jika Anda mengupload file, kode di editor akan diabaikan saat disimpan.</p>
                    </div>

                    <div class="flex flex-col h-80">
                        <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Atau Paste Kode HTML di Sini <span class="text-rose-500">*</span></label>
                        <div class="flex-1 border border-slate-700 rounded-xl overflow-hidden bg-[#04080f]">
                            <textarea id="cm-add" name="html_content"></textarea>
                        </div>
                    </div>
                </div>

                <div class="p-6 pt-4 flex items-center justify-end gap-3 border-t border-slate-800 bg-slate-900/50">
                    <button type="button" @click="modalTemplateOpen = false" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700">
                        Batal
                    </button>
                    <button type="submit" class="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold shadow-lg shadow-brand-500/20">
                        Simpan Template
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL 4: Edit Template -->
    <div x-show="modalEditTemplateOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" 
         x-cloak>
        
        <div @click.away="modalEditTemplateOpen = false" 
             class="glass-card w-full max-w-4xl max-h-[95vh] flex flex-col rounded-3xl border border-slate-700 shadow-2xl overflow-hidden">
            
            <div class="flex items-center justify-between border-b border-slate-800 p-6 pb-4">
                <h3 class="text-lg font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-pen text-brand-400"></i> Edit Template HTML
                </h3>
                <button @click="modalEditTemplateOpen = false" class="text-slate-400 hover:text-white">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <form action="/admin/dashboard.php" method="POST" class="flex flex-col flex-1 overflow-hidden">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="edit_template">
                <input type="hidden" name="id" :value="editTpl.id">
                
                <div class="flex-1 overflow-y-auto p-6 space-y-4 flex flex-col">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 flex-shrink-0">
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Nama Template <span class="text-rose-500">*</span></label>
                            <input type="text" name="name" :value="editTpl.name" required
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Deskripsi Singkat</label>
                            <input type="text" name="description" :value="editTpl.description"
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        </div>
                    </div>

                    <div class="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-4 text-xs text-indigo-300 flex-shrink-0">
                        <div class="font-bold text-indigo-200 mb-2 flex items-center gap-2">
                            <i class="fa-solid fa-circle-info"></i> Dokumentasi Variabel Dinamis (Dynamic Tags)
                        </div>
                        <p class="mb-2 text-indigo-300/80 leading-relaxed">Gunakan tag ini di dalam HTML Anda agar nilainya otomatis di-generate oleh sistem dari Builder:</p>
                        <ul class="list-disc pl-4 space-y-1 text-indigo-300/90 font-mono text-[10px]">
                            <li>{{ title | default('Teks Default') }} &mdash; <span class="font-sans text-xs">Untuk Judul SEO / H1</span></li>
                            <li>{{ meta_description | default('...') }} &mdash; <span class="font-sans text-xs">Untuk Tag Meta Description</span></li>
                            <li>{{ canonical_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk Tag rel="canonical"</span></li>
                            <li>{{ amp_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk Tag rel="amphtml"</span></li>
                            <li>{{ logo_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk atribut src logo (img)</span></li>
                            <li>{{ banner_url | default('...') }} &mdash; <span class="font-sans text-xs">Untuk atribut src banner utama (img)</span></li>
                            <li>{{ block:faqs }} &mdash; <span class="font-sans text-xs">Merender otomatis daftar Accordion FAQ</span></li>
                            <li>{{ block:reviews }} &mdash; <span class="font-sans text-xs">Merender otomatis Grid Testimonial & Rating</span></li>
                        </ul>
                    </div>

                    <div class="flex flex-col flex-1 min-h-[400px]">
                        <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Kode HTML <span class="text-rose-500">*</span></label>
                        <div class="flex-1 border border-slate-700 rounded-xl overflow-hidden bg-[#04080f] flex flex-col">
                            <textarea id="cm-edit" name="html_content" class="flex-1"></textarea>
                        </div>
                    </div>
                </div>

                <div class="p-6 pt-4 flex items-center justify-end gap-3 border-t border-slate-800 bg-slate-900/50 flex-shrink-0">
                    <button type="button" @click="modalEditTemplateOpen = false" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700">
                        Batal
                    </button>
                    <button type="submit" class="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold shadow-lg shadow-brand-500/20">
                        Update Template
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL 5: Edit Detail Project (Admin Mode) -->
    <div x-show="modalEditProjectOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" 
         x-cloak>
        
        <div @click.away="modalEditProjectOpen = false" 
             class="glass-card w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl border border-slate-700 shadow-2xl overflow-hidden">
            
            <div class="flex items-center justify-between border-b border-slate-800 p-6 pb-4">
                <div>
                    <h3 class="text-lg font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-sliders text-amber-400"></i> Edit Detail Project #<span x-text="editProj.id"></span>
                    </h3>
                    <p class="text-xs text-slate-400 mt-0.5">Ubah nama brand, link, judul, dan status project langsung dari kontrol Admin</p>
                </div>
                <button @click="modalEditProjectOpen = false" class="text-slate-400 hover:text-white">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <form action="/admin/dashboard.php" method="POST" class="flex flex-col flex-1 overflow-hidden">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="edit_project_admin">
                <input type="hidden" name="project_id" :value="editProj.id">
                <input type="hidden" name="redirect_tab" :value="activeTab">
                
                <div class="flex-1 overflow-y-auto p-6 space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Nama Project <span class="text-rose-500">*</span></label>
                            <input type="text" name="name" :value="editProj.name" required
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Nama Brand Resmi</label>
                            <input type="text" name="brand_name" :value="editProj.brand_name || editProj.name"
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Format Halaman</label>
                            <select name="type" :value="editProj.type || 'amp'"
                                    class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                                <option value="amp">Google AMP (⚡ Super Cepat)</option>
                                <option value="lp">Landing Page Biasa (🌐 HTML5 Standard)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Status Publikasi</label>
                            <select name="status" :value="editProj.status || 'draft'"
                                    class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                                <option value="draft">Draft (Private)</option>
                                <option value="published">Published (Live Publik)</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Judul SEO Halaman (Title)</label>
                        <input type="text" name="title" :value="editProj.title" placeholder="Judul Halaman..."
                               class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">URL Canonical</label>
                            <input type="text" name="canonical_url" :value="editProj.canonical_url" placeholder="https://..."
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm font-mono text-xs focus:outline-none focus:border-brand-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">URL Google AMP</label>
                            <input type="text" name="amp_url" :value="editProj.amp_url" placeholder="https://.../amp"
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm font-mono text-xs focus:outline-none focus:border-brand-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Link Tombol Login</label>
                            <input type="text" name="login_url" :value="editProj.login_url" placeholder="https://..."
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm font-mono text-xs focus:outline-none focus:border-brand-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Link Tombol Daftar</label>
                            <input type="text" name="register_url" :value="editProj.register_url" placeholder="https://..."
                                   class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm font-mono text-xs focus:outline-none focus:border-brand-500">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Meta Description</label>
                        <textarea name="meta_description" rows="3" :value="editProj.meta_description" placeholder="Deskripsi meta untuk search engine..."
                                  class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500"></textarea>
                    </div>
                </div>

                <div class="p-6 pt-4 flex items-center justify-between border-t border-slate-800 bg-slate-900/50 flex-shrink-0">
                    <a :href="'/user/builder.php?id=' + editProj.id" class="text-xs text-brand-400 hover:text-brand-300 font-semibold flex items-center gap-1.5">
                        <i class="fa-solid fa-pen-to-square"></i> Buka Full Visual Builder
                    </a>
                    <div class="flex items-center gap-3">
                        <button type="button" @click="modalEditProjectOpen = false" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700">
                            Batal
                        </button>
                        <button type="submit" class="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20">
                            Simpan Perubahan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>

    <!-- CodeMirror Resources -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/htmlmixed/htmlmixed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/xml/xml.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/javascript/javascript.min.js"></script>

    <style>
        .CodeMirror { height: 100% !important; font-family: monospace; font-size: 13px; background:#04080f !important;}
        .cm-wrap-bldr { flex:1; display:flex; flex-direction:column; }
    </style>

    <script>
        let cmAddInstance, cmEditInstance;

        function initCodeMirrorAdd() {
            if (!cmAddInstance) {
                cmAddInstance = CodeMirror.fromTextArea(document.getElementById('cm-add'), {
                    mode: 'htmlmixed', theme: 'dracula', lineNumbers: true, lineWrapping: true
                });
            } else {
                cmAddInstance.refresh();
            }
        }

        function initCodeMirrorEdit() {
            const el = document.getElementById('cm-edit');
            // We get the Alpine context's editTpl
            const editData = document.querySelector('[x-data]').__x.$data.editTpl;
            
            if (!cmEditInstance) {
                cmEditInstance = CodeMirror.fromTextArea(el, {
                    mode: 'htmlmixed', theme: 'dracula', lineNumbers: true, lineWrapping: true
                });
                cmEditInstance.setValue(editData.html_content || '');
            } else {
                cmEditInstance.setValue(editData.html_content || '');
                cmEditInstance.refresh();
            }
        }

        // Initialize CodeMirror when tab becomes visible (just in case they were hidden)
        function initCodeMirror() {
            setTimeout(() => {
                if (cmAddInstance) cmAddInstance.refresh();
                if (cmEditInstance) cmEditInstance.refresh();
            }, 100);
        }
    </script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
