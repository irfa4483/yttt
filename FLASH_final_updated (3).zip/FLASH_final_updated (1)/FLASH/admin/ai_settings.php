<?php
// admin/ai_settings.php
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$currentUser = current_user();

// Fetch settings
function get_setting($key, $default = '') {
    global $pdo;
    $stmt = $pdo->prepare("SELECT value FROM settings WHERE key = ?");
    $stmt->execute([$key]);
    $res = $stmt->fetch();
    return $res ? $res['value'] : $default;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        set_flash('error', 'Validasi token CSRF gagal.');
        header('Location: /admin/ai_settings.php');
        exit;
    }

    $aiProvider      = trim($_POST['ai_provider'] ?? 'gemini');
    $aiApiKey        = trim($_POST['ai_api_key'] ?? '');
    $aiApiKeyBuilder = trim($_POST['ai_api_key_builder'] ?? '');
    $aiApiKeyCloak   = trim($_POST['ai_api_key_cloaking'] ?? '');
    $aiModel         = trim($_POST['ai_model'] ?? 'gemini-3.6-flash');
    $siteDomain      = trim($_POST['site_domain'] ?? 'http://localhost:8000');
    $tgToken         = trim($_POST['telegram_bot_token'] ?? '');
    $tgUsername      = trim($_POST['telegram_bot_username'] ?? 'FlashOfficialBot');
    $tgEnabled       = isset($_POST['telegram_otp_enabled']) ? '1' : '0';

    $bankName        = trim($_POST['bank_name'] ?? 'BCA');
    $bankAccNumber   = trim($_POST['bank_account_number'] ?? '');
    $bankAccName     = trim($_POST['bank_account_name'] ?? '');

    // Handle Upload Gambar QRIS kustom
    $qrisImagePath = get_setting('qris_image_path', '');
    if (isset($_FILES['qris_image']) && $_FILES['qris_image']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['qris_image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            $qrisDir = __DIR__ . '/../uploads/qris/';
            if (!is_dir($qrisDir)) {
                @mkdir($qrisDir, 0755, true);
            }
            $newQrisFile = 'qris_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['qris_image']['tmp_name'], $qrisDir . $newQrisFile)) {
                $qrisImagePath = '/uploads/qris/' . $newQrisFile;
            }
        }
    }

    $saveSetting = $pdo->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
    $saveSetting->execute(['ai_provider', $aiProvider]);
    $saveSetting->execute(['ai_api_key', $aiApiKey]);
    $saveSetting->execute(['ai_api_key_builder', $aiApiKeyBuilder]);
    $saveSetting->execute(['ai_api_key_cloaking', $aiApiKeyCloak]);
    $saveSetting->execute(['ai_model', $aiModel]);
    $saveSetting->execute(['site_domain', $siteDomain]);
    $saveSetting->execute(['telegram_bot_token', $tgToken]);
    $saveSetting->execute(['telegram_bot_username', $tgUsername]);
    $saveSetting->execute(['telegram_otp_enabled', $tgEnabled]);
    $saveSetting->execute(['bank_name', $bankName]);
    $saveSetting->execute(['bank_account_number', $bankAccNumber]);
    $saveSetting->execute(['bank_account_name', $bankAccName]);
    $saveSetting->execute(['qris_image_path', $qrisImagePath]);

    set_flash('success', 'Pengaturan AI, Pemisahan API Key, Pembayaran & Integrasi Telegram berhasil disimpan!');
    header('Location: /admin/ai_settings.php');
    exit;
}

$aiProvider      = get_setting('ai_provider', 'gemini');
$aiApiKey        = get_setting('ai_api_key', '');
$aiApiKeyBuilder = get_setting('ai_api_key_builder', '');
$aiApiKeyCloak   = get_setting('ai_api_key_cloaking', '');
$aiModel         = get_setting('ai_model', 'gemini-3.6-flash');
$siteDomain      = get_setting('site_domain', 'http://localhost:8000');
$tgToken         = get_setting('telegram_bot_token', '');
$tgUsername      = get_setting('telegram_bot_username', 'FlashOfficialBot');
$tgEnabled       = get_setting('telegram_otp_enabled', '0');
$bankName        = get_setting('bank_name', 'BCA');
$bankAccNumber   = get_setting('bank_account_number', '8735091234');
$bankAccName     = get_setting('bank_account_name', 'FLASH OFFICIAL');
$qrisImagePath   = get_setting('qris_image_path', '');

$pageTitle = 'Pengaturan AI API Key';

// Fetch counts for sidebar
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalNews = $pdo->query("SELECT COUNT(*) FROM news")->fetchColumn();
$totalTemplates = $pdo->query("SELECT COUNT(*) FROM templates")->fetchColumn();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" x-data="{ sidebarOpen: false }">
    
    <!-- Admin Sidebar Navigation -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        
        <div class="p-6 space-y-6">
            <!-- Brand Logo -->
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/20">
                    <i class="fa-solid fa-shield-halved text-lg"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Admin Panel</h2>
                    <span class="text-[11px] text-amber-400 font-semibold uppercase tracking-wider">Control Center</span>
                </div>
            </div>

            <!-- Navigation Links -->
            <nav class="space-y-1.5 pt-4">
                <a href="/admin/dashboard.php?tab=users" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-users-gear w-4 text-center"></i>
                        <span>Kelola User & Role</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= $totalUsers ?></span>
                </a>

                <a href="/admin/dashboard.php?tab=news" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-newspaper w-4 text-center"></i>
                        <span>Kelola Berita / News</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= $totalNews ?></span>
                </a>

                <a href="/admin/dashboard.php?tab=templates" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-code w-4 text-center"></i>
                        <span>Manajemen Template</span>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold"><?= $totalTemplates ?></span>
                </a>

                <a href="/admin/ai_settings.php" 
                   class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border bg-brand-600/20 text-brand-300 border-brand-500/40 font-semibold text-xs transition-all text-left">
                    <i class="fa-solid fa-wand-magic-sparkles w-4 text-center text-amber-400"></i>
                    <span>Pengaturan AI API</span>
                </a>
            </nav>

            <!-- Tombol Kembali ke Dashboard User -->
            <div class="pt-6 border-t border-slate-800/80">
                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">Navigasi Utama</span>
                <a href="/user/dashboard.php" 
                   class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white text-xs font-semibold transition-all">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-arrow-left text-brand-400"></i>
                        <span>Dashboard User</span>
                    </div>
                </a>
            </div>
        </div>

        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <button type="button" 
                    @click="customConfirm({
                        title: 'Konfirmasi Keluar',
                        message: 'Apakah Anda yakin ingin keluar dari Admin Panel?',
                        variant: 'warning',
                        icon: 'fa-arrow-right-from-bracket',
                        confirmText: 'Ya, Keluar',
                        onConfirm: () => window.location.href = '/auth/logout.php'
                    })"
                    class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </button>
        </div>
    </aside>

    <!-- Main Workspace -->
    <div class="flex-1 flex flex-col min-w-0">
        
        <!-- Topbar -->
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-300 text-[10px] font-bold uppercase border border-amber-500/20">ADMINISTRATOR</span>
                    <h1 class="font-bold text-base text-white leading-none">Pengaturan AI API Key</h1>
                </div>
            </div>

            <a href="/user/dashboard.php" class="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-2 transition-all">
                <i class="fa-solid fa-house text-brand-400"></i>
                <span class="hidden sm:inline">Dashboard User</span>
            </a>
        </header>

        <main class="flex-1 p-4 lg:p-8 max-w-4xl w-full mx-auto space-y-8">
            
            <div class="border-b border-slate-800 pb-4">
                <h2 class="text-xl font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-brain text-brand-400"></i> Integrasi AI API Key (Pusat Kendali Admin)
                </h2>
                <p class="text-xs text-slate-400 mt-1">Konfigurasi API Key di sini agar seluruh pengguna dapat menggunakan fitur AI Title, Description, Artikel & FAQ Generator di Builder tanpa perlu memasukkan API key sendiri.</p>
            </div>

            <!-- Settings Form Card -->
            <div class="glass-card p-8 rounded-3xl border border-slate-800 shadow-2xl space-y-6">
                <form action="/admin/ai_settings.php" method="POST" enctype="multipart/form-data" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                    <!-- Provider & Model Selection -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Penyedia AI (AI Provider)</label>
                            <select name="ai_provider" class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                                <option value="gemini" <?= $aiProvider === 'gemini' ? 'selected' : '' ?>>Google Gemini API (Direkomendasikan)</option>
                                <option value="openai" <?= $aiProvider === 'openai' ? 'selected' : '' ?>>OpenAI API (ChatGPT)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Model AI Aktif</label>
                            <input type="text" name="ai_model" value="<?= e($aiModel) ?>"
                                   placeholder="gemini-3-flash-preview"
                                   class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm font-mono focus:outline-none focus:border-brand-500">
                        </div>
                    </div>

                    <!-- Pemisahan API Key AI: Builder vs Cloaking -->
                    <div class="p-5 rounded-2xl bg-slate-900/80 border border-brand-500/30 space-y-4">
                        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
                            <div>
                                <h3 class="text-sm font-bold text-white flex items-center gap-2">
                                    <i class="fa-solid fa-code-fork text-brand-400"></i> Pemisahan Kunci API AI (Anti Limit Quota)
                                </h3>
                                <p class="text-[11px] text-slate-400 mt-0.5">Memisahkan API key untuk Builder dan Cloaking agar penggunaan kuota tidak saling mengganggu atau terkena limit rate.</p>
                            </div>
                            <span class="px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                                <i class="fa-solid fa-check"></i> Dual Key Active
                            </span>
                        </div>

                        <!-- 1. Builder API Key -->
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-wider text-indigo-300 mb-1.5 flex items-center gap-2">
                                <i class="fa-solid fa-wand-magic-sparkles text-indigo-400"></i> 1. Kunci API AI Khusus Builder (LP & Content Generator)
                            </label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                                    <i class="fa-solid fa-file-pen text-sm"></i>
                                </span>
                                <input type="password" name="ai_api_key_builder" value="<?= e($aiApiKeyBuilder ?: $aiApiKey) ?>"
                                       placeholder="Kunci API Gemini khusus pembuatan Landing Page & artikel..."
                                       class="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-100 font-mono text-sm focus:outline-none focus:border-indigo-500">
                            </div>
                            <p class="text-[10px] text-slate-500 mt-1">Digunakan untuk auto-generate Judul SEO, Meta Deskripsi, Artikel, dan Testimoni di Visual Builder.</p>
                        </div>

                        <!-- 2. Cloaking API Key -->
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-wider text-amber-300 mb-1.5 flex items-center gap-2">
                                <i class="fa-solid fa-user-secret text-amber-400"></i> 2. Kunci API AI Khusus Cloaking & SEO (Tunnel, Googlebot & Keyword)
                            </label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500">
                                    <i class="fa-solid fa-shield-halved text-sm"></i>
                                </span>
                                <input type="password" name="ai_api_key_cloaking" value="<?= e($aiApiKeyCloak ?: $aiApiKey) ?>"
                                       placeholder="Kunci API Gemini khusus cloaking & riset kata kunci..."
                                       class="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-100 font-mono text-sm focus:outline-none focus:border-amber-500">
                            </div>
                            <p class="text-[10px] text-slate-500 mt-1">Digunakan untuk ekstraksi bypass Googlebot, analisis LP target cloaking, dan pengelompokan riset kata kunci VIP.</p>
                        </div>

                        <!-- Master Fallback Key -->
                        <div class="pt-2 border-t border-slate-800/80">
                            <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
                                <i class="fa-solid fa-key text-slate-500"></i> Kunci API Cadangan Master (Fallback)
                            </label>
                            <input type="password" name="ai_api_key" value="<?= e($aiApiKey) ?>"
                                   placeholder="Kunci API fallback jika field spesifik di atas kosong"
                                   class="w-full px-3.5 py-2 bg-slate-950/70 border border-slate-800 rounded-lg text-slate-300 font-mono text-xs focus:outline-none focus:border-slate-600">
                        </div>
                    </div>

                    <!-- Base Domain -->
                    <div>
                        <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Domain Publik Default</label>
                        <input type="text" name="site_domain" value="<?= e($siteDomain) ?>"
                               placeholder="http://localhost:8000"
                               class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                        <p class="text-[11px] text-slate-500 mt-1.5">Digunakan untuk menghasilkan URL Canonical & AMP default saat penerbitan project 1-klik.</p>
                    </div>

                    <!-- Pengaturan Pembayaran: Rekening & QRIS -->
                    <div class="pt-6 border-t border-slate-800 space-y-4">
                        <h3 class="text-sm font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-qrcode text-emerald-400 text-base"></i> Pengaturan Pembayaran (QRIS & Transfer Bank)
                        </h3>
                        <p class="text-[11px] text-slate-400 leading-relaxed">
                            Informasi rekening dan kode QRIS ini akan ditampilkan kepada pengguna di halaman penagihan saat masa trial berakhir atau saat upgrade paket.
                        </p>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Nama Bank / E-Wallet</label>
                                <input type="text" name="bank_name" value="<?= e($bankName) ?>" placeholder="BCA / Mandiri / Dana"
                                       class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Nomor Rekening</label>
                                <input type="text" name="bank_account_number" value="<?= e($bankAccNumber) ?>" placeholder="8735091234"
                                       class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 font-mono text-sm focus:outline-none focus:border-brand-500">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Atas Nama Rekening</label>
                                <input type="text" name="bank_account_name" value="<?= e($bankAccName) ?>" placeholder="FLASH OFFICIAL"
                                       class="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-brand-500">
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Upload Gambar QRIS Kustom (JPG / PNG / WEBP)</label>
                            <div class="flex items-center gap-4">
                                <?php if (!empty($qrisImagePath) && file_exists(__DIR__ . '/..' . $qrisImagePath)): ?>
                                    <div class="w-16 h-16 rounded-xl bg-white p-1 border border-slate-700 flex-shrink-0">
                                        <img src="<?= e($qrisImagePath) ?>" alt="QRIS" class="w-full h-full object-contain rounded-lg">
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="qris_image" accept="image/*"
                                       class="w-full text-xs text-slate-400 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-brand-300 hover:file:bg-slate-700 cursor-pointer">
                            </div>
                            <p class="text-[10px] text-slate-500 mt-1">Jika gambar QRIS diunggah, halaman billing user akan menampilkan QR code resmi Anda. Jika kosong, sistem membuat QRIS dinamis otomatis.</p>
                        </div>
                    </div>

                    <!-- Integrasi Telegram OTP -->
                    <div class="pt-6 border-t border-slate-800 space-y-4">
                        <h3 class="text-sm font-bold text-white flex items-center gap-2">
                            <i class="fa-brands fa-telegram text-sky-400 text-base"></i> Konfigurasi Bot Telegram (Verifikasi OTP Pendaftaran)
                        </h3>
                        <p class="text-[11px] text-slate-400 leading-relaxed">
                            Hubungkan Bot Telegram untuk memvalidasi nomor/identitas pengguna saat registrasi, mencegah bot spam, dan mengirimkan kode OTP secara otomatis.
                        </p>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Username Bot Telegram</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-sky-400 font-bold">@</span>
                                    <input type="text" name="telegram_bot_username" value="<?= e($tgUsername) ?>"
                                           placeholder="FlashOfficialBot"
                                           class="w-full pl-9 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 font-mono text-sm focus:outline-none focus:border-brand-500">
                                </div>
                                <p class="text-[10px] text-slate-500 mt-1">Username bot tanpa tanda @ (dibuat via @BotFather).</p>
                            </div>

                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Bot API Token Telegram</label>
                                <input type="password" name="telegram_bot_token" value="<?= e($tgToken) ?>"
                                       placeholder="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ..."
                                       class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 font-mono text-sm focus:outline-none focus:border-brand-500">
                                <p class="text-[10px] text-slate-500 mt-1">Token resmi dari @BotFather untuk mengirim pesan balasan.</p>
                            </div>
                        </div>

                        <div class="pt-2">
                            <label class="flex items-center gap-2.5 cursor-pointer">
                                <input type="checkbox" name="telegram_otp_enabled" value="1" <?= $tgEnabled === '1' ? 'checked' : '' ?> class="rounded border-slate-700 text-brand-500 focus:ring-brand-500/30">
                                <span class="text-xs font-semibold text-slate-200">Wajibkan Verifikasi OTP Telegram untuk Setiap Pendaftaran Akun Baru</span>
                            </label>
                        </div>
                    </div>
                                    <input type="text" name="telegram_bot_username" value="<?= e($tgUsername) ?>"
                                           placeholder="FlashOfficialBot"
                                           class="w-full pl-9 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 font-mono text-sm focus:outline-none focus:border-brand-500">
                                </div>
                                <p class="text-[10px] text-slate-500 mt-1">Username bot tanpa tanda @ (dibuat via @BotFather).</p>
                            </div>

                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Bot API Token Telegram</label>
                                <input type="password" name="telegram_bot_token" value="<?= e($tgToken) ?>"
                                       placeholder="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ..."
                                       class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 font-mono text-sm focus:outline-none focus:border-brand-500">
                                <p class="text-[10px] text-slate-500 mt-1">Token resmi dari @BotFather untuk mengirim pesan balasan.</p>
                            </div>
                        </div>

                        <div class="pt-2">
                            <label class="flex items-center gap-2.5 cursor-pointer">
                                <input type="checkbox" name="telegram_otp_enabled" value="1" <?= $tgEnabled === '1' ? 'checked' : '' ?> class="rounded border-slate-700 text-brand-500 focus:ring-brand-500/30">
                                <span class="text-xs font-semibold text-slate-200">Wajibkan Verifikasi OTP Telegram untuk Setiap Pendaftaran Akun Baru</span>
                            </label>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" 
                            class="px-6 py-3.5 bg-brand-600 hover:bg-brand-500 text-white font-semibold rounded-xl text-sm shadow-lg shadow-brand-500/25 flex items-center gap-2 transition-all cursor-pointer">
                        <i class="fa-solid fa-floppy-disk"></i>
                        <span>Simpan Seluruh Pengaturan</span>
                    </button>
                </form>
            </div>

        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
