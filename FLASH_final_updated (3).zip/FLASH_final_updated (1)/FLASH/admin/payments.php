<?php
// admin/payments.php - Admin Payment Approval & User Subscription Manager
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$currentUser = current_user();

// 1. Handle Approve / Reject Payment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($token)) {
        $action = $_POST['action'] ?? '';
        
        // APPROVE PAYMENT
        if ($action === 'approve_payment') {
            $paymentId = intval($_POST['payment_id'] ?? 0);
            $stmtP = $pdo->prepare("SELECT * FROM payments WHERE id = ?");
            $stmtP->execute([$paymentId]);
            $payment = $stmtP->fetch();

            if ($payment && $payment['status'] === 'pending') {
                $targetRole = 'user';
                $expiryInterval = '+7 days';

                if ($payment['plan_name'] === 'vip') {
                    $targetRole = 'vip';
                    $expiryInterval = '+30 days';
                } elseif ($payment['plan_name'] === 'vpro') {
                    $targetRole = 'vpro';
                    $expiryInterval = '+30 days';
                } elseif ($payment['plan_name'] === 'trial7') {
                    $targetRole = 'trial7';
                    $expiryInterval = '+7 days';
                } elseif ($payment['plan_name'] === 'lite') {
                    $targetRole = 'lite';
                    $expiryInterval = '+14 days';
                } elseif ($payment['plan_name'] === 'elite') {
                    $targetRole = 'elite';
                    $expiryInterval = '+30 days';
                } elseif ($payment['plan_name'] === 'premium') {
                    $targetRole = 'premium';
                    $expiryInterval = '+30 days';
                } elseif ($payment['plan_name'] === 'diamond') {
                    $targetRole = 'diamond';
                    $expiryInterval = '+30 days';
                }

                // Update Role & Trial Expiry User
                $stmtU = $pdo->prepare("UPDATE users SET role = ?, trial_expires_at = datetime('now', '{$expiryInterval}') WHERE id = ?");
                $stmtU->execute([$targetRole, $payment['user_id']]);

                // Update Status Pembayaran
                $stmtPayUpd = $pdo->prepare("UPDATE payments SET status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                $stmtPayUpd->execute([$paymentId]);

                set_flash('success', "Pembayaran Invoice {$payment['invoice_id']} berhasil disetujui! Akun pengguna telah di-upgrade ke {$targetRole}.");
            }
        }

        // REJECT PAYMENT
        if ($action === 'reject_payment') {
            $paymentId = intval($_POST['payment_id'] ?? 0);
            $stmtPayUpd = $pdo->prepare("UPDATE payments SET status = 'rejected', updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmtPayUpd->execute([$paymentId]);
            set_flash('warning', "Pembayaran berhasil ditolak.");
        }

        // MANUAL ROLE CHANGE FOR USER
        if ($action === 'manual_role_change') {
            $targetUserId = intval($_POST['user_id'] ?? 0);
            $newRole = trim($_POST['new_role'] ?? 'user');
            $newDays = intval($_POST['duration_days'] ?? 30);

            if ($targetUserId > 0) {
                $stmtU = $pdo->prepare("UPDATE users SET role = ?, trial_expires_at = datetime('now', '+{$newDays} days') WHERE id = ?");
                $stmtU->execute([$newRole, $targetUserId]);
                set_flash('success', "Hak akses / Role pengguna berhasil diperbarui ke {$newRole} ({$newDays} hari).");
            }
        }
    }
    header('Location: /admin/payments.php');
    exit;
}

// Ambil Daftar Pembayaran
$stmtPayments = $pdo->query("SELECT p.*, u.name as user_name, u.email as user_email FROM payments p JOIN users u ON p.user_id = u.id ORDER BY p.id DESC");
$payments = $stmtPayments->fetchAll();

// Ambil Seluruh Daftar Pengguna untuk Pengaturan Manual
$stmtUsers = $pdo->query("SELECT id, name, email, role, trial_expires_at, created_at FROM users ORDER BY id DESC");
$allUsers = $stmtUsers->fetchAll();

$pageTitle = 'Manajemen Pembayaran & Role User - Admin FLASH';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen bg-slate-950 flex" x-data="{ sidebarOpen: false, previewProofModal: null }">
    
    <!-- Admin Sidebar -->
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/95 border-r border-slate-800 backdrop-blur-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:w-64 flex flex-col justify-between"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        <div class="p-6 space-y-6">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/20">
                    <i class="fa-solid fa-shield-halved text-lg"></i>
                </div>
                <div>
                    <h2 class="font-bold text-slate-100 text-base leading-tight">Admin Panel</h2>
                    <span class="text-[11px] text-amber-400 font-semibold uppercase tracking-wider">Control Center</span>
                </div>
            </div>

            <nav class="space-y-1.5 pt-4">
                <a href="/admin/dashboard.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-gauge w-4 text-center"></i>
                    <span>Ringkasan Sistem</span>
                </a>
                <a href="/admin/payments.php" class="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-xs transition-all text-left">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-money-bill-transfer w-4 text-center text-amber-400"></i>
                        <span>Pembayaran & Role</span>
                    </div>
                    <span class="px-1.5 py-0.5 rounded-full bg-amber-500/30 text-amber-200 text-[9px] font-black"><?= count($payments) ?></span>
                </a>
                <a href="/admin/ai_settings.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-brain w-4 text-center text-brand-400"></i>
                    <span>Pengaturan AI & Bot</span>
                </a>
                <a href="/user/dashboard.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-transparent text-slate-400 hover:text-white hover:bg-slate-800/60 text-xs transition-all text-left">
                    <i class="fa-solid fa-house w-4 text-center"></i>
                    <span>Portal Pengguna</span>
                </a>
            </nav>
        </div>

        <div class="p-4 border-t border-slate-800 bg-slate-900/40">
            <a href="/auth/logout.php" class="w-full px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar dari Akun</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col min-w-0">
        <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-lg sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-black uppercase border border-amber-500/30">ADMINISTRATOR</span>
                    <h1 class="font-bold text-base text-white leading-none">Verifikasi Pembayaran & Role Pengguna</h1>
                </div>
            </div>
        </header>

        <main class="flex-1 p-4 lg:p-8 max-w-6xl w-full mx-auto space-y-8">
            
            <!-- Antrean Pembayaran Masuk -->
            <div class="space-y-4">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fa-solid fa-qrcode text-amber-400"></i> Antrean Pembayaran QRIS / Transfer Bank
                        </h2>
                        <p class="text-xs text-slate-400 mt-0.5">Tinjau bukti transfer member dan setujui untuk mengaktifkan paket secara instan.</p>
                    </div>
                </div>

                <div class="overflow-x-auto rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
                    <table class="w-full text-left text-xs text-slate-300">
                        <thead class="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                            <tr>
                                <th class="p-4">Invoice</th>
                                <th class="p-4">User</th>
                                <th class="p-4">Paket</th>
                                <th class="p-4">Nominal</th>
                                <th class="p-4">Bukti TF</th>
                                <th class="p-4">Status</th>
                                <th class="p-4 text-center">Aksi Admin</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-800/80">
                            <?php if (empty($payments)): ?>
                                <tr>
                                    <td colspan="7" class="p-8 text-center text-slate-500">Belum ada pengajuan pembayaran masuk.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($payments as $p): ?>
                                    <tr class="hover:bg-slate-800/30 transition-colors">
                                        <td class="p-4 font-mono font-bold text-white"><?= e($p['invoice_id']) ?></td>
                                        <td class="p-4">
                                            <div class="font-bold text-white"><?= e($p['user_name']) ?></div>
                                            <div class="text-[11px] text-slate-500"><?= e($p['user_email']) ?></div>
                                            <?php if (!empty($p['telegram_username'])): ?>
                                                <div class="text-[10px] text-sky-400"><i class="fa-brands fa-telegram"></i> <?= e($p['telegram_username']) ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-4">
                                            <span class="px-2.5 py-1 rounded-full font-bold text-[10px] uppercase
                                                <?= $p['plan_name'] === 'vpro' ? 'bg-purple-500/20 text-purple-300' : ($p['plan_name'] === 'vip' ? 'bg-amber-500/20 text-amber-300' : 'bg-brand-500/20 text-brand-300') ?>">
                                                <?= e($p['plan_name']) ?>
                                            </span>
                                        </td>
                                        <td class="p-4 font-mono font-bold text-amber-300">
                                            Rp <?= number_format($p['total_amount'], 0, ',', '.') ?>
                                        </td>
                                        <td class="p-4">
                                            <?php if (!empty($p['proof_image'])): ?>
                                                <button type="button" @click="previewProofModal = '/uploads/proofs/<?= e($p['proof_image']) ?>'"
                                                        class="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 text-[11px] font-semibold flex items-center gap-1.5 cursor-pointer">
                                                    <i class="fa-regular fa-image"></i> Lihat Bukti
                                                </button>
                                            <?php else: ?>
                                                <span class="text-[10px] text-slate-500">Kirim via Telegram</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-4">
                                            <?php if ($p['status'] === 'approved'): ?>
                                                <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">Approved</span>
                                            <?php elseif ($p['status'] === 'rejected'): ?>
                                                <span class="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold text-[10px]">Rejected</span>
                                            <?php else: ?>
                                                <span class="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold text-[10px]">Pending</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-4 text-center">
                                            <?php if ($p['status'] === 'pending'): ?>
                                                <div class="flex items-center justify-center gap-2">
                                                    <form action="/admin/payments.php" method="POST" onsubmit="return confirm('Setujui pembayaran ini dan upgrade akun user?')">
                                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                        <input type="hidden" name="action" value="approve_payment">
                                                        <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                                                        <button type="submit" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1">
                                                            <i class="fa-solid fa-check"></i> Setujui
                                                        </button>
                                                    </form>
                                                    <form action="/admin/payments.php" method="POST" onsubmit="return confirm('Tolak pengajuan pembayaran ini?')">
                                                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                        <input type="hidden" name="action" value="reject_payment">
                                                        <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                                                        <button type="submit" class="px-2.5 py-1.5 rounded-lg bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 font-bold text-[11px]">
                                                            Tolak
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-slate-600 text-[11px]">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Manajemen Role & Hak Akses Pengguna Manual -->
            <div class="space-y-4 pt-6 border-t border-slate-800">
                <div>
                    <h2 class="text-xl font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-user-gear text-indigo-400"></i> Atur Hak Akses & Role Pengguna Manual
                    </h2>
                    <p class="text-xs text-slate-400 mt-0.5">Admin dapat menetapkan user menjadi VIP, VPro Sultan, atau Paket 7 Hari secara instan tanpa menunggu pembayaran.</p>
                </div>

                <div class="overflow-x-auto rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
                    <table class="w-full text-left text-xs text-slate-300">
                        <thead class="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                            <tr>
                                <th class="p-4">User</th>
                                <th class="p-4">Role Saat Ini</th>
                                <th class="p-4">Masa Berlaku</th>
                                <th class="p-4">Ubah Paket / Role</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-800/80">
                            <?php foreach ($allUsers as $u): ?>
                                <tr class="hover:bg-slate-800/30 transition-colors">
                                    <td class="p-4">
                                        <div class="font-bold text-white"><?= e($u['name']) ?></div>
                                        <div class="text-[11px] text-slate-500"><?= e($u['email']) ?></div>
                                    </td>
                                    <td class="p-4 font-mono font-bold">
                                        <span class="px-2.5 py-1 rounded-full text-[10px] uppercase
                                            <?= $u['role'] === 'admin' ? 'bg-amber-500/20 text-amber-300' : ($u['role'] === 'vpro' ? 'bg-purple-500/20 text-purple-300' : ($u['role'] === 'vip' ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-300')) ?>">
                                            <?= e($u['role']) ?>
                                        </span>
                                    </td>
                                    <td class="p-4 text-slate-400 font-mono text-[11px]">
                                        <?= !empty($u['trial_expires_at']) ? date('d M Y H:i', strtotime($u['trial_expires_at'])) : 'Permanen' ?>
                                    </td>
                                    <td class="p-4">
                                        <form action="/admin/payments.php" method="POST" class="flex items-center gap-2">
                                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                            <input type="hidden" name="action" value="manual_role_change">
                                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">

                                            <select name="new_role" class="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 text-xs focus:outline-none">
                                                <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>Free Trial 1 Hari</option>
                                                <option value="trial7" <?= $u['role'] === 'trial7' ? 'selected' : '' ?>>Paket 7 Hari (Rp 150k)</option>
                                                <option value="lite" <?= $u['role'] === 'lite' ? 'selected' : '' ?>>Paket Lite (Rp 350k)</option>
                                                <option value="elite" <?= $u['role'] === 'elite' ? 'selected' : '' ?>>Paket Elite (Rp 550k)</option>
                                                <option value="premium" <?= $u['role'] === 'premium' ? 'selected' : '' ?>>Paket Premium (Rp 1 Juta)</option>
                                                <option value="diamond" <?= $u['role'] === 'diamond' ? 'selected' : '' ?>>Paket Diamond (Rp 2 Juta)</option>
                                                <option value="vip" <?= $u['role'] === 'vip' ? 'selected' : '' ?>>VIP Ultra-Rank (Rp 4 Juta)</option>
                                                <option value="vpro" <?= $u['role'] === 'vpro' ? 'selected' : '' ?>>VPro Sultan (Rp 6 Juta)</option>
                                                <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>Administrator</option>
                                            </select>

                                            <select name="duration_days" class="px-2 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 text-xs focus:outline-none">
                                                <option value="7">7 Hari</option>
                                                <option value="30" selected>30 Hari</option>
                                                <option value="90">90 Hari</option>
                                                <option value="365">1 Tahun</option>
                                            </select>

                                            <button type="submit" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-[11px] transition-all">
                                                Simpan
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <!-- Modal Pratinjau Bukti Transfer -->
    <div x-show="previewProofModal" x-cloak 
         class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
        <div @click.away="previewProofModal = null" class="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div class="flex items-center justify-between">
                <h3 class="font-bold text-white text-sm">Bukti Transfer Pembayaran</h3>
                <button type="button" @click="previewProofModal = null" class="text-slate-400 hover:text-white">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>
            <div class="max-h-[70vh] overflow-auto rounded-2xl bg-black p-2 flex items-center justify-center">
                <img :src="previewProofModal" alt="Bukti Transfer" class="max-w-full max-h-full object-contain">
            </div>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
