<?php
$apiKey = 'AQ.Ab8RN6KDWl3EhpTcE886o0pu-W2EXseQBQ2j3SQ-dCPY5bdEUw';
$model = 'gemini-3.8-flash';
$url = "https://generativelanguage.googleapis.com/v1beta/models/" . $model . ":generateContent?key=" . $apiKey;

$prompt = "Kamu adalah pakar SEO & Copywriter profesional.
Berdasarkan landing page ini, buatkan:
1. Nama brand yang bagus dan menarik.
2. Judul SEO (Title) 50-65 karakter, clickable dan memikat.
3. Meta Description 130-160 karakter memikat dan ramah Google.
4. Rekomendasi gambar (deskripsi banner dan deskripsi logo).
5. 3 FAQ pertanyaan & jawaban unik.

Output WAJIB JSON persis:
{
  \"brand_name\": \"...\",
  \"title\": \"...\",
  \"meta_description\": \"...\",
  \"banner_title\": \"...\",
  \"logo_title\": \"...\",
  \"faqs\": [{\"question\": \"...\", \"answer\": \"...\"}]
}";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'contents' => [['parts' => [['text' => $prompt]]]],
    'generationConfig' => ['responseMimeType' => 'application/json']
]));
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP CODE: $code\n";
echo "RESPONSE:\n$res\n";
