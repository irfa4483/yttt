#!/usr/bin/env bash
# ==============================================================================
# FLASH PLATFORM - AAPanel Automated Setup & Domain Configurator
# ==============================================================================
# Skrip ini mengonfigurasi website FLASH di AAPanel:
# 1. Mengatur hak akses & izin folder www:www (SQLite writeable)
# 2. Mengaktifkan Nginx URL Rewrite & proteksi berkas database.sqlite
# 3. Memeriksa modul PHP AAPanel (pdo_sqlite, curl, zip, mbstring)
# 4. Pengaturan domain & verifikasi sistem
# ==============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

clear
echo -e "${CYAN}${BOLD}"
echo "========================================================================"
echo "          ⚡ FLASH PLATFORM - AAPANEL AUTOMATED SETUP ⚡                "
echo "========================================================================"
echo -e "${NC}"

# Cek apakah dijalankan sebagai root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Skrip ini harus dijalankan dengan hak akses root (sudo)!${NC}"
    exit 1
fi

echo -e "${YELLOW}Direktori Target FLASH:${NC} ${BOLD}$SCRIPT_DIR${NC}"
echo ""

# 1. PENGATURAN PERMISSIONS & OWNERSHIP (AAPANEL www:www)
echo -e "${CYAN}>>> [1/4] Mengatur Izin Berkas & Direktori AAPanel...${NC}"

# Buat folder esensial jika belum ada
mkdir -p "$SCRIPT_DIR/cdn/templates" "$SCRIPT_DIR/uploads" "$SCRIPT_DIR/exports" "$SCRIPT_DIR/config"

# Ubah kepemilikan ke user web server AAPanel (www:www)
if id "www" >/dev/null 2>&1; then
    chown -R www:www "$SCRIPT_DIR"
    echo -e "  [${GREEN}OK${NC}] Kepemilikan diatur ke ${BOLD}www:www${NC}"
else
    chown -R www-data:www-data "$SCRIPT_DIR" 2>/dev/null || true
    echo -e "  [${YELLOW}WARN${NC}] User 'www' tidak ditemukan, menggunakan www-data"
fi

# Izin folder tulis
chmod -R 775 "$SCRIPT_DIR/cdn" "$SCRIPT_DIR/uploads" "$SCRIPT_DIR/exports"
chmod 775 "$SCRIPT_DIR"

# Izin berkas database SQLite
if [ -f "$SCRIPT_DIR/database.sqlite" ]; then
    chmod 664 "$SCRIPT_DIR/database.sqlite"
    echo -e "  [${GREEN}OK${NC}] File database.sqlite diberi izin baca & tulis (664)"
else
    touch "$SCRIPT_DIR/database.sqlite"
    chown www:www "$SCRIPT_DIR/database.sqlite" 2>/dev/null || true
    chmod 664 "$SCRIPT_DIR/database.sqlite"
    echo -e "  [${GREEN}OK${NC}] Berkas database.sqlite baru diinisialisasi (664)"
fi

echo ""

# 2. GENERATE ATURAN NGINX REWRITE & KEAMANAN AAPANEL
echo -e "${CYAN}>>> [2/4] Menghasilkan Konfigurasi Nginx AAPanel...${NC}"

NGINX_CONF_DIR="/www/server/panel/vhost/rewrite"
CUSTOM_CONF_FILE="$SCRIPT_DIR/nginx_flash.conf"

cat << 'EOF' > "$CUSTOM_CONF_FILE"
# ==============================================================================
# FLASH PLATFORM - AAPanel Nginx URL Rewrite & Security Rules
# Tempelkan kode ini di: AAPanel > Website > Pilih Domain > URL rewrite
# ==============================================================================

# 1. Routing Bersih Short-URL Landing Page: /s/slug -> /p.php?s=slug
location ~* ^/s/([a-zA-Z0-9_\-]+)/?$ {
    rewrite ^/s/([a-zA-Z0-9_\-]+)/?$ /p.php?s=$1 last;
}

# 2. Routing Statis & Fallback Index
location / {
    try_files $uri $uri/ /index.php?$query_string;
}

# 3. Direct execution file php tanpa ekstensi
location /p {
    try_files $uri $uri.php /p.php?$query_string;
}

# 4. KEAMANAN TINGKAT TINGGI: Blokir Akses Download Langsung Berkas Database & Kode Sensitif
location ~* \.(sqlite|sqlite3|db|env|log|sh|sql|bak|git)$ {
    deny all;
    return 404;
}

# 5. Blokir Akses Direktori Internal Privat
location ~* ^/(config|tunnel_templates|scratch)/ {
    deny all;
    return 404;
}

# 6. Izinkan Akses File SEO Resmi
location = /robots.txt {
    allow all;
    log_not_found off;
    access_log off;
}

location = /sitemap.xml {
    allow all;
    log_not_found off;
    access_log off;
}
EOF

echo -e "  [${GREEN}OK${NC}] Berkas aturan Nginx dibuat di: ${BOLD}$CUSTOM_CONF_FILE${NC}"

# Jika folder rewrite AAPanel ada, simpan template rewrite global
if [ -d "$NGINX_CONF_DIR" ]; then
    cp "$CUSTOM_CONF_FILE" "$NGINX_CONF_DIR/flash.conf"
    echo -e "  [${GREEN}OK${NC}] Template Rewrite terpasang di AAPanel: ${BOLD}flash.conf${NC}"
fi

echo ""

# 3. DETEKSI & KONFIGURASI DOMAIN AAPANEL
echo -e "${CYAN}>>> [3/4] Konfigurasi Domain Website di AAPanel...${NC}"
echo -e "Apakah Anda ingin menghubungkan domain situs sekarang? (y/n)"
read -r -p "Pilihan Anda: " CONF_DOMAIN

if [[ "$CONF_DOMAIN" =~ ^[Yy]$ ]]; then
    read -r -p "Masukkan nama domain (contoh: promo-resmi.com): " USER_DOMAIN
    USER_DOMAIN=$(echo "$USER_DOMAIN" | tr -d ' ' | tr '[:upper:]' '[:lower:]')
    
    if [ -n "$USER_DOMAIN" ]; then
        echo -e "  Menyiapkan vhost untuk domain: ${BOLD}$USER_DOMAIN${NC}"
        
        # Cek vhost Nginx AAPanel
        AAPANEL_VHOST="/www/server/panel/vhost/nginx/${USER_DOMAIN}.conf"
        if [ -f "$AAPANEL_VHOST" ]; then
            echo -e "  [${GREEN}OK${NC}] Vhost domain ditemukan di AAPanel ($AAPANEL_VHOST)"
            
            # Cek apakah rewrite rule sudah dimasukkan
            if ! grep -q "location ~\* ^/s/" "$AAPANEL_VHOST"; then
                # Sisipkan sebelum penutup server block
                sed -i "/#REWRITE-END/r $CUSTOM_CONF_FILE" "$AAPANEL_VHOST" 2>/dev/null || true
                echo -e "  [${GREEN}OK${NC}] Aturan rewrite berhasil disisipkan ke vhost domain."
                # Reload Nginx
                nginx -t >/dev/null 2>&1 && nginx -s reload 2>/dev/null || true
            fi
        else
            echo -e "  ${YELLOW}Catatan:${NC} Buat website terlebih dahulu di panel AAPanel GUI:"
            echo -e "    1. Buka AAPanel > Menu 'Website' > 'Add site'"
            echo -e "    2. Domain: ${BOLD}$USER_DOMAIN${NC}"
            echo -e "    3. Root Directory: ${BOLD}$SCRIPT_DIR${NC}"
            echo -e "    4. PHP Version: ${BOLD}PHP-8.1 / PHP-8.2 / PHP-8.3${NC}"
            echo -e "    5. Buka tab 'URL rewrite' dan tempelkan isi berkas: ${BOLD}$CUSTOM_CONF_FILE${NC}"
        fi
    fi
fi

echo ""

# 4. JALANKAN DIAGNOSTIK KESEHATAN SISTEM
echo -e "${CYAN}>>> [4/4] Memeriksa Integritas Sistem & Modul PHP...${NC}"
if [ -f "$SCRIPT_DIR/check_system.sh" ]; then
    chmod +x "$SCRIPT_DIR/check_system.sh"
    bash "$SCRIPT_DIR/check_system.sh"
else
    echo -e "  ${GREEN}Konfigurasi AAPanel selesai!${NC}"
fi

echo ""
echo -e "${GREEN}${BOLD}========================================================================${NC}"
echo -e "${GREEN}${BOLD}    ✓ KONFIGURASI AAPANEL FLASH PLATFORM SELESAI DILAKUKAN!             ${NC}"
echo -e "${GREEN}${BOLD}========================================================================${NC}"
echo -e "Langkah Selanjutnya:"
echo -e "1. Pastikan domain sudah diarahkan (DNS A Record) ke IP VPS Anda."
echo -e "2. Di AAPanel, pasang SSL gratis via menu ${BOLD}Website > SSL > Let's Encrypt${NC}."
echo -e "3. Akses via browser: ${BOLD}http://domain-anda/check.php${NC} untuk melihat status hijau."
echo -e "4. Login Administrator: ${BOLD}admin@example.com${NC} / Password: ${BOLD}admin123${NC}"
echo -e "${CYAN}========================================================================${NC}"
