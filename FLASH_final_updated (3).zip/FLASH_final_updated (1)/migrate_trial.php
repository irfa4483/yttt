<?php
$db = new PDO('sqlite:FLASH/database.sqlite');
$cols = $db->query('PRAGMA table_info(users)')->fetchAll(PDO::FETCH_ASSOC);
$colNames = array_column($cols, 'name');

if (!in_array('trial_expires_at', $colNames)) {
    $db->exec("ALTER TABLE users ADD COLUMN trial_expires_at DATETIME DEFAULT NULL");
    echo "Added column trial_expires_at to users table!\n";
} else {
    echo "Column trial_expires_at already exists.\n";
}

// Update existing users if they have NULL to 1 day from created_at or lifetime if admin
$db->exec("UPDATE users SET trial_expires_at = datetime(created_at, '+1 day') WHERE trial_expires_at IS NULL AND role != 'admin'");
echo "Updated existing users trial dates!\n";
