<?php
$url = 'https://coastalwellnessofsavannah.com/direct-primary-care/';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
$raw = curl_exec($ch);
curl_close($ch);

// Cari semua tag yang punya src atau background yang mengandung kata gambar jackpot 88.888.888
preg_match_all('/<[^>]+(?:slot777gacor|\.png|\.jpg|\.webp)[^>]*>/i', $raw, $m);
foreach ($m[0] as $tag) {
    if (stripos($tag, 'Airbet88') !== false || stripos($tag, 'slot777') !== false || stripos($tag, 'jackpot') !== false || stripos($tag, '88') !== false) {
        echo "TAG: " . substr($tag, 0, 200) . "\n";
    }
}
